package edu.vanderbilt.isis.sm;

public interface IEventHolder {
	void addEvent(Event e);
}
