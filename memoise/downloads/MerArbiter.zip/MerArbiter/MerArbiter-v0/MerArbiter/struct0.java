package MerArbiter;

public class struct0 {
	public boolean signal1;
	public boolean signal2;
	public boolean signal3;
	public boolean signal4;
	public boolean signal5;
	public boolean signal6;
}