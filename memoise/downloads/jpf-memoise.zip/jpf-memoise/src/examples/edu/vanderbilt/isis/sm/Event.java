package edu.vanderbilt.isis.sm;

public class Event {
	
	private String s;
	
	public Event(String s) {
		this.s = s;
	}
	
	public String name(){
		return this.s;		
	}
}
