package coverage;
import org.junit.Test;

import MerArbiter.MyMerArbiterSym;
public class MyMerArbiterSymTest {
	MyMerArbiterSym o = new MyMerArbiterSym();
	@Test
	public void test0() {
		o.run2(771, true, 0, true, 2, 771, true, 2, true, 0, 0, false, 2, false, 4, 2, true, 2, false, 61, false, true, -1053, 1);
	}
	@Test
	public void test1() {
		o.run2(0, false, -563, false, 4526, 834, false, 834, false, 834, 0, false, 0, true, 834, 0, false, 834, false, 0, false, false, 0, 0);
	}
	@Test
	public void test2() {
		o.run2(0, false, 0, true, 1632, 1632, false, 1632, true, 1833, 0, false, 0, false, 1632, 834, true, -739, false, -739, true, false, 0, 99);
	}
	@Test
	public void test3() {
		o.run2(0, false, -563, false, 4526, 834, false, 834, true, 834, 0, false, 0, true, 834, 0, false, 834, true, 0, false, false, 0, 0);
	}
	@Test
	public void test4() {
		o.run2(834, false, 0, false, 834, 0, true, 0, false, 0, -1, true, 925, false, -563, 834, true, 179, false, 834, true, true, 0, 179);
	}
	@Test
	public void test5() {
		o.run2(0, false, -563, false, 4526, 834, false, 834, false, 834, 0, false, 0, true, 834, 0, false, 834, false, 0, false, false, 0, 0);
	}
	@Test
	public void test6() {
		o.run2(0, true, -1219, true, 1, 0, true, 1264, true, 0, 0, true, 0, true, 0, 143, false, -1219, false, 0, true, false, 0, 834);
	}
	@Test
	public void test7() {
		o.run2(0, true, -563, true, 4505, 834, true, 834, false, 834, 0, true, 0, true, 834, 0, true, 834, false, 0, true, true, 0, 0);
	}

}