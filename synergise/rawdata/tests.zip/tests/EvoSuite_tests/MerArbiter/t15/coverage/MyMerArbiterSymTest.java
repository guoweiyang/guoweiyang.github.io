package coverage;
import org.junit.Test;

import MerArbiter.MyMerArbiterSym;
public class MyMerArbiterSymTest {
	MyMerArbiterSym o = new MyMerArbiterSym();
	@Test
	public void test0() {
		o.run2(-991, false, 4, false, 0, 0, false, 0, true, 0, -991, false, 4, true, -195, 0, false, 0, false, 1939, false, false, -991, 1939);
	}
	@Test
	public void test1() {
		o.run2(-1402, false, 2, false, 0, -2599, false, 0, false, 0, 0, true, -1402, true, -2086, -2086, false, 1939, false, 0, false, false, 0, 0);
	}
	@Test
	public void test2() {
		o.run2(0, false, -991, true, 0, 0, true, -991, true, 0, 0, true, -991, true, -1945, 0, true, -3873, true, 0, true, false, -1492, 2822);
	}
	@Test
	public void test3() {
		o.run2(2, true, 2, true, 2, 2, false, 2, false, 2, 2, false, 2, true, 2, 2, true, 2, false, 2, false, true, 2, 164);
	}
	@Test
	public void test4() {
		o.run2(777, true, 0, true, 777, -781, true, 516, true, 0, 3113, false, 11, true, -781, 2466, false, 3113, true, 0, false, true, 594, 0);
	}
	@Test
	public void test5() {
		o.run2(2, true, 2, true, 2, 2, true, 2, true, 2, 2, false, 0, true, 0, 2, true, 0, true, 2, false, true, 0, 2);
	}
	@Test
	public void test6() {
		o.run2(3312, false, 2, true, 1, 31, false, 1, false, 3312, 1, true, -4161, true, 3312, 0, false, -845, true, 0, true, false, -4161, -845);
	}
	@Test
	public void test7() {
		o.run2(0, true, 32, true, 777, 32, true, 2, true, 112, 0, false, 0, true, -946, 0, true, 2, false, 0, true, false, -946, -1);
	}
	@Test
	public void test8() {
		o.run2(2, false, 2, true, 2, 2, true, 2, false, 2, 0, false, 0, true, 0, 2, true, 0, false, 2, false, true, 0, 164);
	}

}