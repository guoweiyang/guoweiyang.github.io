package coverage;
import org.junit.Test;

import MerArbiter.MyMerArbiterSym;
public class MyMerArbiterSymTest {
	MyMerArbiterSym o = new MyMerArbiterSym();
	@Test
	public void test0() {
		o.run2(0, true, 0, false, -4665, 2433, true, 0, true, 0, -680, false, -4665, true, -1, 0, false, 1506, true, 0, true, false, 2063, 2433);
	}
	@Test
	public void test1() {
		o.run2(-4665, true, -1, false, 0, 1891, false, 803, true, 1, -4665, true, 1506, false, 2, -1, true, -2650, false, -2650, false, false, 2, 11);
	}
	@Test
	public void test2() {
		o.run2(1891, true, -4665, true, 1, -4665, true, 1, true, 1, 1, true, -680, true, 0, 0, true, -1, true, -4665, true, true, 2, 1);
	}
	@Test
	public void test3() {
		o.run2(0, false, 2433, false, 0, 35, false, 1521, false, 0, 2433, true, 1241, false, 80, 0, false, 425, false, 0, true, true, 3277, 1095);
	}
	@Test
	public void test4() {
		o.run2(0, true, 0, false, -4665, 2433, true, 0, true, 0, -680, false, -4665, true, -1, 0, false, 1506, true, 0, true, false, 2063, 2433);
	}
	@Test
	public void test5() {
		o.run2(1891, true, -4665, true, 1, -4665, true, 1, true, 1, 1, true, -680, true, 0, 0, true, 0, true, -4665, true, true, 2, 1);
	}
	@Test
	public void test6() {
		o.run2(0, false, 2433, true, -1, 0, true, 16, true, 0, 0, false, -1, true, 2433, 16, true, -168, false, -30, true, true, 0, 35);
	}
	@Test
	public void test7() {
		o.run2(0, true, 0, false, 0, 2433, true, 0, true, 0, -680, false, 0, true, -1, 0, false, 1506, false, 0, true, false, 2063, 2433);
	}
	@Test
	public void test8() {
		o.run2(-1858, true, 1, false, -4665, 1, true, 0, true, 1, 1, true, -4665, true, -4665, 1, true, -1858, true, 1, true, false, 1, 1);
	}
	@Test
	public void test9() {
		o.run2(5, true, 0, false, -4665, 1, true, 0, true, 0, 1, false, -4665, false, -4665, 0, true, 1506, false, 0, true, false, 1, 1);
	}
	@Test
	public void test10() {
		o.run2(1901, true, -4665, true, 1, -4665, true, 1, true, 1, 1, true, 1, false, 0, 0, true, -1, true, -4665, true, true, 2, 0);
	}
	@Test
	public void test11() {
		o.run2(0, true, 0, false, -4665, 2433, true, 0, true, 0, -680, false, -4665, true, -1, 0, false, 1506, true, 0, true, false, 2063, 2433);
	}
	@Test
	public void test12() {
		o.run2(1891, true, -4665, true, 1, -4665, true, 1, true, 1, 1, true, -680, true, 0, 0, true, -1, true, -4665, true, true, 2, 1);
	}
	@Test
	public void test13() {
		o.run2(-680, true, -20, true, -4665, -4665, true, 0, true, 0, -680, true, -4665, true, -4665, -20, true, -680, true, -20, true, true, -680, -4665);
	}
	@Test
	public void test14() {
		o.run2(1901, true, -4665, true, -4665, -4665, true, -4665, true, -4665, -4665, true, -680, true, -4665, -4665, true, -1, true, -4665, true, true, 2, 1901);
	}
	@Test
	public void test15() {
		o.run2(0, true, 1, false, -4665, 1, true, 0, true, 0, -4665, true, -4665, true, -4665, 1, true, 1, true, 1, true, false, -4665, 1);
	}
	@Test
	public void test16() {
		o.run2(1901, true, -4665, true, 1, -4665, true, 1, true, 1, 1, true, 1, true, -4665, -4665, true, -1, true, -4665, true, true, 2, 1901);
	}
	@Test
	public void test17() {
		o.run2(1, true, 1, true, -4694, 1, true, 0, true, 0, 1, true, -4694, true, -4694, 1, true, 0, true, 1, true, true, 1, 1);
	}

}