package coverage;
import org.junit.Test;

import MerArbiter.MyMerArbiterSym;
public class MyMerArbiterSymTest {
	MyMerArbiterSym o = new MyMerArbiterSym();
	@Test
	public void test0() {
		o.run2(3215, false, 3215, false, -633, -1952, false, 3215, false, 0, -2384, false, 3215, false, 3215, -90, false, -90, false, 599, false, true, 0, -1952);
	}
	@Test
	public void test1() {
		o.run2(0, true, 0, true, -1, 562, false, 0, false, -1, 0, false, 2844, true, 1354, 0, false, 1, true, 0, false, false, 0, -2561);
	}
	@Test
	public void test2() {
		o.run2(562, true, -1, false, -1448, -3029, false, 11, false, 0, 0, false, 0, false, 0, -3029, false, 0, false, -1218, false, false, 562, -1);
	}
	@Test
	public void test3() {
		o.run2(0, false, 0, false, 0, 2, false, 0, false, 0, -1, false, 11, false, 0, -3029, false, 0, false, 0, false, false, 1, -3884);
	}

}