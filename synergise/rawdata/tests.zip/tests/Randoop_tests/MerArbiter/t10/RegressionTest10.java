
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest10 {

  public static boolean debug = false;

  @Test
  public void test01() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest10.test01"); }


    MerArbiter.TestMyMerArbiterSym testMyMerArbiterSym0 = new MerArbiter.TestMyMerArbiterSym();
    testMyMerArbiterSym0.run2((int)(short)10, true, 10, true, 0, (int)(byte)(-1), false, 100, false, (int)(byte)(-1), (int)(short)0, true, 10, false, (int)(short)(-1), (int)(byte)0, false, (int)(byte)1, true, (int)' ', false, false, (int)(short)100, (int)(byte)(-1));
    testMyMerArbiterSym0.run2(10, false, (int)(byte)0, true, 1, (-1), false, 1, false, (-1), 10, true, (int)'4', true, (int)'4', 100, true, 0, false, (int)' ', false, false, (int)'a', (int)(short)1);
    testMyMerArbiterSym0.run2(0, true, (int)(short)10, false, 10, (int)(byte)0, true, 10, false, 10, 0, false, 0, false, 0, 0, true, (int)(byte)0, false, (int)'#', false, false, (int)(byte)10, 10);

  }

  @Test
  public void test02() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest10.test02"); }


    MerArbiter.TestMyMerArbiterSym testMyMerArbiterSym0 = new MerArbiter.TestMyMerArbiterSym();
    testMyMerArbiterSym0.run2((int)(short)(-1), true, (int)(short)1, true, (int)'#', 1, false, (int)(byte)0, false, (int)(short)(-1), 0, true, (int)(byte)(-1), false, 1, (int)'#', true, (int)(byte)10, false, (int)(short)1, false, true, (int)(short)1, (int)'4');
    testMyMerArbiterSym0.run2((int)'#', true, (int)(short)0, false, (-1), 100, true, (int)(byte)1, false, (int)(short)1, 0, true, 0, false, (int)(short)1, (int)(short)0, true, (-1), true, (int)'4', true, true, (int)(byte)(-1), (int)(byte)0);
    testMyMerArbiterSym0.run2(0, true, (int)(byte)1, false, (int)(byte)0, 0, false, (int)'a', false, 1, 1, true, (int)(short)100, true, (int)(byte)1, (int)(byte)10, true, (int)(short)10, true, (int)(short)(-1), true, false, 0, 1);

  }

  @Test
  public void test03() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest10.test03"); }


    MerArbiter.TestMyMerArbiterSym testMyMerArbiterSym0 = new MerArbiter.TestMyMerArbiterSym();
    testMyMerArbiterSym0.run2(100, true, (int)'4', false, (int)(byte)10, (int)(short)0, true, (int)(byte)0, false, (int)(short)10, 10, true, (int)(byte)1, true, (-1), (int)' ', false, 100, true, 0, true, false, 0, (int)(byte)1);
    testMyMerArbiterSym0.run2(10, false, (int)(short)0, false, 10, (int)'4', true, 0, false, (-1), 0, false, (-1), false, 1, (int)(byte)(-1), true, (int)' ', false, 10, true, false, (int)(short)0, 0);
    testMyMerArbiterSym0.run2((int)(short)1, false, (int)'#', false, (int)(short)(-1), 1, false, (int)(byte)1, false, (int)' ', (int)(byte)1, true, 10, false, 0, 0, false, 0, true, (int)(short)1, false, true, (int)(byte)100, (-1));

  }

  @Test
  public void test04() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest10.test04"); }


    MerArbiter.TestMyMerArbiterSym testMyMerArbiterSym0 = new MerArbiter.TestMyMerArbiterSym();
    testMyMerArbiterSym0.run2((int)(short)100, false, (int)(short)100, false, (int)'#', (int)'#', true, (-1), true, (int)(short)10, (int)(short)10, true, (int)(short)100, false, 100, (int)(byte)100, false, 10, false, 100, false, false, (int)(byte)10, 100);
    testMyMerArbiterSym0.run2((int)'a', true, (int)'a', false, 1, (int)(byte)1, true, 1, false, (int)(short)(-1), (int)'4', true, (int)'#', true, 0, 0, false, (-1), false, (int)'#', false, false, (int)(byte)10, (int)(byte)0);
    testMyMerArbiterSym0.run2((int)(byte)10, false, 10, false, (-1), (int)(short)100, false, (int)(byte)1, true, 10, (int)(short)(-1), true, (int)(byte)10, true, (int)(byte)(-1), 100, false, (int)(byte)0, true, (int)' ', true, true, (int)(short)(-1), 0);

  }

  @Test
  public void test05() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest10.test05"); }


    MerArbiter.TestMyMerArbiterSym testMyMerArbiterSym0 = new MerArbiter.TestMyMerArbiterSym();
    testMyMerArbiterSym0.run2((int)(byte)0, false, (int)(byte)(-1), true, (int)'#', (int)(byte)0, false, (int)(short)(-1), true, (-1), (int)(short)0, false, (int)(short)100, true, (int)(byte)(-1), (int)(byte)0, true, (-1), true, (int)(byte)0, false, false, 1, (int)'4');
    testMyMerArbiterSym0.run2((int)'4', false, 10, true, (int)(short)0, (int)(byte)0, false, (int)'#', false, (int)(byte)100, (int)(byte)(-1), true, 1, false, (int)' ', (int)' ', false, (int)(short)(-1), true, 0, false, false, (int)(short)0, (int)(short)0);
    testMyMerArbiterSym0.run2((int)(short)0, true, 1, true, (int)(short)1, (-1), false, (int)(byte)(-1), true, 0, (int)(byte)0, false, (int)'#', false, (int)(byte)100, (int)'a', false, 0, true, 100, true, false, 1, 0);

  }

  @Test
  public void test06() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest10.test06"); }


    MerArbiter.TestMyMerArbiterSym testMyMerArbiterSym0 = new MerArbiter.TestMyMerArbiterSym();
    testMyMerArbiterSym0.run2(1, true, 10, true, (int)(byte)100, (-1), false, (int)(short)10, true, (int)(byte)(-1), 1, false, (int)' ', true, (int)'4', (int)(short)100, true, (int)'#', true, (int)'#', false, true, 10, (int)'#');
    testMyMerArbiterSym0.run2(100, true, (int)(byte)0, false, (int)'#', (-1), false, 0, false, (int)(short)1, (int)'a', true, (int)(short)10, false, (int)'#', (int)(byte)1, false, (int)(byte)(-1), false, (int)(byte)10, false, false, (int)'#', 100);
    testMyMerArbiterSym0.run2((int)(byte)0, false, 1, true, (int)'a', (int)(byte)10, true, (int)(byte)10, true, (int)(short)10, (int)'#', false, (int)(byte)10, false, 0, (int)(short)100, true, 0, false, (int)'a', false, false, (int)(short)100, 0);

  }

  @Test
  public void test07() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest10.test07"); }


    MerArbiter.TestMyMerArbiterSym testMyMerArbiterSym0 = new MerArbiter.TestMyMerArbiterSym();
    testMyMerArbiterSym0.run2((int)(byte)(-1), true, (int)(short)0, false, 100, 100, true, (int)(short)(-1), true, (-1), (int)(short)100, true, (int)(byte)1, true, (int)(short)10, (int)(short)100, false, (int)(byte)0, true, 1, true, true, (int)(byte)10, (int)(short)0);
    testMyMerArbiterSym0.run2((int)(byte)(-1), true, (int)'4', false, (int)'#', (int)(byte)0, false, 10, false, (int)(short)100, (int)(byte)(-1), false, (int)(byte)10, true, (int)'#', (int)(short)100, false, 0, true, (int)'#', false, false, (int)(short)0, (int)' ');
    testMyMerArbiterSym0.run2((int)(byte)1, true, (int)'a', false, (int)(short)1, (int)'4', true, 10, true, (int)(byte)100, (int)(short)10, true, (int)(short)1, true, (int)'#', 100, false, (int)(byte)0, false, (int)(byte)100, false, false, (int)(short)10, 1);

  }

  @Test
  public void test08() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest10.test08"); }


    MerArbiter.TestMyMerArbiterSym testMyMerArbiterSym0 = new MerArbiter.TestMyMerArbiterSym();
    testMyMerArbiterSym0.run2((int)(short)100, false, (int)(short)100, false, (int)'#', (int)'#', true, (-1), true, (int)(short)10, (int)(short)10, true, (int)(short)100, false, 100, (int)(byte)100, false, 10, false, 100, false, false, (int)(byte)10, 100);
    testMyMerArbiterSym0.run2((int)(byte)100, false, (int)(short)1, true, (int)(short)10, (-1), true, (-1), false, (int)(short)10, (int)(byte)100, false, (int)(byte)10, false, (int)(short)0, (int)(short)10, true, 0, true, 100, false, true, (int)(byte)10, (int)(short)10);
    testMyMerArbiterSym0.run2(100, true, 0, false, 100, (-1), true, (int)(short)100, true, 0, (int)'4', true, (int)(byte)(-1), false, (int)(byte)1, 10, false, 100, false, (int)(byte)0, false, false, 10, 0);

  }

  @Test
  public void test09() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest10.test09"); }


    MerArbiter.TestMyMerArbiterSym testMyMerArbiterSym0 = new MerArbiter.TestMyMerArbiterSym();
    testMyMerArbiterSym0.run2((int)'#', true, (int)(short)0, false, (int)(short)10, (int)'4', true, 10, true, 1, (int)(byte)(-1), false, (int)(byte)10, true, (int)(byte)(-1), (int)(byte)1, false, (int)(byte)0, false, (int)'4', false, false, (int)(short)100, (int)(byte)0);
    testMyMerArbiterSym0.run2((int)'#', false, (int)(short)(-1), true, (int)(short)(-1), (int)(short)(-1), false, (int)(byte)100, true, (int)(short)0, 10, true, (int)(byte)100, false, (int)(byte)(-1), (int)' ', true, (int)(short)1, false, 100, false, true, (int)(short)0, (-1));
    testMyMerArbiterSym0.run2((int)'a', true, (int)'a', true, 0, (int)(short)100, false, (int)(short)(-1), false, 1, (int)(byte)100, false, (int)(short)100, false, (int)(byte)10, (-1), true, (int)(byte)0, false, 10, false, false, 0, (int)'#');

  }

  @Test
  public void test10() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest10.test10"); }


    MerArbiter.TestMyMerArbiterSym testMyMerArbiterSym0 = new MerArbiter.TestMyMerArbiterSym();
    testMyMerArbiterSym0.run2((int)(byte)100, true, (int)(byte)0, true, 100, (int)(short)1, true, (int)(short)0, true, (int)(short)1, (int)(short)(-1), true, (int)(byte)10, false, (int)(short)1, 0, true, (int)(short)100, true, (int)' ', false, false, (int)'4', 0);
    testMyMerArbiterSym0.run2((int)(byte)(-1), true, (int)(short)100, true, 0, (int)(byte)0, true, (int)(byte)10, false, (int)(byte)0, (int)' ', false, (int)(byte)0, false, (-1), 1, true, 10, true, (int)(byte)0, true, false, (int)(short)100, (int)(byte)0);
    testMyMerArbiterSym0.run2((int)'4', true, (int)(short)0, false, (int)(short)(-1), (-1), false, (int)(byte)1, false, (int)(short)1, 0, false, (int)(byte)100, false, (int)(short)0, (int)(byte)10, false, (int)(short)10, true, (int)(short)(-1), false, true, (int)(short)10, (int)(byte)10);

  }

  @Test
  public void test11() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest10.test11"); }


    MerArbiter.TestMyMerArbiterSym testMyMerArbiterSym0 = new MerArbiter.TestMyMerArbiterSym();
    testMyMerArbiterSym0.run2((int)(byte)(-1), true, (int)(byte)10, false, (int)'#', 0, true, (int)(byte)0, false, (int)(byte)1, 1, true, (int)(short)100, true, (int)(short)0, (int)(short)1, true, (int)'a', false, (int)(byte)0, false, true, (int)(short)(-1), (int)'a');
    testMyMerArbiterSym0.run2((int)'a', false, (int)(byte)0, false, (int)(byte)(-1), 0, false, (int)(short)100, false, 1, 1, true, (int)' ', false, (int)(byte)0, (int)(byte)(-1), false, 1, false, 1, false, false, (int)'a', 10);
    testMyMerArbiterSym0.run2(100, false, (int)(byte)1, false, (int)'4', (int)(byte)1, true, (int)(short)(-1), true, (int)(byte)0, (int)'a', false, 1, true, (int)(short)1, (int)(short)(-1), true, (int)'4', false, (int)(short)0, false, true, 1, 0);

  }

  @Test
  public void test12() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest10.test12"); }


    MerArbiter.TestMyMerArbiterSym testMyMerArbiterSym0 = new MerArbiter.TestMyMerArbiterSym();
    testMyMerArbiterSym0.run2((int)(byte)(-1), true, (int)(byte)10, false, (int)'#', 0, true, (int)(byte)0, false, (int)(byte)1, 1, true, (int)(short)100, true, (int)(short)0, (int)(short)1, true, (int)'a', false, (int)(byte)0, false, true, (int)(short)(-1), (int)'a');
    testMyMerArbiterSym0.run2((int)(byte)10, false, 0, false, 0, (-1), false, (int)'a', false, (int)'a', (int)(short)1, false, (-1), false, (int)'a', (int)(short)0, false, (int)(short)100, true, (int)(short)(-1), true, true, (int)(short)1, (int)(short)100);
    testMyMerArbiterSym0.run2((int)(short)100, true, 0, true, (int)(short)1, (int)(short)(-1), true, (-1), false, (int)(byte)1, (-1), true, (int)(short)1, false, (int)' ', 0, true, (int)(short)100, false, (int)(short)1, false, true, 100, (int)(byte)0);

  }

  @Test
  public void test13() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest10.test13"); }


    MerArbiter.TestMyMerArbiterSym testMyMerArbiterSym0 = new MerArbiter.TestMyMerArbiterSym();
    testMyMerArbiterSym0.run2(0, false, 1, false, (int)(short)1, (int)' ', true, 1, false, (int)'4', (int)(short)(-1), true, (int)(byte)10, false, (int)(short)(-1), (int)(short)1, true, (int)(byte)100, true, (int)(byte)100, true, false, (int)(byte)1, 0);
    testMyMerArbiterSym0.run2((int)(short)0, true, (int)(short)0, false, (-1), (int)(byte)100, true, (int)(byte)0, false, (-1), (int)(short)100, true, 1, false, (int)(byte)10, (int)(short)0, false, 0, false, (int)(short)10, true, true, (int)(short)(-1), (int)(short)1);
    testMyMerArbiterSym0.run2((int)'#', false, (int)(short)0, true, (int)'#', (-1), false, (int)(short)100, true, (int)(short)1, 0, false, (int)(short)(-1), true, 100, (int)' ', true, (int)(byte)0, true, (int)(short)10, false, true, (int)'a', 0);

  }

  @Test
  public void test14() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest10.test14"); }


    MerArbiter.TestMyMerArbiterSym testMyMerArbiterSym0 = new MerArbiter.TestMyMerArbiterSym();
    testMyMerArbiterSym0.run2((int)(short)1, true, (int)(byte)0, true, (int)' ', (int)'4', true, (int)(byte)100, true, (int)'4', 0, false, (int)(byte)(-1), false, (-1), (int)(byte)0, true, (int)(short)(-1), true, (int)(byte)10, true, true, 10, (int)'4');
    testMyMerArbiterSym0.run2((int)(byte)100, true, (-1), true, (int)(short)1, (int)'a', false, 0, true, 0, 0, false, (int)(byte)0, true, (int)(short)100, (int)'4', false, (int)(short)10, true, (int)(short)(-1), false, true, (int)(byte)10, (int)(byte)(-1));
    testMyMerArbiterSym0.run2(0, false, (int)(short)100, false, 1, 0, false, (int)(short)0, true, (int)(byte)10, (-1), true, 100, true, 0, (int)(short)100, false, (int)(byte)(-1), false, (int)'a', true, false, 1, (int)(byte)1);

  }

  @Test
  public void test15() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest10.test15"); }


    MerArbiter.TestMyMerArbiterSym testMyMerArbiterSym0 = new MerArbiter.TestMyMerArbiterSym();
    testMyMerArbiterSym0.run2((int)(short)(-1), true, (int)(short)1, true, (int)'#', 1, false, (int)(byte)0, false, (int)(short)(-1), 0, true, (int)(byte)(-1), false, 1, (int)'#', true, (int)(byte)10, false, (int)(short)1, false, true, (int)(short)1, (int)'4');
    testMyMerArbiterSym0.run2(1, true, 0, false, 0, 0, true, 0, false, (int)'4', (int)' ', true, 0, false, (int)'4', 1, true, (-1), true, 100, true, true, (int)(short)100, (int)(short)0);
    testMyMerArbiterSym0.run2((int)(short)(-1), false, (int)(byte)(-1), false, 0, (int)(short)100, true, (int)(short)100, false, (int)(byte)100, (int)' ', false, (int)(byte)100, false, (int)'#', (int)(byte)0, false, 0, true, (int)(byte)100, false, true, (int)'4', (int)(byte)0);

  }

  @Test
  public void test16() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest10.test16"); }


    MerArbiter.TestMyMerArbiterSym testMyMerArbiterSym0 = new MerArbiter.TestMyMerArbiterSym();
    testMyMerArbiterSym0.run2(0, false, 1, false, (int)(short)1, (int)' ', true, 1, false, (int)'4', (int)(short)(-1), true, (int)(byte)10, false, (int)(short)(-1), (int)(short)1, true, (int)(byte)100, true, (int)(byte)100, true, false, (int)(byte)1, 0);
    testMyMerArbiterSym0.run2((int)(short)100, true, (int)(byte)(-1), true, (int)(short)1, (int)' ', false, (int)(byte)10, false, (int)'4', (int)(short)10, false, (int)'a', false, (int)(byte)100, (int)(byte)1, true, 0, true, (int)(byte)10, false, true, (int)(short)100, 100);

  }

  @Test
  public void test17() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest10.test17"); }


    MerArbiter.TestMyMerArbiterSym testMyMerArbiterSym0 = new MerArbiter.TestMyMerArbiterSym();
    testMyMerArbiterSym0.run2((int)(short)100, false, (int)(short)100, false, (int)'#', (int)'#', true, (-1), true, (int)(short)10, (int)(short)10, true, (int)(short)100, false, 100, (int)(byte)100, false, 10, false, 100, false, false, (int)(byte)10, 100);
    testMyMerArbiterSym0.run2((int)' ', false, (int)(byte)100, false, (-1), 10, false, 0, false, (int)(short)(-1), (int)(short)(-1), false, 100, false, (int)'a', (int)(byte)(-1), true, (int)(short)100, false, (int)'a', true, true, (int)(byte)1, (int)(byte)1);
    testMyMerArbiterSym0.run2((int)(short)100, true, (int)'4', false, 0, 100, true, (int)'4', false, (int)(byte)10, (-1), false, (int)(short)(-1), false, (int)(short)100, 1, true, (int)(byte)(-1), true, (int)(byte)100, true, false, 0, 0);

  }

  @Test
  public void test18() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest10.test18"); }


    MerArbiter.TestMyMerArbiterSym testMyMerArbiterSym0 = new MerArbiter.TestMyMerArbiterSym();
    testMyMerArbiterSym0.run2((int)(byte)(-1), true, (int)(short)0, false, 100, 100, true, (int)(short)(-1), true, (-1), (int)(short)100, true, (int)(byte)1, true, (int)(short)10, (int)(short)100, false, (int)(byte)0, true, 1, true, true, (int)(byte)10, (int)(short)0);
    testMyMerArbiterSym0.run2((int)(byte)(-1), true, (int)'4', false, (int)'#', (int)(byte)0, false, 10, false, (int)(short)100, (int)(byte)(-1), false, (int)(byte)10, true, (int)'#', (int)(short)100, false, 0, true, (int)'#', false, false, (int)(short)0, (int)' ');
    testMyMerArbiterSym0.run2((int)(short)1, false, (int)(byte)100, false, 0, (int)(byte)(-1), false, (int)(short)10, false, (int)(byte)100, (int)(short)10, true, (int)'4', false, (int)(short)0, 10, false, (int)(byte)0, false, (int)(byte)0, false, false, 1, (int)(byte)1);

  }

  @Test
  public void test19() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest10.test19"); }


    MerArbiter.TestMyMerArbiterSym testMyMerArbiterSym0 = new MerArbiter.TestMyMerArbiterSym();
    testMyMerArbiterSym0.run2((int)(short)(-1), true, (int)(short)1, true, (int)'#', 1, false, (int)(byte)0, false, (int)(short)(-1), 0, true, (int)(byte)(-1), false, 1, (int)'#', true, (int)(byte)10, false, (int)(short)1, false, true, (int)(short)1, (int)'4');
    testMyMerArbiterSym0.run2(100, false, 10, false, (int)'4', 100, false, 0, false, 0, (int)'a', false, (int)(short)1, true, (int)(short)(-1), (int)(short)100, false, (int)' ', false, (int)(short)1, false, true, 10, (int)(short)10);
    testMyMerArbiterSym0.run2((int)'4', false, (int)(short)1, false, 0, (int)'4', true, (int)(short)10, false, (int)(byte)0, 1, true, (int)'#', true, 0, 100, false, (int)(short)(-1), false, (int)(byte)10, false, true, (int)'a', (int)(short)100);

  }

}
