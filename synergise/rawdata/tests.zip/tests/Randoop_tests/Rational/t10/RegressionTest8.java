
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest8 {

  public static boolean debug = false;

  @Test
  public void test001() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test001"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)'a', (int)(byte)(-1), (int)' ', (int)'#', (int)(short)1);
    testRational0.mysimp((int)(byte)1, 1, (int)(short)1, (int)(short)100, (int)(byte)(-1), (int)'#');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)(byte)1, 0, (int)(short)100, (int)(short)100);
    testRational0.mysimp(0, 100, 10, (int)(byte)0, (int)' ', (int)(short)(-1));
    testRational0.mysimp(0, (int)(byte)10, (int)(short)100, (int)'a', 100, (int)'4');
    testRational0.mysimp((int)' ', (int)(byte)0, 1, (int)'a', 0, (int)(byte)(-1));

  }

  @Test
  public void test002() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test002"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, 100, 100);
    testRational0.mysimp((int)(byte)(-1), (int)'a', (-1), (int)'4', (-1), (int)(byte)0);
    testRational0.mysimp((int)'a', (-1), 0, (-1), (int)(byte)100, (int)'a');
    testRational0.mysimp((int)(short)1, (-1), (int)(short)100, (int)(byte)(-1), (int)'4', (int)(byte)0);
    testRational0.mysimp(10, (int)' ', (int)'a', (int)'#', (int)(byte)(-1), (int)(short)1);
    testRational0.mysimp((int)'a', (int)(byte)0, 100, (int)(byte)1, (int)(byte)1, (int)(byte)(-1));

  }

  @Test
  public void test003() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test003"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)1, 1, (int)(short)1, 0);
    testRational0.mysimp((int)(byte)100, (int)(byte)100, (int)(short)1, (int)(short)10, (int)(short)1, (int)(short)0);
    testRational0.mysimp((int)'a', (int)(short)0, (int)(byte)1, (int)(byte)10, (int)(byte)100, 0);
    testRational0.mysimp((int)(byte)100, 1, (int)(short)1, (int)'4', (int)(byte)100, (int)(short)100);
    testRational0.mysimp((int)(byte)0, (int)(byte)10, 0, (int)(short)0, 100, (int)(byte)10);
    testRational0.mysimp((int)(byte)0, (int)(short)100, (int)'a', (int)'#', (int)(byte)100, (int)(short)1);
    testRational0.mysimp((-1), (-1), (int)' ', 0, (int)'a', (int)(byte)(-1));
    testRational0.mysimp((int)(byte)10, (int)(byte)100, (int)(short)10, (int)(short)100, (int)' ', 10);
    testRational0.mysimp((int)'#', (int)'#', (int)'a', 1, (int)(short)1, (int)(short)0);

  }

  @Test
  public void test004() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test004"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(byte)(-1), (int)(short)(-1), (int)(short)10, 0, (int)(byte)100, 1);
    testRational0.mysimp(100, (int)(short)1, 10, (int)' ', (int)'a', 1);
    testRational0.mysimp(10, 100, (int)(byte)0, (int)' ', (int)(byte)10, (int)(byte)0);
    testRational0.mysimp((int)(byte)(-1), (int)' ', (int)'4', 0, 10, (int)'a');
    testRational0.mysimp((int)'#', 0, (int)'a', (-1), (int)(short)10, 0);
    testRational0.mysimp(0, (int)(short)1, 100, (int)'#', (-1), (int)(byte)10);
    testRational0.mysimp((int)(short)0, 10, (int)'#', (int)(byte)0, 0, (int)(byte)(-1));

  }

  @Test
  public void test005() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test005"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)' ', 10, (int)' ', (int)(short)0, 0, (int)(short)1);
    testRational0.mysimp((int)(short)1, (int)' ', (int)(short)100, (int)(short)100, (int)(byte)100, 10);
    testRational0.mysimp((int)(byte)10, (int)' ', (-1), (int)(short)100, (int)'a', (int)(short)(-1));
    testRational0.mysimp((int)'4', (int)(byte)(-1), 100, (int)(short)1, (int)(short)0, (int)(short)10);
    testRational0.mysimp((int)(short)0, 100, 10, (int)(short)10, (int)'a', (int)'#');
    testRational0.mysimp((int)(short)10, (int)(short)(-1), (int)(short)10, (int)(byte)(-1), (int)(short)100, (int)(short)100);
    testRational0.mysimp((int)(byte)1, 10, 10, 0, (int)(byte)(-1), (int)(byte)100);

  }

  @Test
  public void test006() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test006"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(byte)100, (int)(byte)1, (int)(byte)(-1), 1, (int)(byte)0, 10);
    testRational0.mysimp((int)(byte)10, (int)'4', (int)(byte)(-1), (int)(byte)100, (int)(byte)(-1), (int)' ');
    testRational0.mysimp((-1), (int)(short)(-1), (int)(short)10, (int)' ', (int)(short)100, (int)(short)100);
    testRational0.mysimp(10, (int)(byte)10, (int)(short)10, (int)(short)0, (int)(short)0, 100);
    testRational0.mysimp((int)(short)10, (int)(short)1, (int)'#', 0, 100, (int)'4');
    testRational0.mysimp(10, (int)(byte)1, (int)'4', (-1), (int)(short)10, (int)(short)100);

  }

  @Test
  public void test007() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test007"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)(short)1, (int)(byte)10, (int)(byte)100, 1, (int)(byte)10, (int)(byte)(-1));
    testRational0.mysimp(100, (int)(short)0, (int)(short)1, (int)(byte)1, (int)(byte)(-1), (int)'#');
    testRational0.mysimp(0, (int)(byte)0, 1, (int)(short)100, (int)(short)(-1), (int)(byte)1);
    testRational0.mysimp((int)' ', 10, 100, (int)'4', (int)'#', (int)(short)1);
    testRational0.mysimp((int)(byte)100, 0, (int)' ', (int)' ', (int)(short)100, (int)(short)1);
    testRational0.mysimp((int)(short)0, (int)'a', (int)(short)1, (int)(short)(-1), 1, (int)'a');

  }

  @Test
  public void test008() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test008"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)'a', (int)(byte)1, (int)(short)100, (int)(byte)1, (int)(short)0, (int)(short)(-1));
    testRational0.mysimp((-1), 1, (int)(byte)0, (-1), 1, (int)'a');
    testRational0.mysimp((int)(short)0, (int)'4', (int)' ', (int)(byte)(-1), 100, (int)(short)1);
    testRational0.mysimp((int)'a', (int)'#', (int)(short)100, (int)(byte)1, (int)'#', (int)(byte)1);
    testRational0.mysimp((int)'#', 0, (int)(byte)(-1), (int)(byte)10, 100, (int)(byte)0);
    testRational0.mysimp(0, (int)' ', (int)'4', (int)(short)10, (int)(short)0, (int)(short)0);
    testRational0.mysimp((int)(byte)10, (int)(byte)0, (int)(short)100, (int)'4', (int)' ', (int)(short)(-1));
    testRational0.mysimp((int)(short)1, (int)'a', (int)'#', (int)'4', (int)(byte)1, (int)(short)(-1));
    testRational0.mysimp((int)'4', 100, (int)(byte)100, (int)(byte)0, (int)(byte)1, (int)'#');

  }

  @Test
  public void test009() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test009"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 0, (-1), 100, (int)'a');
    testRational0.mysimp((int)' ', (int)(short)100, (int)(short)10, (-1), (int)'a', (int)(byte)0);
    testRational0.mysimp((int)(short)0, 100, (-1), (int)(byte)10, (int)(byte)100, (int)(short)1);
    testRational0.mysimp((int)'4', (int)(short)1, (int)(byte)0, 0, (-1), 100);
    testRational0.mysimp((int)(byte)0, (int)(short)0, (int)(short)0, (-1), (int)(byte)0, 0);
    testRational0.mysimp(10, (int)(short)0, (int)(byte)100, (int)(short)1, (int)(byte)1, (-1));
    testRational0.mysimp((int)(short)(-1), (int)(byte)(-1), 10, 10, (int)(byte)0, (int)(short)10);

  }

  @Test
  public void test010() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test010"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)(short)1, (int)(byte)10, (int)(byte)100, 1, (int)(byte)10, (int)(byte)(-1));
    testRational0.mysimp(0, (int)(short)(-1), (int)(short)0, (int)(byte)0, (int)' ', 1);
    testRational0.mysimp((int)(byte)0, (int)(byte)0, (int)(short)100, 10, (int)(byte)0, (int)(short)100);
    testRational0.mysimp((int)'#', (-1), (int)'a', (int)(byte)1, (int)(short)0, 0);
    testRational0.mysimp((int)(short)0, (int)(byte)10, (int)(byte)10, (int)'4', (int)(byte)1, (int)(byte)10);
    testRational0.mysimp(10, (int)(short)100, 0, (int)(short)10, (int)(short)0, (int)(byte)100);

  }

  @Test
  public void test011() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test011"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp((int)(short)(-1), (int)(short)10, (int)(short)10, 0, (int)'4', (int)(byte)1);
    testRational0.mysimp((-1), (int)' ', (int)'a', (int)'4', (int)(short)0, (-1));
    testRational0.mysimp((int)(short)100, (int)'4', (int)(short)100, 1, (int)(byte)100, (int)(byte)10);
    testRational0.mysimp((int)(short)1, (int)(byte)1, (int)(byte)10, (-1), (int)(byte)(-1), (-1));
    testRational0.mysimp((int)(short)0, (-1), 1, 100, (int)'#', (int)(byte)10);
    testRational0.mysimp((int)(short)0, (int)'4', (int)' ', (int)'a', (int)(byte)100, 0);
    testRational0.mysimp((int)(byte)100, (int)(byte)0, (int)(byte)10, (int)(byte)1, (int)(short)10, (int)(short)0);
    testRational0.mysimp((int)(byte)0, (int)(byte)100, (int)(byte)1, (int)(short)(-1), (int)'#', (int)(byte)(-1));

  }

  @Test
  public void test012() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test012"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(10, (int)(short)100, (int)(short)10, (int)(short)100, (int)(byte)10, 0);
    testRational0.mysimp(10, (int)'4', (int)(byte)0, (int)(byte)(-1), 0, 1);
    testRational0.mysimp((int)(short)(-1), (int)(short)(-1), 0, 100, (int)(byte)100, (int)(short)10);
    testRational0.mysimp((int)(byte)(-1), 100, (int)(short)(-1), (int)' ', (int)'4', (int)' ');
    testRational0.mysimp((int)'4', (int)(byte)100, (int)(byte)0, (int)' ', 1, (int)(short)100);
    testRational0.mysimp((int)' ', 100, 0, (int)(byte)100, (int)' ', 0);
    testRational0.mysimp((int)'#', 0, (int)'#', (int)(byte)0, (int)(byte)1, 100);

  }

  @Test
  public void test013() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test013"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)(short)(-1), 100, (int)(byte)10, (int)'4', (int)(short)(-1));
    testRational0.mysimp((int)' ', 1, (int)(byte)(-1), (int)(short)1, 10, (int)(byte)0);
    testRational0.mysimp((int)(short)100, (int)(byte)(-1), 0, 0, 100, 100);
    testRational0.mysimp((int)(short)100, 0, (int)(short)(-1), (int)(byte)100, (int)'4', (int)(byte)0);
    testRational0.mysimp(0, (int)'#', (int)(short)(-1), 0, (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp((int)(short)(-1), (-1), (int)'4', (int)(byte)1, (int)(short)0, 10);
    testRational0.mysimp(100, (int)(byte)10, (int)(short)1, 10, 0, 10);
    testRational0.mysimp((int)(byte)10, (int)(short)(-1), (int)'a', (int)'#', (int)(short)100, 0);

  }

  @Test
  public void test014() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test014"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(10, (int)(short)100, (int)(short)10, (int)(short)100, (int)(byte)10, 0);
    testRational0.mysimp(10, (int)'4', (int)(byte)0, (int)(byte)(-1), 0, 1);
    testRational0.mysimp((int)(short)(-1), (int)(short)(-1), 0, 100, (int)(byte)100, (int)(short)10);
    testRational0.mysimp((int)(byte)1, (int)(short)100, (-1), (int)(short)10, (int)(short)1, (int)(short)(-1));
    testRational0.mysimp((int)(short)0, (int)(byte)0, 0, (int)'#', (int)(short)0, (int)(short)0);
    testRational0.mysimp((int)(short)10, (int)(short)10, (int)(short)100, (int)(byte)1, 1, (int)(short)1);
    testRational0.mysimp(0, (int)(short)1, (int)'a', 0, (-1), (int)'a');

  }

  @Test
  public void test015() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test015"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(short)(-1), (int)(short)10, (int)' ', 0, (int)(byte)100, (int)' ');
    testRational0.mysimp((int)' ', 0, (int)(byte)100, 100, (int)(byte)10, 0);
    testRational0.mysimp(0, (int)(byte)(-1), 1, (int)(byte)1, (int)(byte)(-1), (int)'a');
    testRational0.mysimp((int)(byte)10, 10, (int)(byte)(-1), (-1), (int)(byte)100, 0);
    testRational0.mysimp((int)(short)10, (int)(short)100, (int)(byte)100, 0, 0, (int)(short)100);
    testRational0.mysimp((int)'4', (int)(byte)0, (int)'a', (int)'#', (int)(byte)10, (int)(short)100);
    testRational0.mysimp((int)'#', 0, (int)' ', 10, (int)(byte)1, 10);
    testRational0.mysimp((int)(byte)1, (int)(short)0, 100, (int)'a', 10, (int)(short)1);
    testRational0.mysimp(0, (int)(short)10, (int)(short)100, (int)(byte)0, (int)(short)(-1), (int)(short)1);
    testRational0.mysimp((int)(byte)0, (int)(byte)1, (int)(byte)1, (int)'a', 10, (int)(byte)0);

  }

  @Test
  public void test016() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test016"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)' ', (int)(byte)0, (int)(byte)1, (int)(byte)100, 10, (int)'4');
    testRational0.mysimp((int)(short)(-1), (int)'a', 100, (int)' ', (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp((int)(short)10, 0, (int)'a', (int)'#', (int)'4', (int)(short)0);
    testRational0.mysimp(1, (int)(byte)0, (int)(short)(-1), (int)'#', (int)'#', 1);
    testRational0.mysimp(1, (int)(byte)10, (int)(short)(-1), (int)(short)(-1), (int)(short)10, (int)(byte)100);
    testRational0.mysimp((int)(short)100, 10, 0, 0, (int)(short)1, (int)(byte)1);
    testRational0.mysimp(100, 0, (int)' ', (int)(short)100, 0, (int)' ');
    testRational0.mysimp((int)' ', 0, (int)(short)100, (int)(short)10, (int)(short)0, 0);
    testRational0.mysimp(0, 0, (int)(byte)100, (int)'a', (int)(byte)0, (int)(short)10);

  }

  @Test
  public void test017() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test017"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)1, 1, (int)(short)1, 0);
    testRational0.mysimp((int)(byte)100, (int)(byte)100, (int)(short)1, (int)(short)10, (int)(short)1, (int)(short)0);
    testRational0.mysimp((int)(short)0, (int)(short)100, 100, 0, (int)(short)(-1), (int)(short)10);
    testRational0.mysimp(0, 100, (int)(short)(-1), 100, (int)'#', (int)'a');
    testRational0.mysimp((int)(byte)(-1), 0, (int)(short)(-1), (int)'a', (int)(short)(-1), (int)(byte)10);
    testRational0.mysimp((int)(short)(-1), 100, (int)(byte)1, (int)'a', (int)(short)10, (int)' ');
    testRational0.mysimp(100, (int)'#', (int)(short)10, 0, (int)(byte)100, 0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)(byte)1, (int)(byte)100, 1, 0);
    testRational0.mysimp((int)'4', 0, (int)(byte)10, 1, (int)(byte)1, (int)(byte)1);
    testRational0.mysimp(0, 100, 0, (int)(byte)1, 0, (int)(byte)10);

  }

  @Test
  public void test018() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test018"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp((-1), (int)(short)(-1), (int)(byte)100, (int)(byte)0, (int)(short)1, (int)'#');
    testRational0.mysimp((int)(byte)10, (int)'4', 10, (int)(byte)(-1), (int)(short)100, (int)(byte)(-1));
    testRational0.mysimp((int)'a', (int)(byte)0, (int)(short)1, 0, 0, (int)(short)0);

  }

  @Test
  public void test019() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test019"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, 100, 100);
    testRational0.mysimp(0, (int)'4', (int)' ', (int)(byte)100, (int)(byte)1, (int)(short)100);
    testRational0.mysimp((int)(short)0, (int)(byte)10, 10, (int)(short)0, 0, (int)(byte)100);
    testRational0.mysimp((-1), 10, 1, (int)(short)(-1), (int)(byte)(-1), 100);
    testRational0.mysimp((int)(byte)100, (int)(byte)10, (-1), (-1), (int)(short)1, 1);
    testRational0.mysimp((int)(byte)100, (int)(byte)0, (int)'#', (int)'4', (int)(byte)10, (int)(byte)(-1));
    testRational0.mysimp((int)'4', (int)(byte)1, (int)'4', (int)(byte)0, 0, (int)(short)0);
    testRational0.mysimp((int)(short)0, (int)'a', (int)'a', (int)(byte)(-1), (int)(byte)1, (int)(byte)0);
    testRational0.mysimp((int)'4', 0, (int)(short)10, (int)' ', (int)(byte)1, (int)'#');
    testRational0.mysimp((int)(byte)10, 0, (int)(short)10, (int)(short)(-1), (int)(short)100, (int)(short)(-1));
    testRational0.mysimp((int)(short)(-1), (-1), (int)(byte)10, (-1), 100, (int)'#');

  }

  @Test
  public void test020() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test020"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(byte)(-1), (int)(short)0, 0, (int)(byte)0, (int)'a');
    testRational0.mysimp(0, (int)'a', 0, (int)(short)100, (int)(short)1, 0);
    testRational0.mysimp((int)(short)10, (int)(byte)(-1), (int)(short)0, (-1), 1, (int)(byte)100);
    testRational0.mysimp((int)(short)(-1), 10, (int)'a', 10, 10, 100);

  }

  @Test
  public void test021() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test021"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)'4', (int)(byte)(-1), 10, (int)(short)0, 0);
    testRational0.mysimp((-1), 100, 0, (int)(byte)100, (int)(byte)(-1), (int)(byte)0);
    testRational0.mysimp(100, 0, (int)(byte)10, (int)(byte)100, 100, 100);
    testRational0.mysimp((int)'a', (int)(short)1, 1, (int)(short)10, (int)(short)100, (int)(byte)100);
    testRational0.mysimp((int)' ', (int)'#', (int)'4', (int)(byte)100, 0, (int)'4');
    testRational0.mysimp((int)' ', (int)(byte)100, (int)'4', (int)'4', 0, (int)(short)10);
    testRational0.mysimp(100, (-1), (int)(byte)(-1), (int)(byte)10, (int)(byte)100, 10);
    testRational0.mysimp((int)(short)10, 1, (int)' ', (-1), (int)(byte)(-1), (int)'4');

  }

  @Test
  public void test022() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test022"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)'a', (int)(short)100, (int)(short)10, 0, 100, (int)(short)1);
    testRational0.mysimp(100, (int)(short)1, (int)' ', (int)(byte)10, (int)(short)1, (int)(byte)0);
    testRational0.mysimp(10, (int)(short)100, (int)' ', (int)(byte)0, (int)(byte)0, 10);
    testRational0.mysimp((int)'4', (int)(byte)(-1), 0, (int)(short)(-1), 0, (int)(short)0);
    testRational0.mysimp(100, (int)(byte)10, 0, (int)(byte)100, (int)' ', (int)'#');

  }

  @Test
  public void test023() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test023"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 0, (-1), 100, (int)'a');
    testRational0.mysimp(0, (int)'4', (int)(byte)0, (int)(short)0, 0, (int)(short)100);
    testRational0.mysimp((-1), 0, (int)(short)0, 100, (int)(short)10, (int)(byte)0);
    testRational0.mysimp((int)(short)100, 1, (-1), (int)(short)10, (int)(short)100, (-1));
    testRational0.mysimp(100, (int)(byte)0, (int)(byte)(-1), (int)'#', (int)(short)100, (-1));
    testRational0.mysimp((int)(byte)10, (int)'#', (int)(byte)(-1), (int)(short)10, (int)(short)(-1), 1);

  }

  @Test
  public void test024() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test024"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)1, 1, (int)(short)1, 0);
    testRational0.mysimp((int)' ', (int)' ', (int)(byte)10, (int)'4', (int)'4', (int)(short)10);
    testRational0.mysimp(0, (int)(short)100, (int)'a', (int)' ', (int)'4', (int)(byte)100);
    testRational0.mysimp((int)'a', (int)'#', 100, (int)(short)10, (int)(short)10, (int)'#');
    testRational0.mysimp(0, 10, (-1), 100, (int)' ', 10);
    testRational0.mysimp((int)' ', (int)(short)10, 0, (int)(byte)(-1), (int)(byte)100, (int)(short)100);

  }

  @Test
  public void test025() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test025"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)' ', 10, (int)' ', (int)(short)0, 0, (int)(short)1);
    testRational0.mysimp((int)'#', 100, (-1), 1, (-1), (int)(byte)(-1));
    testRational0.mysimp((int)(short)(-1), (int)'#', (int)(short)1, (int)(short)10, (int)(byte)1, 100);
    testRational0.mysimp((int)(byte)0, 0, (int)(short)100, 100, 10, (-1));
    testRational0.mysimp((int)' ', (int)(short)1, (int)(short)0, (int)(byte)100, (int)'#', 100);
    testRational0.mysimp((int)'a', (int)(byte)0, (int)(byte)100, (int)(short)1, (int)(byte)(-1), (int)(short)100);
    testRational0.mysimp((int)(byte)(-1), (int)(byte)10, (int)(byte)10, (int)(short)(-1), (-1), (int)(short)0);

  }

  @Test
  public void test026() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test026"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)'a', (int)(short)100, (int)(short)10, 0, 100, (int)(short)1);
    testRational0.mysimp(100, (int)(short)1, (int)' ', (int)(byte)10, (int)(short)1, (int)(byte)0);
    testRational0.mysimp((int)'#', (int)'#', (int)'4', (int)(short)(-1), (int)'4', (int)(byte)1);
    testRational0.mysimp((int)(byte)10, 1, (-1), (int)'4', (int)'4', (int)(short)100);
    testRational0.mysimp(1, (-1), 0, (int)'4', 0, 100);

  }

  @Test
  public void test027() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test027"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'a', (int)(byte)0, 0, (int)(short)0, 0);
    testRational0.mysimp((int)(short)10, (int)(byte)0, (int)'a', (int)(byte)0, (int)(byte)0, (int)(byte)(-1));
    testRational0.mysimp((int)(short)1, 0, (int)(byte)(-1), (int)(short)1, 10, (int)(short)(-1));
    testRational0.mysimp((int)(short)10, (int)(short)1, (int)'a', (int)(byte)10, (int)(short)1, 1);
    testRational0.mysimp((int)(byte)100, (int)(short)0, 1, (int)(short)0, (-1), (-1));
    testRational0.mysimp((int)(short)0, (int)'a', (int)(short)10, (int)(byte)100, 10, (int)(short)(-1));
    testRational0.mysimp((int)(byte)1, (int)(byte)10, (int)'4', 100, (int)'4', (int)(byte)10);
    testRational0.mysimp((int)(byte)0, (int)(short)(-1), (int)(short)100, (-1), 10, (int)' ');

  }

  @Test
  public void test028() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test028"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)(byte)100, (int)' ', 10, (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp((int)' ', 1, 1, (int)'a', 0, (int)'#');
    testRational0.mysimp((int)(byte)0, 10, 0, (int)(byte)(-1), (int)(byte)100, (int)(byte)100);
    testRational0.mysimp((int)(byte)10, 0, (int)' ', (int)(byte)0, (-1), (int)(byte)0);
    testRational0.mysimp(0, (int)' ', (int)(byte)0, (int)(byte)10, 0, (int)(short)0);
    testRational0.mysimp((int)'#', (int)'a', 1, (int)'4', (-1), (int)(short)(-1));
    testRational0.mysimp((int)'4', (-1), (int)'#', (int)(byte)100, (int)(byte)1, (int)(short)(-1));

  }

  @Test
  public void test029() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test029"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'a', (int)(byte)0, 0, (int)(short)0, 0);
    testRational0.mysimp((int)(short)10, (int)(byte)0, (int)'a', (int)(byte)0, (int)(byte)0, (int)(byte)(-1));
    testRational0.mysimp(1, 1, (int)(short)0, (-1), (int)(byte)1, (int)(byte)1);
    testRational0.mysimp((int)(byte)100, (int)(byte)1, (int)(short)10, (int)(short)(-1), (-1), (int)(short)1);
    testRational0.mysimp(100, (int)(short)0, (int)(short)1, 0, 100, (int)(byte)1);
    testRational0.mysimp(1, (int)'a', 0, (int)'#', (int)(short)0, (int)'#');
    testRational0.mysimp((int)' ', (-1), (int)' ', (int)'4', (int)'a', 100);

  }

  @Test
  public void test030() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test030"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)' ', 10, (int)' ', (int)(short)0, 0, (int)(short)1);
    testRational0.mysimp((int)(short)1, (int)' ', (int)(short)100, (int)(short)100, (int)(byte)100, 10);
    testRational0.mysimp((int)'#', (int)'a', (int)(short)0, (int)(short)10, 1, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(byte)(-1), 0, (int)(byte)(-1), (int)'a', (-1));

  }

  @Test
  public void test031() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test031"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(10, (int)(short)100, (int)' ', (int)(byte)1, (int)(short)(-1), 0);
    testRational0.mysimp((int)(byte)(-1), (int)'#', 0, (int)(short)(-1), (int)'#', (int)'#');
    testRational0.mysimp((int)'a', (int)(byte)1, (int)(byte)(-1), 0, (int)(byte)10, 100);
    testRational0.mysimp((-1), 0, (int)(byte)0, (int)(short)0, 0, (int)(byte)0);
    testRational0.mysimp((int)(byte)0, 0, (int)(short)100, (int)(short)10, (int)(byte)1, (int)'4');

  }

  @Test
  public void test032() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test032"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(10, (int)(short)100, (int)(short)10, (int)(short)100, (int)(byte)10, 0);
    testRational0.mysimp((int)(byte)10, (int)(byte)10, (int)(byte)0, (int)'#', (int)(short)0, 0);
    testRational0.mysimp(10, (int)(short)(-1), (int)(byte)0, 0, (int)(byte)100, (int)(byte)1);
    testRational0.mysimp((int)(short)100, 10, (int)(short)10, 0, (int)(short)100, 1);
    testRational0.mysimp(0, (int)'4', 10, (int)(byte)100, (int)(byte)10, (int)(byte)10);
    testRational0.mysimp(10, (-1), (int)(byte)(-1), 100, (int)(short)100, (int)(byte)10);
    testRational0.mysimp((-1), 0, (int)(short)10, (-1), 10, 0);

  }

  @Test
  public void test033() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test033"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)(short)1, (int)(byte)10, (int)(byte)100, 1, (int)(byte)10, (int)(byte)(-1));
    testRational0.mysimp((int)(short)100, 0, (int)'4', (int)'4', (int)(short)1, (int)(byte)(-1));
    testRational0.mysimp((int)(short)10, (-1), 10, (int)(byte)(-1), (int)(short)(-1), (int)(short)0);
    testRational0.mysimp((int)(byte)10, 10, 0, 1, 0, (int)(byte)(-1));
    testRational0.mysimp((int)(byte)1, (int)'#', (int)' ', 10, 100, (int)'4');
    testRational0.mysimp(0, 10, (int)' ', (int)(short)100, (int)(short)100, 0);

  }

  @Test
  public void test034() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test034"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(byte)0, (int)(short)0, 10, (int)(byte)(-1), (int)'4', (int)(byte)0);
    testRational0.mysimp((int)(byte)10, (int)(short)10, (int)'4', (int)(byte)(-1), (int)' ', 1);
    testRational0.mysimp((int)'#', (int)'a', (int)(short)100, (int)(byte)10, (int)(byte)0, (int)' ');
    testRational0.mysimp((-1), (int)(byte)1, (int)' ', 1, (int)(short)10, (int)'4');

  }

  @Test
  public void test035() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test035"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'a', (int)(byte)0, 0, (int)(short)0, 0);
    testRational0.mysimp((int)(short)10, (int)(byte)0, (int)'a', (int)(byte)0, (int)(byte)0, (int)(byte)(-1));
    testRational0.mysimp((int)(short)10, 1, (-1), 100, 1, (int)(byte)10);
    testRational0.mysimp(1, (int)(short)0, (int)(short)1, 0, (int)' ', 0);
    testRational0.mysimp((int)(short)10, (int)(short)(-1), (int)' ', (int)' ', (int)(short)(-1), 0);
    testRational0.mysimp((int)'#', (int)(short)10, (int)' ', (int)(short)(-1), (int)'4', (int)(short)10);
    testRational0.mysimp(1, (int)(short)(-1), (int)(byte)1, (int)(byte)(-1), (int)(short)100, (int)(byte)10);
    testRational0.mysimp((int)(short)0, (int)'a', (int)(short)(-1), (int)(short)(-1), 0, (int)(byte)100);

  }

  @Test
  public void test036() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test036"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(byte)100, (int)(byte)1, (int)(byte)(-1), 1, (int)(byte)0, 10);
    testRational0.mysimp((int)(byte)10, (int)'4', (int)(byte)(-1), (int)(byte)100, (int)(byte)(-1), (int)' ');
    testRational0.mysimp(0, (int)(byte)1, (int)(byte)100, (int)(byte)0, 100, (int)(byte)0);
    testRational0.mysimp(10, (int)(byte)100, (-1), 1, 10, (int)(byte)1);

  }

  @Test
  public void test037() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test037"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)10, (int)'#', 0, (-1));
    testRational0.mysimp((int)'4', (int)(byte)(-1), (int)(byte)100, (int)(short)1, (int)'#', 100);
    testRational0.mysimp((int)(byte)10, (int)'a', (int)(short)100, (int)'#', (int)(short)10, (int)(short)100);
    testRational0.mysimp((int)(short)100, 0, (int)(byte)0, 100, 100, 1);
    testRational0.mysimp(10, 100, (int)'a', (int)'4', (int)'4', (int)'#');
    testRational0.mysimp((int)(byte)(-1), 0, (-1), 0, (-1), 100);
    testRational0.mysimp((int)(byte)0, (int)'#', (int)(short)10, (-1), (int)' ', (int)(byte)0);
    testRational0.mysimp(10, (-1), (int)(byte)1, (int)(short)10, (int)(byte)0, (-1));

  }

  @Test
  public void test038() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test038"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 0, (-1), 100, (int)'a');
    testRational0.mysimp(10, (int)(short)0, 100, (int)'4', (-1), 0);
    testRational0.mysimp(0, (int)(byte)(-1), 100, (int)(short)1, (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp((int)(byte)0, (int)'4', 100, (int)(byte)1, (int)(byte)10, 0);
    testRational0.mysimp((int)(byte)0, 0, (int)(short)(-1), (int)'#', (int)(byte)0, (int)(short)1);
    testRational0.mysimp((int)(byte)0, 10, (int)'4', (int)(short)(-1), 1, (int)(byte)(-1));
    testRational0.mysimp((int)(short)100, (int)'a', 0, 10, 0, (int)(short)1);
    testRational0.mysimp(0, (int)(short)0, 0, 0, (int)(short)(-1), 1);
    testRational0.mysimp((int)(short)10, (int)(byte)10, 0, (int)(short)100, (int)(short)100, (int)(byte)0);
    testRational0.mysimp((int)(short)10, (int)(byte)1, (int)(short)100, (int)(byte)100, (int)(byte)100, (int)(short)100);
    testRational0.mysimp(100, (int)' ', (int)'#', (int)(byte)100, (int)(byte)1, (-1));

  }

  @Test
  public void test039() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test039"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)(byte)100, (int)' ', 10, (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp((int)' ', 1, 1, (int)'a', 0, (int)'#');
    testRational0.mysimp((int)(short)0, (int)'4', 0, (int)'#', (int)'4', (int)' ');
    testRational0.mysimp(0, 10, (int)(short)10, (int)'a', 0, 10);
    testRational0.mysimp((int)(short)0, 1, (int)(byte)1, (int)(short)0, (-1), 100);
    testRational0.mysimp(10, (int)(byte)1, (int)(byte)10, (int)(byte)(-1), (-1), (int)(short)1);

  }

  @Test
  public void test040() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test040"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(byte)(-1), (int)(short)(-1), (int)(short)10, 0, (int)(byte)100, 1);
    testRational0.mysimp(100, (int)(short)1, 10, (int)' ', (int)'a', 1);
    testRational0.mysimp(10, 100, (int)(byte)0, (int)' ', (int)(byte)10, (int)(byte)0);
    testRational0.mysimp((int)(byte)(-1), (int)' ', (int)'4', 0, 10, (int)'a');
    testRational0.mysimp((int)'#', 0, (int)'a', (-1), (int)(short)10, 0);
    testRational0.mysimp((int)(short)1, (int)'#', (int)(short)1, (int)(byte)1, (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(byte)0, (int)(short)1, (int)' ', (int)(short)100, (int)'4', (int)(short)100);
    testRational0.mysimp((-1), (int)(short)0, (int)(short)100, (int)(short)1, (int)(short)100, (int)(byte)100);

  }

  @Test
  public void test041() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test041"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)(byte)100, (int)' ', 10, (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp((int)' ', 1, 1, (int)'a', 0, (int)'#');
    testRational0.mysimp((int)(short)1, (int)'#', (int)(short)(-1), (-1), 100, (int)(byte)100);
    testRational0.mysimp(10, (int)(byte)(-1), (int)(byte)(-1), 0, (int)(byte)10, (int)(byte)100);
    testRational0.mysimp((int)(byte)1, (int)(byte)1, (int)(short)(-1), (int)' ', (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp(1, (-1), (int)(byte)100, (int)(short)10, (int)(byte)100, (-1));
    testRational0.mysimp(1, (int)(short)1, (int)(short)10, (int)'a', (int)(byte)(-1), 0);
    testRational0.mysimp((int)(byte)10, 0, (int)(short)1, (int)(byte)1, (int)(short)0, (int)(short)1);
    testRational0.mysimp((int)(byte)100, (int)(byte)1, (int)'4', 10, (int)'#', (int)(byte)(-1));
    testRational0.mysimp(0, (int)(byte)(-1), (int)(short)(-1), (int)(short)0, 100, (int)(byte)10);
    testRational0.mysimp((-1), (int)(short)1, (int)(byte)(-1), 0, 10, 0);

  }

  @Test
  public void test042() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test042"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)1, (int)(short)(-1), (int)(short)1, (int)(byte)(-1), (int)'#', (int)(byte)(-1));
    testRational0.mysimp(0, (-1), 1, 100, (int)(byte)0, 100);
    testRational0.mysimp((int)(short)100, (-1), 1, (int)(byte)10, 1, (int)'#');

  }

  @Test
  public void test043() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test043"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, 100, 100);
    testRational0.mysimp(0, (int)'4', (int)' ', (int)(byte)100, (int)(byte)1, (int)(short)100);
    testRational0.mysimp((int)(short)100, (int)(byte)0, (int)(short)100, (int)' ', 0, (-1));
    testRational0.mysimp((int)' ', (int)(byte)(-1), (int)'4', (int)(byte)(-1), (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)100, (int)'4', (int)(short)1, 0, 100, (int)(byte)10);
    testRational0.mysimp((int)(short)1, (int)' ', (int)'#', (int)'#', (int)' ', (int)(short)100);
    testRational0.mysimp((-1), 0, (int)' ', (int)' ', (int)'a', (int)(byte)10);
    testRational0.mysimp((int)(short)10, 10, (int)(short)100, (int)(short)1, 0, (int)(short)(-1));
    testRational0.mysimp((int)(byte)0, (int)' ', (int)'a', 1, (int)(short)100, (int)(short)(-1));
    testRational0.mysimp((int)(byte)1, (int)(byte)1, (int)(short)(-1), (int)(byte)10, (int)(short)10, (int)(short)1);
    testRational0.mysimp(1, (int)(byte)0, 10, (int)(byte)10, 10, (int)'4');
    testRational0.mysimp((int)(byte)0, (int)'#', 1, (int)(short)(-1), (int)(short)10, 1);
    testRational0.mysimp((int)(short)(-1), (int)(short)100, (int)(short)(-1), (int)' ', (int)(byte)1, (int)'4');

  }

  @Test
  public void test044() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test044"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)' ', (int)(byte)0, (int)(byte)1, (int)(byte)100, 10, (int)'4');
    testRational0.mysimp((int)(short)(-1), (int)'a', 100, (int)' ', (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp((int)(short)10, (int)(byte)0, (int)(short)0, (-1), (-1), (int)(short)100);
    testRational0.mysimp((-1), (int)(byte)10, (int)(short)10, 0, (int)(byte)1, (int)(byte)10);
    testRational0.mysimp((int)'#', 10, (int)'4', (int)'#', (int)(short)10, (int)'4');
    testRational0.mysimp((int)(byte)0, (int)(short)10, (int)(byte)10, (int)(short)1, 0, (int)(byte)(-1));
    testRational0.mysimp((-1), (int)(byte)0, (int)' ', 0, (int)(short)0, (int)(byte)100);

  }

  @Test
  public void test045() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test045"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)10, (int)'#', 0, (-1));
    testRational0.mysimp((int)(byte)1, (int)(byte)100, (int)' ', (int)(short)0, (int)(short)100, 0);
    testRational0.mysimp((int)(byte)0, (int)(short)10, (int)'4', (int)'4', (int)'a', (int)'4');
    testRational0.mysimp((int)'4', (int)'#', (int)(byte)10, (int)(byte)(-1), (int)(byte)(-1), (int)(short)(-1));
    testRational0.mysimp(10, (int)(byte)100, (int)(byte)1, (int)(short)100, 100, 1);
    testRational0.mysimp((int)'#', (int)(short)10, (int)(short)100, (int)' ', (int)'#', 10);

  }

  @Test
  public void test046() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test046"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)' ', 10, (int)' ', (int)(short)0, 0, (int)(short)1);
    testRational0.mysimp((int)(short)1, (int)' ', (int)(short)100, (int)(short)100, (int)(byte)100, 10);
    testRational0.mysimp((int)'a', (int)(short)1, (-1), (int)(short)0, (int)(byte)100, (int)(byte)(-1));
    testRational0.mysimp((int)(byte)10, (int)'#', (int)(byte)0, (int)(short)1, 0, (int)(byte)10);
    testRational0.mysimp((int)(short)100, (int)' ', (int)(short)0, (int)(short)0, 100, (int)(short)1);
    testRational0.mysimp((int)'a', (int)(short)10, (int)'4', (int)(byte)0, (int)(short)100, (int)(byte)10);
    testRational0.mysimp((int)(short)10, (int)(short)10, (int)'a', (-1), (int)(short)10, (int)'#');

  }

  @Test
  public void test047() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test047"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(10, (int)(short)100, (int)' ', (int)(byte)1, (int)(short)(-1), 0);
    testRational0.mysimp((int)(short)(-1), 100, 1, 0, (int)(short)10, (int)(byte)10);
    testRational0.mysimp((int)'4', (int)(short)100, (int)'4', 100, 1, (int)'#');
    testRational0.mysimp((int)(byte)0, (int)(byte)0, (int)(byte)(-1), 100, (int)(byte)10, (int)(byte)1);
    testRational0.mysimp(10, (-1), (int)(byte)10, (int)(byte)100, (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp((int)(short)100, (int)(byte)100, (int)(byte)1, (int)(byte)1, (int)' ', (int)'#');

  }

  @Test
  public void test048() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test048"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)1, (int)(short)10, 0, 1, (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp((int)(byte)0, (-1), (int)' ', 100, (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp((int)(byte)0, (int)' ', 10, (int)(byte)10, (int)(short)0, (int)(byte)100);

  }

  @Test
  public void test049() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test049"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)(short)1, (int)(byte)10, (int)(byte)100, 1, (int)(byte)10, (int)(byte)(-1));
    testRational0.mysimp(0, (int)(short)(-1), (int)(short)0, (int)(byte)0, (int)' ', 1);
    testRational0.mysimp((int)(short)1, (int)(byte)100, 10, (int)(byte)0, (int)' ', (int)(byte)0);
    testRational0.mysimp((-1), 10, (int)'4', (int)(byte)0, (int)' ', (-1));
    testRational0.mysimp((-1), 1, (int)(short)10, 0, (int)'4', (int)(short)1);
    testRational0.mysimp((int)'#', (int)(short)100, 100, (int)(byte)10, 0, (int)(short)10);
    testRational0.mysimp(0, (int)(byte)10, 100, (int)(short)(-1), (int)(short)(-1), 0);
    testRational0.mysimp((int)(byte)100, 10, (int)(short)(-1), 1, (int)(byte)0, (int)(byte)100);
    testRational0.mysimp((int)(byte)10, 0, (int)(short)10, (int)'#', (int)(short)10, 10);

  }

  @Test
  public void test050() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test050"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp((int)(byte)100, (int)(byte)0, 1, (int)(byte)10, (int)(short)100, 1);
    testRational0.mysimp((int)'#', (int)(byte)0, (int)(byte)100, (int)(byte)10, (int)'4', (int)(byte)(-1));
    testRational0.mysimp((int)(short)0, (int)(byte)10, (int)(byte)10, (int)(byte)10, (-1), 0);
    testRational0.mysimp((int)'4', (int)' ', (int)(short)(-1), (int)(short)100, (int)'4', (int)(short)1);
    testRational0.mysimp((int)(short)10, 1, (int)(byte)1, (int)(short)10, 0, (int)(short)0);
    testRational0.mysimp((int)(short)100, 100, (int)(short)0, (int)(byte)100, (int)(byte)0, (int)(short)0);
    testRational0.mysimp((int)(short)10, (int)(short)0, (-1), 100, (int)(byte)1, (int)' ');
    testRational0.mysimp((int)(short)1, (int)(byte)100, (int)'a', 0, (int)(short)10, (int)'4');
    testRational0.mysimp((int)'#', (int)(short)0, (int)(short)100, (int)(byte)100, (int)(short)(-1), 10);

  }

  @Test
  public void test051() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test051"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(byte)100, (int)(byte)1, (int)(byte)(-1), 1, (int)(byte)0, 10);
    testRational0.mysimp((int)(byte)(-1), 10, (-1), (int)(byte)1, (int)(byte)0, 10);
    testRational0.mysimp((int)(byte)100, (int)'#', (int)(byte)1, 10, 1, (int)(byte)0);
    testRational0.mysimp(0, (int)(byte)(-1), (int)(short)1, (int)(byte)100, (-1), (-1));
    testRational0.mysimp(1, (int)(short)10, (int)' ', 10, 10, 10);
    testRational0.mysimp(0, (int)(short)10, (int)'#', (int)(short)100, (int)'#', (int)(short)100);
    testRational0.mysimp(0, 100, (int)(byte)100, (int)' ', 0, (int)(short)10);

  }

  @Test
  public void test052() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test052"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)1, 1, (int)(short)1, 0);
    testRational0.mysimp((int)(byte)100, (int)(byte)100, (int)(short)1, (int)(short)10, (int)(short)1, (int)(short)0);
    testRational0.mysimp((int)'a', (int)(short)0, (int)(byte)1, (int)(byte)10, (int)(byte)100, 0);
    testRational0.mysimp((int)(byte)100, 1, (int)(short)1, (int)'4', (int)(byte)100, (int)(short)100);
    testRational0.mysimp((int)(byte)0, (int)(byte)10, 0, (int)(short)0, 100, (int)(byte)10);
    testRational0.mysimp(1, (int)(short)(-1), (int)(byte)0, 0, (int)(short)(-1), (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)(short)10, (int)(short)100, (int)(byte)0, (int)(byte)(-1), (int)(short)(-1));
    testRational0.mysimp((int)(byte)0, 0, (int)' ', (int)(short)10, 100, 0);

  }

  @Test
  public void test053() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test053"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 0, (-1), 100, (int)'a');
    testRational0.mysimp(0, (int)'4', (int)(byte)0, (int)(short)0, 0, (int)(short)100);
    testRational0.mysimp((int)(short)1, (int)(short)(-1), (int)(short)0, 0, 10, (int)(byte)0);
    testRational0.mysimp(1, (int)(short)(-1), (int)(byte)10, (int)(byte)0, (int)(byte)100, (int)(short)1);
    testRational0.mysimp(10, (int)'a', (int)(short)100, 0, (-1), (int)(byte)10);
    testRational0.mysimp((int)(byte)10, (int)(short)10, 0, (int)(byte)1, 100, (int)(byte)10);
    testRational0.mysimp((int)(short)10, (int)(short)(-1), (int)'a', 100, (int)(byte)10, (int)'4');

  }

  @Test
  public void test054() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test054"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(10, (int)(short)100, (int)' ', (int)(byte)1, (int)(short)(-1), 0);
    testRational0.mysimp((int)(byte)100, (int)(short)(-1), (int)(byte)10, (int)(byte)100, (-1), 100);
    testRational0.mysimp((int)(short)10, (int)(byte)(-1), (int)(byte)0, (int)'#', (int)' ', (int)(byte)10);
    testRational0.mysimp((int)'#', (int)(short)10, (int)(short)0, (int)'a', (int)(short)0, (int)(short)1);
    testRational0.mysimp((int)(byte)0, (int)(byte)1, 1, (int)(short)100, (int)(short)100, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)'#', (int)(short)100, (int)(byte)100, (int)'#', (int)(byte)0);
    testRational0.mysimp((int)(short)(-1), (int)(short)1, (int)(short)100, (int)(short)0, 100, 1);
    testRational0.mysimp((int)'4', (int)' ', (int)'#', (int)(byte)10, 10, (int)' ');
    testRational0.mysimp((int)(byte)(-1), (-1), (int)'4', (int)(short)10, (int)(byte)100, (int)(short)1);

  }

  @Test
  public void test055() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test055"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(10, (int)(short)100, (int)(short)10, (int)(short)100, (int)(byte)10, 0);
    testRational0.mysimp(10, (int)'4', (int)(byte)0, (int)(byte)(-1), 0, 1);
    testRational0.mysimp((int)(short)(-1), (int)(short)(-1), 0, 100, (int)(byte)100, (int)(short)10);
    testRational0.mysimp((int)(byte)0, 0, (int)(byte)1, (-1), (int)'4', (int)(short)10);
    testRational0.mysimp((int)(short)1, 1, (int)'#', (int)(short)10, 0, (int)(byte)10);
    testRational0.mysimp(1, 1, (int)(byte)0, (int)(byte)0, (int)(short)1, (int)(byte)(-1));
    testRational0.mysimp((int)(byte)100, 1, 0, (int)(short)10, (int)(short)(-1), (int)' ');
    testRational0.mysimp((int)(byte)1, (int)'#', 100, (int)(short)1, (int)(short)0, (int)'a');
    testRational0.mysimp(0, (int)' ', (-1), (int)(byte)0, (int)' ', (int)(short)(-1));

  }

  @Test
  public void test056() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test056"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)' ', 10, (int)' ', (int)(short)0, 0, (int)(short)1);
    testRational0.mysimp((int)(short)1, (int)' ', (int)(short)100, (int)(short)100, (int)(byte)100, 10);
    testRational0.mysimp((int)'#', (int)'a', (int)(short)0, (int)(short)10, 1, (int)'a');
    testRational0.mysimp((int)(short)1, 0, (int)(short)(-1), (int)(byte)(-1), 100, (int)'#');
    testRational0.mysimp(10, 0, (int)' ', (int)(short)(-1), (-1), (int)(short)10);
    testRational0.mysimp(0, (-1), (int)(short)100, (int)(short)10, (int)(short)10, (int)(byte)1);
    testRational0.mysimp((int)' ', (int)(short)10, (int)' ', (int)(short)100, (int)(short)0, (int)'4');

  }

  @Test
  public void test057() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test057"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(100, 100, 0, 1, (int)'a', 0);
    testRational0.mysimp((int)(byte)10, (int)(byte)1, (int)(short)(-1), (int)(short)(-1), (int)(byte)10, 0);
    testRational0.mysimp((int)(byte)10, 100, (int)' ', (int)(byte)1, 1, (int)'4');
    testRational0.mysimp(1, (int)(byte)100, 0, 100, 0, (int)' ');
    testRational0.mysimp((int)(byte)100, 100, (int)(byte)0, (int)'#', (int)(short)100, (int)(byte)(-1));
    testRational0.mysimp((int)(byte)100, (int)(byte)0, (int)(short)(-1), (int)(byte)0, (-1), (int)(byte)100);
    testRational0.mysimp((-1), 1, (int)(byte)1, (int)(byte)100, (int)'4', (int)(short)(-1));
    testRational0.mysimp((int)(byte)10, (int)(short)0, (-1), (int)(short)1, (int)(byte)(-1), 1);

  }

  @Test
  public void test058() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test058"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)' ', (int)(byte)0, (int)(byte)1, (int)(byte)100, 10, (int)'4');
    testRational0.mysimp((int)(short)(-1), (int)'a', 100, (int)' ', (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp((int)(short)10, 0, (int)'a', (int)'#', (int)'4', (int)(short)0);
    testRational0.mysimp(1, (int)(byte)0, (int)(short)(-1), (int)'#', (int)'#', 1);
    testRational0.mysimp((int)'a', 10, (int)(byte)1, (int)(short)10, (int)' ', (int)(short)10);
    testRational0.mysimp((-1), 0, (int)' ', (int)'#', (int)(byte)0, (int)(short)1);
    testRational0.mysimp((int)(byte)1, (int)(short)(-1), (int)(short)0, 0, 0, (int)(byte)(-1));
    testRational0.mysimp((int)(short)0, (int)(byte)0, (int)(short)10, (int)(byte)100, (int)(byte)10, (int)(byte)1);

  }

  @Test
  public void test059() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test059"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(10, (int)'a', (int)(short)10, (int)(short)(-1), (int)(byte)0, (int)'a');
    testRational0.mysimp((int)(byte)100, (int)(short)0, (int)'a', (int)(byte)(-1), 0, (int)(short)(-1));
    testRational0.mysimp((int)(byte)10, 0, (int)(short)(-1), (int)(short)1, 0, (int)(byte)0);
    testRational0.mysimp(100, (-1), (int)(short)100, (int)(byte)10, 10, (int)(byte)(-1));
    testRational0.mysimp((int)(short)100, (-1), 100, (int)(byte)100, (int)(short)10, (int)(short)(-1));
    testRational0.mysimp((int)(short)100, (int)(byte)(-1), 1, 100, (int)' ', (int)(short)(-1));
    testRational0.mysimp((int)' ', 10, (int)' ', 10, (int)(byte)100, (int)(byte)100);
    testRational0.mysimp((int)' ', 0, (int)'#', (int)(byte)(-1), (-1), 10);

  }

  @Test
  public void test060() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test060"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 0, (-1), 100, (int)'a');
    testRational0.mysimp(10, (int)(short)0, 100, (int)'4', (-1), 0);
    testRational0.mysimp(0, (int)(byte)(-1), 100, (int)(short)1, (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp((int)(byte)0, (int)'4', 100, (int)(byte)1, (int)(byte)10, 0);
    testRational0.mysimp((int)(byte)0, 0, (int)(short)(-1), (int)'#', (int)(byte)0, (int)(short)1);
    testRational0.mysimp((int)(byte)0, 10, (int)'4', (int)(short)(-1), 1, (int)(byte)(-1));
    testRational0.mysimp((int)(short)100, (int)'a', 0, 10, 0, (int)(short)1);
    testRational0.mysimp(0, (int)(short)0, 0, 0, (int)(short)(-1), 1);
    testRational0.mysimp((int)(short)100, (int)(short)(-1), (int)(byte)0, 0, 0, (int)(short)0);
    testRational0.mysimp((int)(short)100, (int)(short)100, (int)'a', (int)(byte)100, 1, (int)(byte)100);
    testRational0.mysimp((int)(byte)10, (int)'a', (int)(short)0, (-1), (int)(short)100, (int)(short)10);
    testRational0.mysimp((int)(byte)10, 10, 10, (int)(short)(-1), (int)(short)100, (int)(short)0);

  }

  @Test
  public void test061() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test061"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)1, 1, (int)(short)1, 0);
    testRational0.mysimp((int)' ', (int)' ', (int)(byte)10, (int)'4', (int)'4', (int)(short)10);
    testRational0.mysimp((int)(short)1, (int)'4', (int)(short)10, (int)'#', (int)'#', (int)(short)100);
    testRational0.mysimp((int)(short)10, (int)(byte)0, 100, (-1), (int)'4', (int)(byte)0);
    testRational0.mysimp((int)(byte)0, (int)(byte)10, (int)(short)1, (int)(byte)10, (-1), 10);

  }

  @Test
  public void test062() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test062"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, 100, 100);
    testRational0.mysimp((int)(byte)(-1), (int)'a', (-1), (int)'4', (-1), (int)(byte)0);
    testRational0.mysimp((int)(short)100, (int)'#', (int)(byte)100, (int)(short)(-1), (int)(short)10, 10);
    testRational0.mysimp(10, (int)(short)1, (int)(short)0, 100, (int)' ', (int)(byte)0);
    testRational0.mysimp(100, 10, (int)(byte)(-1), (int)(short)0, (int)(short)10, 1);
    testRational0.mysimp((int)'#', (int)(short)(-1), (int)'4', (int)(byte)100, (int)(short)1, 0);

  }

  @Test
  public void test063() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test063"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(short)(-1), (int)(short)10, (int)' ', 0, (int)(byte)100, (int)' ');
    testRational0.mysimp((int)' ', 0, (int)(byte)100, 100, (int)(byte)10, 0);
    testRational0.mysimp(0, (int)(byte)(-1), 1, (int)(byte)1, (int)(byte)(-1), (int)'a');
    testRational0.mysimp((int)(byte)10, 10, (int)(byte)(-1), (-1), (int)(byte)100, 0);
    testRational0.mysimp(10, (int)(byte)0, 10, (int)(short)(-1), (int)(short)0, 10);
    testRational0.mysimp(1, (int)'4', (int)'#', (int)'4', 0, (int)(short)(-1));
    testRational0.mysimp((int)(short)1, (int)' ', (int)(byte)1, (int)(short)10, (int)(short)100, (int)(byte)(-1));
    testRational0.mysimp((int)(byte)(-1), (int)'#', (int)(short)1, 0, (-1), (int)(byte)100);

  }

  @Test
  public void test064() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test064"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)' ', 10, (int)' ', (int)(short)0, 0, (int)(short)1);
    testRational0.mysimp((int)(short)1, (int)(short)(-1), (int)(short)100, (int)'4', 1, (int)(short)100);
    testRational0.mysimp(1, (int)(short)1, (int)(byte)100, 1, (int)(byte)1, (int)(short)0);
    testRational0.mysimp((int)' ', (int)(byte)(-1), 10, (int)(short)1, (int)(short)0, (int)(short)(-1));

  }

  @Test
  public void test065() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test065"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)'4', (int)(byte)(-1), 10, (int)(short)0, 0);
    testRational0.mysimp((-1), 100, 0, (int)(byte)100, (int)(byte)(-1), (int)(byte)0);
    testRational0.mysimp(100, (int)'#', (int)'#', 100, 1, 1);
    testRational0.mysimp(1, (int)(byte)0, 10, (int)' ', (int)(byte)10, (int)'a');
    testRational0.mysimp((int)(short)10, (int)(byte)0, (int)'a', (int)'a', (int)(byte)(-1), (-1));
    testRational0.mysimp((int)(byte)100, (int)'#', (int)'4', (int)'4', (int)(short)(-1), 0);
    testRational0.mysimp(0, (int)(byte)10, (int)'#', 0, 10, (int)(byte)100);

  }

  @Test
  public void test066() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test066"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)'a', (int)(short)100, (int)(short)10, 0, 100, (int)(short)1);
    testRational0.mysimp(100, (int)(short)1, (int)' ', (int)(byte)10, (int)(short)1, (int)(byte)0);
    testRational0.mysimp(10, (int)(short)100, (int)' ', (int)(byte)0, (int)(byte)0, 10);
    testRational0.mysimp(0, (-1), 0, 1, 0, (int)'a');
    testRational0.mysimp(1, (int)(byte)(-1), 0, (int)(short)100, (int)(short)10, (int)(short)1);
    testRational0.mysimp(0, (-1), 0, (int)(byte)0, 100, (int)(byte)0);
    testRational0.mysimp(0, 1, (int)(byte)0, (int)(byte)100, (int)(short)(-1), (int)(short)0);
    testRational0.mysimp((int)' ', (int)(byte)10, 0, 100, 100, 10);

  }

  @Test
  public void test067() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test067"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(10, (int)(short)100, (int)' ', (int)(byte)1, (int)(short)(-1), 0);
    testRational0.mysimp((int)(short)(-1), 100, 1, 0, (int)(short)10, (int)(byte)10);
    testRational0.mysimp(100, (-1), (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)(-1));
    testRational0.mysimp((int)(byte)1, (int)(byte)0, (int)(byte)100, 100, (int)(byte)1, 100);
    testRational0.mysimp(1, (int)(short)100, (int)(short)(-1), 0, (int)(byte)100, (int)'#');
    testRational0.mysimp((int)(byte)(-1), (int)(byte)100, (int)(byte)100, (int)(byte)(-1), 100, 100);
    testRational0.mysimp((int)(short)10, (int)(byte)1, (int)(short)0, (int)'#', 100, 0);
    testRational0.mysimp(10, (-1), (int)(short)(-1), 1, 0, (int)(short)(-1));

  }

  @Test
  public void test068() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test068"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)10, (int)'#', 0, (-1));
    testRational0.mysimp((int)'#', (int)'a', (int)(byte)1, (int)' ', 0, (int)'4');
    testRational0.mysimp(0, (int)' ', 100, (int)'4', (int)'a', 0);
    testRational0.mysimp((int)(short)0, (int)(byte)0, 100, (-1), 1, 10);
    testRational0.mysimp((int)(short)10, (int)' ', (int)' ', (int)(byte)100, (int)'4', (int)'#');
    testRational0.mysimp(0, (int)(short)100, (int)(byte)100, (int)(short)10, (int)(byte)1, (int)(byte)0);
    testRational0.mysimp((int)(byte)(-1), (int)(byte)100, (int)(short)1, (int)(short)1, (int)' ', 100);
    testRational0.mysimp((int)'#', 10, (int)(byte)1, (int)(short)(-1), (int)(short)100, 100);
    testRational0.mysimp((int)'4', (-1), (int)(byte)(-1), (int)(short)0, (int)(byte)1, 0);

  }

  @Test
  public void test069() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test069"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)'a', 100, 1, (int)(short)1, 0, 10);
    testRational0.mysimp((int)(byte)100, (int)'#', (int)(short)1, (int)(byte)0, (int)(short)(-1), (int)(byte)1);
    testRational0.mysimp((int)(byte)10, (int)'4', (int)(short)100, (int)(short)(-1), 0, (int)(byte)1);
    testRational0.mysimp((int)(byte)0, (int)(byte)100, (int)'4', (int)(byte)0, (int)(byte)1, (int)(short)10);
    testRational0.mysimp(10, (int)(byte)1, 0, (int)'a', 1, (-1));

  }

  @Test
  public void test070() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test070"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)100, (int)(short)0, (int)'4', (int)(short)100, 0, (int)(byte)(-1));
    testRational0.mysimp((int)(byte)1, (int)(byte)1, (int)(byte)10, 0, (int)'#', (int)(byte)1);
    testRational0.mysimp((int)'a', (int)(short)100, (int)'4', (int)(byte)(-1), (int)(byte)100, (int)(short)(-1));
    testRational0.mysimp(0, (int)(byte)0, (-1), (int)(byte)0, 1, 1);
    testRational0.mysimp(1, 1, (int)' ', (int)(byte)100, (int)(short)0, (int)'4');

  }

  @Test
  public void test071() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test071"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)10, (int)'#', 0, (-1));
    testRational0.mysimp(1, (-1), (int)(byte)1, (int)'4', (int)(byte)10, (int)(short)10);
    testRational0.mysimp((int)' ', (int)'#', (int)(short)(-1), 0, (int)(short)0, (int)'#');

  }

  @Test
  public void test072() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test072"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)' ', (int)(byte)0, (int)(byte)1, (int)(byte)100, 10, (int)'4');
    testRational0.mysimp((int)(short)(-1), (int)'a', 100, (int)' ', (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp((int)(short)10, (int)(byte)0, (int)(short)0, (-1), (-1), (int)(short)100);
    testRational0.mysimp((int)(short)0, 10, 1, 10, (-1), (int)'4');
    testRational0.mysimp((int)'#', (-1), 0, (int)' ', 10, (int)'4');
    testRational0.mysimp(0, (int)(byte)100, 1, (-1), (int)(byte)(-1), (int)(byte)100);
    testRational0.mysimp((int)'#', (int)(byte)1, 1, (int)(byte)0, (int)'#', (int)'4');

  }

  @Test
  public void test073() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test073"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(10, (int)(short)100, (int)(short)10, (int)(short)100, (int)(byte)10, 0);
    testRational0.mysimp(10, (int)'4', (int)(byte)0, (int)(byte)(-1), 0, 1);
    testRational0.mysimp((int)(byte)100, (int)(short)(-1), (int)(short)1, (int)(byte)(-1), 0, (int)(byte)100);
    testRational0.mysimp((int)'a', (int)(byte)0, 0, 1, (int)(byte)10, (int)(short)1);
    testRational0.mysimp((int)'a', (int)(byte)0, (int)(short)10, (int)(byte)0, (int)(short)100, (int)'#');
    testRational0.mysimp((int)(byte)10, 0, (int)(byte)1, (int)(short)100, (int)'4', 10);
    testRational0.mysimp((int)(byte)0, (int)(short)10, 10, (int)'a', 100, (int)(short)1);
    testRational0.mysimp(10, (int)(short)0, 10, 0, 0, (int)(byte)0);

  }

  @Test
  public void test074() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test074"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'a', (int)(byte)0, 0, (int)(short)0, 0);
    testRational0.mysimp(100, (int)(byte)10, (int)(byte)10, 10, 0, (int)(short)1);
    testRational0.mysimp(1, (int)(short)0, (int)(byte)1, (int)(short)(-1), 1, (int)(byte)(-1));
    testRational0.mysimp((int)(byte)10, (int)(byte)100, (int)(byte)0, 10, 1, (int)(byte)1);
    testRational0.mysimp((int)'4', (int)(short)10, (int)'4', (int)(short)(-1), (int)' ', (int)'4');
    testRational0.mysimp((-1), (int)'4', (int)(short)100, (int)(short)0, (int)(short)100, 1);

  }

  @Test
  public void test075() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test075"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(10, (int)(short)100, (int)' ', (int)(byte)1, (int)(short)(-1), 0);
    testRational0.mysimp((int)(byte)100, (int)(short)(-1), (int)(byte)10, (int)(byte)100, (-1), 100);
    testRational0.mysimp((int)(short)10, (int)(byte)(-1), (int)(byte)0, (int)'#', (int)' ', (int)(byte)10);
    testRational0.mysimp((int)' ', (int)(short)0, (int)(byte)10, 0, (int)(byte)1, (int)(short)1);
    testRational0.mysimp(10, (int)'#', 10, (int)(byte)(-1), (int)(short)1, 10);
    testRational0.mysimp((int)(byte)1, (int)(short)100, 10, (int)(byte)(-1), (int)'4', 0);
    testRational0.mysimp(0, (-1), (int)(short)100, (int)(short)1, (int)(short)100, (int)(byte)1);
    testRational0.mysimp((int)'4', (int)(short)10, 100, (int)(short)(-1), 0, 100);

  }

  @Test
  public void test076() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test076"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)1, 1, (int)(short)1, 0);
    testRational0.mysimp((int)(byte)100, (int)(byte)100, (int)(short)1, (int)(short)10, (int)(short)1, (int)(short)0);
    testRational0.mysimp((int)'a', (int)(short)0, (int)(byte)1, (int)(byte)10, (int)(byte)100, 0);
    testRational0.mysimp((int)(byte)100, 1, (int)(short)1, (int)'4', (int)(byte)100, (int)(short)100);
    testRational0.mysimp(0, 0, (-1), (int)(short)100, (int)(byte)1, (-1));
    testRational0.mysimp(10, 1, 0, (int)(short)10, (int)' ', 10);
    testRational0.mysimp(1, (int)' ', (int)'a', 0, (int)(byte)(-1), (int)(short)1);
    testRational0.mysimp((int)(short)10, (int)(short)10, 100, (int)(short)(-1), (int)(short)(-1), 10);
    testRational0.mysimp((int)(short)(-1), (int)'#', (int)(short)100, (int)(byte)1, (int)(short)100, (int)(byte)(-1));
    testRational0.mysimp((int)(short)100, (int)(short)0, (int)'4', (int)(short)0, 1, (int)(byte)0);

  }

  @Test
  public void test077() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test077"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)(short)(-1), 100, (int)(byte)10, (int)'4', (int)(short)(-1));
    testRational0.mysimp((int)' ', 1, (int)(byte)(-1), (int)(short)1, 10, (int)(byte)0);
    testRational0.mysimp((int)(byte)10, (int)(byte)1, (int)(byte)100, (int)(short)10, (int)(byte)1, (int)'4');
    testRational0.mysimp((-1), (int)(short)10, (int)(byte)100, (int)(short)1, (int)'#', 10);
    testRational0.mysimp((int)(short)100, (int)(short)10, (int)(short)10, (int)'#', 1, (int)(short)(-1));
    testRational0.mysimp(100, (-1), (int)'4', 0, (int)'#', (int)'4');
    testRational0.mysimp(0, (int)(short)(-1), 0, 0, 0, (int)(short)(-1));
    testRational0.mysimp(10, 0, (int)(short)1, 10, (int)(byte)0, (int)(byte)100);

  }

  @Test
  public void test078() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test078"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)' ', (int)(byte)0, (int)(byte)1, (int)(byte)100, 10, (int)'4');
    testRational0.mysimp((int)(short)(-1), (int)'a', 100, (int)' ', (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp((int)'4', (int)(short)1, (int)(byte)10, (int)(byte)10, (-1), (int)'a');
    testRational0.mysimp(10, (int)(byte)1, (int)'#', 100, 0, (int)(short)1);
    testRational0.mysimp((int)(short)10, (int)(byte)100, 0, 100, (int)(short)100, (int)(short)100);
    testRational0.mysimp(100, (int)(short)(-1), (int)'a', (int)(short)100, 10, (int)(short)10);

  }

  @Test
  public void test079() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test079"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'#', 1, (int)(short)10, (int)'4', (int)(short)1);
    testRational0.mysimp(0, (int)'#', 10, (int)(byte)0, (int)'a', (int)(byte)(-1));
    testRational0.mysimp((int)(short)0, (-1), (int)(short)100, (int)'a', 0, (int)(short)0);
    testRational0.mysimp((int)'#', 10, (int)(byte)1, (int)(short)(-1), (int)' ', (int)(short)10);
    testRational0.mysimp((int)(byte)0, (int)(short)10, 10, 1, (int)(byte)1, (int)(short)100);

  }

  @Test
  public void test080() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test080"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp((int)(byte)(-1), 0, (int)(short)100, (int)'4', (int)(short)100, (int)'a');
    testRational0.mysimp(0, (int)(byte)100, (int)'a', (int)'a', 1, 1);
    testRational0.mysimp((int)(byte)10, (int)'4', (int)'#', (int)(byte)10, (int)(byte)(-1), (int)(byte)100);
    testRational0.mysimp(100, (int)(byte)1, (int)'a', (int)(byte)100, 1, (int)'#');

  }

  @Test
  public void test081() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test081"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 0, (-1), 100, (int)'a');
    testRational0.mysimp(100, (int)'#', (int)(byte)0, (int)' ', (int)(short)0, (int)(short)10);
    testRational0.mysimp(1, (int)(short)(-1), (int)(short)10, (int)(short)100, 100, (int)(byte)100);
    testRational0.mysimp((int)(short)1, 10, (int)(short)10, (int)(short)1, (int)(short)(-1), 1);
    testRational0.mysimp(100, (int)(byte)10, 100, 10, (int)'4', (int)(short)1);

  }

  @Test
  public void test082() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test082"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)(short)100, (int)(byte)1, (int)(byte)0, 100, (int)(short)100);
    testRational0.mysimp((int)(short)(-1), 0, (int)(short)0, 10, 0, (int)(byte)10);
    testRational0.mysimp(0, (int)'#', 100, (int)' ', (int)(short)0, (int)(byte)1);
    testRational0.mysimp(0, (int)(byte)(-1), (int)(byte)(-1), (int)(short)0, 0, (int)(byte)1);
    testRational0.mysimp(0, 10, (int)(byte)10, (int)(short)0, (int)(byte)10, (int)(short)10);

  }

  @Test
  public void test083() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test083"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(10, (int)(short)100, (int)' ', (int)(byte)1, (int)(short)(-1), 0);
    testRational0.mysimp((int)(short)(-1), 100, 1, 0, (int)(short)10, (int)(byte)10);
    testRational0.mysimp((int)'4', (int)(short)100, (int)'4', 100, 1, (int)'#');
    testRational0.mysimp((int)(byte)0, (int)(byte)0, (int)(byte)(-1), 100, (int)(byte)10, (int)(byte)1);
    testRational0.mysimp((int)(byte)100, (int)(short)100, 0, (int)(short)10, (int)(short)0, (int)(short)1);
    testRational0.mysimp((int)(byte)1, (int)(byte)(-1), (int)(short)1, (int)'#', (int)(short)10, (int)(short)0);
    testRational0.mysimp(10, (int)(short)1, (int)'a', (int)(byte)10, (int)(short)(-1), 100);
    testRational0.mysimp((int)(byte)0, (int)'a', (int)(byte)1, (int)(short)100, (int)(byte)10, (int)(byte)100);

  }

  @Test
  public void test084() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test084"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(10, (int)(byte)100, (int)(byte)10, (int)(short)0, (int)(byte)0, (int)' ');
    testRational0.mysimp((int)(short)10, (int)(byte)10, (int)(short)100, (int)(byte)0, (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp((int)(short)(-1), (int)'#', (int)'#', (int)(short)10, (int)(byte)0, (int)(byte)100);
    testRational0.mysimp((int)(byte)0, (int)(short)1, (-1), (int)(byte)1, (int)(short)(-1), (int)'4');
    testRational0.mysimp(0, (int)(byte)0, (int)'4', 100, 0, 0);
    testRational0.mysimp(100, (int)'4', (int)(short)1, (int)'4', (int)(short)10, (int)' ');
    testRational0.mysimp((int)(short)0, 0, (int)(short)0, (int)(short)10, (int)(byte)100, (int)(byte)10);

  }

  @Test
  public void test085() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test085"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)10, (int)'#', 0, (-1));
    testRational0.mysimp((int)(byte)1, (int)(byte)100, (int)' ', (int)(short)0, (int)(short)100, 0);
    testRational0.mysimp(1, (int)(short)10, (int)(short)10, (int)(byte)1, (int)(short)1, (int)(short)100);
    testRational0.mysimp((int)(byte)(-1), 1, (int)(short)1, 100, (int)(short)0, 0);
    testRational0.mysimp(10, 100, 100, (int)(short)(-1), (int)' ', (int)(short)(-1));
    testRational0.mysimp((int)'4', (int)'a', 100, 1, (int)(byte)0, (int)' ');
    testRational0.mysimp((int)'#', (int)'a', 0, (int)(byte)1, (int)'#', (int)(byte)10);
    testRational0.mysimp((int)(short)100, (int)(short)100, 1, (int)(byte)1, (-1), (int)'#');

  }

  @Test
  public void test086() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test086"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(byte)100, (int)(byte)1, (int)(byte)(-1), 1, (int)(byte)0, 10);
    testRational0.mysimp((int)(byte)10, (int)'4', (int)(byte)(-1), (int)(byte)100, (int)(byte)(-1), (int)' ');
    testRational0.mysimp((int)(byte)100, (int)(byte)1, (int)(byte)0, (int)(byte)0, 10, (int)(short)(-1));
    testRational0.mysimp((int)(short)100, (int)(byte)100, (int)'4', 0, (int)(short)0, (int)(byte)0);
    testRational0.mysimp((int)(short)(-1), (int)(short)1, 10, (int)(byte)1, (int)' ', (int)(short)100);
    testRational0.mysimp(10, 10, (int)(short)0, (int)'#', (int)(short)100, (int)(byte)100);
    testRational0.mysimp((int)'a', (int)(byte)0, (int)(byte)10, (int)(short)10, (int)'a', 1);

  }

  @Test
  public void test087() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test087"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)' ', (int)(byte)0, (int)(byte)1, (int)(byte)100, 10, (int)'4');
    testRational0.mysimp((int)(short)(-1), (int)'a', 100, (int)' ', (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp((int)'4', (int)(short)1, (int)(byte)10, (int)(byte)10, (-1), (int)'a');
    testRational0.mysimp(10, (int)(byte)1, (int)'#', 100, 0, (int)(short)1);
    testRational0.mysimp((-1), 0, 1, (int)(byte)1, (int)(short)10, (int)(short)(-1));
    testRational0.mysimp((int)(byte)1, (int)(byte)1, 1, (int)(byte)100, (int)(byte)0, 10);
    testRational0.mysimp((int)(short)10, (int)'a', (int)(short)100, 100, (int)(byte)1, (int)(byte)100);

  }

  @Test
  public void test088() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test088"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)' ', (int)(byte)0, (int)(byte)1, (int)(byte)100, 10, (int)'4');
    testRational0.mysimp(0, (int)(short)100, (int)(byte)1, (int)' ', (int)(short)100, (int)(short)1);
    testRational0.mysimp(10, (int)(short)1, 1, 1, (int)(short)10, 0);
    testRational0.mysimp((int)'a', (int)(short)10, 0, 1, (-1), (int)'a');
    testRational0.mysimp((int)'4', (int)(short)0, (int)(byte)(-1), (int)(short)10, (int)(byte)(-1), (int)(short)(-1));

  }

  @Test
  public void test089() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test089"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(10, (int)(byte)100, (int)(byte)10, (int)(short)0, (int)(byte)0, (int)' ');
    testRational0.mysimp((int)(short)10, (int)(byte)10, (int)(short)100, (int)(byte)0, (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp((int)(short)(-1), (int)'#', (int)'#', (int)(short)10, (int)(byte)0, (int)(byte)100);
    testRational0.mysimp((int)(byte)0, 1, 10, (int)(byte)100, (int)(short)(-1), (int)(byte)1);
    testRational0.mysimp((int)(short)10, (int)(byte)(-1), (int)'a', (int)(short)0, (int)(byte)10, (int)(short)100);
    testRational0.mysimp((int)(short)10, (int)'4', 0, (int)(short)1, (int)(byte)(-1), (-1));
    testRational0.mysimp((int)(short)0, (int)(short)100, (int)'4', (int)(byte)100, (int)(byte)1, (int)(byte)0);
    testRational0.mysimp((int)(short)10, 0, (int)'#', (int)'a', (int)'4', (int)'#');
    testRational0.mysimp((int)(byte)1, (int)(byte)1, (int)' ', 0, (int)(byte)1, (int)(short)1);

  }

  @Test
  public void test090() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test090"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'a', (int)(byte)0, 0, (int)(short)0, 0);
    testRational0.mysimp((-1), 10, (int)(byte)10, 0, (int)' ', 0);
    testRational0.mysimp((int)'4', (-1), (int)'4', (int)(byte)10, (int)(byte)100, (int)' ');
    testRational0.mysimp(0, 0, (int)(byte)0, (int)'4', (int)(short)1, (int)(byte)0);
    testRational0.mysimp((int)(short)(-1), (int)(byte)(-1), (int)(short)0, (int)(byte)1, 10, 0);
    testRational0.mysimp((int)(short)100, 100, 10, (int)(byte)100, 10, (int)(short)100);
    testRational0.mysimp((int)(short)0, (-1), 1, 1, (int)'#', (-1));
    testRational0.mysimp((int)'a', (int)(short)(-1), 1, (int)(short)1, 100, (int)(byte)0);

  }

  @Test
  public void test091() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test091"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(10, (int)(short)100, (int)' ', (int)(byte)1, (int)(short)(-1), 0);
    testRational0.mysimp((int)(byte)100, (int)(short)(-1), (int)(byte)10, (int)(byte)100, (-1), 100);
    testRational0.mysimp((int)(short)10, (int)(byte)(-1), (int)(byte)0, (int)'#', (int)' ', (int)(byte)10);
    testRational0.mysimp((int)'#', (int)(short)10, (int)(short)0, (int)'a', (int)(short)0, (int)(short)1);
    testRational0.mysimp((int)(byte)0, (int)(byte)1, 1, (int)(short)100, (int)(short)100, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)'#', (int)(short)100, (int)(byte)100, (int)'#', (int)(byte)0);
    testRational0.mysimp((int)(short)10, (int)'4', (-1), (int)(byte)1, (int)'4', (int)(byte)1);
    testRational0.mysimp((int)(short)100, (int)'4', 0, (int)' ', 10, (int)'a');
    testRational0.mysimp(100, 0, 10, (-1), (int)(byte)0, (int)' ');

  }

  @Test
  public void test092() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test092"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)' ', 10, (int)' ', (int)(short)0, 0, (int)(short)1);
    testRational0.mysimp((int)(short)1, (int)(short)(-1), (int)(short)100, (int)'4', 1, (int)(short)100);
    testRational0.mysimp(0, (int)(byte)10, (int)(short)(-1), (int)(short)10, 1, (int)(short)100);
    testRational0.mysimp((int)(byte)(-1), (int)(byte)(-1), (int)(byte)10, 100, (-1), (int)(byte)1);
    testRational0.mysimp((int)'#', (int)'a', (int)(short)0, (int)' ', 0, (-1));
    testRational0.mysimp((int)(byte)0, (int)(short)1, 1, 0, (int)(short)100, (int)(byte)(-1));

  }

  @Test
  public void test093() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test093"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(10, (int)(short)100, (int)' ', (int)(byte)1, (int)(short)(-1), 0);
    testRational0.mysimp((int)(byte)100, (int)(short)(-1), (int)(byte)10, (int)(byte)100, (-1), 100);
    testRational0.mysimp((int)(short)10, (int)(byte)(-1), (int)(byte)0, (int)'#', (int)' ', (int)(byte)10);
    testRational0.mysimp((int)'#', (int)(short)10, (int)(short)0, (int)'a', (int)(short)0, (int)(short)1);
    testRational0.mysimp((int)(byte)0, (int)(byte)1, 1, (int)(short)100, (int)(short)100, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)'#', (int)(short)100, (int)(byte)100, (int)'#', (int)(byte)0);
    testRational0.mysimp((int)(byte)10, (int)(short)0, 1, 0, (int)(byte)10, (int)(byte)1);
    testRational0.mysimp(1, (int)'a', (int)(byte)0, (int)(byte)0, (int)'4', 1);
    testRational0.mysimp((int)'4', (int)(short)0, (int)' ', (int)(short)100, (int)' ', 0);

  }

  @Test
  public void test094() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test094"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(byte)(-1), (int)(short)(-1), (int)(short)10, 0, (int)(byte)100, 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)(-1), (int)(byte)100, 1, (int)(byte)10);
    testRational0.mysimp((int)'a', (int)(short)0, (int)' ', 0, (int)(short)1, 0);
    testRational0.mysimp((int)' ', (int)'#', (-1), (int)' ', (int)(short)1, (int)' ');

  }

  @Test
  public void test095() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test095"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)10, (int)'#', 0, (-1));
    testRational0.mysimp((int)(byte)1, (int)(byte)100, (int)' ', (int)(short)0, (int)(short)100, 0);
    testRational0.mysimp((int)(byte)100, 0, (int)(short)100, (-1), 1, (int)(byte)100);
    testRational0.mysimp((int)(byte)1, 10, 10, (int)(short)0, (int)'#', (int)'4');
    testRational0.mysimp(100, 0, (int)(short)0, (int)(short)0, 0, (int)(byte)100);
    testRational0.mysimp((int)' ', (int)(short)1, 1, (int)(byte)1, (int)(byte)1, 10);
    testRational0.mysimp(10, (int)(byte)(-1), (int)' ', (int)(byte)1, (int)' ', (int)(byte)10);

  }

  @Test
  public void test096() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test096"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp((int)(byte)100, (int)(byte)0, 1, (int)(byte)10, (int)(short)100, 1);
    testRational0.mysimp((int)'#', (int)(byte)0, (int)(byte)100, (int)(byte)10, (int)'4', (int)(byte)(-1));
    testRational0.mysimp((-1), (int)' ', 0, (int)(byte)(-1), (int)(short)100, (int)(byte)1);
    testRational0.mysimp((-1), (int)'#', 10, 0, 1, 10);
    testRational0.mysimp((int)(byte)1, (int)(short)100, (-1), (int)'4', (int)(byte)0, 0);
    testRational0.mysimp((int)(short)100, (int)' ', (int)'a', (int)(byte)100, (int)(byte)100, 100);
    testRational0.mysimp((int)(byte)0, 10, 1, (int)(short)100, (-1), (int)(short)1);
    testRational0.mysimp((int)' ', (int)(short)0, (int)(byte)1, (int)(short)10, (int)(byte)100, (int)' ');
    testRational0.mysimp(0, (int)(byte)1, (int)' ', (int)(byte)1, (int)(byte)(-1), (int)(byte)100);

  }

  @Test
  public void test097() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test097"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(10, (int)(short)100, (int)(short)10, (int)(short)100, (int)(byte)10, 0);
    testRational0.mysimp((int)(byte)10, (int)(byte)10, (int)(byte)0, (int)'#', (int)(short)0, 0);
    testRational0.mysimp((int)' ', (int)'#', (int)(short)0, 1, (int)'#', (int)'4');
    testRational0.mysimp((int)(byte)(-1), (-1), (int)' ', (-1), (int)'#', (int)(short)0);
    testRational0.mysimp(0, (int)(short)10, (int)' ', (-1), (int)(byte)1, 100);
    testRational0.mysimp((int)'4', (int)(byte)10, (int)(byte)10, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp((int)(short)(-1), 0, (int)(short)0, (int)(short)0, (int)(short)100, (int)(short)0);
    testRational0.mysimp((int)(short)100, 100, (int)'a', 1, (int)(short)(-1), (-1));

  }

  @Test
  public void test098() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test098"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)10, (int)'#', 0, (-1));
    testRational0.mysimp((int)(byte)1, (int)(byte)100, (int)' ', (int)(short)0, (int)(short)100, 0);
    testRational0.mysimp(1, (int)(short)10, (int)(short)10, (int)(byte)1, (int)(short)1, (int)(short)100);
    testRational0.mysimp((int)(byte)(-1), 1, (int)(short)1, 100, (int)(short)0, 0);
    testRational0.mysimp(10, 100, 100, (int)(short)(-1), (int)' ', (int)(short)(-1));
    testRational0.mysimp((-1), 1, (int)(byte)100, (int)(byte)0, 100, (int)(byte)10);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)(byte)100, (int)'a', (int)(short)0, (int)(byte)0);
    testRational0.mysimp((int)(short)10, (int)(short)(-1), (-1), (int)(short)0, (int)'#', (int)(byte)100);

  }

  @Test
  public void test099() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test099"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)(short)100, (int)(byte)1, (int)(byte)0, 100, (int)(short)100);
    testRational0.mysimp((int)'#', 1, (int)(byte)1, (-1), (int)'4', (int)(byte)(-1));
    testRational0.mysimp(100, (int)(short)100, (int)(short)0, 0, (int)(short)100, (int)(byte)(-1));
    testRational0.mysimp((int)(short)1, (int)(byte)0, (int)(byte)10, (int)' ', (int)(short)0, (int)(short)1);
    testRational0.mysimp(0, (int)(byte)10, (int)(short)100, (int)(byte)(-1), (int)'#', (int)(short)10);

  }

  @Test
  public void test100() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test100"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)' ', 10, (int)' ', (int)(short)0, 0, (int)(short)1);
    testRational0.mysimp((int)(short)1, (int)' ', (int)(short)100, (int)(short)100, (int)(byte)100, 10);
    testRational0.mysimp((int)'#', (int)'a', (int)(short)0, (int)(short)10, 1, (int)'a');
    testRational0.mysimp(10, 10, (int)(short)10, (int)'4', (int)(byte)100, (int)(byte)0);
    testRational0.mysimp((int)(short)(-1), 100, 100, 10, (int)(byte)10, (int)(short)10);
    testRational0.mysimp((int)'#', 1, (int)(short)0, (-1), (int)' ', 0);
    testRational0.mysimp((int)(byte)1, (int)(byte)1, 1, (int)' ', (int)'a', (int)' ');

  }

  @Test
  public void test101() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test101"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(10, (int)(byte)100, (int)(byte)10, (int)(short)0, (int)(byte)0, (int)' ');
    testRational0.mysimp((int)(short)10, (int)(byte)10, (int)(short)100, (int)(byte)0, (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp((int)'4', (int)(byte)1, (int)(byte)0, (int)'4', (int)(short)1, 0);
    testRational0.mysimp((int)'#', (int)(byte)100, (int)(byte)(-1), 10, (int)(short)100, (int)(byte)(-1));
    testRational0.mysimp((int)(short)0, (int)(byte)(-1), (int)(short)(-1), 1, (int)(short)0, (int)(byte)0);
    testRational0.mysimp((int)(byte)10, (int)(short)0, (int)(byte)100, (int)'a', (int)'#', (int)(short)0);
    testRational0.mysimp((int)' ', (int)' ', 100, 0, 100, 0);

  }

  @Test
  public void test102() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test102"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)10, (int)'#', 0, (-1));
    testRational0.mysimp((int)(byte)1, (int)(byte)100, (int)' ', (int)(short)0, (int)(short)100, 0);
    testRational0.mysimp(1, (int)(short)10, (int)(short)10, (int)(byte)1, (int)(short)1, (int)(short)100);
    testRational0.mysimp((int)(byte)(-1), 1, (int)(short)1, 100, (int)(short)0, 0);
    testRational0.mysimp(10, 100, 100, (int)(short)(-1), (int)' ', (int)(short)(-1));
    testRational0.mysimp((int)'4', (int)'a', 100, 1, (int)(byte)0, (int)' ');
    testRational0.mysimp(0, (int)(short)0, (int)(byte)100, 1, (int)(short)100, (int)(byte)(-1));
    testRational0.mysimp((int)(short)(-1), (int)(short)0, (int)(short)1, (int)' ', (int)' ', (-1));
    testRational0.mysimp((int)(byte)(-1), (int)(byte)1, (int)(short)1, (int)(byte)100, (int)(short)10, (int)(short)100);

  }

  @Test
  public void test103() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test103"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)10, (int)'#', 0, (-1));
    testRational0.mysimp((int)'4', (int)(byte)(-1), (int)(byte)100, (int)(short)1, (int)'#', 100);
    testRational0.mysimp((int)(byte)10, (int)'a', (int)(short)100, (int)'#', (int)(short)10, (int)(short)100);
    testRational0.mysimp((int)(short)0, (int)(byte)10, 1, (int)'4', 10, 0);

  }

  @Test
  public void test104() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test104"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(100, 100, 0, 1, (int)'a', 0);
    testRational0.mysimp((int)(short)10, (int)'a', 0, (int)'a', 0, 0);
    testRational0.mysimp(1, (int)(byte)10, (int)' ', 0, (int)(byte)1, (int)(short)0);
    testRational0.mysimp((int)(byte)1, (int)(byte)0, (int)'#', (int)(short)1, (int)(byte)10, (int)(short)1);
    testRational0.mysimp((int)(short)0, 0, 10, (int)(byte)100, (int)(short)100, (int)(short)1);
    testRational0.mysimp((-1), (int)(byte)10, 10, 100, (int)(short)100, (-1));
    testRational0.mysimp(100, 0, (int)(short)10, (int)'#', (int)(short)100, (int)' ');
    testRational0.mysimp((int)(byte)100, (int)(short)1, (int)'a', (int)(byte)(-1), (int)(byte)100, (int)(byte)0);

  }

  @Test
  public void test105() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test105"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)(short)1, (int)(byte)10, (int)(byte)100, 1, (int)(byte)10, (int)(byte)(-1));
    testRational0.mysimp(0, (int)(short)(-1), (int)(short)0, (int)(byte)0, (int)' ', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)'4', (int)(short)10, (int)(byte)1, (int)(short)(-1));
    testRational0.mysimp((int)(short)1, (int)(byte)0, 10, (int)'4', (int)(short)0, (int)'4');
    testRational0.mysimp(0, (int)(byte)10, (int)(short)(-1), 100, (int)' ', (int)(byte)1);
    testRational0.mysimp((int)(byte)10, (int)(short)10, 0, 100, (int)(byte)0, (int)(byte)10);
    testRational0.mysimp((int)(short)(-1), 1, 0, (int)(short)100, (int)(short)(-1), 1);

  }

  @Test
  public void test106() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test106"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, 100, 100);
    testRational0.mysimp(0, (int)'4', (int)' ', (int)(byte)100, (int)(byte)1, (int)(short)100);
    testRational0.mysimp((int)(short)100, (int)(byte)0, (int)(short)100, (int)' ', 0, (-1));
    testRational0.mysimp((int)' ', (int)(byte)(-1), (int)'4', (int)(byte)(-1), (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)100, (int)'4', (int)(short)1, 0, 100, (int)(byte)10);
    testRational0.mysimp((int)(short)1, (int)' ', (int)'#', (int)'#', (int)' ', (int)(short)100);
    testRational0.mysimp(0, (int)(short)100, (int)(byte)(-1), 100, (int)(byte)0, (int)(byte)0);
    testRational0.mysimp((int)(byte)0, (int)(short)(-1), (int)'4', 10, (int)(byte)100, (-1));
    testRational0.mysimp((int)(short)(-1), (int)(byte)100, (int)(short)0, (int)(byte)1, (-1), (int)(byte)100);
    testRational0.mysimp((int)' ', (int)'4', (int)(byte)1, (int)(byte)1, (int)(short)1, 10);
    testRational0.mysimp((int)(byte)(-1), (int)(short)(-1), (-1), (int)'4', 10, (int)(byte)10);

  }

  @Test
  public void test107() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test107"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, 100, 100);
    testRational0.mysimp((int)(byte)(-1), (int)'a', (-1), (int)'4', (-1), (int)(byte)0);
    testRational0.mysimp((int)' ', 0, (int)'#', (int)(short)100, (int)(short)0, 100);
    testRational0.mysimp((int)'a', (int)(short)1, 1, (int)'4', (int)'4', 10);
    testRational0.mysimp((-1), 0, (int)'4', (-1), (int)(byte)0, (int)(short)1);
    testRational0.mysimp((int)(short)0, 100, (int)'4', (int)(short)0, 0, (int)(byte)100);
    testRational0.mysimp((int)(short)1, (int)'a', (int)(short)(-1), (int)(short)(-1), (int)(short)0, (int)(short)(-1));
    testRational0.mysimp(0, (int)(byte)(-1), 0, (int)(byte)1, 100, (int)(short)1);
    testRational0.mysimp((-1), (int)(byte)1, (int)' ', (int)'a', (int)'4', (int)(byte)100);

  }

  @Test
  public void test108() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test108"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, 100, 100);
    testRational0.mysimp(0, (int)'4', (int)' ', (int)(byte)100, (int)(byte)1, (int)(short)100);
    testRational0.mysimp((int)(short)100, (int)(byte)0, (int)(short)100, (int)' ', 0, (-1));
    testRational0.mysimp((int)' ', (int)(byte)(-1), (int)'4', (int)(byte)(-1), (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)10, (int)(short)10, (int)(short)10, (int)'4', 10, (int)(short)1);
    testRational0.mysimp((int)(short)100, 100, (int)(short)1, (int)(short)(-1), (int)(short)(-1), 100);
    testRational0.mysimp((int)'a', 0, (int)'#', (int)(short)(-1), 100, (int)' ');
    testRational0.mysimp((int)(short)0, (int)(byte)100, (int)(byte)(-1), 1, 0, (-1));
    testRational0.mysimp((int)'4', 1, (int)(byte)(-1), (int)(short)10, (int)(byte)0, (int)(byte)100);

  }

  @Test
  public void test109() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test109"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)'a', 100, 1, (int)(short)1, 0, 10);
    testRational0.mysimp((int)(byte)100, (int)'#', (int)(short)1, (int)(byte)0, (int)(short)(-1), (int)(byte)1);
    testRational0.mysimp((int)(short)100, (-1), (int)(byte)100, (int)(short)0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, (int)(short)(-1), (int)(byte)100, (int)(short)100, (int)(byte)(-1), (int)'4');

  }

  @Test
  public void test110() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test110"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)'a', (int)(byte)(-1), (int)' ', (int)'#', (int)(short)1);
    testRational0.mysimp((int)(short)100, 0, (int)'#', (int)(byte)1, (int)(byte)10, (int)(byte)(-1));
    testRational0.mysimp((-1), (int)'#', (int)(byte)100, (int)(byte)0, 100, (int)' ');
    testRational0.mysimp((int)'#', (int)(byte)10, (int)' ', 100, (int)(byte)1, 0);
    testRational0.mysimp(1, (int)(short)(-1), (int)' ', (int)(short)10, (int)(short)100, 0);
    testRational0.mysimp((-1), (int)(byte)100, (int)' ', (int)'a', (int)(byte)(-1), (int)'4');

  }

  @Test
  public void test111() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test111"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(byte)100, (int)(byte)1, (int)(byte)(-1), 1, (int)(byte)0, 10);
    testRational0.mysimp(0, (int)'#', (int)(short)0, (int)'#', 100, (int)(short)100);
    testRational0.mysimp((int)'#', (int)(short)(-1), 0, (int)'a', (int)(byte)100, (-1));
    testRational0.mysimp((int)(short)10, 0, 100, 0, 10, (int)(byte)0);
    testRational0.mysimp((int)(byte)10, 10, (int)(short)100, (int)(short)(-1), (int)'#', (int)'#');
    testRational0.mysimp((int)'4', (int)'4', (int)(byte)0, (int)(short)0, 0, (int)'a');
    testRational0.mysimp((int)(byte)10, 0, (int)(byte)0, (int)'a', (int)'#', (int)(short)10);

  }

  @Test
  public void test112() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test112"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)'a', (int)(short)100, (int)(short)10, 0, 100, (int)(short)1);
    testRational0.mysimp(100, (int)(short)1, (int)' ', (int)(byte)10, (int)(short)1, (int)(byte)0);
    testRational0.mysimp((int)'#', (int)'#', (int)'4', (int)(short)(-1), (int)'4', (int)(byte)1);
    testRational0.mysimp((int)(byte)10, (int)' ', 10, (int)(byte)10, 0, (int)'4');
    testRational0.mysimp(100, (int)(short)1, (int)(short)(-1), 10, 10, (int)(byte)1);

  }

  @Test
  public void test113() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test113"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(10, (int)(short)100, (int)' ', (int)(byte)1, (int)(short)(-1), 0);
    testRational0.mysimp((int)(byte)100, (int)(short)(-1), (int)(byte)10, (int)(byte)100, (-1), 100);
    testRational0.mysimp((int)'a', (int)'#', (-1), (int)(short)10, (int)(short)100, (int)(byte)1);
    testRational0.mysimp(0, (int)' ', 10, (int)(short)0, (int)(byte)0, 0);
    testRational0.mysimp((int)(short)100, (int)(short)100, (int)(short)(-1), (int)(byte)10, (int)'4', (int)(short)10);

  }

  @Test
  public void test114() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test114"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, 100, 100);
    testRational0.mysimp(0, (int)'4', (int)' ', (int)(byte)100, (int)(byte)1, (int)(short)100);
    testRational0.mysimp((int)(short)100, (int)(byte)0, (int)(short)100, (int)' ', 0, (-1));
    testRational0.mysimp((int)' ', (int)(byte)(-1), (int)'4', (int)(byte)(-1), (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)100, (int)'4', (int)(short)1, 0, 100, (int)(byte)10);
    testRational0.mysimp((int)(short)1, (int)' ', (int)'#', (int)'#', (int)' ', (int)(short)100);
    testRational0.mysimp(0, (int)(byte)100, (int)(byte)(-1), 0, (int)(short)100, (int)(short)(-1));
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)'a', (int)' ', (int)(short)100);
    testRational0.mysimp((int)(byte)(-1), 100, (int)(byte)1, (int)(byte)0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (-1), 0, 100, 0, (int)(short)10);

  }

  @Test
  public void test115() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test115"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)' ', 10, (int)' ', (int)(short)0, 0, (int)(short)1);
    testRational0.mysimp((int)(short)1, 1, (int)' ', (int)(byte)10, (int)(short)(-1), 0);
    testRational0.mysimp((int)(byte)0, 100, (int)(byte)(-1), (int)(byte)1, (int)(short)(-1), 1);
    testRational0.mysimp((int)(byte)0, (int)(byte)100, (int)(byte)(-1), 0, (int)(short)100, (int)(short)10);
    testRational0.mysimp(0, (int)(short)1, (int)(short)1, (int)(byte)0, (int)(byte)1, 0);
    testRational0.mysimp((int)(short)1, (int)'4', (int)(short)0, (int)(byte)(-1), (int)(byte)(-1), (int)(short)(-1));
    testRational0.mysimp((int)(short)1, (int)(short)0, (int)'#', (int)(byte)100, 1, (int)(short)100);

  }

  @Test
  public void test116() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test116"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(10, (int)(short)100, (int)' ', (int)(byte)1, (int)(short)(-1), 0);
    testRational0.mysimp((int)(byte)100, (int)(short)(-1), (int)(byte)10, (int)(byte)100, (-1), 100);
    testRational0.mysimp((int)(short)10, (int)(byte)(-1), (int)(byte)0, (int)'#', (int)' ', (int)(byte)10);
    testRational0.mysimp((int)'#', (int)(short)10, (int)(short)0, (int)'a', (int)(short)0, (int)(short)1);
    testRational0.mysimp(0, (int)(byte)100, 100, (int)(short)100, (-1), (int)(byte)1);
    testRational0.mysimp(0, 10, (int)(short)1, 1, 100, (int)(short)0);

  }

  @Test
  public void test117() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test117"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp((int)(short)(-1), (int)(short)10, (int)(short)10, 0, (int)'4', (int)(byte)1);
    testRational0.mysimp((int)(short)(-1), (int)'a', (int)(byte)(-1), (int)(byte)1, 0, 0);
    testRational0.mysimp(10, (int)(short)(-1), 0, (int)(short)1, (int)(byte)(-1), (int)'a');
    testRational0.mysimp(0, (int)(byte)0, (int)'4', (-1), 0, 100);
    testRational0.mysimp((int)(byte)0, (int)(byte)1, (int)(short)(-1), (int)' ', (int)'4', (int)(short)0);
    testRational0.mysimp((int)(short)100, (int)' ', 0, (int)' ', (int)(short)100, (int)(byte)100);
    testRational0.mysimp((-1), (int)'4', (int)(short)100, (-1), (int)'#', (int)(short)1);

  }

  @Test
  public void test118() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test118"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(byte)(-1), (int)(short)(-1), (int)(short)10, 0, (int)(byte)100, 1);
    testRational0.mysimp(100, (int)(short)1, 10, (int)' ', (int)'a', 1);
    testRational0.mysimp(10, 100, (int)(byte)0, (int)' ', (int)(byte)10, (int)(byte)0);
    testRational0.mysimp((int)(byte)(-1), (int)' ', (int)'4', 0, 10, (int)'a');
    testRational0.mysimp((int)'#', 0, (int)'a', (-1), (int)(short)10, 0);
    testRational0.mysimp((int)(short)1, (int)'#', (int)(short)1, (int)(byte)1, (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(byte)10, (int)'4', 0, (int)(byte)100, (int)'a', (int)'4');
    testRational0.mysimp((int)(byte)1, (int)'4', (int)(byte)1, (int)(short)1, (int)(short)10, (int)(byte)100);
    testRational0.mysimp((int)'a', (int)(short)0, (int)(byte)(-1), 100, (int)(byte)(-1), (int)'4');

  }

  @Test
  public void test119() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test119"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)(short)100, (int)(byte)1, (int)(byte)0, 100, (int)(short)100);
    testRational0.mysimp((int)'#', 1, (int)(byte)1, (-1), (int)'4', (int)(byte)(-1));
    testRational0.mysimp((int)(byte)100, (int)(short)10, 1, (int)(byte)0, (int)(byte)(-1), (int)(short)100);
    testRational0.mysimp((int)'4', (int)(byte)1, 100, (int)'a', (int)(byte)100, (int)' ');
    testRational0.mysimp((int)(short)0, 0, (int)(short)0, (int)'4', (int)(short)10, 0);
    testRational0.mysimp((int)(short)100, (int)(short)100, (int)'a', (int)(short)1, (int)(byte)10, 0);
    testRational0.mysimp((-1), (int)(byte)10, (int)(short)1, (int)'#', (int)(byte)(-1), (int)'a');
    testRational0.mysimp((int)(short)10, 0, (int)'#', (int)(short)1, (int)'a', 1);

  }

  @Test
  public void test120() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test120"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)'a', (int)(byte)1, (int)(short)100, (int)(byte)1, (int)(short)0, (int)(short)(-1));
    testRational0.mysimp((-1), 1, (int)(byte)0, (-1), 1, (int)'a');
    testRational0.mysimp((int)(short)0, (int)'4', (int)' ', (int)(byte)(-1), 100, (int)(short)1);
    testRational0.mysimp((-1), 10, (-1), (int)(short)0, (int)(byte)100, (int)(byte)1);
    testRational0.mysimp((int)(byte)10, (int)(byte)(-1), (int)(byte)(-1), (int)(byte)10, 0, (int)(short)0);
    testRational0.mysimp((int)' ', (int)(byte)1, (int)'a', (int)(byte)0, (int)(byte)(-1), (int)(short)(-1));

  }

  @Test
  public void test121() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test121"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp((int)(byte)100, (int)(byte)0, 1, (int)(byte)10, (int)(short)100, 1);
    testRational0.mysimp((int)'#', (int)(byte)0, (int)(byte)100, (int)(byte)10, (int)'4', (int)(byte)(-1));
    testRational0.mysimp((-1), (int)' ', 0, (int)(byte)(-1), (int)(short)100, (int)(byte)1);
    testRational0.mysimp((-1), (int)'#', 10, 0, 1, 10);
    testRational0.mysimp((int)(byte)1, (int)(short)100, (-1), (int)'4', (int)(byte)0, 0);
    testRational0.mysimp((int)'4', (-1), (-1), (-1), (int)'a', 100);
    testRational0.mysimp((int)' ', (int)(short)10, 0, (int)(byte)1, (int)'4', (-1));
    testRational0.mysimp(100, (int)(short)100, (int)(byte)(-1), 0, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(byte)0, (int)(byte)(-1), 10, (-1), (int)(byte)100, (int)(short)100);

  }

  @Test
  public void test122() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test122"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp((int)(short)(-1), (int)(short)10, (int)(short)10, 0, (int)'4', (int)(byte)1);
    testRational0.mysimp((-1), (int)' ', (int)'a', (int)'4', (int)(short)0, (-1));
    testRational0.mysimp((int)(short)100, (int)'4', (int)(short)100, 1, (int)(byte)100, (int)(byte)10);
    testRational0.mysimp((-1), (int)(byte)100, (int)(short)0, (int)(byte)10, (int)(byte)1, (int)(short)100);
    testRational0.mysimp(100, (int)(short)0, (int)'4', (int)'#', (int)'#', (int)(short)0);
    testRational0.mysimp((int)(short)10, (int)(short)(-1), (int)(short)100, 0, (int)(byte)1, (int)(byte)100);
    testRational0.mysimp((int)(short)(-1), 1, (int)'a', (int)(short)0, (int)'#', (-1));
    testRational0.mysimp((int)(byte)(-1), (int)(byte)(-1), (int)(short)0, (int)(short)10, 10, (int)(short)(-1));

  }

  @Test
  public void test123() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test123"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'#', 1, (int)(short)10, (int)'4', (int)(short)1);
    testRational0.mysimp(0, (int)'#', 10, (int)(byte)0, (int)'a', (int)(byte)(-1));
    testRational0.mysimp((int)(short)0, (-1), (int)(short)100, (int)'a', 0, (int)(short)0);
    testRational0.mysimp((int)'4', 0, 100, (int)(short)(-1), (int)(short)100, (int)'#');
    testRational0.mysimp((int)(short)(-1), (int)(byte)100, (int)'#', 10, (-1), (int)'a');
    testRational0.mysimp((int)(short)1, (int)'#', 100, (int)(short)10, (-1), 0);
    testRational0.mysimp((int)(short)1, (int)(short)1, (int)(short)0, 0, (-1), (int)(byte)1);
    testRational0.mysimp((int)(short)(-1), (int)(byte)(-1), (int)' ', (int)(short)10, (int)(byte)0, 100);

  }

  @Test
  public void test124() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test124"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)'a', (int)(byte)1, (int)(short)100, (int)(byte)1, (int)(short)0, (int)(short)(-1));
    testRational0.mysimp((-1), 1, (int)(byte)0, (-1), 1, (int)'a');
    testRational0.mysimp((int)(short)100, (int)(short)1, 0, 100, (int)(byte)10, 10);
    testRational0.mysimp((int)(byte)1, (int)' ', 1, 0, (int)(short)1, (int)(short)1);
    testRational0.mysimp((-1), (int)'a', 100, (int)' ', (int)' ', (int)'4');
    testRational0.mysimp((int)(short)100, (int)(short)0, (int)'a', (int)'4', 100, (int)(byte)1);

  }

  @Test
  public void test125() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test125"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(10, (int)'a', (int)(short)10, (int)(short)(-1), (int)(byte)0, (int)'a');
    testRational0.mysimp((int)(byte)100, (int)(short)0, (int)'a', (int)(byte)(-1), 0, (int)(short)(-1));
    testRational0.mysimp((int)(byte)0, 1, (int)'4', (int)(short)1, (int)' ', (int)'4');
    testRational0.mysimp(0, (int)(byte)10, 100, 0, (int)'4', (int)(byte)1);
    testRational0.mysimp(0, (int)(short)100, (int)' ', (int)'#', (int)'#', 1);
    testRational0.mysimp(0, (int)(short)10, 10, (int)'a', (int)(byte)0, (int)(byte)100);
    testRational0.mysimp((int)(byte)1, (int)'#', 0, 0, (int)'4', (int)(byte)(-1));
    testRational0.mysimp(100, (int)(short)(-1), (int)(byte)10, (int)(byte)0, (int)(short)1, (-1));
    testRational0.mysimp(1, 0, 0, 100, (int)(short)0, (int)(byte)(-1));

  }

  @Test
  public void test126() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test126"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, 100, 100);
    testRational0.mysimp(0, (int)'4', (int)' ', (int)(byte)100, (int)(byte)1, (int)(short)100);
    testRational0.mysimp((int)(short)100, (int)(byte)0, (int)(short)100, (int)' ', 0, (-1));
    testRational0.mysimp((int)' ', (int)(byte)(-1), (int)'4', (int)(byte)(-1), (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)100, (int)'4', (int)(short)1, 0, 100, (int)(byte)10);
    testRational0.mysimp((int)(short)1, (int)' ', (int)'#', (int)'#', (int)' ', (int)(short)100);
    testRational0.mysimp((-1), 0, (int)' ', (int)' ', (int)'a', (int)(byte)10);
    testRational0.mysimp((int)(short)10, 10, (int)(short)100, (int)(short)1, 0, (int)(short)(-1));
    testRational0.mysimp((int)(byte)10, (int)(short)0, 0, (-1), 10, (int)(short)(-1));
    testRational0.mysimp((int)(short)1, (int)(short)100, (int)(short)100, (int)(short)0, (int)(short)10, (int)'a');

  }

  @Test
  public void test127() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test127"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'#', 1, (int)(short)10, (int)'4', (int)(short)1);
    testRational0.mysimp((-1), (int)(short)10, (int)(byte)1, (int)(short)10, (int)(byte)(-1), 0);
    testRational0.mysimp(1, (int)' ', (int)(short)100, (int)(short)100, (int)(byte)(-1), (int)(short)(-1));
    testRational0.mysimp(0, (int)(byte)(-1), (int)'4', (int)(byte)10, (int)(byte)0, 100);
    testRational0.mysimp((int)(short)0, (int)(byte)100, (int)(byte)0, (int)(short)(-1), (int)'#', (int)(short)10);
    testRational0.mysimp((int)(short)100, 1, 1, (int)(short)1, (int)'#', (int)(short)0);
    testRational0.mysimp(0, (int)(short)10, 1, (int)(byte)1, (int)(short)100, (int)(byte)(-1));
    testRational0.mysimp((int)(byte)1, (int)(short)1, (int)'4', (-1), (int)(byte)0, (int)(byte)100);

  }

  @Test
  public void test128() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test128"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)' ', (int)(byte)0, (int)(byte)1, (int)(byte)100, 10, (int)'4');
    testRational0.mysimp((int)(short)(-1), (int)'a', 100, (int)' ', (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp((int)(short)10, (int)(byte)0, (int)(short)0, (-1), (-1), (int)(short)100);
    testRational0.mysimp((int)(short)0, 10, 1, 10, (-1), (int)'4');
    testRational0.mysimp((int)'#', (-1), 0, (int)' ', 10, (int)'4');
    testRational0.mysimp((int)(byte)1, (int)(short)(-1), (int)(byte)10, (int)' ', (int)' ', 0);

  }

  @Test
  public void test129() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test129"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)' ', 10, (int)' ', (int)(short)0, 0, (int)(short)1);
    testRational0.mysimp((int)(short)1, 1, (int)' ', (int)(byte)10, (int)(short)(-1), 0);
    testRational0.mysimp((int)(short)1, (int)(byte)10, (int)'4', (int)(short)10, (int)(byte)0, 0);
    testRational0.mysimp((int)(byte)10, (int)'#', (int)(byte)1, (int)(byte)10, (int)(byte)100, 100);
    testRational0.mysimp((-1), (int)'#', (-1), (int)(byte)10, (int)'#', (int)(short)100);

  }

  @Test
  public void test130() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test130"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'#', 1, (int)(short)10, (int)'4', (int)(short)1);
    testRational0.mysimp(0, (int)'#', 10, (int)(byte)0, (int)'a', (int)(byte)(-1));
    testRational0.mysimp((int)'4', 100, (int)(short)(-1), 10, (int)(short)1, 1);

  }

  @Test
  public void test131() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test131"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)1, 1, (int)(short)1, 0);
    testRational0.mysimp((int)(byte)100, (int)(byte)100, (int)(short)1, (int)(short)10, (int)(short)1, (int)(short)0);
    testRational0.mysimp((int)'a', (int)(short)0, (int)(byte)1, (int)(byte)10, (int)(byte)100, 0);
    testRational0.mysimp((int)(byte)100, 1, (int)(short)1, (int)'4', (int)(byte)100, (int)(short)100);
    testRational0.mysimp(1, (int)' ', 0, (int)(byte)0, (int)'#', (int)(short)0);
    testRational0.mysimp((int)(byte)0, (int)(byte)1, (int)'4', (int)(short)(-1), (int)(byte)0, (int)(byte)100);
    testRational0.mysimp(100, (int)(byte)100, 0, (int)'#', (int)'#', 0);
    testRational0.mysimp(10, (int)(short)0, (int)(short)10, (int)(short)10, 0, (int)(byte)0);
    testRational0.mysimp(100, (int)(byte)10, (int)(byte)100, (-1), (int)(short)0, 10);
    testRational0.mysimp((int)(short)100, 100, (int)(byte)100, (-1), (int)' ', 10);

  }

  @Test
  public void test132() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test132"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)(short)100, (int)(byte)1, (int)(byte)0, 100, (int)(short)100);
    testRational0.mysimp((int)'a', (int)(short)0, 0, (int)'4', (int)'#', (int)'4');
    testRational0.mysimp((int)' ', (int)' ', (int)' ', (int)(short)10, 10, (int)(byte)1);
    testRational0.mysimp((int)(short)1, (int)'a', (int)(short)100, (-1), 0, (int)(byte)1);
    testRational0.mysimp((int)(short)100, 1, 0, (int)(byte)(-1), 10, (-1));

  }

  @Test
  public void test133() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test133"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'a', (int)(byte)0, 0, (int)(short)0, 0);
    testRational0.mysimp((int)(short)10, (int)(byte)0, (int)'a', (int)(byte)0, (int)(byte)0, (int)(byte)(-1));
    testRational0.mysimp((int)(byte)0, 0, (int)(short)10, (int)(short)1, (int)(short)1, (int)(short)(-1));
    testRational0.mysimp((int)(short)0, (int)' ', 10, (int)'#', (int)'a', (int)(byte)100);
    testRational0.mysimp(100, (int)(short)0, (int)(byte)1, (int)(byte)(-1), 1, 1);
    testRational0.mysimp((int)(short)(-1), (int)(short)100, 1, (int)'4', (int)(byte)0, (int)(byte)100);

  }

  @Test
  public void test134() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test134"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)10, (int)'#', 0, (-1));
    testRational0.mysimp((int)'#', (int)'a', (int)(byte)1, (int)' ', 0, (int)'4');
    testRational0.mysimp(0, (int)' ', 100, (int)'4', (int)'a', 0);
    testRational0.mysimp(100, (int)'4', (-1), (int)'4', (-1), (int)' ');
    testRational0.mysimp(10, 0, (int)(short)100, (int)(byte)0, 0, (int)'#');
    testRational0.mysimp((int)(byte)10, 100, 100, (int)(byte)1, (int)'4', (int)(short)10);
    testRational0.mysimp(10, (int)(byte)1, (int)(byte)100, 100, (int)(byte)10, 0);
    testRational0.mysimp((int)(byte)1, (int)(byte)0, (int)(byte)10, (int)(byte)100, (int)(short)(-1), (int)(byte)100);

  }

  @Test
  public void test135() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test135"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(0, (int)(byte)1, 10, (int)(byte)10, (int)(byte)100, (int)(byte)100);
    testRational0.mysimp(100, (int)(short)100, 10, (int)(byte)100, (int)(byte)1, (int)(byte)0);

  }

  @Test
  public void test136() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test136"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'a', (int)(byte)0, 0, (int)(short)0, 0);
    testRational0.mysimp((int)(short)0, (int)(short)10, (-1), (int)(short)(-1), (int)(short)0, 0);
    testRational0.mysimp((int)(byte)0, (int)(byte)100, 0, (int)'4', 10, (int)(short)100);
    testRational0.mysimp((-1), (int)(byte)(-1), (int)(byte)(-1), (int)'#', 100, 10);
    testRational0.mysimp((int)(short)10, (int)' ', (int)(short)1, (int)'a', (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)0, 10, 10, (int)' ', (int)(short)10, 1);
    testRational0.mysimp((int)(byte)10, (int)(short)100, (int)(short)1, 0, (int)' ', (int)'a');

  }

  @Test
  public void test137() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test137"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)10, (int)'#', 0, (-1));
    testRational0.mysimp((int)(byte)1, (int)(byte)100, (int)' ', (int)(short)0, (int)(short)100, 0);
    testRational0.mysimp((int)(byte)(-1), 10, 0, (int)(short)(-1), (int)'a', (int)(short)0);
    testRational0.mysimp((int)' ', 10, (int)(short)(-1), 0, (int)(short)0, (int)(short)100);
    testRational0.mysimp(100, (int)(short)100, (int)(byte)100, (int)(byte)1, (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp(0, (int)(short)(-1), (int)(byte)100, 10, 0, 0);
    testRational0.mysimp(10, 0, (int)' ', (int)(short)1, (int)(byte)10, (int)(short)100);

  }

  @Test
  public void test138() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test138"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)(short)(-1), 100, (int)(byte)10, (int)'4', (int)(short)(-1));
    testRational0.mysimp((-1), 10, (int)'#', (int)(byte)1, (int)(byte)10, 100);
    testRational0.mysimp((int)(byte)100, 10, (int)(byte)0, (int)(byte)100, 10, (-1));
    testRational0.mysimp((int)(byte)1, (int)(short)100, (-1), (int)(byte)(-1), (int)'4', (int)(short)1);
    testRational0.mysimp((int)(short)10, (int)'4', 0, 1, (int)'#', (-1));
    testRational0.mysimp((int)(byte)100, (int)(byte)1, (int)(byte)100, (int)(byte)10, (int)(short)(-1), (int)'4');

  }

  @Test
  public void test139() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test139"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)(short)100, (int)(byte)1, (int)(byte)0, 100, (int)(short)100);
    testRational0.mysimp((int)'#', (int)(short)1, 0, (int)(short)0, (int)'a', (int)'#');
    testRational0.mysimp((int)' ', (int)(byte)0, (int)(short)10, 0, 0, (int)(short)(-1));
    testRational0.mysimp((int)'a', 0, (int)(short)1, (int)'4', (int)(byte)100, (-1));
    testRational0.mysimp((int)(short)0, (int)'4', (int)'4', (int)(short)0, (int)(short)0, (int)(byte)1);
    testRational0.mysimp((int)(short)1, (int)(short)10, 10, 0, (int)' ', (int)(short)1);

  }

  @Test
  public void test140() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test140"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 0, (-1), 100, (int)'a');
    testRational0.mysimp(10, (int)(short)0, 100, (int)'4', (-1), 0);
    testRational0.mysimp(0, (int)(byte)(-1), 100, (int)(short)1, (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp((int)(byte)0, (int)'4', 100, (int)(byte)1, (int)(byte)10, 0);
    testRational0.mysimp((int)(byte)0, 0, (int)(short)(-1), (int)'#', (int)(byte)0, (int)(short)1);
    testRational0.mysimp((int)(byte)0, 10, (int)'4', (int)(short)(-1), 1, (int)(byte)(-1));
    testRational0.mysimp((int)(short)100, (int)'a', 0, 10, 0, (int)(short)1);
    testRational0.mysimp((int)(short)100, (int)(byte)1, (int)(byte)0, (int)(short)1, (int)(byte)100, (int)(short)(-1));
    testRational0.mysimp((int)(byte)100, (int)(byte)(-1), (int)(short)100, 0, (int)'#', (int)' ');
    testRational0.mysimp((int)'4', (int)(short)(-1), 0, 0, (int)(short)100, (int)(short)0);

  }

  @Test
  public void test141() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test141"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)(short)(-1), 100, (int)(byte)10, (int)'4', (int)(short)(-1));
    testRational0.mysimp((int)' ', 1, (int)(byte)(-1), (int)(short)1, 10, (int)(byte)0);
    testRational0.mysimp(1, 0, (int)(short)1, (int)(short)(-1), 0, (int)(short)0);
    testRational0.mysimp(0, (int)'4', (int)'#', (int)(short)(-1), 0, 100);
    testRational0.mysimp((int)'4', 0, (int)(short)10, (int)'a', 1, (int)(short)(-1));
    testRational0.mysimp((int)(byte)100, (int)(short)10, 100, (int)(short)0, 0, (-1));
    testRational0.mysimp((int)(byte)(-1), (int)'a', (int)'#', (int)(short)10, 10, (int)(short)(-1));

  }

  @Test
  public void test142() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test142"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(10, (int)'a', (int)(short)10, (int)(short)(-1), (int)(byte)0, (int)'a');
    testRational0.mysimp((int)(byte)100, (int)(short)0, (int)'a', (int)(byte)(-1), 0, (int)(short)(-1));
    testRational0.mysimp((int)(byte)0, 1, (int)'4', (int)(short)1, (int)' ', (int)'4');
    testRational0.mysimp(0, (int)(byte)10, 100, 0, (int)'4', (int)(byte)1);
    testRational0.mysimp((int)' ', (int)(byte)100, (int)(byte)10, (int)(short)(-1), 0, (int)' ');
    testRational0.mysimp((int)(short)0, (int)(short)1, 0, (-1), (int)(short)0, (int)(byte)100);
    testRational0.mysimp((int)(byte)10, 100, (int)(byte)(-1), (int)(short)10, 0, (int)(short)100);
    testRational0.mysimp((int)(byte)0, (int)(byte)(-1), (int)(short)(-1), (int)(short)10, (int)(short)0, 0);

  }

  @Test
  public void test143() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test143"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(10, (int)(byte)100, (int)(byte)10, (int)(short)0, (int)(byte)0, (int)' ');
    testRational0.mysimp((int)(short)10, (int)(byte)10, (int)(short)100, (int)(byte)0, (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp((int)(short)(-1), (int)'#', (int)'#', (int)(short)10, (int)(byte)0, (int)(byte)100);
    testRational0.mysimp(0, (int)(short)10, (int)(short)1, (int)'4', (-1), (int)(byte)100);
    testRational0.mysimp(1, (int)(short)(-1), (-1), (int)'#', (int)'a', (int)(byte)10);

  }

  @Test
  public void test144() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test144"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'a', (int)(byte)0, 0, (int)(short)0, 0);
    testRational0.mysimp((int)(short)10, (int)(byte)0, (int)'a', (int)(byte)0, (int)(byte)0, (int)(byte)(-1));
    testRational0.mysimp(100, 0, (int)'4', 10, (int)'#', (int)(short)10);
    testRational0.mysimp((int)'a', (int)'a', 0, (int)' ', 0, (int)' ');
    testRational0.mysimp((-1), 1, (int)'a', (int)(short)10, (int)(byte)10, 0);
    testRational0.mysimp((int)(short)10, (int)(byte)1, (int)(byte)1, (int)' ', (int)(byte)1, (-1));
    testRational0.mysimp((int)(byte)(-1), (int)(byte)(-1), (int)(byte)10, 0, (int)'a', (int)(short)100);

  }

  @Test
  public void test145() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test145"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)(byte)0, (int)(byte)(-1), (int)'a', 100, (int)' ', (int)(short)(-1));
    testRational0.mysimp((int)(short)100, (int)(byte)1, (int)(short)0, 1, (int)(short)100, (int)(byte)10);
    testRational0.mysimp(0, 10, (int)(short)0, (int)'#', (-1), (int)'4');
    testRational0.mysimp(10, 0, (int)'#', (int)(short)0, (int)(byte)10, (int)(short)10);
    testRational0.mysimp((-1), 0, (int)' ', (int)(short)100, (int)' ', (int)'4');

  }

  @Test
  public void test146() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test146"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(10, (int)(short)100, (int)' ', (int)(byte)1, (int)(short)(-1), 0);
    testRational0.mysimp((int)(byte)100, (int)(short)(-1), (int)(byte)10, (int)(byte)100, (-1), 100);
    testRational0.mysimp((int)' ', (int)(short)(-1), (int)(short)1, (int)'#', (int)'a', 1);
    testRational0.mysimp((int)(byte)1, 0, (-1), (int)(short)1, (int)(short)10, (int)' ');

  }

  @Test
  public void test147() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test147"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(10, (int)(short)100, (int)' ', (int)(byte)1, (int)(short)(-1), 0);
    testRational0.mysimp(0, (int)'a', (-1), (int)(byte)10, (int)'#', (int)(byte)1);
    testRational0.mysimp((int)(short)(-1), 0, (int)(short)(-1), (int)(short)0, (int)' ', (int)(short)1);
    testRational0.mysimp(10, (int)(short)(-1), (int)(byte)1, (int)(short)100, 1, (int)(byte)10);
    testRational0.mysimp((int)(short)0, (int)(byte)10, (int)(byte)(-1), 1, 1, 100);
    testRational0.mysimp((int)'#', (int)(byte)10, (int)' ', (-1), 0, (int)(short)10);
    testRational0.mysimp((int)(short)(-1), (int)(short)0, (int)' ', (int)(short)100, 100, 0);
    testRational0.mysimp((-1), (int)(byte)(-1), (int)(byte)10, (int)(byte)(-1), 0, (int)'a');

  }

  @Test
  public void test148() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test148"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)(byte)100, (int)' ', 10, (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp((int)(short)0, (int)' ', (int)'a', (int)(short)10, (int)(short)(-1), (int)(short)100);
    testRational0.mysimp((int)(byte)0, (int)'a', 0, 100, (int)(short)(-1), (int)(short)0);
    testRational0.mysimp((-1), 0, 100, 100, (int)' ', (int)' ');
    testRational0.mysimp((int)'#', (int)(short)(-1), (-1), 10, (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp((int)(byte)1, 0, (-1), (int)(short)100, 0, (int)(byte)100);
    testRational0.mysimp((int)'#', (int)(byte)10, (-1), 0, 0, 0);
    testRational0.mysimp((int)(short)100, (int)'a', 100, (int)(short)1, (int)(short)10, 1);

  }

  @Test
  public void test149() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test149"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(10, (int)(short)100, (int)' ', (int)(byte)1, (int)(short)(-1), 0);
    testRational0.mysimp((int)(short)10, (int)(byte)10, (int)(byte)10, (int)(short)1, 10, (int)(byte)0);
    testRational0.mysimp((int)'#', (int)(short)10, (int)' ', 1, (int)' ', (int)(byte)10);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, (int)'a', (int)(byte)100, (int)(short)1);
    testRational0.mysimp((int)(byte)(-1), (int)(byte)1, (int)'a', (-1), 10, (int)(short)1);
    testRational0.mysimp(100, 0, 0, 0, (int)(short)0, 1);
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(short)1, 1, 100);
    testRational0.mysimp((int)(short)100, (int)'#', (int)(byte)(-1), (int)(short)(-1), (int)(short)1, (int)'4');
    testRational0.mysimp((int)(short)10, (int)(byte)(-1), (int)'#', (int)'a', (int)(short)0, (int)(short)0);

  }

  @Test
  public void test150() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test150"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 0, (-1), 100, (int)'a');
    testRational0.mysimp(0, (int)'4', (int)(byte)0, (int)(short)0, 0, (int)(short)100);
    testRational0.mysimp(10, (int)' ', (int)' ', 0, (int)' ', 10);
    testRational0.mysimp(100, (int)(byte)(-1), (int)'#', (int)(byte)10, (int)(short)100, (int)(short)10);
    testRational0.mysimp((int)(short)1, (int)'a', (int)(byte)1, (int)(short)1, (int)'#', (int)(short)1);
    testRational0.mysimp((int)(short)1, 1, (int)(short)0, (int)(short)1, (-1), 100);

  }

  @Test
  public void test151() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test151"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)' ', (int)(byte)0, (int)(byte)1, (int)(byte)100, 10, (int)'4');
    testRational0.mysimp((int)(short)10, (int)(short)100, (int)(short)(-1), 1, (int)(byte)100, (-1));
    testRational0.mysimp((-1), (int)(short)1, (int)(short)100, (int)'4', (int)(short)10, 100);
    testRational0.mysimp((int)'a', (-1), (int)(byte)100, (int)(short)10, (int)(short)100, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(byte)(-1), (int)(byte)(-1), 100, (int)' ', (-1));

  }

  @Test
  public void test152() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test152"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)(byte)100, (int)' ', 10, (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp((int)' ', 1, 1, (int)'a', 0, (int)'#');
    testRational0.mysimp((int)(short)1, (int)'#', (int)(short)(-1), (-1), 100, (int)(byte)100);
    testRational0.mysimp(10, (int)(byte)(-1), (int)(byte)(-1), 0, (int)(byte)10, (int)(byte)100);
    testRational0.mysimp((int)(short)10, (int)(short)0, (int)'#', 1, (-1), 100);
    testRational0.mysimp((int)(short)100, (int)(byte)10, (int)(short)(-1), (int)'4', (int)'#', (int)(byte)(-1));
    testRational0.mysimp((int)'#', (int)'a', 0, 0, 10, 0);
    testRational0.mysimp((int)'4', (int)'a', (int)(byte)(-1), (int)'4', (int)(short)1, (int)(byte)100);
    testRational0.mysimp((-1), (int)(short)10, (int)(byte)100, (int)' ', (int)(byte)10, (int)' ');
    testRational0.mysimp((int)'a', 10, 1, (int)'a', (-1), (int)(byte)1);

  }

  @Test
  public void test153() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test153"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)1, 1, (int)(short)1, 0);
    testRational0.mysimp((int)(byte)100, (int)(byte)100, (int)(short)1, (int)(short)10, (int)(short)1, (int)(short)0);
    testRational0.mysimp((int)'a', (int)(short)0, (int)(byte)1, (int)(byte)10, (int)(byte)100, 0);
    testRational0.mysimp((int)(byte)100, 1, (int)(short)1, (int)'4', (int)(byte)100, (int)(short)100);
    testRational0.mysimp(0, 0, (int)'4', (int)(short)10, (int)'4', (-1));
    testRational0.mysimp(0, (int)(byte)0, (int)(byte)(-1), 0, 0, (int)(byte)1);
    testRational0.mysimp((int)'4', (int)'4', (int)(byte)10, (int)'a', (int)(byte)0, (int)(short)10);
    testRational0.mysimp((int)(short)100, (int)'#', (int)(short)1, 10, (int)(byte)0, (int)' ');
    testRational0.mysimp((int)(byte)1, (int)'a', 100, (int)'a', (int)'a', 10);

  }

  @Test
  public void test154() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test154"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)(short)1, (int)(byte)10, (int)(byte)100, 1, (int)(byte)10, (int)(byte)(-1));
    testRational0.mysimp(0, (int)(short)(-1), (int)(short)0, (int)(byte)0, (int)' ', 1);
    testRational0.mysimp((int)(byte)100, (int)(short)0, (int)'a', (int)(short)0, (int)(short)1, (int)' ');
    testRational0.mysimp((int)(byte)(-1), (int)(short)10, (int)'#', (int)(short)10, (int)' ', (int)'a');
    testRational0.mysimp(10, (int)(short)10, (int)(byte)10, (int)(short)(-1), 1, (int)(byte)1);
    testRational0.mysimp((int)(byte)0, (int)(byte)1, (int)(byte)100, (int)(short)0, (int)(byte)100, (int)' ');
    testRational0.mysimp((int)(byte)10, (int)'#', (int)'#', (int)'4', 100, 0);
    testRational0.mysimp((int)(byte)10, (int)(byte)100, 0, (int)(byte)1, 0, (int)(byte)0);

  }

  @Test
  public void test155() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test155"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp((int)'4', (int)(short)100, 100, 0, (int)(byte)100, 0);
    testRational0.mysimp((int)(byte)10, 0, 10, (int)(short)0, 0, (int)(short)0);
    testRational0.mysimp(100, 10, (int)(byte)100, (int)(byte)(-1), (int)(byte)(-1), (int)(short)0);
    testRational0.mysimp((int)(byte)0, (int)(short)(-1), (int)(byte)10, (int)(byte)(-1), (int)(byte)100, (int)'a');
    testRational0.mysimp((int)(byte)10, (int)(short)0, (int)(byte)(-1), (int)(byte)(-1), (int)(short)10, 0);
    testRational0.mysimp((int)(short)100, (int)(byte)1, (int)'4', (int)(short)100, 0, 100);

  }

  @Test
  public void test156() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test156"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)100, (int)(short)0, (int)'4', (int)(short)100, 0, (int)(byte)(-1));
    testRational0.mysimp((int)(byte)0, (int)(byte)1, (int)(byte)0, (int)(short)10, (int)(byte)1, (int)'#');
    testRational0.mysimp((int)(byte)100, 100, (-1), (int)(short)10, 0, (int)'a');
    testRational0.mysimp((int)(short)100, 0, 10, 0, (int)(short)100, (int)(byte)(-1));
    testRational0.mysimp((int)(byte)1, (int)(byte)100, 0, 0, (-1), (int)' ');
    testRational0.mysimp((int)(byte)(-1), (int)' ', 1, (int)(byte)(-1), 10, 1);
    testRational0.mysimp((int)(short)100, (int)'4', (int)(short)1, (int)(short)100, (int)(short)10, (int)(byte)10);
    testRational0.mysimp((int)(short)0, 10, (int)(byte)1, (int)'a', (int)(short)1, (int)'4');

  }

  @Test
  public void test157() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test157"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp((int)(short)(-1), (int)(short)10, (int)(short)10, 0, (int)'4', (int)(byte)1);
    testRational0.mysimp((-1), (int)' ', (int)'a', (int)'4', (int)(short)0, (-1));
    testRational0.mysimp((int)(short)100, (int)'4', (int)(short)100, 1, (int)(byte)100, (int)(byte)10);
    testRational0.mysimp((int)' ', (int)'#', 1, (int)(short)10, (int)'#', 10);
    testRational0.mysimp(100, 1, 0, (int)(short)0, (int)(short)100, 0);
    testRational0.mysimp(100, (int)(short)100, (-1), (int)(short)1, (int)(byte)1, (int)(short)100);

  }

  @Test
  public void test158() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test158"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)(byte)100, (int)' ', 10, (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp((int)' ', 1, 1, (int)'a', 0, (int)'#');
    testRational0.mysimp((int)(short)1, (int)'#', (int)(short)(-1), (-1), 100, (int)(byte)100);
    testRational0.mysimp(10, (int)(byte)(-1), (int)(byte)(-1), 0, (int)(byte)10, (int)(byte)100);
    testRational0.mysimp((int)(short)10, (int)(short)0, (int)'#', 1, (-1), 100);
    testRational0.mysimp((int)(short)100, (int)(byte)10, (int)(short)(-1), (int)'4', (int)'#', (int)(byte)(-1));
    testRational0.mysimp((int)(byte)1, 10, 10, (int)'4', 0, (int)'a');
    testRational0.mysimp((int)(byte)0, (int)' ', (int)(short)(-1), 10, 0, 0);

  }

  @Test
  public void test159() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test159"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(byte)(-1), (int)(short)(-1), (int)(short)10, 0, (int)(byte)100, 1);
    testRational0.mysimp(10, (int)'#', (int)(short)10, 0, (int)(byte)100, 0);
    testRational0.mysimp((int)(byte)(-1), (int)' ', 0, (int)(short)0, (int)(byte)(-1), (int)'a');
    testRational0.mysimp((int)(byte)1, (int)(short)100, (int)'4', (int)(short)10, (-1), (int)(byte)10);

  }

  @Test
  public void test160() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test160"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)10, (int)'#', 0, (-1));
    testRational0.mysimp((int)'4', (int)(byte)(-1), (int)(byte)100, (int)(short)1, (int)'#', 100);
    testRational0.mysimp(10, 0, (int)(byte)100, (int)(short)0, (int)(short)(-1), (int)(short)(-1));
    testRational0.mysimp((int)'a', (int)'4', (int)(short)0, (int)(short)(-1), (int)' ', (int)(byte)100);
    testRational0.mysimp((int)(byte)1, 0, (int)'a', (int)(short)100, (int)'a', (int)'4');
    testRational0.mysimp((int)'a', (int)'4', (int)(byte)0, (int)(short)1, (int)' ', (int)(byte)0);

  }

  @Test
  public void test161() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test161"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(10, (int)(short)100, (int)' ', (int)(byte)1, (int)(short)(-1), 0);
    testRational0.mysimp((int)(byte)100, (int)(short)(-1), (int)(byte)10, (int)(byte)100, (-1), 100);
    testRational0.mysimp((int)(short)10, (int)(byte)(-1), (int)(byte)0, (int)'#', (int)' ', (int)(byte)10);
    testRational0.mysimp((int)'#', (int)(short)10, (int)(short)0, (int)'a', (int)(short)0, (int)(short)1);
    testRational0.mysimp((int)(byte)0, (int)(byte)1, 1, (int)(short)100, (int)(short)100, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)'#', (int)(short)100, (int)(byte)100, (int)'#', (int)(byte)0);
    testRational0.mysimp((int)(byte)10, (int)(short)0, 1, 0, (int)(byte)10, (int)(byte)1);
    testRational0.mysimp(100, 10, 1, (int)(short)10, (int)(short)0, 0);
    testRational0.mysimp((int)(short)0, 0, (int)(byte)(-1), (int)'#', (int)(byte)0, (int)'#');
    testRational0.mysimp((int)(short)0, 1, 100, (int)'#', (int)'#', (int)' ');
    testRational0.mysimp((int)(byte)10, (int)'#', 0, (int)(short)(-1), (-1), (int)(byte)10);

  }

  @Test
  public void test162() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test162"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)10, (int)'#', 0, (-1));
    testRational0.mysimp((int)'#', (int)'a', (int)(byte)1, (int)' ', 0, (int)'4');
    testRational0.mysimp(0, (int)' ', 100, (int)'4', (int)'a', 0);
    testRational0.mysimp((int)(short)0, (int)(byte)0, 100, (-1), 1, 10);
    testRational0.mysimp((-1), (int)'#', 10, 1, 0, (int)'a');

  }

  @Test
  public void test163() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test163"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(byte)0, (int)(short)0, 10, (int)(byte)(-1), (int)'4', (int)(byte)0);
    testRational0.mysimp((int)(byte)10, (int)(short)10, (int)'4', (int)(byte)(-1), (int)' ', 1);
    testRational0.mysimp((int)(short)(-1), (int)(byte)(-1), (int)(byte)100, 0, (int)(short)100, (int)(short)10);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)(byte)1, 0, (int)(short)0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)'#', (int)(short)1, 0, 100, (int)'#');
    testRational0.mysimp(0, (int)'a', (int)(byte)(-1), (int)(short)10, 0, (int)(byte)1);
    testRational0.mysimp(100, 10, 0, (int)'4', (int)(short)1, (int)'4');
    testRational0.mysimp((int)(byte)(-1), (int)'4', (int)(short)(-1), (int)(byte)0, (int)(short)100, 100);
    testRational0.mysimp(10, (int)'a', 10, (int)(short)100, (int)(byte)100, (int)(byte)(-1));

  }

  @Test
  public void test164() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test164"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(10, (int)(short)100, (int)(short)10, (int)(short)100, (int)(byte)10, 0);
    testRational0.mysimp(10, (int)'4', (int)(byte)0, (int)(byte)(-1), 0, 1);
    testRational0.mysimp((int)(short)(-1), (int)(short)(-1), 0, 100, (int)(byte)100, (int)(short)10);
    testRational0.mysimp((int)(byte)0, 0, (int)(byte)1, (-1), (int)'4', (int)(short)10);
    testRational0.mysimp((int)(short)1, 1, (int)'#', (int)(short)10, 0, (int)(byte)10);
    testRational0.mysimp((int)(short)10, (int)(short)0, (int)(short)100, (int)(short)(-1), (int)'#', (int)(short)10);
    testRational0.mysimp((int)(short)10, 0, (int)'#', 0, (int)'a', 10);
    testRational0.mysimp((-1), (int)(short)10, (int)' ', (int)(short)1, 0, (int)(byte)(-1));
    testRational0.mysimp((int)(short)0, (int)(byte)1, 1, (int)'4', 10, 10);

  }

  @Test
  public void test165() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test165"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)' ', 10, (int)' ', (int)(short)0, 0, (int)(short)1);
    testRational0.mysimp((int)'#', 100, (-1), 1, (-1), (int)(byte)(-1));
    testRational0.mysimp(0, 0, (int)'4', 1, 0, (-1));
    testRational0.mysimp((int)(byte)(-1), (int)(byte)0, (int)(short)10, 1, 0, (-1));
    testRational0.mysimp((int)'a', (int)(short)(-1), (int)' ', (int)(short)0, (int)'#', 1);

  }

  @Test
  public void test166() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test166"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)' ', 10, (int)' ', (int)(short)0, 0, (int)(short)1);
    testRational0.mysimp((int)(short)1, (int)' ', (int)(short)100, (int)(short)100, (int)(byte)100, 10);
    testRational0.mysimp((int)'#', (int)'a', (int)(short)0, (int)(short)10, 1, (int)'a');
    testRational0.mysimp(10, 10, (int)(short)10, (int)'4', (int)(byte)100, (int)(byte)0);
    testRational0.mysimp((int)(byte)1, (int)'4', (int)(short)10, (int)'a', (int)(short)10, (int)(short)(-1));
    testRational0.mysimp((int)(byte)1, 10, (int)(byte)(-1), (int)(short)100, 1, (int)'#');
    testRational0.mysimp((int)(byte)(-1), (int)(byte)100, (int)(byte)10, (int)(byte)10, (int)(short)(-1), 10);
    testRational0.mysimp(100, (int)(short)100, (int)(short)100, (int)'#', (int)(byte)1, 1);
    testRational0.mysimp(0, (int)(short)(-1), 0, (int)(byte)(-1), (int)(byte)(-1), (int)(short)1);
    testRational0.mysimp(0, (int)(short)1, (int)'4', (int)(short)1, (int)(byte)1, 1);

  }

  @Test
  public void test167() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test167"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, 100, 100);
    testRational0.mysimp((int)(byte)(-1), (int)'a', (-1), (int)'4', (-1), (int)(byte)0);
    testRational0.mysimp((int)' ', 0, (int)'#', (int)(short)100, (int)(short)0, 100);
    testRational0.mysimp((int)'a', (int)(short)1, 1, (int)'4', (int)'4', 10);
    testRational0.mysimp((-1), 0, (int)'4', (-1), (int)(byte)0, (int)(short)1);
    testRational0.mysimp((int)(short)0, 100, (int)'4', (int)(short)0, 0, (int)(byte)100);
    testRational0.mysimp((int)(short)1, (int)'a', (int)(short)(-1), (int)(short)(-1), (int)(short)0, (int)(short)(-1));
    testRational0.mysimp(1, (int)'#', (int)' ', (int)(byte)0, (int)(byte)(-1), (int)(short)0);
    testRational0.mysimp((int)' ', (int)(short)(-1), (int)(short)100, (int)'a', (int)'4', (int)'4');
    testRational0.mysimp((int)'4', 0, (int)(short)100, 0, (int)(byte)100, 10);
    testRational0.mysimp((int)(short)1, (int)(short)0, 10, (int)'#', (int)(short)0, 0);

  }

  @Test
  public void test168() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test168"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(100, 100, 0, 1, (int)'a', 0);
    testRational0.mysimp((int)'a', (int)(byte)(-1), (int)(short)10, (int)'a', (int)'a', (int)(byte)0);
    testRational0.mysimp((int)'a', 1, 10, (int)'a', (int)' ', (int)' ');
    testRational0.mysimp((int)(short)100, (int)(byte)1, (int)(short)10, (int)(byte)(-1), (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp(10, (int)(byte)100, (int)(short)(-1), (int)'a', (int)(short)100, 0);
    testRational0.mysimp(100, 10, 1, (int)(short)100, (int)(short)100, (int)(short)0);
    testRational0.mysimp((int)(short)100, 10, (int)(byte)0, (int)(byte)(-1), 0, 1);

  }

  @Test
  public void test169() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test169"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(100, (int)(short)1, 0, (int)(byte)(-1), (int)(byte)1, 0);
    testRational0.mysimp(10, (int)(short)1, (int)(byte)100, (int)(byte)1, (int)(short)1, (int)(short)10);
    testRational0.mysimp((int)'#', 0, (int)(byte)1, 0, (int)(short)1, (int)'a');

  }

  @Test
  public void test170() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test170"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(10, (int)(short)100, (int)' ', (int)(byte)1, (int)(short)(-1), 0);
    testRational0.mysimp((int)(byte)100, (int)(short)(-1), (int)(byte)10, (int)(byte)100, (-1), 100);
    testRational0.mysimp((int)(short)10, (int)(byte)(-1), (int)(byte)0, (int)'#', (int)' ', (int)(byte)10);
    testRational0.mysimp((int)'#', (int)(short)10, (int)(short)0, (int)'a', (int)(short)0, (int)(short)1);
    testRational0.mysimp((int)(byte)0, (int)(byte)1, 1, (int)(short)100, (int)(short)100, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)'#', (int)(short)100, (int)(byte)100, (int)'#', (int)(byte)0);
    testRational0.mysimp((int)(short)10, (int)'4', (-1), (int)(byte)1, (int)'4', (int)(byte)1);
    testRational0.mysimp(100, (int)'#', (int)(byte)(-1), (int)(byte)(-1), (int)(byte)(-1), (int)(byte)10);
    testRational0.mysimp(0, 1, (int)(short)10, 10, (int)(short)0, (int)(short)0);

  }

  @Test
  public void test171() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test171"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)10, (int)'#', 0, (-1));
    testRational0.mysimp((int)'4', (int)(byte)(-1), (int)(byte)100, (int)(short)1, (int)'#', 100);
    testRational0.mysimp((int)(byte)10, (int)'a', (int)(short)100, (int)'#', (int)(short)10, (int)(short)100);
    testRational0.mysimp((int)(short)0, 100, (int)(byte)(-1), (int)'#', (int)(byte)(-1), 0);
    testRational0.mysimp(0, (int)(byte)(-1), 1, 100, 100, (int)(short)1);
    testRational0.mysimp((int)'#', (int)(byte)0, 100, (int)(byte)10, (int)' ', 1);
    testRational0.mysimp((int)(short)0, (int)(short)1, (int)' ', (int)(short)10, 0, 10);

  }

  @Test
  public void test172() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test172"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(byte)0, (int)(short)0, 10, (int)(byte)(-1), (int)'4', (int)(byte)0);
    testRational0.mysimp((int)(byte)10, (int)(short)10, (int)'4', (int)(byte)(-1), (int)' ', 1);
    testRational0.mysimp((int)(byte)(-1), (int)(byte)1, (int)(short)0, (int)(short)1, (int)(byte)(-1), (int)(short)0);
    testRational0.mysimp(1, (-1), 0, (int)(byte)0, (int)(short)100, (int)(short)100);
    testRational0.mysimp((int)(byte)0, 1, (int)' ', 0, (int)(byte)0, 100);
    testRational0.mysimp(1, (int)(byte)(-1), (int)'4', (int)(short)0, (int)(byte)0, (int)'a');
    testRational0.mysimp((int)(byte)10, 0, 0, (int)(byte)100, 0, 100);
    testRational0.mysimp((int)(short)10, (int)' ', (int)'a', 1, (int)'#', (int)(short)10);

  }

  @Test
  public void test173() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test173"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'a', (int)(byte)0, 0, (int)(short)0, 0);
    testRational0.mysimp(100, (int)(byte)10, (int)(byte)10, 10, 0, (int)(short)1);
    testRational0.mysimp(1, (int)(short)0, (int)(byte)1, (int)(short)(-1), 1, (int)(byte)(-1));
    testRational0.mysimp((int)(byte)10, (int)(byte)100, (int)(byte)0, 10, 1, (int)(byte)1);
    testRational0.mysimp((int)'4', (int)(short)10, (int)'4', (int)(short)(-1), (int)' ', (int)'4');
    testRational0.mysimp((int)(byte)100, 0, (int)(short)0, 10, 0, 0);
    testRational0.mysimp((int)' ', (-1), (int)(byte)10, (int)(byte)(-1), (int)'4', (int)(short)0);
    testRational0.mysimp((int)(short)10, (int)(short)1, (int)(byte)100, (int)(short)1, (int)(short)(-1), 10);

  }

  @Test
  public void test174() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test174"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(10, (int)(short)100, (int)(short)10, (int)(short)100, (int)(byte)10, 0);
    testRational0.mysimp((int)(byte)10, (int)(byte)10, (int)(byte)0, (int)'#', (int)(short)0, 0);
    testRational0.mysimp(10, (int)(short)(-1), (int)(byte)0, 0, (int)(byte)100, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)(byte)100, (int)'#', (-1), 100, (int)(byte)1);
    testRational0.mysimp((-1), (int)'a', (int)'a', 1, (int)' ', (int)' ');
    testRational0.mysimp((int)(byte)1, (int)(short)1, 10, (int)(short)1, (int)(short)1, 10);
    testRational0.mysimp((int)(byte)100, (int)(short)(-1), (int)(short)100, (-1), (int)(byte)100, 10);

  }

  @Test
  public void test175() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test175"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'a', (int)(byte)0, 0, (int)(short)0, 0);
    testRational0.mysimp((int)(short)10, (int)(byte)0, (int)'a', (int)(byte)0, (int)(byte)0, (int)(byte)(-1));
    testRational0.mysimp((int)(short)1, (int)(short)0, (int)(short)0, (int)' ', (int)(byte)100, 0);
    testRational0.mysimp(1, (int)(byte)100, 100, (int)(short)(-1), (int)(byte)0, (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(byte)100, (int)'4', (int)(short)(-1), 0);
    testRational0.mysimp(0, (int)(short)10, (int)(short)10, (int)'4', 10, 0);
    testRational0.mysimp((int)(byte)0, (int)(byte)1, (int)(byte)0, (int)' ', (int)' ', (int)(byte)1);

  }

  @Test
  public void test176() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test176"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)(short)100, (int)(byte)1, (int)(byte)0, 100, (int)(short)100);
    testRational0.mysimp((int)(short)(-1), 0, (int)(short)0, 10, 0, (int)(byte)10);
    testRational0.mysimp(0, (int)'#', 100, (int)' ', (int)(short)0, (int)(byte)1);
    testRational0.mysimp((int)'4', (int)(byte)0, (int)(short)(-1), 0, (int)'#', (int)(short)10);
    testRational0.mysimp((int)(short)0, 10, (int)(byte)10, 1, (int)'a', (int)'4');
    testRational0.mysimp((int)(byte)1, (int)(short)10, (int)(short)(-1), (int)' ', 100, (int)'4');
    testRational0.mysimp((-1), (int)'a', 0, (int)(byte)1, (int)(byte)0, (int)(byte)10);
    testRational0.mysimp((int)(short)100, (int)(short)0, (int)(short)100, (-1), (int)'4', (int)(byte)0);

  }

  @Test
  public void test177() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test177"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)'4', (int)(byte)(-1), 10, (int)(short)0, 0);
    testRational0.mysimp((-1), (int)(byte)(-1), (int)(short)100, (int)' ', 0, (int)(byte)10);
    testRational0.mysimp((int)(short)(-1), (int)(short)0, 100, 10, (int)(short)1, 100);

  }

  @Test
  public void test178() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test178"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(10, (int)'a', (int)(short)10, (int)(short)(-1), (int)(byte)0, (int)'a');
    testRational0.mysimp((int)(byte)100, (int)(short)0, (int)'a', (int)(byte)(-1), 0, (int)(short)(-1));
    testRational0.mysimp((int)(short)10, (int)(short)0, (int)(byte)0, (int)(byte)1, (int)(byte)(-1), (int)(short)100);
    testRational0.mysimp((int)(short)1, (int)(byte)100, (-1), (int)' ', (int)(byte)(-1), (int)(short)(-1));
    testRational0.mysimp(10, (int)' ', (int)(short)(-1), (int)(short)100, 0, (int)(byte)0);
    testRational0.mysimp((int)(short)1, (int)(byte)10, 0, (int)(short)10, (int)(short)0, (-1));
    testRational0.mysimp((int)(short)(-1), 10, (int)(byte)(-1), (int)(byte)0, (int)(short)0, (int)(short)100);

  }

  @Test
  public void test179() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test179"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp((-1), (int)(short)(-1), (int)(byte)100, (int)(byte)0, (int)(short)1, (int)'#');
    testRational0.mysimp(0, 100, 10, (int)(short)100, (int)(byte)1, 10);
    testRational0.mysimp((int)'4', (int)(byte)100, (int)(byte)1, (int)'#', (int)'a', (-1));
    testRational0.mysimp(1, (int)'#', 10, (int)(byte)10, 100, (int)(short)1);
    testRational0.mysimp((int)'#', (int)(short)1, (int)(byte)1, (int)'a', (int)(short)0, 10);
    testRational0.mysimp(100, (int)' ', 0, (-1), (int)' ', (int)(byte)100);

  }

  @Test
  public void test180() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test180"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)' ', 10, (int)' ', (int)(short)0, 0, (int)(short)1);
    testRational0.mysimp((int)(short)1, (int)' ', (int)(short)100, (int)(short)100, (int)(byte)100, 10);
    testRational0.mysimp((int)'#', (int)'a', (int)(short)0, (int)(short)10, 1, (int)'a');
    testRational0.mysimp(10, 10, (int)(short)10, (int)'4', (int)(byte)100, (int)(byte)0);
    testRational0.mysimp((int)(short)(-1), (int)(byte)100, (int)(byte)100, 1, (int)(byte)100, 0);
    testRational0.mysimp(0, 1, (int)(short)1, (int)(byte)10, 0, 0);
    testRational0.mysimp(0, (int)(short)1, 100, 10, (int)'#', (int)(short)100);
    testRational0.mysimp((int)'4', (int)' ', (int)'#', (int)(short)1, 10, (int)'4');

  }

  @Test
  public void test181() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test181"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)(byte)100, (int)' ', 10, (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp((int)(short)0, (int)' ', (int)'a', (int)(short)10, (int)(short)(-1), (int)(short)100);
    testRational0.mysimp((int)(short)100, 100, (int)(byte)0, 10, (int)(byte)100, (-1));
    testRational0.mysimp((int)(short)1, (int)'4', (int)(byte)0, 10, 10, (int)(byte)0);
    testRational0.mysimp((int)'a', 1, 100, (int)'a', 10, (int)(short)100);
    testRational0.mysimp((int)(byte)10, (int)(short)10, 0, (int)(short)(-1), (int)'4', 10);
    testRational0.mysimp(1, (-1), (int)(byte)100, (int)(short)(-1), (int)(short)(-1), (int)(short)0);
    testRational0.mysimp((int)(byte)100, 100, (int)(byte)0, 1, (int)(short)(-1), (int)(short)(-1));

  }

  @Test
  public void test182() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test182"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'#', 1, (int)(short)10, (int)'4', (int)(short)1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)10, (int)(short)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)'#', (int)(short)0, (int)(short)100, 0, (int)(byte)10, (int)(short)10);
    testRational0.mysimp((int)'a', (int)(short)0, 0, (int)(byte)10, (int)(short)10, (int)(short)100);
    testRational0.mysimp(1, 10, 100, (int)(short)(-1), (int)(short)1, (int)'a');
    testRational0.mysimp((int)(short)1, 0, (int)(short)1, (int)(short)100, (int)(short)(-1), (int)(byte)1);
    testRational0.mysimp((int)(short)100, (int)'#', (int)'4', 10, 100, 100);

  }

  @Test
  public void test183() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test183"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)1, 1, (int)(short)1, 0);
    testRational0.mysimp((int)(byte)100, (int)(byte)100, (int)(short)1, (int)(short)10, (int)(short)1, (int)(short)0);
    testRational0.mysimp(10, 0, 10, 0, (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp((int)(byte)1, (int)'4', 10, (int)'a', (int)(short)100, (-1));
    testRational0.mysimp(10, (int)(short)10, (int)(byte)(-1), 0, (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)100, (int)(short)0, (int)'#', (-1), (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp((int)'a', (int)(short)1, (int)(byte)100, 0, (int)(short)100, 1);

  }

  @Test
  public void test184() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test184"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)1, (int)(short)10, 0, 1, (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp((int)(short)(-1), 100, (int)(short)0, (int)(byte)1, (int)'4', (int)(short)10);
    testRational0.mysimp((int)(byte)(-1), (int)' ', (int)(byte)0, (int)'4', 100, 1);
    testRational0.mysimp(100, (int)(short)1, (int)'a', (int)(byte)100, (int)' ', 1);

  }

  @Test
  public void test185() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test185"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)(short)(-1), 100, (int)(byte)10, (int)'4', (int)(short)(-1));
    testRational0.mysimp((-1), 10, (int)'#', (int)(byte)1, (int)(byte)10, 100);
    testRational0.mysimp((int)(byte)100, 10, (int)(byte)0, (int)(byte)100, 10, (-1));
    testRational0.mysimp((int)(short)1, (int)(byte)100, 10, 10, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(short)100, (int)(byte)10, 10, (int)(byte)1, (int)(short)10, (int)' ');
    testRational0.mysimp((int)(byte)1, (int)(byte)1, (int)' ', (int)' ', 0, (-1));
    testRational0.mysimp((-1), (int)' ', 0, (int)(byte)100, (int)'#', 0);
    testRational0.mysimp((int)(byte)1, 1, (int)(byte)0, (int)'#', 0, (int)(byte)0);

  }

  @Test
  public void test186() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test186"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp((int)(short)(-1), (int)(short)10, (int)(short)10, 0, (int)'4', (int)(byte)1);
    testRational0.mysimp((-1), (int)' ', (int)'a', (int)'4', (int)(short)0, (-1));
    testRational0.mysimp((int)(short)100, (int)'4', (int)(short)100, 1, (int)(byte)100, (int)(byte)10);
    testRational0.mysimp((-1), (int)(byte)100, (int)(short)0, (int)(byte)10, (int)(byte)1, (int)(short)100);
    testRational0.mysimp(100, (int)(short)10, (int)(short)0, (int)(short)10, (int)'4', 0);
    testRational0.mysimp((int)(byte)10, 1, (int)'4', (int)(short)100, 1, (int)(byte)0);
    testRational0.mysimp((int)'#', (int)(byte)(-1), (int)(short)1, (int)(short)10, (int)(byte)(-1), 1);

  }

  @Test
  public void test187() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test187"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)(byte)100, (int)' ', 10, (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp((int)(short)0, (int)' ', (int)'a', (int)(short)10, (int)(short)(-1), (int)(short)100);
    testRational0.mysimp((int)(byte)0, (int)'a', 0, 100, (int)(short)(-1), (int)(short)0);
    testRational0.mysimp((int)'4', (int)(byte)0, 0, (int)(byte)10, (-1), 1);
    testRational0.mysimp((int)'a', (int)(byte)(-1), 0, 10, (int)(byte)0, (-1));
    testRational0.mysimp((int)(short)10, 100, (int)(byte)100, (int)'a', 1, (int)'#');
    testRational0.mysimp((int)(byte)(-1), 0, (-1), (int)(short)100, (int)(short)1, 1);

  }

  @Test
  public void test188() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test188"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)(short)1, (int)(byte)10, (int)(byte)100, 1, (int)(byte)10, (int)(byte)(-1));
    testRational0.mysimp((int)(short)100, 0, (int)'4', (int)'4', (int)(short)1, (int)(byte)(-1));
    testRational0.mysimp(0, (int)' ', (int)(short)(-1), (-1), (int)(short)(-1), (int)' ');
    testRational0.mysimp(0, (int)(short)100, (int)'4', (int)(byte)(-1), (int)(byte)0, (int)'4');
    testRational0.mysimp((int)(byte)(-1), 100, 10, (int)(byte)(-1), 0, (int)(byte)10);
    testRational0.mysimp((int)' ', (int)(short)(-1), (int)'a', 1, (int)(short)(-1), (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)(byte)1, 0, (int)'#', 0, (-1));

  }

  @Test
  public void test189() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test189"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'a', (int)(byte)0, 0, (int)(short)0, 0);
    testRational0.mysimp((-1), 10, (int)(byte)10, 0, (int)' ', 0);
    testRational0.mysimp((int)'4', (-1), (int)'4', (int)(byte)10, (int)(byte)100, (int)' ');
    testRational0.mysimp(0, 0, (int)(byte)0, (int)'4', (int)(short)1, (int)(byte)0);
    testRational0.mysimp((int)(short)(-1), (int)(byte)(-1), (int)(short)0, (int)(byte)1, 10, 0);
    testRational0.mysimp((int)(short)100, 100, 10, (int)(byte)100, 10, (int)(short)100);
    testRational0.mysimp((int)(short)0, (-1), 1, 1, (int)'#', (-1));
    testRational0.mysimp((int)(short)(-1), (int)' ', (int)(short)100, (int)'a', (int)(byte)10, 0);

  }

  @Test
  public void test190() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test190"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp((int)(short)(-1), (int)(short)10, (int)(short)10, 0, (int)'4', (int)(byte)1);
    testRational0.mysimp((int)(short)(-1), (int)'a', (int)(byte)(-1), (int)(byte)1, 0, 0);
    testRational0.mysimp(10, (int)(short)(-1), 0, (int)(short)1, (int)(byte)(-1), (int)'a');
    testRational0.mysimp((int)(byte)0, (int)(short)(-1), (int)(byte)100, (int)(byte)1, 0, (int)(byte)10);
    testRational0.mysimp((int)(byte)10, (int)(byte)10, 0, 0, (int)' ', (int)(byte)(-1));
    testRational0.mysimp((int)(short)100, (int)(short)100, 1, 1, (int)'a', (int)(byte)(-1));
    testRational0.mysimp((int)(byte)0, 0, (int)(short)(-1), 1, (int)(byte)1, 100);
    testRational0.mysimp((int)(byte)(-1), (-1), 1, (-1), (int)(short)0, (int)'#');
    testRational0.mysimp(0, (int)'#', (int)(short)0, (int)(short)10, (int)(byte)(-1), (int)(byte)0);

  }

  @Test
  public void test191() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test191"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)(byte)100, (int)' ', 10, (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp((int)' ', 1, 1, (int)'a', 0, (int)'#');
    testRational0.mysimp((int)(short)1, (int)'#', (int)(short)(-1), (-1), 100, (int)(byte)100);
    testRational0.mysimp(10, (int)(byte)(-1), (int)(byte)(-1), 0, (int)(byte)10, (int)(byte)100);
    testRational0.mysimp((int)(byte)1, (int)(byte)1, (int)(short)(-1), (int)' ', (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp(1, (-1), (int)(byte)100, (int)(short)10, (int)(byte)100, (-1));
    testRational0.mysimp(1, (int)(short)1, (int)(short)10, (int)'a', (int)(byte)(-1), 0);
    testRational0.mysimp((int)(byte)10, 0, (int)(short)1, (int)(byte)1, (int)(short)0, (int)(short)1);
    testRational0.mysimp((int)(byte)100, (int)(byte)1, (int)'4', 10, (int)'#', (int)(byte)(-1));
    testRational0.mysimp((-1), (-1), (int)'#', (int)'4', (int)(short)100, (int)(byte)0);
    testRational0.mysimp(0, (int)'a', (int)(short)(-1), (int)(short)100, (int)(short)10, (int)(short)1);
    testRational0.mysimp((int)'#', 1, 10, (int)(short)10, 100, 1);

  }

  @Test
  public void test192() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test192"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)(byte)100, (int)' ', 10, (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp((int)' ', 1, 1, (int)'a', 0, (int)'#');
    testRational0.mysimp((int)(short)0, (int)'4', 0, (int)'#', (int)'4', (int)' ');
    testRational0.mysimp(0, 10, (int)(short)10, (int)'a', 0, 10);
    testRational0.mysimp((int)(short)10, 1, (int)(short)0, 0, (int)'4', (int)(byte)(-1));

  }

  @Test
  public void test193() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test193"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)' ', (int)(byte)0, (int)(byte)1, (int)(byte)100, 10, (int)'4');
    testRational0.mysimp((int)(short)10, (int)(short)100, (int)(short)(-1), 1, (int)(byte)100, (-1));
    testRational0.mysimp((int)(byte)0, 0, 0, (int)'a', (int)' ', (int)'a');
    testRational0.mysimp((int)'4', 100, (int)(short)0, (int)(short)0, (int)(short)1, (-1));
    testRational0.mysimp((int)'4', 10, (int)(byte)10, (-1), (int)(byte)(-1), (int)(short)10);
    testRational0.mysimp(100, (int)(short)0, 0, (int)(short)0, 1, 0);
    testRational0.mysimp((int)(byte)100, (int)(short)0, (int)'a', 1, (int)(short)100, 10);
    testRational0.mysimp((int)(short)10, (int)'4', (int)(short)0, 100, (int)(short)1, (int)(short)10);
    testRational0.mysimp((int)(byte)(-1), (int)(short)0, (int)(byte)100, (int)'#', (int)'#', 0);
    testRational0.mysimp((int)(byte)1, (int)(short)100, (int)'4', (int)(short)100, 0, (int)' ');
    testRational0.mysimp((int)(byte)1, (int)(short)1, 0, (int)(byte)1, 0, (int)(short)1);

  }

  @Test
  public void test194() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test194"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)1, 1, (int)(short)1, 0);
    testRational0.mysimp((int)(byte)100, (int)(byte)100, (int)(short)1, (int)(short)10, (int)(short)1, (int)(short)0);
    testRational0.mysimp(100, (int)(byte)1, (int)'a', (int)(byte)(-1), (int)' ', (int)'4');
    testRational0.mysimp((int)(short)100, (int)'a', (int)(short)1, 0, 100, 100);
    testRational0.mysimp(100, (int)(byte)0, (int)(short)10, (-1), 0, (int)' ');

  }

  @Test
  public void test195() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test195"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, 100, 100);
    testRational0.mysimp(0, (int)'4', (int)' ', (int)(byte)100, (int)(byte)1, (int)(short)100);
    testRational0.mysimp((int)(short)100, (int)(byte)0, (int)(short)100, (int)' ', 0, (-1));
    testRational0.mysimp((int)' ', (int)(byte)(-1), (int)'4', (int)(byte)(-1), (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)10, (int)(short)10, (int)(short)10, (int)'4', 10, (int)(short)1);
    testRational0.mysimp((int)(short)100, 100, (int)(short)1, (int)(short)(-1), (int)(short)(-1), 100);
    testRational0.mysimp((int)'a', 0, (int)'#', (int)(short)(-1), 100, (int)' ');
    testRational0.mysimp(0, (-1), (int)(byte)100, 0, 0, (int)'#');
    testRational0.mysimp((int)(short)0, (int)'a', (int)'#', 10, 100, 10);
    testRational0.mysimp(0, (int)' ', (int)(byte)(-1), (-1), (int)(byte)10, (int)(short)(-1));

  }

  @Test
  public void test196() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test196"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'a', (int)(byte)0, 0, (int)(short)0, 0);
    testRational0.mysimp(100, (int)(byte)10, (int)(byte)10, 10, 0, (int)(short)1);
    testRational0.mysimp(1, (int)(short)0, (int)(byte)1, (int)(short)(-1), 1, (int)(byte)(-1));
    testRational0.mysimp((int)(byte)10, (int)(byte)100, (int)(byte)0, 10, 1, (int)(byte)1);
    testRational0.mysimp((int)(byte)10, (int)(short)100, (int)'4', (int)(byte)100, (int)(byte)1, (int)'#');
    testRational0.mysimp((int)'#', (int)(byte)0, 0, (int)(short)10, (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)100, (int)'a', (int)(short)100, (int)'4', (int)(byte)10);

  }

  @Test
  public void test197() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test197"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)' ', (int)(byte)0, (int)(byte)1, (int)(byte)100, 10, (int)'4');
    testRational0.mysimp((int)(short)10, (int)(short)100, (int)(short)(-1), 1, (int)(byte)100, (-1));
    testRational0.mysimp((int)(byte)0, 0, 0, (int)'a', (int)' ', (int)'a');
    testRational0.mysimp((int)'4', 100, (int)(short)0, (int)(short)0, (int)(short)1, (-1));
    testRational0.mysimp((int)'4', 10, (int)(byte)10, (-1), (int)(byte)(-1), (int)(short)10);
    testRational0.mysimp((-1), 10, (-1), (int)(short)1, 10, 10);
    testRational0.mysimp((int)(short)0, (-1), (int)' ', (int)(byte)1, 100, (int)(short)0);
    testRational0.mysimp((int)'a', (int)'4', 1, 0, (int)'4', 10);

  }

  @Test
  public void test198() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test198"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(10, (int)(byte)100, (int)(byte)10, (int)(short)0, (int)(byte)0, (int)' ');
    testRational0.mysimp((int)(short)10, (int)(byte)10, (int)(short)100, (int)(byte)0, (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp((int)'4', (int)(byte)1, (int)(byte)0, (int)'4', (int)(short)1, 0);
    testRational0.mysimp(100, (int)(short)0, (int)'4', (int)(short)10, 0, (int)(byte)1);

  }

  @Test
  public void test199() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test199"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(10, (int)(short)100, (int)' ', (int)(byte)1, (int)(short)(-1), 0);
    testRational0.mysimp((int)(short)(-1), 100, 1, 0, (int)(short)10, (int)(byte)10);
    testRational0.mysimp(100, (-1), (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)(-1));
    testRational0.mysimp((int)(byte)1, (int)(short)1, (int)(short)0, 10, (int)(short)100, (int)'#');
    testRational0.mysimp((int)(short)100, (int)(short)0, (int)(short)10, 100, (-1), 0);

  }

  @Test
  public void test200() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test200"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)(byte)100, (int)' ', 10, (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp((int)(short)0, (int)' ', (int)'a', (int)(short)10, (int)(short)(-1), (int)(short)100);
    testRational0.mysimp((int)(short)(-1), (int)'#', (int)(byte)1, (int)' ', (int)(short)100, 100);
    testRational0.mysimp((int)'a', (-1), (int)(byte)1, (int)(byte)0, (int)(byte)1, 10);
    testRational0.mysimp((-1), (int)'4', (int)(byte)1, (int)'4', 10, (int)(byte)10);
    testRational0.mysimp((int)(short)(-1), (int)(byte)0, (int)'a', (int)' ', (int)(byte)100, (int)(byte)0);
    testRational0.mysimp((int)(short)100, (int)'a', 0, (int)(short)100, 0, (int)(byte)1);
    testRational0.mysimp((int)(byte)0, (int)' ', (int)(short)(-1), (int)(byte)100, (int)(byte)0, (int)'#');

  }

  @Test
  public void test201() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test201"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)'a', (int)(byte)(-1), (int)' ', (int)'#', (int)(short)1);
    testRational0.mysimp((int)(byte)1, 1, (int)(short)1, (int)(short)100, (int)(byte)(-1), (int)'#');
    testRational0.mysimp(10, (int)(short)10, (int)' ', (int)(short)10, (int)'a', (int)(byte)(-1));
    testRational0.mysimp((int)' ', (int)(short)100, (int)(short)(-1), 1, 0, (int)(short)1);
    testRational0.mysimp(0, (int)(byte)0, 100, (int)' ', 0, 0);

  }

  @Test
  public void test202() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test202"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(byte)100, (int)(byte)1, (int)(byte)(-1), 1, (int)(byte)0, 10);
    testRational0.mysimp(0, (int)'#', (int)(short)0, (int)'#', 100, (int)(short)100);
    testRational0.mysimp((int)'#', (int)(short)(-1), 0, (int)'a', (int)(byte)100, (-1));
    testRational0.mysimp((int)(short)10, 0, 100, 0, 10, (int)(byte)0);
    testRational0.mysimp((int)'#', (int)(byte)10, 10, (int)(short)10, 100, (int)(byte)100);

  }

  @Test
  public void test203() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test203"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(10, (int)'a', (int)(short)10, (int)(short)(-1), (int)(byte)0, (int)'a');
    testRational0.mysimp((int)(byte)100, (int)(short)0, (int)'a', (int)(byte)(-1), 0, (int)(short)(-1));
    testRational0.mysimp((int)(byte)10, 0, (int)(short)(-1), (int)(short)1, 0, (int)(byte)0);
    testRational0.mysimp((int)(short)10, (-1), (int)(byte)0, 0, (int)(byte)0, (int)' ');
    testRational0.mysimp(0, (int)(short)1, (int)(byte)(-1), (int)(short)(-1), (int)(short)(-1), 0);
    testRational0.mysimp((int)(short)100, 100, (int)(short)100, (int)'4', 0, (int)(short)10);
    testRational0.mysimp(100, 0, (int)(byte)1, (int)(byte)1, 1, (-1));
    testRational0.mysimp((int)' ', (int)(short)10, (-1), (int)(byte)1, (int)'a', (int)(short)10);

  }

  @Test
  public void test204() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test204"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)'a', 100, 1, (int)(short)1, 0, 10);
    testRational0.mysimp((int)(short)100, 100, 0, 1, (int)(short)(-1), (int)(byte)10);
    testRational0.mysimp((int)(short)1, (int)(byte)100, 100, 100, (int)(short)100, 10);
    testRational0.mysimp((int)'#', (int)(byte)1, (int)(byte)0, (int)(byte)1, (int)'a', (int)(short)10);

  }

  @Test
  public void test205() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test205"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)100, (int)(short)0, (int)'4', (int)(short)100, 0, (int)(byte)(-1));
    testRational0.mysimp((int)(byte)1, (int)(byte)1, (int)(byte)10, 0, (int)'#', (int)(byte)1);
    testRational0.mysimp((int)'a', (int)(short)100, (int)'4', (int)(byte)(-1), (int)(byte)100, (int)(short)(-1));
    testRational0.mysimp((int)' ', (int)(short)100, 10, (int)(short)1, (int)(short)1, (int)(byte)10);
    testRational0.mysimp((int)(byte)10, (-1), 10, (int)(byte)10, (int)(short)0, (int)(byte)10);

  }

  @Test
  public void test206() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test206"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(100, 100, 0, 1, (int)'a', 0);
    testRational0.mysimp((int)'a', (int)(byte)(-1), (int)(short)10, (int)'a', (int)'a', (int)(byte)0);
    testRational0.mysimp((int)'a', 1, 10, (int)'a', (int)' ', (int)' ');
    testRational0.mysimp((int)(short)100, (int)(byte)1, (int)(short)10, (int)(byte)(-1), (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp((int)'a', (int)(short)(-1), 0, (int)(short)1, 10, 1);
    testRational0.mysimp(10, (int)'#', 100, (int)(byte)1, 1, (int)(short)0);
    testRational0.mysimp((int)'4', 1, 0, (int)'a', 100, (int)(byte)1);
    testRational0.mysimp((int)'#', 0, (int)(byte)10, (int)'#', 0, (int)(byte)1);

  }

  @Test
  public void test207() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test207"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(short)(-1), (int)(short)10, (int)' ', 0, (int)(byte)100, (int)' ');
    testRational0.mysimp((int)' ', 0, (int)(byte)100, 100, (int)(byte)10, 0);
    testRational0.mysimp(0, (int)(byte)(-1), 1, (int)(byte)1, (int)(byte)(-1), (int)'a');
    testRational0.mysimp((int)(short)1, (int)'#', (int)' ', (int)'#', (int)(byte)100, (int)' ');
    testRational0.mysimp((int)(byte)0, 0, (int)'#', (int)(short)0, 100, (int)(byte)0);
    testRational0.mysimp((int)(byte)(-1), 1, (-1), 100, (int)'a', 1);

  }

  @Test
  public void test208() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test208"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(short)(-1), (int)(short)10, (int)' ', 0, (int)(byte)100, (int)' ');
    testRational0.mysimp((int)(byte)10, (-1), (int)(short)(-1), (int)' ', (int)'4', (int)'#');
    testRational0.mysimp(0, 0, (int)(short)(-1), (-1), 10, (int)'4');
    testRational0.mysimp((int)' ', 1, (int)'4', 10, (int)(short)1, (int)'4');
    testRational0.mysimp((int)(byte)0, (int)(short)100, 0, (int)(byte)100, (int)(byte)100, (int)'a');
    testRational0.mysimp(1, (int)'a', (int)(byte)0, (int)(short)(-1), (int)(byte)0, (int)(short)(-1));
    testRational0.mysimp((int)' ', (int)(byte)(-1), (int)(short)10, 100, 10, (int)(short)(-1));
    testRational0.mysimp((int)(byte)100, (int)(short)1, (int)'4', (int)(short)10, (int)' ', (int)(short)10);

  }

  @Test
  public void test209() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test209"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp((int)(short)(-1), (int)(short)10, (int)(short)10, 0, (int)'4', (int)(byte)1);
    testRational0.mysimp((-1), (int)' ', (int)'a', (int)'4', (int)(short)0, (-1));
    testRational0.mysimp((int)(short)1, 0, (int)' ', (int)'#', (int)'#', 10);
    testRational0.mysimp((-1), (-1), (-1), (int)(short)10, (int)(byte)100, (int)(short)100);
    testRational0.mysimp((int)'#', (int)(short)1, 0, (int)(short)100, 10, (int)'a');
    testRational0.mysimp((int)(short)0, (int)(short)10, 100, (int)(short)0, (int)(short)10, (int)(byte)(-1));
    testRational0.mysimp(1, (int)(short)1, (int)(short)1, (int)(short)1, 10, (int)(short)1);
    testRational0.mysimp(1, (int)(short)1, (int)' ', 1, (int)'a', (int)(short)0);

  }

  @Test
  public void test210() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test210"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)(byte)100, (int)' ', 10, (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp((int)(short)0, (int)' ', (int)'a', (int)(short)10, (int)(short)(-1), (int)(short)100);
    testRational0.mysimp((int)(byte)0, (int)'a', 0, 100, (int)(short)(-1), (int)(short)0);
    testRational0.mysimp((int)'4', (int)(byte)0, 0, (int)(byte)10, (-1), 1);
    testRational0.mysimp((int)'a', (int)(byte)(-1), 0, 10, (int)(byte)0, (-1));
    testRational0.mysimp((int)(short)(-1), (int)'#', (int)(byte)0, (int)' ', (-1), (int)'a');

  }

  @Test
  public void test211() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test211"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp(100, (int)(byte)100, (int)(byte)10, (int)(short)0, (int)(byte)1, 0);
    testRational0.mysimp((-1), (-1), 10, (int)' ', (int)(short)1, (int)(byte)100);
    testRational0.mysimp((int)(byte)10, (int)(short)0, 0, (int)(byte)100, 0, (int)' ');
    testRational0.mysimp((int)'#', (int)(byte)100, (int)'4', (int)(short)1, (int)(byte)0, 0);
    testRational0.mysimp((int)(byte)0, (int)(short)10, 100, (int)(byte)10, (int)'4', (int)'#');
    testRational0.mysimp((int)' ', 100, (int)(byte)0, (int)(short)10, 1, 1);

  }

  @Test
  public void test212() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test212"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)' ', 10, (int)' ', (int)(short)0, 0, (int)(short)1);
    testRational0.mysimp((int)'#', 100, (-1), 1, (-1), (int)(byte)(-1));
    testRational0.mysimp((int)(short)(-1), (int)'#', (int)(short)1, (int)(short)10, (int)(byte)1, 100);
    testRational0.mysimp((int)(byte)0, 0, (int)(short)100, 100, 10, (-1));
    testRational0.mysimp((int)' ', (int)(short)1, (int)(short)0, (int)(byte)100, (int)'#', 100);
    testRational0.mysimp((int)'a', (int)'4', (int)'4', 10, (int)(byte)10, (int)(byte)0);

  }

  @Test
  public void test213() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test213"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 0, (-1), 100, (int)'a');
    testRational0.mysimp(10, (int)(short)0, 100, (int)'4', (-1), 0);
    testRational0.mysimp(0, (int)(byte)(-1), 100, (int)(short)1, (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp((int)(byte)0, (int)'4', 100, (int)(byte)1, (int)(byte)10, 0);
    testRational0.mysimp((int)(byte)0, 0, (int)(short)(-1), (int)'#', (int)(byte)0, (int)(short)1);
    testRational0.mysimp((int)(byte)0, 10, (int)'4', (int)(short)(-1), 1, (int)(byte)(-1));
    testRational0.mysimp((int)(short)100, (int)'a', 0, 10, 0, (int)(short)1);
    testRational0.mysimp((int)(short)100, (int)(byte)1, (int)(byte)0, (int)(short)1, (int)(byte)100, (int)(short)(-1));
    testRational0.mysimp((int)(short)(-1), (-1), 100, (-1), 0, (int)(byte)10);

  }

  @Test
  public void test214() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test214"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)1, 1, (int)(short)1, 0);
    testRational0.mysimp((int)(byte)100, (int)(byte)100, (int)(short)1, (int)(short)10, (int)(short)1, (int)(short)0);
    testRational0.mysimp((int)'a', (int)(short)0, (int)(byte)1, (int)(byte)10, (int)(byte)100, 0);
    testRational0.mysimp((int)(byte)100, 1, (int)(short)1, (int)'4', (int)(byte)100, (int)(short)100);
    testRational0.mysimp(0, 0, (-1), (int)(short)100, (int)(byte)1, (-1));
    testRational0.mysimp(10, 1, 0, (int)(short)10, (int)' ', 10);
    testRational0.mysimp(1, (int)' ', (int)'a', 0, (int)(byte)(-1), (int)(short)1);
    testRational0.mysimp((int)'4', (int)'4', 0, (int)(byte)(-1), (int)(short)0, (int)(short)0);

  }

  @Test
  public void test215() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test215"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, 100, 100);
    testRational0.mysimp(0, (int)'4', (int)' ', (int)(byte)100, (int)(byte)1, (int)(short)100);
    testRational0.mysimp((int)(byte)0, (int)(byte)100, (int)(byte)100, (int)'4', (int)(short)0, (int)(short)(-1));
    testRational0.mysimp((int)(short)100, (int)(short)10, (int)'a', (-1), (int)(short)1, 0);

  }

  @Test
  public void test216() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test216"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)(short)(-1), 100, (int)(byte)10, (int)'4', (int)(short)(-1));
    testRational0.mysimp((int)' ', 1, (int)(byte)(-1), (int)(short)1, 10, (int)(byte)0);
    testRational0.mysimp(1, 0, (int)(short)1, (int)(short)(-1), 0, (int)(short)0);
    testRational0.mysimp(0, (int)'4', (int)'#', (int)(short)(-1), 0, 100);
    testRational0.mysimp((int)'4', 0, (int)(short)10, (int)'a', 1, (int)(short)(-1));
    testRational0.mysimp(10, (int)(byte)1, (int)'a', (int)(short)100, 0, (int)(short)(-1));

  }

  @Test
  public void test217() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test217"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(short)(-1), (int)(short)10, (int)' ', 0, (int)(byte)100, (int)' ');
    testRational0.mysimp((int)(short)(-1), (int)' ', (int)(short)(-1), (int)'a', (int)(short)0, (int)(short)100);
    testRational0.mysimp((int)(short)(-1), 10, 1, 10, (int)(short)100, (int)'4');
    testRational0.mysimp((int)(short)100, 1, 1, (int)'a', (int)(short)1, (int)(byte)10);

  }

  @Test
  public void test218() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test218"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(100, 100, 0, 1, (int)'a', 0);
    testRational0.mysimp((int)(short)10, (int)'a', 0, (int)'a', 0, 0);
    testRational0.mysimp((int)(short)10, 100, (int)' ', (int)'a', 1, (int)(short)(-1));
    testRational0.mysimp(10, 100, (int)(byte)(-1), (int)'4', 1, 10);
    testRational0.mysimp((int)(byte)0, (int)(short)0, (int)(byte)100, (int)(byte)(-1), (int)'4', 0);
    testRational0.mysimp((int)(byte)(-1), 0, (int)(byte)(-1), 10, (int)(byte)10, (-1));
    testRational0.mysimp((int)(byte)10, 100, (int)(byte)100, (-1), 100, 0);

  }

  @Test
  public void test219() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test219"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)' ', (int)(byte)0, (int)(byte)1, (int)(byte)100, 10, (int)'4');
    testRational0.mysimp((int)(short)(-1), (int)'a', 100, (int)' ', (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp((int)(short)10, 0, (int)'a', (int)'#', (int)'4', (int)(short)0);
    testRational0.mysimp(1, (int)(byte)0, (int)(short)(-1), (int)'#', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)0, (int)(byte)100, (int)(byte)10, (int)(byte)0, (int)' ');
    testRational0.mysimp((int)(byte)0, (int)(byte)10, (int)(short)1, (int)' ', (int)(byte)10, (int)(short)0);
    testRational0.mysimp((int)(byte)1, (int)'4', (int)(byte)1, 1, (int)(short)(-1), (int)'a');

  }

  @Test
  public void test220() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test220"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)(byte)100, (int)' ', 10, (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp((int)' ', 1, 1, (int)'a', 0, (int)'#');
    testRational0.mysimp((int)(short)0, (int)'4', 0, (int)'#', (int)'4', (int)' ');
    testRational0.mysimp((int)(byte)1, (int)(byte)0, (int)(byte)1, (int)(byte)10, (int)'#', 0);
    testRational0.mysimp((int)(byte)1, (int)(byte)0, (int)(short)1, (int)(short)1, (int)(byte)0, 0);
    testRational0.mysimp((int)(short)(-1), (int)'#', 0, (int)(short)10, 0, (int)(byte)1);
    testRational0.mysimp((int)'4', (int)(short)1, (int)' ', (int)'a', (int)(short)100, 0);
    testRational0.mysimp(1, (int)(byte)0, (int)'4', (int)(byte)1, (-1), (int)(byte)(-1));
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, (int)(short)10, 10, (int)(short)1, (int)(short)(-1));
    testRational0.mysimp((int)(byte)(-1), (int)(short)10, (int)(short)100, (int)'a', (int)'a', (int)(short)100);

  }

  @Test
  public void test221() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test221"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(byte)1, (int)(byte)100, (int)(short)(-1), 1, 10, (int)' ');
    testRational0.mysimp((int)'a', (int)(short)10, (int)(short)10, (int)(short)1, 0, (int)(byte)10);
    testRational0.mysimp((int)(byte)100, 100, 10, (int)' ', (-1), 0);
    testRational0.mysimp((int)(byte)0, (int)'a', (int)(byte)100, 10, (int)'a', (int)(byte)(-1));

  }

  @Test
  public void test222() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test222"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)1, 1, (int)(short)1, 0);
    testRational0.mysimp((int)' ', (int)' ', (int)(byte)10, (int)'4', (int)'4', (int)(short)10);
    testRational0.mysimp((int)'a', (int)(byte)(-1), (int)'a', 100, (int)'4', 0);
    testRational0.mysimp(0, (int)(short)(-1), 0, (int)' ', (int)'a', (int)(short)0);
    testRational0.mysimp((int)(short)100, (int)'a', (int)'#', (int)(byte)1, (int)(short)1, (int)(byte)10);
    testRational0.mysimp((int)(short)10, (-1), 0, (int)(byte)0, (int)'#', (int)(short)0);

  }

  @Test
  public void test223() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test223"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 0, (-1), 100, (int)'a');
    testRational0.mysimp(0, (int)'4', (int)(byte)0, (int)(short)0, 0, (int)(short)100);
    testRational0.mysimp(10, (int)' ', (int)' ', 0, (int)' ', 10);
    testRational0.mysimp(100, (int)(byte)(-1), (int)'#', (int)(byte)10, (int)(short)100, (int)(short)10);
    testRational0.mysimp((int)(short)100, (-1), (int)(short)(-1), (int)(short)(-1), 1, (int)(byte)10);
    testRational0.mysimp(100, 0, 1, (-1), (-1), 0);
    testRational0.mysimp((int)(short)(-1), 1, (int)' ', 0, (int)(short)100, 0);
    testRational0.mysimp(0, 1, 10, (int)(byte)0, (int)(short)100, (int)(byte)10);

  }

  @Test
  public void test224() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test224"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)(short)100, (int)(byte)1, (int)(byte)0, 100, (int)(short)100);
    testRational0.mysimp((int)'a', (int)(short)0, 0, (int)'4', (int)'#', (int)'4');
    testRational0.mysimp(1, 0, (int)(byte)0, (int)'4', (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp((int)(short)1, 0, (int)(short)10, (int)(byte)100, (int)'4', 1);
    testRational0.mysimp((int)'a', 0, (int)(byte)10, 1, (int)(short)100, (int)'a');
    testRational0.mysimp((-1), (int)(byte)0, (int)(byte)100, (int)(short)100, (int)(byte)100, (int)(short)100);
    testRational0.mysimp(10, 0, 10, (int)(short)1, (int)(byte)0, (int)(short)1);
    testRational0.mysimp((int)(byte)1, (int)(byte)100, (int)' ', (int)(byte)10, 10, (int)(byte)1);

  }

  @Test
  public void test225() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test225"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 0, (-1), 100, (int)'a');
    testRational0.mysimp((int)' ', (int)(short)100, (int)(short)10, (-1), (int)'a', (int)(byte)0);
    testRational0.mysimp((int)(short)10, (int)(short)1, (int)(byte)1, (int)(short)100, 0, (-1));
    testRational0.mysimp((int)(short)100, (int)(short)(-1), (int)(byte)10, (int)(short)0, (int)(short)1, (int)'4');

  }

  @Test
  public void test226() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test226"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(10, (int)(short)100, (int)(short)10, (int)(short)100, (int)(byte)10, 0);
    testRational0.mysimp((int)'a', (int)(short)0, 10, (int)(short)10, (int)(short)1, (int)(byte)100);
    testRational0.mysimp((int)'4', (int)(short)0, 10, (int)(short)0, (int)'4', (int)' ');

  }

  @Test
  public void test227() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test227"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(byte)(-1), (int)(short)(-1), (int)(short)10, 0, (int)(byte)100, 1);
    testRational0.mysimp((int)(short)1, (int)' ', (int)'4', (int)'a', (int)' ', (int)(byte)100);
    testRational0.mysimp((int)'4', (int)' ', (int)'#', (int)(short)(-1), (int)(short)100, (int)' ');
    testRational0.mysimp((int)(byte)10, (int)'#', (int)(byte)10, (int)'#', 1, 100);

  }

  @Test
  public void test228() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test228"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'a', (int)(byte)0, 0, (int)(short)0, 0);
    testRational0.mysimp((int)(short)10, (int)(byte)0, (int)'a', (int)(byte)0, (int)(byte)0, (int)(byte)(-1));
    testRational0.mysimp(1, 1, (int)(short)0, (-1), (int)(byte)1, (int)(byte)1);
    testRational0.mysimp((int)(byte)100, (int)(byte)1, (int)(short)10, (int)(short)(-1), (-1), (int)(short)1);
    testRational0.mysimp(0, 1, (int)' ', (int)(byte)0, 10, (int)(short)1);
    testRational0.mysimp(10, (int)(byte)0, (int)(byte)1, (int)(byte)(-1), (int)'#', 0);
    testRational0.mysimp((int)(byte)10, (int)(byte)1, (int)(byte)10, (int)(short)1, 0, 10);
    testRational0.mysimp(10, 100, (int)'4', 10, (int)' ', 10);

  }

  @Test
  public void test229() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test229"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)(byte)100, (int)' ', 10, (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp((int)' ', 1, 1, (int)'a', 0, (int)'#');
    testRational0.mysimp((int)(short)1, (int)'#', (int)(short)(-1), (-1), 100, (int)(byte)100);
    testRational0.mysimp(10, (int)(byte)(-1), (int)(byte)(-1), 0, (int)(byte)10, (int)(byte)100);
    testRational0.mysimp((int)(byte)1, (int)(byte)1, (int)(short)(-1), (int)' ', (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp(1, (-1), (int)(byte)100, (int)(short)10, (int)(byte)100, (-1));
    testRational0.mysimp(1, (int)(short)1, (int)(short)10, (int)'a', (int)(byte)(-1), 0);
    testRational0.mysimp((-1), 100, (int)(byte)10, (int)(short)(-1), (int)(byte)(-1), (int)' ');

  }

  @Test
  public void test230() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test230"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)1, 1, (int)(short)1, 0);
    testRational0.mysimp((int)' ', (int)' ', (int)(byte)10, (int)'4', (int)'4', (int)(short)10);
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(byte)10, (int)'#', (int)(byte)100, 10);
    testRational0.mysimp((-1), 100, (int)(short)1, 0, (int)'#', 100);
    testRational0.mysimp(0, (int)'4', (int)' ', (int)(short)0, 1, (int)'4');
    testRational0.mysimp((int)(short)100, (int)'#', (int)'4', (int)' ', (int)' ', 0);
    testRational0.mysimp((int)(short)0, (int)(short)100, (int)(short)10, (int)(byte)0, 1, (int)(byte)100);
    testRational0.mysimp((int)'4', (int)(byte)1, (int)(byte)(-1), 0, (int)' ', (int)(short)10);

  }

  @Test
  public void test231() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test231"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(byte)0, (int)(short)0, 10, (int)(byte)(-1), (int)'4', (int)(byte)0);
    testRational0.mysimp((int)(byte)10, (int)(short)10, (int)'4', (int)(byte)(-1), (int)' ', 1);
    testRational0.mysimp((int)(byte)(-1), (int)(byte)1, (int)(short)0, (int)(short)1, (int)(byte)(-1), (int)(short)0);
    testRational0.mysimp(1, (int)(byte)100, (int)' ', (int)(short)0, (int)(short)(-1), (int)'#');

  }

  @Test
  public void test232() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test232"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 0, (-1), 100, (int)'a');
    testRational0.mysimp(0, (int)'4', (int)(byte)0, (int)(short)0, 0, (int)(short)100);
    testRational0.mysimp((-1), 0, (int)(short)0, 100, (int)(short)10, (int)(byte)0);
    testRational0.mysimp((int)(short)10, (int)(byte)100, (-1), (int)(byte)10, (int)(byte)0, (int)(short)0);
    testRational0.mysimp((int)(byte)10, 100, (int)(byte)(-1), (int)'4', (int)'a', (int)(short)1);
    testRational0.mysimp(100, (int)' ', (int)(short)0, (int)(short)0, (int)(short)100, 0);
    testRational0.mysimp(100, (int)'#', (int)(short)10, (int)'4', (int)(byte)1, (int)(byte)10);
    testRational0.mysimp((-1), (int)(byte)100, (int)(short)(-1), (int)' ', (int)(short)100, (int)(byte)(-1));

  }

  @Test
  public void test233() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test233"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)' ', 10, (int)' ', (int)(short)0, 0, (int)(short)1);
    testRational0.mysimp((int)(short)1, (int)' ', (int)(short)100, (int)(short)100, (int)(byte)100, 10);
    testRational0.mysimp((int)'#', (int)'a', (int)(short)0, (int)(short)10, 1, (int)'a');
    testRational0.mysimp(10, 10, (int)(short)10, (int)'4', (int)(byte)100, (int)(byte)0);
    testRational0.mysimp((int)(byte)1, (int)'4', (int)(short)10, (int)'a', (int)(short)10, (int)(short)(-1));
    testRational0.mysimp((int)(byte)1, 10, (int)(byte)(-1), (int)(short)100, 1, (int)'#');
    testRational0.mysimp((int)'a', 10, 100, (int)' ', 1, (int)(short)10);

  }

  @Test
  public void test234() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test234"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 0, (-1), 100, (int)'a');
    testRational0.mysimp(10, (int)(short)0, 100, (int)'4', (-1), 0);
    testRational0.mysimp(0, (int)(byte)(-1), 100, (int)(short)1, (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp(10, (int)' ', 10, (int)'#', 10, 100);
    testRational0.mysimp((int)' ', 10, (int)(short)100, (int)(short)1, (int)(short)0, (int)(byte)100);
    testRational0.mysimp((int)' ', 0, (int)'4', (int)(byte)1, (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp((int)(short)(-1), 0, (int)(short)0, 1, (int)' ', (int)(short)1);
    testRational0.mysimp((int)(byte)0, (int)(byte)1, 0, (int)(byte)(-1), (int)'4', (int)(short)0);

  }

  @Test
  public void test235() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test235"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(100, 100, 0, 1, (int)'a', 0);
    testRational0.mysimp((int)(short)10, (int)'a', 0, (int)'a', 0, 0);
    testRational0.mysimp(1, (int)(byte)10, (int)' ', 0, (int)(byte)1, (int)(short)0);
    testRational0.mysimp((int)(byte)1, (int)(byte)0, (int)'#', (int)(short)1, (int)(byte)10, (int)(short)1);
    testRational0.mysimp((int)(short)0, 0, 10, (int)(byte)100, (int)(short)100, (int)(short)1);
    testRational0.mysimp((-1), (int)(byte)10, 10, 100, (int)(short)100, (-1));
    testRational0.mysimp(100, 0, (int)(short)10, (int)'#', (int)(short)100, (int)' ');
    testRational0.mysimp((int)'4', 100, 100, (int)(byte)0, (int)'a', (int)(short)0);

  }

  @Test
  public void test236() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test236"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(byte)100, (int)(byte)1, (int)(byte)(-1), 1, (int)(byte)0, 10);
    testRational0.mysimp((int)(byte)(-1), 10, (-1), (int)(byte)1, (int)(byte)0, 10);
    testRational0.mysimp((int)(byte)100, (int)'#', (int)(byte)1, 10, 1, (int)(byte)0);
    testRational0.mysimp(0, (int)(short)0, (int)'4', 10, (int)(short)0, (int)(short)10);
    testRational0.mysimp(0, 10, (int)(byte)(-1), 1, (int)(byte)10, (int)(short)1);
    testRational0.mysimp((int)(short)0, (int)(short)100, (int)(short)10, (int)(byte)1, 100, 0);
    testRational0.mysimp((int)'4', 100, (int)(short)1, (int)(short)1, (int)'4', (int)(short)10);
    testRational0.mysimp((int)(short)0, (int)(short)(-1), (int)(byte)1, (int)'4', 0, 0);
    testRational0.mysimp((int)(short)100, (-1), (int)'4', (int)'4', (int)(byte)100, (int)(byte)(-1));
    testRational0.mysimp(10, 100, (int)(short)0, (int)(short)100, (int)' ', (int)(short)100);

  }

  @Test
  public void test237() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test237"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(10, (int)'a', (int)(short)10, (int)(short)(-1), (int)(byte)0, (int)'a');
    testRational0.mysimp((int)(byte)100, (int)(short)0, (int)'a', (int)(byte)(-1), 0, (int)(short)(-1));
    testRational0.mysimp((int)(short)10, (int)(short)0, (int)(byte)0, (int)(byte)1, (int)(byte)(-1), (int)(short)100);
    testRational0.mysimp((int)(byte)1, 1, (int)(byte)10, (int)(short)10, (int)'a', (int)(short)10);
    testRational0.mysimp((int)(short)1, (int)(byte)1, (int)(byte)(-1), (int)(short)0, (int)(short)1, (int)(byte)100);
    testRational0.mysimp((int)(short)0, (int)(byte)(-1), (int)(byte)100, (int)(short)1, 1, (int)(byte)10);
    testRational0.mysimp((int)'4', (int)(short)(-1), (int)'a', (int)'a', (int)(short)(-1), 100);
    testRational0.mysimp(100, (int)(short)100, 1, 10, (int)(short)100, (int)(byte)100);
    testRational0.mysimp((int)(byte)1, (int)(byte)100, (int)'4', (int)(short)(-1), 0, 10);

  }

  @Test
  public void test238() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test238"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)'a', (int)(byte)(-1), (int)' ', (int)'#', (int)(short)1);
    testRational0.mysimp((int)'#', (int)'a', (int)(byte)(-1), 100, (int)(byte)(-1), (-1));
    testRational0.mysimp(10, (-1), 0, (int)(short)1, (int)(short)0, (int)(short)1);
    testRational0.mysimp((int)(byte)(-1), 1, (int)(byte)1, (int)(short)10, (int)(short)10, (int)(short)1);
    testRational0.mysimp((int)'4', (int)'4', (int)(byte)1, 0, (int)' ', 1);
    testRational0.mysimp((int)'a', 0, 0, (int)' ', (int)(byte)10, (int)'#');
    testRational0.mysimp((-1), (int)'4', (int)(byte)(-1), (int)' ', (-1), (int)' ');

  }

  @Test
  public void test239() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test239"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(short)(-1), (int)(short)10, (int)' ', 0, (int)(byte)100, (int)' ');
    testRational0.mysimp((int)' ', 0, (int)(byte)100, 100, (int)(byte)10, 0);
    testRational0.mysimp((int)'4', (int)(byte)10, (int)(short)10, (int)(byte)0, (-1), (-1));
    testRational0.mysimp((int)' ', (int)(short)(-1), (int)(short)1, (int)(short)100, 0, (-1));
    testRational0.mysimp(100, (int)(short)(-1), (int)(short)(-1), (int)'a', (int)(byte)0, 0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)(short)0, 1, (-1), 0);

  }

  @Test
  public void test240() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test240"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(100, 100, 0, 1, (int)'a', 0);
    testRational0.mysimp((int)'a', (int)(byte)(-1), (int)(short)10, (int)'a', (int)'a', (int)(byte)0);
    testRational0.mysimp(1, (int)(byte)1, (int)(short)1, (int)(byte)(-1), (int)(byte)100, (int)(byte)100);
    testRational0.mysimp((int)(short)10, (int)(byte)100, 1, (int)(byte)1, (int)(short)100, (int)(byte)1);
    testRational0.mysimp((int)'a', (int)(byte)10, 0, (int)(short)(-1), (int)' ', (int)'#');

  }

  @Test
  public void test241() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test241"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)1, 1, (int)(short)1, 0);
    testRational0.mysimp((int)(byte)100, (int)(byte)100, (int)(short)1, (int)(short)10, (int)(short)1, (int)(short)0);
    testRational0.mysimp((int)'a', (int)(short)0, (int)(byte)1, (int)(byte)10, (int)(byte)100, 0);
    testRational0.mysimp((int)(byte)100, 1, (int)(short)1, (int)'4', (int)(byte)100, (int)(short)100);
    testRational0.mysimp(0, 0, (-1), (int)(short)100, (int)(byte)1, (-1));
    testRational0.mysimp((int)(short)10, (int)(short)10, 10, (int)(byte)10, (int)(byte)10, (int)(byte)1);
    testRational0.mysimp((int)(byte)1, (int)(byte)(-1), 0, (int)'a', (int)(short)1, (int)(short)0);

  }

  @Test
  public void test242() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test242"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)(byte)100, (int)' ', 10, (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp((int)' ', 1, 1, (int)'a', 0, (int)'#');
    testRational0.mysimp((int)(byte)0, (int)' ', (int)(short)1, (int)(short)(-1), (int)(byte)0, 0);
    testRational0.mysimp((int)(byte)100, (int)'a', 0, (int)(short)10, 0, 0);
    testRational0.mysimp((int)(byte)0, (int)'a', (int)'4', (int)(short)(-1), (-1), (int)(byte)10);
    testRational0.mysimp(0, 1, (int)(short)1, 10, 0, (int)'a');
    testRational0.mysimp(100, (int)' ', (int)'a', 0, (-1), 1);
    testRational0.mysimp((-1), (int)'a', 0, (int)'a', 0, 0);
    testRational0.mysimp((int)(byte)0, (int)(short)1, 10, (int)' ', (int)(short)(-1), (int)(byte)100);

  }

  @Test
  public void test243() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test243"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(10, (int)(short)100, (int)' ', (int)(byte)1, (int)(short)(-1), 0);
    testRational0.mysimp((int)(short)10, (int)(byte)10, (int)(byte)10, (int)(short)1, 10, (int)(byte)0);
    testRational0.mysimp((int)'#', (int)(short)10, (int)' ', 1, (int)' ', (int)(byte)10);
    testRational0.mysimp((int)'a', (int)(short)1, (-1), 10, (-1), (int)(short)100);
    testRational0.mysimp((int)'a', (int)'4', (int)(short)1, (int)(short)(-1), (int)'#', (int)'#');
    testRational0.mysimp((int)' ', (int)(byte)10, (int)(byte)0, (int)'#', (int)'4', (int)(short)100);
    testRational0.mysimp(0, 10, (int)'4', (int)' ', (int)(short)(-1), (int)'#');
    testRational0.mysimp((-1), 100, (-1), (int)' ', (int)' ', (int)(byte)(-1));
    testRational0.mysimp((int)(short)(-1), (int)(short)10, (int)(short)0, (int)(byte)1, (int)(short)10, (int)(byte)100);

  }

  @Test
  public void test244() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test244"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)(short)1, (int)(byte)10, (int)(byte)100, 1, (int)(byte)10, (int)(byte)(-1));
    testRational0.mysimp((int)(short)100, 0, (int)'4', (int)'4', (int)(short)1, (int)(byte)(-1));
    testRational0.mysimp(0, (int)' ', (int)(short)(-1), (-1), (int)(short)(-1), (int)' ');
    testRational0.mysimp((int)(byte)(-1), (int)(byte)10, (-1), (-1), (int)' ', (int)'#');
    testRational0.mysimp((int)(short)10, (int)(byte)1, (int)'4', (int)'a', (int)(short)100, (int)(short)10);
    testRational0.mysimp((int)(short)100, (int)'a', (int)(byte)0, (int)(byte)10, (int)(byte)(-1), (int)(short)(-1));
    testRational0.mysimp((-1), (int)(byte)(-1), (int)(byte)10, (int)'4', (int)'4', 10);

  }

  @Test
  public void test245() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test245"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'a', (int)(byte)0, 0, (int)(short)0, 0);
    testRational0.mysimp((int)(short)10, (int)(byte)0, (int)'a', (int)(byte)0, (int)(byte)0, (int)(byte)(-1));
    testRational0.mysimp((int)(short)1, 0, (int)(byte)(-1), (int)(short)1, 10, (int)(short)(-1));
    testRational0.mysimp((int)(short)10, (int)(short)1, (int)'a', (int)(byte)10, (int)(short)1, 1);
    testRational0.mysimp((int)(short)1, 0, (int)(byte)100, (int)' ', 0, (int)(byte)100);
    testRational0.mysimp((int)(byte)1, (int)(short)10, (int)(byte)0, (int)'#', (int)(byte)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)(short)1, (int)(byte)1, (int)(byte)(-1), (int)(byte)10, (-1));

  }

  @Test
  public void test246() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test246"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 0, (-1), 100, (int)'a');
    testRational0.mysimp(0, (int)'4', (int)(byte)0, (int)(short)0, 0, (int)(short)100);
    testRational0.mysimp(10, (int)' ', (int)' ', 0, (int)' ', 10);
    testRational0.mysimp(100, (int)(byte)(-1), (int)'#', (int)(byte)10, (int)(short)100, (int)(short)10);
    testRational0.mysimp((int)(byte)1, 10, (int)(byte)0, (int)' ', (int)' ', (-1));
    testRational0.mysimp((int)(byte)10, (int)' ', (int)(byte)0, (int)(byte)100, 10, (int)(byte)0);
    testRational0.mysimp(10, (int)(short)1, (int)(short)0, 1, (int)(short)0, (int)(short)0);
    testRational0.mysimp(0, 1, (int)(short)10, (int)(short)0, (int)(short)(-1), (int)(byte)10);

  }

  @Test
  public void test247() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test247"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, 100, 100);
    testRational0.mysimp((int)(byte)(-1), (int)'a', (-1), (int)'4', (-1), (int)(byte)0);
    testRational0.mysimp((int)(short)100, (int)'#', (int)(byte)100, (int)(short)(-1), (int)(short)10, 10);
    testRational0.mysimp((-1), (int)' ', 10, (int)'#', (int)' ', (int)(short)10);
    testRational0.mysimp((int)(byte)10, (int)(byte)100, (int)(byte)0, (int)' ', 0, (int)(short)10);
    testRational0.mysimp((int)(byte)1, (int)(byte)1, (int)'4', (int)'4', (int)(byte)100, (int)'a');
    testRational0.mysimp((int)'#', 10, 0, (int)'#', (int)'a', (int)(short)(-1));
    testRational0.mysimp((int)'4', (int)'4', 1, (-1), (int)' ', 0);

  }

  @Test
  public void test248() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test248"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(10, (int)(short)100, (int)' ', (int)(byte)1, (int)(short)(-1), 0);
    testRational0.mysimp((int)(short)(-1), 100, 1, 0, (int)(short)10, (int)(byte)10);
    testRational0.mysimp((int)'4', (int)(short)100, (int)'4', 100, 1, (int)'#');
    testRational0.mysimp((int)(byte)0, (int)(byte)0, (int)(byte)(-1), 100, (int)(byte)10, (int)(byte)1);
    testRational0.mysimp((int)(byte)1, (int)(byte)1, (int)(short)0, (int)' ', (int)(short)(-1), (int)(short)100);
    testRational0.mysimp(10, (int)' ', (int)(short)0, (int)(short)1, (int)(short)100, 1);
    testRational0.mysimp((-1), (int)'a', 1, (int)(short)10, (int)'4', (int)' ');
    testRational0.mysimp((int)(short)0, (int)'#', (int)(byte)(-1), 10, (int)(byte)100, (int)'#');
    testRational0.mysimp((int)(byte)1, (int)(short)1, (int)(byte)0, (int)(byte)100, (int)(short)10, 0);

  }

  @Test
  public void test249() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test249"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)'a', (int)(byte)1, (int)(short)100, (int)(byte)1, (int)(short)0, (int)(short)(-1));
    testRational0.mysimp((-1), 1, (int)(byte)0, (-1), 1, (int)'a');
    testRational0.mysimp((int)(short)0, (int)'4', (int)' ', (int)(byte)(-1), 100, (int)(short)1);
    testRational0.mysimp((int)(byte)1, (int)(short)(-1), (-1), 100, 0, 100);
    testRational0.mysimp(0, (int)(byte)1, (int)(short)(-1), (int)(byte)10, (int)'4', (int)(byte)0);

  }

  @Test
  public void test250() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test250"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)'4', (int)(short)0, 0, (int)(short)(-1), (int)(byte)100, (int)'a');
    testRational0.mysimp((int)(short)100, 0, (int)(short)(-1), (int)(byte)100, (int)'a', (-1));

  }

  @Test
  public void test251() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test251"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)(short)(-1), 100, (int)(byte)10, (int)'4', (int)(short)(-1));
    testRational0.mysimp((int)' ', 1, (int)(byte)(-1), (int)(short)1, 10, (int)(byte)0);
    testRational0.mysimp(100, (int)' ', 100, (int)(byte)100, (int)(byte)100, 0);
    testRational0.mysimp(100, 1, (int)(byte)10, (int)(short)10, (int)(short)10, 10);
    testRational0.mysimp((-1), (int)(byte)0, (int)(byte)100, 10, (int)(byte)(-1), 100);
    testRational0.mysimp((int)(short)(-1), (int)'a', (int)(short)1, (int)(byte)1, (int)(short)(-1), 10);

  }

  @Test
  public void test252() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test252"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 0, (-1), 100, (int)'a');
    testRational0.mysimp(0, (int)'4', (int)(byte)0, (int)(short)0, 0, (int)(short)100);
    testRational0.mysimp(10, (int)' ', (int)' ', 0, (int)' ', 10);
    testRational0.mysimp(100, (int)(byte)(-1), (int)'#', (int)(byte)10, (int)(short)100, (int)(short)10);
    testRational0.mysimp((int)(byte)1, 10, (int)(byte)0, (int)' ', (int)' ', (-1));
    testRational0.mysimp((int)(byte)10, (int)' ', (int)(byte)0, (int)(byte)100, 10, (int)(byte)0);
    testRational0.mysimp(100, 10, (int)(short)0, 100, (int)'a', 1);

  }

  @Test
  public void test253() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test253"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(short)(-1), (int)(short)10, (int)' ', 0, (int)(byte)100, (int)' ');
    testRational0.mysimp(0, 0, (int)'4', (int)(byte)(-1), (int)(short)100, (int)(short)10);
    testRational0.mysimp((int)'#', (int)(byte)10, 1, (int)(short)1, (int)(short)0, (int)(short)0);
    testRational0.mysimp((int)'4', (int)'4', (-1), (int)'#', (int)(short)1, 0);
    testRational0.mysimp(0, 0, 1, (int)(short)1, (int)(byte)1, (int)(short)0);
    testRational0.mysimp((int)(byte)1, (int)(short)10, 0, 0, (int)(byte)10, (int)(short)(-1));

  }

  @Test
  public void test254() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test254"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)(byte)1, 10, 0, 0, 0, (int)'4');
    testRational0.mysimp((int)'4', (int)(byte)100, (int)(short)0, (int)(short)100, 100, (int)'a');
    testRational0.mysimp((int)(byte)100, (int)(short)10, 10, (int)(short)0, (int)(byte)100, (int)(byte)(-1));

  }

  @Test
  public void test255() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test255"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, 100, 100);
    testRational0.mysimp(0, (int)'4', (int)' ', (int)(byte)100, (int)(byte)1, (int)(short)100);
    testRational0.mysimp((int)(short)100, (int)(byte)0, (int)(short)100, (int)' ', 0, (-1));
    testRational0.mysimp((int)' ', (int)(byte)(-1), (int)'4', (int)(byte)(-1), (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)10, (int)(short)10, (int)(short)10, (int)'4', 10, (int)(short)1);
    testRational0.mysimp(0, (int)(byte)(-1), (int)'4', (int)(short)10, (int)(short)10, (int)'4');
    testRational0.mysimp((-1), 0, (int)(byte)(-1), (int)(short)0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)0, (int)(short)1, 0, (int)(short)100, (int)(byte)1, (int)(short)100);

  }

  @Test
  public void test256() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test256"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)'#', 10, (int)(short)10, (int)(short)0, (int)(short)0, 1);
    testRational0.mysimp(0, (-1), (int)'#', 1, 0, (int)(short)1);
    testRational0.mysimp((int)(short)(-1), (int)(short)1, (int)(byte)0, (int)(byte)1, (int)(byte)1, 1);
    testRational0.mysimp((int)(short)100, 0, (int)(short)100, 0, 0, (int)(byte)10);

  }

  @Test
  public void test257() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test257"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(byte)1, (int)(byte)100, (int)(short)(-1), 1, 10, (int)' ');
    testRational0.mysimp((int)'a', (int)(short)10, (int)(short)10, (int)(short)1, 0, (int)(byte)10);
    testRational0.mysimp(0, (int)(byte)1, 1, (int)(short)1, (int)(short)(-1), (-1));
    testRational0.mysimp((int)(short)1, 0, (int)(byte)10, (int)(byte)0, 10, (int)(byte)1);
    testRational0.mysimp((int)(short)100, (-1), (int)(short)(-1), (int)(byte)(-1), (int)(short)(-1), (int)'a');

  }

  @Test
  public void test258() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test258"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(10, (int)'a', (int)(short)10, (int)(short)(-1), (int)(byte)0, (int)'a');
    testRational0.mysimp((int)(byte)100, (int)(short)0, (int)'a', (int)(byte)(-1), 0, (int)(short)(-1));
    testRational0.mysimp((int)(short)10, (int)(short)0, (int)(byte)0, (int)(byte)1, (int)(byte)(-1), (int)(short)100);
    testRational0.mysimp((int)(short)1, (int)(byte)100, (-1), (int)' ', (int)(byte)(-1), (int)(short)(-1));
    testRational0.mysimp((int)(short)(-1), (-1), 0, 10, (-1), (int)' ');
    testRational0.mysimp((int)(short)100, (int)(short)100, (int)(short)0, (-1), (int)(short)(-1), (int)'a');

  }

  @Test
  public void test259() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test259"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'a', (int)(byte)0, 0, (int)(short)0, 0);
    testRational0.mysimp(100, (int)(byte)10, (int)(byte)10, 10, 0, (int)(short)1);
    testRational0.mysimp(1, (int)(short)0, (int)(byte)1, (int)(short)(-1), 1, (int)(byte)(-1));
    testRational0.mysimp((int)(byte)10, (int)(byte)100, (int)(byte)0, 10, 1, (int)(byte)1);
    testRational0.mysimp((int)(byte)1, (int)(short)10, (int)(byte)0, (int)(byte)100, (int)(byte)0, (int)' ');
    testRational0.mysimp((-1), 100, (int)(short)1, (int)(byte)100, (int)'#', (int)'a');
    testRational0.mysimp(100, (int)(short)10, 100, 0, 10, 0);

  }

  @Test
  public void test260() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test260"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(byte)100, (int)(byte)1, (int)(byte)(-1), 1, (int)(byte)0, 10);
    testRational0.mysimp(0, (int)'#', (int)(short)0, (int)'#', 100, (int)(short)100);
    testRational0.mysimp((int)(short)1, (int)' ', (int)(short)100, (int)(byte)1, (int)'4', (int)' ');
    testRational0.mysimp((-1), (int)'#', (-1), 100, (int)'4', (int)(short)1);
    testRational0.mysimp((int)(short)1, 1, (int)(byte)(-1), (int)'4', (int)(short)10, (int)(short)10);
    testRational0.mysimp((int)(short)100, (int)(byte)0, 100, (int)(short)100, (int)'a', (int)(byte)(-1));
    testRational0.mysimp((int)'a', (int)(byte)0, (int)(short)1, (int)(byte)(-1), 1, 10);
    testRational0.mysimp((-1), (int)'#', (int)'#', (int)(byte)10, (int)'4', (int)(byte)100);
    testRational0.mysimp((int)(short)100, (int)'#', 1, (int)' ', (int)(byte)0, 1);
    testRational0.mysimp((int)'#', 0, (int)(short)1, (int)(short)100, 1, (int)(byte)1);

  }

  @Test
  public void test261() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test261"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(10, (int)(short)100, (int)(short)10, (int)(short)100, (int)(byte)10, 0);
    testRational0.mysimp(10, (int)'4', (int)(byte)0, (int)(byte)(-1), 0, 1);
    testRational0.mysimp((int)(short)(-1), (int)(short)(-1), 0, 100, (int)(byte)100, (int)(short)10);
    testRational0.mysimp((int)' ', (int)' ', 10, (int)(byte)0, (int)(short)0, (-1));
    testRational0.mysimp((int)(short)0, 0, 0, (int)'#', (int)(byte)10, (int)(byte)0);
    testRational0.mysimp((int)' ', 1, (int)(byte)10, (int)(short)0, (int)(byte)100, (int)(byte)1);
    testRational0.mysimp((int)(short)1, (int)(short)10, (int)(byte)1, 1, (int)'4', 1);
    testRational0.mysimp((int)(byte)100, (int)(byte)1, (int)(short)(-1), 0, (int)(short)100, (int)'#');
    testRational0.mysimp((int)(byte)1, (int)(short)0, 1, (int)(short)0, (int)(short)0, (int)(byte)10);

  }

  @Test
  public void test262() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test262"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)(short)(-1), 100, (int)(byte)10, (int)'4', (int)(short)(-1));
    testRational0.mysimp((-1), 10, (int)'#', (int)(byte)1, (int)(byte)10, 100);
    testRational0.mysimp((int)(byte)100, 10, (int)(byte)0, (int)(byte)100, 10, (-1));
    testRational0.mysimp((int)(short)1, (int)(byte)100, 10, 10, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(byte)0, (int)' ', (int)(short)(-1), (int)(byte)0, (int)(short)0, (int)(short)100);
    testRational0.mysimp(0, 10, 0, (int)(byte)10, (int)(byte)(-1), (int)'a');
    testRational0.mysimp(0, (-1), (int)(short)(-1), 100, (int)(byte)(-1), (int)(byte)0);

  }

  @Test
  public void test263() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test263"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)' ', 10, (int)' ', (int)(short)0, 0, (int)(short)1);
    testRational0.mysimp((int)(short)1, 1, (int)' ', (int)(byte)10, (int)(short)(-1), 0);
    testRational0.mysimp((int)(short)(-1), 10, (int)' ', (int)'4', (int)(short)1, (int)'#');
    testRational0.mysimp((int)(short)100, (int)(short)100, (-1), (int)(byte)0, (int)(byte)100, (int)' ');
    testRational0.mysimp((int)(short)10, 1, (int)(byte)0, (int)(byte)100, (int)(byte)10, (int)(byte)100);
    testRational0.mysimp((int)' ', 10, 100, (int)(short)10, (int)(byte)10, (int)(byte)100);
    testRational0.mysimp((-1), (int)(short)(-1), (int)(short)0, 0, (int)(short)1, 100);

  }

  @Test
  public void test264() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test264"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)1, (int)(short)10, 0, 1, (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp((int)'#', 10, 0, (int)(byte)(-1), (int)(short)0, 10);
    testRational0.mysimp((int)(short)10, (int)(byte)0, (int)(short)(-1), (int)'a', (int)'4', (int)(byte)10);
    testRational0.mysimp((int)'a', (int)(short)10, (int)(byte)100, (int)' ', (int)(short)10, 1);
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, (int)(short)100, (int)'#', (int)'a', (int)' ');
    testRational0.mysimp((int)(byte)1, (int)(short)10, (int)(byte)0, (int)(byte)100, (int)(short)0, (int)(byte)0);
    testRational0.mysimp((int)(short)100, (int)'a', (int)'a', (int)(short)10, (int)(short)100, (int)(byte)0);

  }

  @Test
  public void test265() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test265"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)10, (int)'#', 0, (-1));
    testRational0.mysimp((int)'#', (int)'a', (int)(byte)1, (int)' ', 0, (int)'4');
    testRational0.mysimp(0, (int)' ', 100, (int)'4', (int)'a', 0);
    testRational0.mysimp(100, (int)'4', (-1), (int)'4', (-1), (int)' ');
    testRational0.mysimp((int)(byte)100, 100, 10, (int)(byte)100, (int)(byte)100, (int)(byte)100);
    testRational0.mysimp(100, (int)(byte)(-1), (int)(short)0, (int)(short)1, (int)' ', (int)(short)0);
    testRational0.mysimp((int)(short)100, (int)(byte)0, (int)(short)(-1), (int)'a', 0, (int)(short)100);
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(byte)100, (-1), (int)(short)100, 0);
    testRational0.mysimp((int)(byte)0, (int)(byte)0, 100, (int)(byte)(-1), (int)(short)1, (int)(short)(-1));
    testRational0.mysimp((-1), 10, (-1), 0, 10, 100);

  }

  @Test
  public void test266() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test266"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'a', (int)(byte)0, 0, (int)(short)0, 0);
    testRational0.mysimp((int)(short)0, (int)(short)10, (-1), (int)(short)(-1), (int)(short)0, 0);
    testRational0.mysimp((int)(byte)10, (int)(byte)100, (int)(short)10, (int)(byte)0, (int)'4', (int)(short)10);
    testRational0.mysimp((int)'a', (int)(byte)100, (int)(byte)1, (int)(short)1, (int)'4', (int)'4');
    testRational0.mysimp(10, (int)(short)(-1), 0, 1, (int)(short)0, (int)(short)(-1));
    testRational0.mysimp((int)'4', 10, (int)(byte)100, (int)(short)(-1), (int)(byte)1, (int)(short)1);
    testRational0.mysimp((int)(byte)100, 100, 1, 10, 1, 100);
    testRational0.mysimp((int)(byte)0, 0, 10, (int)(short)1, (int)' ', (int)(short)0);

  }

  @Test
  public void test267() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test267"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)1, (int)(short)10, 0, 1, (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp((int)(short)100, (int)(short)0, (int)(short)(-1), (int)(byte)0, (int)'#', (int)'4');
    testRational0.mysimp(100, (int)(short)10, (-1), (int)'#', (int)(short)100, (int)'4');
    testRational0.mysimp((int)(byte)1, 1, 0, (int)(short)100, 10, 0);
    testRational0.mysimp((int)'#', (-1), 10, (int)(byte)10, (int)(byte)100, (int)(short)0);
    testRational0.mysimp(0, 1, 10, (int)(short)(-1), 0, (int)(short)0);

  }

  @Test
  public void test268() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test268"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)1, 1, (int)(short)1, 0);
    testRational0.mysimp((int)(byte)100, (int)(byte)100, (int)(short)1, (int)(short)10, (int)(short)1, (int)(short)0);
    testRational0.mysimp((int)'a', (int)(short)0, (int)(byte)1, (int)(byte)10, (int)(byte)100, 0);
    testRational0.mysimp((int)(byte)100, 1, (int)(short)1, (int)'4', (int)(byte)100, (int)(short)100);
    testRational0.mysimp(0, 0, (-1), (int)(short)100, (int)(byte)1, (-1));
    testRational0.mysimp(1, 0, (int)(byte)1, (int)(short)100, (int)(short)100, 10);
    testRational0.mysimp((int)'a', (int)(short)10, (-1), (int)'4', (int)(byte)(-1), (int)(short)0);
    testRational0.mysimp((int)(byte)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 0, (int)' ');

  }

  @Test
  public void test269() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test269"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)' ', 10, (int)' ', (int)(short)0, 0, (int)(short)1);
    testRational0.mysimp((int)(short)1, (int)' ', (int)(short)100, (int)(short)100, (int)(byte)100, 10);
    testRational0.mysimp((int)'#', (int)'a', (int)(short)0, (int)(short)10, 1, (int)'a');
    testRational0.mysimp(10, 10, (int)(short)10, (int)'4', (int)(byte)100, (int)(byte)0);
    testRational0.mysimp((int)(byte)1, (int)'4', (int)(short)10, (int)'a', (int)(short)10, (int)(short)(-1));
    testRational0.mysimp((int)(byte)1, 10, (int)(byte)(-1), (int)(short)100, 1, (int)'#');
    testRational0.mysimp((-1), (int)(short)100, 10, (int)(short)(-1), (int)(short)0, (int)'4');
    testRational0.mysimp(100, (int)'a', (int)(short)1, 10, (int)' ', (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'a', (int)'4', (int)'4', 100, (int)(short)(-1));

  }

  @Test
  public void test270() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test270"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)' ', (int)(byte)0, (int)(byte)1, (int)(byte)100, 10, (int)'4');
    testRational0.mysimp((int)(short)(-1), (int)'a', 100, (int)' ', (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp((int)'4', (int)(short)1, (int)(byte)10, (int)(byte)10, (-1), (int)'a');
    testRational0.mysimp((int)(short)1, (int)' ', (int)'4', 0, (int)(short)100, 0);
    testRational0.mysimp((int)'4', (int)(short)100, (int)(byte)0, (int)(short)(-1), (int)(byte)(-1), (int)(short)(-1));
    testRational0.mysimp((int)(byte)100, (-1), (int)(byte)0, (int)(short)(-1), (int)(byte)100, (int)' ');
    testRational0.mysimp((int)(short)(-1), 0, (int)(short)100, 0, 0, 0);
    testRational0.mysimp((int)(short)(-1), 10, (int)'a', 1, (int)(byte)100, (int)(byte)(-1));
    testRational0.mysimp(1, 10, 1, (int)(short)0, (int)(byte)10, (int)(byte)100);

  }

  @Test
  public void test271() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test271"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(10, (int)(short)100, (int)' ', (int)(byte)1, (int)(short)(-1), 0);
    testRational0.mysimp((int)(byte)100, (int)(short)(-1), (int)(byte)10, (int)(byte)100, (-1), 100);
    testRational0.mysimp((int)'a', (int)'#', (-1), (int)(short)10, (int)(short)100, (int)(byte)1);
    testRational0.mysimp((int)(short)1, (int)(short)0, (-1), (int)'4', 10, (-1));
    testRational0.mysimp((int)'#', (int)(short)(-1), (-1), (int)(byte)0, (int)(byte)(-1), 0);

  }

  @Test
  public void test272() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test272"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)'a', (int)(byte)(-1), (int)' ', (int)'#', (int)(short)1);
    testRational0.mysimp((int)(byte)1, 1, (int)(short)1, (int)(short)100, (int)(byte)(-1), (int)'#');
    testRational0.mysimp(10, (int)(short)10, (int)' ', (int)(short)10, (int)'a', (int)(byte)(-1));
    testRational0.mysimp(0, (int)(byte)100, (int)(byte)1, 100, (int)(byte)0, (int)(byte)0);
    testRational0.mysimp(1, (int)(short)1, (int)(short)100, 0, (int)(byte)1, (int)(byte)(-1));
    testRational0.mysimp((int)(short)1, (int)(byte)10, 100, (int)(short)(-1), (int)(byte)10, (int)(byte)(-1));
    testRational0.mysimp((int)'a', (-1), (int)(short)10, 0, 10, (-1));
    testRational0.mysimp((int)'a', (int)(short)100, (int)(short)(-1), (int)(byte)0, (int)(short)1, (int)(byte)0);
    testRational0.mysimp((int)(short)0, (int)'a', (int)(short)100, (int)'#', 1, (int)(short)1);

  }

  @Test
  public void test273() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test273"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(byte)100, (int)(byte)1, (int)(byte)(-1), 1, (int)(byte)0, 10);
    testRational0.mysimp(0, (int)'#', (int)(short)0, (int)'#', 100, (int)(short)100);
    testRational0.mysimp((int)(byte)(-1), (int)' ', (int)(byte)10, (int)(short)(-1), (int)(byte)100, (int)(short)100);
    testRational0.mysimp((int)(byte)10, (int)(short)0, (int)(byte)1, (-1), 1, (int)'4');
    testRational0.mysimp((int)(byte)1, (-1), (int)(short)1, 100, (int)(byte)100, (int)(byte)(-1));
    testRational0.mysimp((-1), (int)(byte)100, 1, (int)(short)10, (int)(short)100, (int)(byte)1);

  }

  @Test
  public void test274() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test274"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)1, (int)(short)10, 0, 1, (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp((int)(short)(-1), 100, (int)(short)0, (int)(byte)1, (int)'4', (int)(short)10);
    testRational0.mysimp((int)' ', (int)'4', (int)(byte)10, (int)'4', (int)(short)0, (int)(short)100);
    testRational0.mysimp(10, (int)(short)1, 10, (int)'a', (int)(short)1, (int)(short)1);

  }

  @Test
  public void test275() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test275"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)10, (int)'#', 0, (-1));
    testRational0.mysimp((int)'#', (int)'a', (int)(byte)1, (int)' ', 0, (int)'4');
    testRational0.mysimp((int)' ', (int)(short)(-1), (int)(short)0, (-1), (int)(byte)10, (-1));
    testRational0.mysimp((int)(short)(-1), (int)(short)10, (int)(short)100, 1, (int)(short)100, (int)' ');
    testRational0.mysimp((int)(short)1, (int)(short)1, 0, (int)(byte)0, (int)(byte)0, (int)(byte)0);
    testRational0.mysimp(0, (int)(byte)(-1), (int)(short)1, 100, (int)(byte)100, (int)(short)1);

  }

  @Test
  public void test276() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test276"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(10, (int)(short)100, (int)' ', (int)(byte)1, (int)(short)(-1), 0);
    testRational0.mysimp((int)(byte)100, (int)(short)(-1), (int)(byte)10, (int)(byte)100, (-1), 100);
    testRational0.mysimp((int)(short)10, (int)(byte)(-1), (int)(byte)0, (int)'#', (int)' ', (int)(byte)10);
    testRational0.mysimp((int)'#', (int)(short)10, (int)(short)0, (int)'a', (int)(short)0, (int)(short)1);
    testRational0.mysimp((int)(byte)0, (int)(byte)1, 1, (int)(short)100, (int)(short)100, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)'#', (int)(short)100, (int)(byte)100, (int)'#', (int)(byte)0);
    testRational0.mysimp((int)(short)(-1), (int)(short)1, (int)(short)100, (int)(short)0, 100, 1);
    testRational0.mysimp((int)(short)10, (int)(byte)100, 0, (int)(short)0, 0, (int)(short)1);
    testRational0.mysimp((int)(short)(-1), (int)(byte)(-1), (int)(byte)100, (int)'#', (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp((int)(short)0, (int)(byte)0, (int)(short)0, (int)(short)1, (int)'a', (int)(short)(-1));
    testRational0.mysimp((int)(byte)0, (int)(short)100, (int)' ', 0, (int)(short)0, (int)(short)10);
    testRational0.mysimp(1, (int)'#', (int)'#', (int)'#', (int)(short)1, (int)(short)10);

  }

  @Test
  public void test277() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test277"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'#', 1, (int)(short)10, (int)'4', (int)(short)1);
    testRational0.mysimp(0, (int)'#', 10, (int)(byte)0, (int)'a', (int)(byte)(-1));
    testRational0.mysimp((int)(short)0, (-1), (int)(short)100, (int)'a', 0, (int)(short)0);
    testRational0.mysimp((int)'4', 0, 100, (int)(short)(-1), (int)(short)100, (int)'#');
    testRational0.mysimp((int)'a', (int)(byte)0, (int)(short)(-1), (int)' ', (int)(byte)1, (int)(byte)1);
    testRational0.mysimp((int)' ', (int)'#', (int)'4', 1, (int)(byte)1, (int)(short)0);

  }

  @Test
  public void test278() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test278"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(byte)0, (int)(short)0, 10, (int)(byte)(-1), (int)'4', (int)(byte)0);
    testRational0.mysimp((int)(byte)10, (int)(short)10, (int)'4', (int)(byte)(-1), (int)' ', 1);
    testRational0.mysimp((int)'4', 0, (int)'a', (int)'#', (int)(short)0, 10);
    testRational0.mysimp((int)(short)(-1), (int)' ', (int)(short)(-1), (int)(byte)1, (int)(short)0, (int)(short)1);
    testRational0.mysimp((int)(short)10, 0, (int)(short)(-1), 100, (int)(byte)(-1), (-1));

  }

  @Test
  public void test279() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test279"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)(byte)100, (int)' ', 10, (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp((int)(short)0, (int)' ', (int)'a', (int)(short)10, (int)(short)(-1), (int)(short)100);
    testRational0.mysimp((int)(short)100, 100, (int)(byte)0, 10, (int)(byte)100, (-1));
    testRational0.mysimp((int)(short)1, (int)'4', (int)(byte)0, 10, 10, (int)(byte)0);
    testRational0.mysimp((int)'a', 1, 100, (int)'a', 10, (int)(short)100);
    testRational0.mysimp((int)(byte)10, (int)(short)10, 0, (int)(short)(-1), (int)'4', 10);
    testRational0.mysimp(1, (-1), (int)(byte)100, (int)(short)(-1), (int)(short)(-1), (int)(short)0);
    testRational0.mysimp((int)(byte)0, (int)'4', (int)'4', (int)'#', 100, (int)(short)0);

  }

  @Test
  public void test280() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test280"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(byte)100, (int)(byte)1, (int)(byte)(-1), 1, (int)(byte)0, 10);
    testRational0.mysimp(0, (int)'#', (int)(short)0, (int)'#', 100, (int)(short)100);
    testRational0.mysimp((int)'#', (int)(short)(-1), 0, (int)'a', (int)(byte)100, (-1));
    testRational0.mysimp((int)(short)10, 0, 100, 0, 10, (int)(byte)0);
    testRational0.mysimp((int)(byte)10, 10, (int)(short)100, (int)(short)(-1), (int)'#', (int)'#');
    testRational0.mysimp((int)'4', (int)'4', (int)(byte)0, (int)(short)0, 0, (int)'a');
    testRational0.mysimp((int)'4', (int)'a', 0, (int)(byte)100, 0, 0);
    testRational0.mysimp((int)(short)(-1), 0, (int)'4', (int)(short)0, (int)(byte)(-1), (int)(short)10);

  }

  @Test
  public void test281() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test281"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 0, (-1), 100, (int)'a');
    testRational0.mysimp(0, (int)'4', (int)(byte)0, (int)(short)0, 0, (int)(short)100);
    testRational0.mysimp(10, (int)' ', (int)' ', 0, (int)' ', 10);
    testRational0.mysimp(100, (int)(byte)(-1), (int)'#', (int)(byte)10, (int)(short)100, (int)(short)10);
    testRational0.mysimp((int)(short)100, (-1), (int)(short)(-1), (int)(short)(-1), 1, (int)(byte)10);
    testRational0.mysimp((int)(short)100, (int)(byte)(-1), (int)'4', (int)' ', (int)(byte)0, (int)' ');
    testRational0.mysimp((int)' ', (int)(short)100, (int)' ', (int)(byte)(-1), 1, (int)(short)10);
    testRational0.mysimp((int)(short)10, 100, (int)' ', (int)(short)100, (int)(byte)0, 0);

  }

  @Test
  public void test282() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test282"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)' ', (int)(byte)0, (int)(byte)1, (int)(byte)100, 10, (int)'4');
    testRational0.mysimp((int)(short)(-1), (int)'a', 100, (int)' ', (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp((int)(short)10, (int)(byte)0, (int)(short)0, (-1), (-1), (int)(short)100);
    testRational0.mysimp((-1), (int)(byte)10, (int)(short)10, 0, (int)(byte)1, (int)(byte)10);
    testRational0.mysimp((int)'#', (-1), 0, (int)(short)0, (-1), (int)(short)(-1));

  }

  @Test
  public void test283() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test283"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(byte)100, (int)(byte)1, (int)(byte)(-1), 1, (int)(byte)0, 10);
    testRational0.mysimp(0, (int)'#', (int)(short)0, (int)'#', 100, (int)(short)100);
    testRational0.mysimp((int)(short)1, (int)' ', (int)(short)100, (int)(byte)1, (int)'4', (int)' ');
    testRational0.mysimp((int)(short)1, (int)'#', 0, (int)(short)100, (-1), (int)(byte)100);
    testRational0.mysimp((int)(short)(-1), (int)(byte)1, (int)(short)(-1), 1, (int)(short)100, 0);
    testRational0.mysimp((int)(byte)1, (int)(byte)0, (int)(short)(-1), (int)'4', (int)(short)0, (int)(byte)0);
    testRational0.mysimp((int)(byte)0, 10, (int)(byte)10, (int)'#', 0, 0);
    testRational0.mysimp((int)(byte)10, (int)'#', (int)(byte)0, (int)(byte)0, (-1), (int)(short)100);
    testRational0.mysimp((int)(short)100, (int)(byte)(-1), (-1), 0, 100, (-1));

  }

  @Test
  public void test284() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test284"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)' ', (int)(byte)0, (int)(byte)1, (int)(byte)100, 10, (int)'4');
    testRational0.mysimp((int)(short)10, (int)(short)100, (int)(short)(-1), 1, (int)(byte)100, (-1));
    testRational0.mysimp((int)(byte)10, (int)(short)(-1), 1, (int)(short)(-1), (int)(short)0, 0);
    testRational0.mysimp((int)(short)0, 100, (int)(short)10, 1, (int)(byte)100, (int)'a');
    testRational0.mysimp(1, (int)(byte)(-1), (int)(byte)0, (int)(byte)(-1), (int)'4', (int)(short)(-1));
    testRational0.mysimp((int)(byte)100, 0, 10, 10, 100, 0);
    testRational0.mysimp((int)(byte)10, 10, (-1), (int)'a', (int)(short)(-1), (int)'4');
    testRational0.mysimp((int)(byte)(-1), (int)(byte)100, (int)(byte)0, (int)(byte)(-1), 1, (int)(byte)10);
    testRational0.mysimp((int)(short)10, 1, (int)' ', 0, (-1), (int)(short)(-1));

  }

  @Test
  public void test285() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test285"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)10, (int)'#', 0, (-1));
    testRational0.mysimp((int)(byte)1, (int)(byte)100, (int)' ', (int)(short)0, (int)(short)100, 0);
    testRational0.mysimp((int)(byte)100, 0, (int)(short)100, (-1), 1, (int)(byte)100);
    testRational0.mysimp((int)(byte)(-1), 10, (int)'a', (int)(short)1, (int)(short)0, (int)(byte)1);
    testRational0.mysimp((int)(short)1, (int)(byte)0, (int)' ', (-1), (int)(byte)(-1), 10);
    testRational0.mysimp((int)(short)(-1), (int)(short)0, 10, 1, 1, (int)(byte)1);
    testRational0.mysimp((int)(byte)10, 1, (-1), (int)(short)10, (int)'#', (int)'#');

  }

  @Test
  public void test286() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test286"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(10, (int)(byte)100, (int)(byte)10, (int)(short)0, (int)(byte)0, (int)' ');
    testRational0.mysimp((int)(short)10, (int)(byte)10, (int)(short)100, (int)(byte)0, (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp((int)(short)(-1), (int)'#', (int)'#', (int)(short)10, (int)(byte)0, (int)(byte)100);
    testRational0.mysimp(100, 10, 10, (int)(short)10, (int)(short)10, (int)(byte)100);
    testRational0.mysimp((int)(short)1, (int)'4', 100, (-1), 1, 1);
    testRational0.mysimp((int)' ', (-1), (int)(short)0, (int)(short)10, (int)(byte)10, (int)'#');

  }

  @Test
  public void test287() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test287"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, 100, 100);
    testRational0.mysimp(0, (int)'4', (int)' ', (int)(byte)100, (int)(byte)1, (int)(short)100);
    testRational0.mysimp((int)(byte)0, (int)(byte)100, (int)(byte)100, (int)'4', (int)(short)0, (int)(short)(-1));
    testRational0.mysimp(1, (int)' ', 0, (int)'a', (int)'a', 1);

  }

  @Test
  public void test288() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test288"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 0, (-1), 100, (int)'a');
    testRational0.mysimp(10, (int)(short)0, 100, (int)'4', (-1), 0);
    testRational0.mysimp(0, (int)(byte)(-1), 100, (int)(short)1, (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp((int)(byte)0, (int)'4', 100, (int)(byte)1, (int)(byte)10, 0);
    testRational0.mysimp((int)(byte)0, 0, (int)(short)(-1), (int)'#', (int)(byte)0, (int)(short)1);
    testRational0.mysimp((int)(byte)0, 10, (int)'4', (int)(short)(-1), 1, (int)(byte)(-1));
    testRational0.mysimp((int)(short)100, (int)'a', 0, 10, 0, (int)(short)1);
    testRational0.mysimp(0, (int)(short)0, 0, 0, (int)(short)(-1), 1);
    testRational0.mysimp((int)(short)100, (int)(short)(-1), (int)(byte)0, 0, 0, (int)(short)0);
    testRational0.mysimp((int)'#', (int)(byte)10, (int)'4', (int)(short)10, 0, (int)(short)(-1));
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)100, (int)'a', (int)(byte)1, (int)(byte)100);
    testRational0.mysimp((int)(short)(-1), (int)(short)(-1), (-1), (int)(short)1, (int)(byte)10, 100);

  }

  @Test
  public void test289() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test289"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(10, (int)(byte)100, (int)(byte)10, (int)(short)0, (int)(byte)0, (int)' ');
    testRational0.mysimp(10, (int)'#', (int)'a', (int)(short)1, 100, (int)(short)1);
    testRational0.mysimp((int)'4', (int)'a', 0, 1, (int)(short)(-1), (int)(byte)10);
    testRational0.mysimp((int)'4', (int)(byte)100, 0, (-1), (int)(byte)0, (int)'#');
    testRational0.mysimp((int)(byte)0, (-1), (int)(short)100, (int)'#', (int)(short)1, (int)(short)(-1));
    testRational0.mysimp((int)(short)0, (int)(short)1, (int)(short)(-1), (int)(byte)1, (int)(short)100, (int)(short)10);
    testRational0.mysimp((int)'#', (int)(byte)1, (int)'#', (int)'a', (int)(short)0, (int)(short)(-1));

  }

  @Test
  public void test290() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test290"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(byte)0, (int)(short)0, 10, (int)(byte)(-1), (int)'4', (int)(byte)0);
    testRational0.mysimp((int)(byte)10, (int)(short)10, (int)'4', (int)(byte)(-1), (int)' ', 1);
    testRational0.mysimp((int)(short)(-1), (int)(byte)(-1), (int)(byte)100, 0, (int)(short)100, (int)(short)10);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)(byte)1, 0, (int)(short)0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)'#', (int)(short)1, 0, 100, (int)'#');
    testRational0.mysimp((int)(byte)(-1), (int)(byte)0, 100, (int)'a', 0, (int)(byte)100);
    testRational0.mysimp((int)(byte)1, (int)(short)0, (int)'4', 100, (-1), (int)'4');
    testRational0.mysimp((int)(byte)10, 0, (int)(short)(-1), (int)(short)100, (int)(byte)(-1), 100);
    testRational0.mysimp((int)(byte)1, (int)(byte)1, (int)(short)100, 100, (int)'a', (int)(short)100);
    testRational0.mysimp((int)(short)10, (int)(short)100, 0, (int)(short)100, 10, (int)(short)10);

  }

  @Test
  public void test291() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test291"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(10, (int)(short)100, (int)(short)10, (int)(short)100, (int)(byte)10, 0);
    testRational0.mysimp(10, (int)'4', (int)(byte)0, (int)(byte)(-1), 0, 1);
    testRational0.mysimp((int)(short)(-1), (int)(short)(-1), 0, 100, (int)(byte)100, (int)(short)10);
    testRational0.mysimp((int)(byte)1, (int)(short)100, (-1), (int)(short)10, (int)(short)1, (int)(short)(-1));
    testRational0.mysimp((int)'#', 1, (int)(short)(-1), (int)(short)(-1), (int)(byte)0, (int)(byte)1);
    testRational0.mysimp((int)(byte)(-1), 1, (int)'a', (int)(byte)100, (int)(byte)10, 1);
    testRational0.mysimp((int)'4', 100, 1, (int)'#', (int)(short)(-1), (int)(short)1);
    testRational0.mysimp((int)(short)100, (int)(byte)0, 0, (int)'a', (int)'#', (int)(byte)0);
    testRational0.mysimp((-1), (int)(short)1, (int)(short)10, 10, (int)(byte)100, 0);

  }

  @Test
  public void test292() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test292"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)10, (int)'#', 0, (-1));
    testRational0.mysimp((int)'4', (int)(byte)(-1), (int)(byte)100, (int)(short)1, (int)'#', 100);
    testRational0.mysimp((int)(short)100, (int)(byte)(-1), 10, (-1), (int)(byte)100, 10);
    testRational0.mysimp(1, 0, (int)'4', 100, (int)(byte)100, 0);
    testRational0.mysimp((int)'a', (int)'a', 0, (-1), 100, 10);
    testRational0.mysimp((int)(byte)100, (int)'#', (int)'a', (int)'a', (int)'#', (int)'#');

  }

  @Test
  public void test293() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test293"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(10, (int)(byte)100, (int)(byte)10, (int)(short)0, (int)(byte)0, (int)' ');
    testRational0.mysimp((int)(short)10, (int)(byte)10, (int)(short)100, (int)(byte)0, (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp((int)'4', (int)(byte)1, (int)(byte)0, (int)'4', (int)(short)1, 0);
    testRational0.mysimp((int)'#', (int)(byte)100, (int)(byte)(-1), 10, (int)(short)100, (int)(byte)(-1));
    testRational0.mysimp(10, (int)(byte)1, (-1), 0, (int)(byte)1, 100);
    testRational0.mysimp((int)'4', (-1), (int)(short)(-1), (int)(short)(-1), 1, 0);
    testRational0.mysimp(1, 1, (int)(byte)10, 0, 0, (int)'#');
    testRational0.mysimp(10, 0, 0, (int)(short)100, (int)(short)1, 0);
    testRational0.mysimp((int)(byte)0, (int)(short)1, (int)'a', (int)(short)10, (int)(short)1, (int)' ');

  }

  @Test
  public void test294() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test294"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'#', 1, (int)(short)10, (int)'4', (int)(short)1);
    testRational0.mysimp((int)'4', (int)'4', (int)(short)(-1), (int)(byte)10, 1, (int)(short)100);
    testRational0.mysimp(0, (int)(short)10, (int)(short)0, (int)(byte)100, (int)' ', (int)(short)10);
    testRational0.mysimp((int)(byte)(-1), (int)(short)100, (int)(short)0, (int)(byte)0, (-1), 10);

  }

  @Test
  public void test295() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test295"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(short)(-1), (int)(short)10, (int)' ', 0, (int)(byte)100, (int)' ');
    testRational0.mysimp((int)' ', 0, (int)(byte)100, 100, (int)(byte)10, 0);
    testRational0.mysimp(0, (int)(byte)(-1), 1, (int)(byte)1, (int)(byte)(-1), (int)'a');
    testRational0.mysimp((int)(byte)10, 10, (int)(byte)(-1), (-1), (int)(byte)100, 0);
    testRational0.mysimp(10, (-1), (int)(byte)0, 0, (int)'a', (int)'4');
    testRational0.mysimp((int)(short)(-1), 1, 0, (int)(byte)100, (int)'a', (int)(byte)(-1));
    testRational0.mysimp(10, 0, 0, (int)(byte)1, 0, 0);
    testRational0.mysimp((int)(short)10, 10, 1, 1, (int)'#', (int)(byte)10);
    testRational0.mysimp(1, (int)(short)(-1), (-1), 100, 100, (int)(byte)(-1));

  }

  @Test
  public void test296() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test296"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(byte)100, (int)(byte)1, (int)(byte)(-1), 1, (int)(byte)0, 10);
    testRational0.mysimp((int)(byte)(-1), 10, (-1), (int)(byte)1, (int)(byte)0, 10);
    testRational0.mysimp((int)(byte)100, (int)'#', (int)(byte)1, 10, 1, (int)(byte)0);
    testRational0.mysimp(0, (int)(byte)(-1), (int)(short)1, (int)(byte)100, (-1), (-1));
    testRational0.mysimp((int)(short)10, (int)(short)0, (int)(short)1, 10, (int)(short)0, (int)(short)(-1));

  }

  @Test
  public void test297() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test297"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)100, (int)(short)0, (int)'4', (int)(short)100, 0, (int)(byte)(-1));
    testRational0.mysimp((int)(byte)1, (int)(byte)1, (int)(byte)10, 0, (int)'#', (int)(byte)1);
    testRational0.mysimp((int)(short)10, 100, (int)(short)10, (int)(byte)1, (int)'4', (int)(short)10);
    testRational0.mysimp((int)'4', (-1), 0, (int)(short)10, (int)'a', 100);
    testRational0.mysimp((int)(byte)100, 10, (int)(byte)(-1), (int)'#', (int)'a', (int)(byte)100);

  }

  @Test
  public void test298() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test298"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp((int)(byte)100, (int)(byte)0, 1, (int)(byte)10, (int)(short)100, 1);
    testRational0.mysimp((int)'#', (int)(byte)0, (int)(byte)100, (int)(byte)10, (int)'4', (int)(byte)(-1));
    testRational0.mysimp(100, (int)'#', (int)(byte)0, (int)'a', (int)'a', 1);
    testRational0.mysimp(0, (-1), (int)'4', 1, (int)'#', (int)(short)(-1));
    testRational0.mysimp((-1), 0, (int)(byte)0, (int)(byte)1, (int)(short)(-1), 0);

  }

  @Test
  public void test299() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test299"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(100, 100, 0, 1, (int)'a', 0);
    testRational0.mysimp((int)(byte)10, (int)(byte)1, (int)(short)(-1), (int)(short)(-1), (int)(byte)10, 0);
    testRational0.mysimp((int)(byte)10, 100, (int)' ', (int)(byte)1, 1, (int)'4');
    testRational0.mysimp(1, (int)(byte)100, 0, 100, 0, (int)' ');
    testRational0.mysimp((int)(short)10, (int)(short)0, (-1), (int)(short)(-1), 100, (int)(short)100);
    testRational0.mysimp((int)(byte)100, (int)(byte)1, (int)(byte)1, (int)'a', (int)' ', (int)(byte)10);
    testRational0.mysimp((int)(short)100, 10, (int)(short)(-1), (int)' ', (-1), (-1));

  }

  @Test
  public void test300() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test300"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 0, (-1), 100, (int)'a');
    testRational0.mysimp(10, (int)(short)0, 100, (int)'4', (-1), 0);
    testRational0.mysimp(0, (int)(byte)(-1), 100, (int)(short)1, (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp((int)(byte)0, (int)'4', 100, (int)(byte)1, (int)(byte)10, 0);
    testRational0.mysimp((int)(byte)0, 0, (int)(short)(-1), (int)'#', (int)(byte)0, (int)(short)1);
    testRational0.mysimp((int)(byte)0, 10, (int)'4', (int)(short)(-1), 1, (int)(byte)(-1));
    testRational0.mysimp((int)(short)100, (int)'a', 0, 10, 0, (int)(short)1);
    testRational0.mysimp((int)(short)100, (int)(byte)1, (int)(byte)0, (int)(short)1, (int)(byte)100, (int)(short)(-1));
    testRational0.mysimp((int)(byte)0, 100, (int)(short)100, (int)(byte)0, (int)(byte)(-1), (int)(byte)100);
    testRational0.mysimp(100, 1, 0, 0, (int)(short)1, (int)(short)1);
    testRational0.mysimp((int)(short)(-1), (int)' ', (int)(byte)1, (int)(byte)0, (int)(short)0, (int)'#');
    testRational0.mysimp((int)(short)1, (int)(byte)10, (-1), (-1), (-1), (int)'4');

  }

  @Test
  public void test301() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test301"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp((int)(short)1, (-1), 0, (int)(byte)0, (int)'a', (int)(short)0);
    testRational0.mysimp((int)'4', 10, (int)(short)(-1), 0, (int)(short)1, (int)(short)100);
    testRational0.mysimp((int)(byte)0, (int)(short)10, (int)(byte)0, (int)'a', (int)(short)10, (int)(short)10);
    testRational0.mysimp((int)'#', 100, 1, (int)'#', 10, (int)'#');

  }

  @Test
  public void test302() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test302"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(1, 10, (int)(byte)100, (int)(byte)0, (int)(short)0, (int)(byte)100);
    testRational0.mysimp((int)(byte)10, (-1), 10, (int)(short)10, (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp((int)(short)0, (int)(byte)(-1), 10, 0, (int)(short)1, (int)(short)0);
    testRational0.mysimp(100, 100, (int)(short)100, (int)(short)1, (int)(short)1, (int)'4');
    testRational0.mysimp((int)(short)10, (int)(byte)1, (int)(short)100, (int)(short)100, 0, (int)'4');

  }

  @Test
  public void test303() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test303"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)' ', 10, (int)' ', (int)(short)0, 0, (int)(short)1);
    testRational0.mysimp((int)(short)1, (int)' ', (int)(short)100, (int)(short)100, (int)(byte)100, 10);
    testRational0.mysimp((int)'#', (int)'a', (int)(short)0, (int)(short)10, 1, (int)'a');
    testRational0.mysimp(10, 10, (int)(short)10, (int)'4', (int)(byte)100, (int)(byte)0);
    testRational0.mysimp((int)' ', (int)(byte)10, 1, 1, (int)'#', (int)(byte)100);
    testRational0.mysimp(0, (int)(byte)0, (int)(byte)(-1), (int)(short)1, (int)(byte)10, (int)' ');
    testRational0.mysimp(0, (int)' ', 1, (int)' ', 100, (-1));
    testRational0.mysimp((int)(byte)0, (int)'4', (int)(byte)(-1), (int)'4', (int)(short)10, (int)(byte)0);
    testRational0.mysimp((int)' ', (int)(byte)10, (int)(byte)100, 100, (int)(short)10, 0);

  }

  @Test
  public void test304() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test304"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)(byte)100, (int)' ', 10, (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp((int)(short)0, (int)' ', (int)'a', (int)(short)10, (int)(short)(-1), (int)(short)100);
    testRational0.mysimp((int)(byte)(-1), (int)'4', (int)(byte)1, 0, (int)(byte)1, (-1));
    testRational0.mysimp((int)(short)100, 0, 0, (int)(short)100, (int)(short)100, (int)' ');
    testRational0.mysimp((int)(byte)100, 10, (int)(byte)(-1), (int)(short)0, (int)'4', (int)(byte)0);

  }

  @Test
  public void test305() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test305"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)' ', (int)(byte)0, (int)(byte)1, (int)(byte)100, 10, (int)'4');
    testRational0.mysimp((int)(short)10, (int)(short)100, (int)(short)(-1), 1, (int)(byte)100, (-1));
    testRational0.mysimp((int)(byte)0, 0, 0, (int)'a', (int)' ', (int)'a');
    testRational0.mysimp((int)'4', 100, (int)(short)0, (int)(short)0, (int)(short)1, (-1));
    testRational0.mysimp((int)'4', 10, (int)(byte)10, (-1), (int)(byte)(-1), (int)(short)10);
    testRational0.mysimp(100, (int)(short)0, 0, (int)(short)0, 1, 0);
    testRational0.mysimp(100, (int)(byte)1, (int)(byte)1, (int)(byte)(-1), (int)(short)100, (int)(byte)10);
    testRational0.mysimp((int)'4', (int)'4', (int)(byte)100, (int)(byte)(-1), (int)(short)1, (int)' ');
    testRational0.mysimp((int)'#', 1, (int)(byte)10, 0, (int)(byte)(-1), 0);
    testRational0.mysimp((int)(short)100, (int)(byte)100, (int)(short)1, 0, 0, 0);

  }

  @Test
  public void test306() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test306"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'a', (int)(byte)0, 0, (int)(short)0, 0);
    testRational0.mysimp((int)(short)10, (int)(byte)0, (int)'a', (int)(byte)0, (int)(byte)0, (int)(byte)(-1));
    testRational0.mysimp(1, 1, (int)(short)0, (-1), (int)(byte)1, (int)(byte)1);
    testRational0.mysimp((int)(byte)100, (int)(byte)1, (int)(short)10, (int)(short)(-1), (-1), (int)(short)1);
    testRational0.mysimp((int)(byte)10, (int)(byte)10, (int)(byte)1, 10, 1, (int)' ');
    testRational0.mysimp((int)(short)1, (int)'#', (int)(byte)0, (int)'#', (int)(byte)0, (int)'a');
    testRational0.mysimp((int)' ', (int)(byte)100, (int)'a', 10, (int)'a', (int)(short)10);

  }

  @Test
  public void test307() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test307"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(10, (int)(short)100, (int)' ', (int)(byte)1, (int)(short)(-1), 0);
    testRational0.mysimp((int)(byte)100, (int)(short)(-1), (int)(byte)10, (int)(byte)100, (-1), 100);
    testRational0.mysimp((int)(short)10, (int)(byte)(-1), (int)(byte)0, (int)'#', (int)' ', (int)(byte)10);
    testRational0.mysimp((int)' ', (int)(short)0, (int)(byte)10, 0, (int)(byte)1, (int)(short)1);
    testRational0.mysimp((int)(byte)10, (int)(short)(-1), (int)(byte)(-1), (int)(byte)10, (int)(byte)0, 100);
    testRational0.mysimp((int)(short)10, (-1), 0, (int)(byte)0, (int)(short)0, 10);
    testRational0.mysimp((int)'#', (int)'4', (int)(byte)10, 100, 100, (int)'4');
    testRational0.mysimp((int)'#', (int)'#', (int)(byte)1, (int)' ', (int)(byte)0, (int)'a');

  }

  @Test
  public void test308() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test308"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)'a', (int)(byte)1, (int)(short)100, (int)(byte)1, (int)(short)0, (int)(short)(-1));
    testRational0.mysimp((-1), 1, (int)(byte)0, (-1), 1, (int)'a');
    testRational0.mysimp(1, (int)'#', (int)(short)0, (-1), (int)(byte)10, 0);

  }

  @Test
  public void test309() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test309"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)10, (int)'#', 0, (-1));
    testRational0.mysimp((int)'4', (int)(byte)(-1), (int)(byte)100, (int)(short)1, (int)'#', 100);
    testRational0.mysimp((int)(byte)10, (int)'a', (int)(short)100, (int)'#', (int)(short)10, (int)(short)100);
    testRational0.mysimp((int)(short)100, 0, (int)(byte)0, 100, 100, 1);
    testRational0.mysimp(0, (int)(short)10, (int)'4', (int)(short)0, (int)(short)10, 1);
    testRational0.mysimp((int)(short)1, 10, (int)'#', (int)(byte)(-1), (int)(byte)10, (int)(byte)0);

  }

  @Test
  public void test310() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test310"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(10, (int)(short)100, (int)' ', (int)(byte)1, (int)(short)(-1), 0);
    testRational0.mysimp((int)(byte)100, (int)(short)(-1), (int)(byte)10, (int)(byte)100, (-1), 100);
    testRational0.mysimp((int)(short)10, (int)(byte)(-1), (int)(byte)0, (int)'#', (int)' ', (int)(byte)10);
    testRational0.mysimp((int)' ', (int)(short)0, (int)(byte)10, 0, (int)(byte)1, (int)(short)1);
    testRational0.mysimp((int)(byte)10, (int)(short)(-1), (int)(byte)(-1), (int)(byte)10, (int)(byte)0, 100);
    testRational0.mysimp((int)(short)10, (-1), 0, (int)(byte)0, (int)(short)0, 10);
    testRational0.mysimp(100, (-1), (int)(byte)0, (int)(byte)100, (int)(short)(-1), (int)(short)(-1));

  }

  @Test
  public void test311() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test311"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, 100, 100);
    testRational0.mysimp((int)(byte)(-1), (int)'a', (-1), (int)'4', (-1), (int)(byte)0);
    testRational0.mysimp((int)' ', 0, (int)'#', (int)(short)100, (int)(short)0, 100);
    testRational0.mysimp((int)'a', (int)(short)1, 1, (int)'4', (int)'4', 10);
    testRational0.mysimp((-1), 0, (int)'4', (-1), (int)(byte)0, (int)(short)1);
    testRational0.mysimp(10, 0, (int)(byte)100, (int)(byte)10, (int)(short)1, (int)'#');
    testRational0.mysimp((int)(byte)1, (int)(byte)10, (int)'#', (int)(byte)10, (int)(short)100, 1);
    testRational0.mysimp((int)(byte)1, (int)'a', 100, (int)'#', (int)'#', 0);
    testRational0.mysimp((int)(short)100, (int)'#', (int)(short)0, (int)(byte)100, 10, (int)(byte)(-1));
    testRational0.mysimp((int)(short)100, 0, (int)(short)100, 1, 0, (int)(short)0);
    testRational0.mysimp(1, (int)(byte)(-1), 100, (int)(short)(-1), (int)'a', (int)(byte)100);
    testRational0.mysimp((int)(byte)(-1), (int)' ', (int)(byte)100, (int)'4', (int)(short)10, (int)(byte)100);

  }

  @Test
  public void test312() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test312"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)(byte)100, (int)' ', 10, (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp((int)' ', 1, 1, (int)'a', 0, (int)'#');
    testRational0.mysimp((int)(byte)10, (int)(byte)(-1), (int)(byte)1, 0, (int)(byte)1, (int)(short)(-1));
    testRational0.mysimp((int)(byte)1, (int)(short)100, 10, (int)(byte)(-1), 0, (int)(short)0);

  }

  @Test
  public void test313() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test313"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(byte)0, (int)(short)0, 10, (int)(byte)(-1), (int)'4', (int)(byte)0);
    testRational0.mysimp((int)(byte)10, (int)(short)10, (int)'4', (int)(byte)(-1), (int)' ', 1);
    testRational0.mysimp((int)(short)(-1), (int)(byte)(-1), (int)(byte)100, 0, (int)(short)100, (int)(short)10);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)(byte)1, 0, (int)(short)0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)'#', (int)(short)1, 0, 100, (int)'#');
    testRational0.mysimp(0, (int)'a', (int)(byte)(-1), (int)(short)10, 0, (int)(byte)1);
    testRational0.mysimp(0, (int)' ', (-1), (int)(byte)100, (int)(byte)10, (int)(byte)(-1));
    testRational0.mysimp((int)(short)(-1), 10, (int)(byte)100, (int)(byte)10, (int)(short)(-1), (int)(byte)0);

  }

  @Test
  public void test314() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test314"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 0, (-1), 100, (int)'a');
    testRational0.mysimp(0, (int)'4', (int)(byte)0, (int)(short)0, 0, (int)(short)100);
    testRational0.mysimp((int)(short)1, (int)(short)(-1), (int)(short)0, 0, 10, (int)(byte)0);
    testRational0.mysimp((int)(short)10, (int)'a', 1, 10, (int)(byte)(-1), (int)(short)100);
    testRational0.mysimp((int)(byte)1, 0, (int)' ', (int)(short)10, (int)(short)10, (int)'4');
    testRational0.mysimp(0, (int)(short)(-1), (int)(byte)10, 1, 1, (int)'a');
    testRational0.mysimp(0, 100, (int)(short)1, 0, (int)(short)10, (int)(short)1);

  }

  @Test
  public void test315() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test315"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)100, (int)(short)0, (int)'4', (int)(short)100, 0, (int)(byte)(-1));
    testRational0.mysimp((int)(byte)0, (int)(byte)1, (int)(byte)0, (int)(short)10, (int)(byte)1, (int)'#');
    testRational0.mysimp((int)(byte)100, 100, (-1), (int)(short)10, 0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)1, (int)(short)10, (int)'4', (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp(100, (int)(byte)(-1), (int)(byte)10, (int)(byte)1, 0, (int)(short)100);
    testRational0.mysimp((int)'a', (int)(byte)1, 100, (int)(byte)0, (int)(byte)100, (int)(short)0);
    testRational0.mysimp((int)(byte)100, 1, (int)(short)10, (int)(byte)10, 1, (-1));

  }

  @Test
  public void test316() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test316"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, 100, 100);
    testRational0.mysimp((int)(byte)(-1), (int)'a', (-1), (int)'4', (-1), (int)(byte)0);
    testRational0.mysimp((int)(short)100, (int)'#', (int)(byte)100, (int)(short)(-1), (int)(short)10, 10);
    testRational0.mysimp((-1), (int)' ', 10, (int)'#', (int)' ', (int)(short)10);
    testRational0.mysimp((int)(byte)10, (int)(byte)100, (int)(byte)0, (int)' ', 0, (int)(short)10);
    testRational0.mysimp((int)'#', 0, (int)(short)10, (int)(short)0, 10, (int)(byte)10);

  }

  @Test
  public void test317() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test317"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)(short)1, (int)(byte)10, (int)(byte)100, 1, (int)(byte)10, (int)(byte)(-1));
    testRational0.mysimp(0, (int)(short)(-1), (int)(short)0, (int)(byte)0, (int)' ', 1);
    testRational0.mysimp((int)'a', (int)'#', (int)(short)1, 10, (int)'#', 100);
    testRational0.mysimp((int)(byte)100, (int)'4', 0, (int)(byte)0, 1, (-1));
    testRational0.mysimp((int)(byte)100, 1, (-1), (int)(byte)1, 0, 0);

  }

  @Test
  public void test318() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test318"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(10, (int)(short)100, (int)(short)10, (int)(short)100, (int)(byte)10, 0);
    testRational0.mysimp(10, (int)'4', (int)(byte)0, (int)(byte)(-1), 0, 1);
    testRational0.mysimp((int)(byte)100, (int)(short)(-1), (int)(short)1, (int)(byte)(-1), 0, (int)(byte)100);
    testRational0.mysimp((int)'a', (int)(byte)0, 0, 1, (int)(byte)10, (int)(short)1);
    testRational0.mysimp((int)'a', (int)(byte)0, (int)(short)10, (int)(byte)0, (int)(short)100, (int)'#');
    testRational0.mysimp((int)(byte)10, 0, (int)(byte)1, (int)(short)100, (int)'4', 10);
    testRational0.mysimp((int)(byte)0, (int)(short)10, 10, (int)'a', 100, (int)(short)1);
    testRational0.mysimp(0, (int)(short)100, 0, (int)(short)100, (int)(byte)10, (int)(short)(-1));
    testRational0.mysimp((int)(byte)10, (int)(byte)1, (int)' ', (int)(byte)100, (int)'4', (int)' ');

  }

  @Test
  public void test319() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test319"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 0, (-1), 100, (int)'a');
    testRational0.mysimp(0, (int)'4', (int)(byte)0, (int)(short)0, 0, (int)(short)100);
    testRational0.mysimp(10, (int)' ', (int)' ', 0, (int)' ', 10);
    testRational0.mysimp(100, (int)(byte)(-1), (int)'#', (int)(byte)10, (int)(short)100, (int)(short)10);
    testRational0.mysimp((int)(short)100, (-1), (int)(short)(-1), (int)(short)(-1), 1, (int)(byte)10);
    testRational0.mysimp((int)(short)(-1), (int)(short)0, (int)(byte)(-1), 0, 10, (int)(short)0);
    testRational0.mysimp(0, (int)(byte)1, 10, 100, (int)(byte)1, (int)(short)0);
    testRational0.mysimp((int)(byte)10, 10, (int)' ', (int)(short)1, (int)'a', (int)(byte)100);
    testRational0.mysimp((int)'a', (int)(byte)0, (int)(short)1, (-1), (int)(byte)(-1), (-1));

  }

  @Test
  public void test320() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test320"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)(short)1, (int)(byte)10, (int)(byte)100, 1, (int)(byte)10, (int)(byte)(-1));
    testRational0.mysimp((int)(byte)100, (int)(short)(-1), 100, (int)' ', (-1), (int)(short)0);
    testRational0.mysimp(0, (int)(byte)100, (int)(byte)100, (int)(short)1, (int)(byte)10, (int)' ');
    testRational0.mysimp((int)(short)100, 1, (int)(short)10, 1, (int)' ', (int)(byte)10);
    testRational0.mysimp((int)(short)10, (int)(byte)0, (int)'a', (int)(byte)0, 0, (int)'a');
    testRational0.mysimp((int)(short)1, 10, (int)(short)(-1), 0, (int)(short)100, (-1));

  }

  @Test
  public void test321() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test321"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(10, (int)'a', (int)(short)10, (int)(short)(-1), (int)(byte)0, (int)'a');
    testRational0.mysimp((int)(byte)100, (int)(short)0, (int)'a', (int)(byte)(-1), 0, (int)(short)(-1));
    testRational0.mysimp((int)(byte)10, 0, (int)(short)(-1), (int)(short)1, 0, (int)(byte)0);
    testRational0.mysimp(100, (-1), (int)(short)100, (int)(byte)10, 10, (int)(byte)(-1));
    testRational0.mysimp((int)(short)100, (-1), 100, (int)(byte)100, (int)(short)10, (int)(short)(-1));
    testRational0.mysimp((int)(short)1, (int)'#', 0, (int)'4', (-1), 1);
    testRational0.mysimp((int)'#', (int)(short)10, 100, 10, (int)(short)1, (int)(byte)10);
    testRational0.mysimp((int)(byte)10, 100, (int)(byte)0, (int)'4', (int)(byte)1, (int)(short)10);
    testRational0.mysimp((int)' ', (int)(byte)100, (int)(short)1, (int)'a', (int)'a', (int)' ');

  }

  @Test
  public void test322() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test322"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp((int)(byte)100, (int)(byte)0, 1, (int)(byte)10, (int)(short)100, 1);
    testRational0.mysimp((int)'#', (int)(byte)0, (int)(byte)100, (int)(byte)10, (int)'4', (int)(byte)(-1));
    testRational0.mysimp((int)(short)0, (int)(byte)10, (int)(byte)10, (int)(byte)10, (-1), 0);
    testRational0.mysimp((int)'4', (int)' ', (int)(short)(-1), (int)(short)100, (int)'4', (int)(short)1);
    testRational0.mysimp((int)(short)100, (int)'4', (int)(short)1, (int)' ', (int)'#', (int)(byte)100);
    testRational0.mysimp((int)(byte)100, (int)(short)0, (int)(byte)(-1), (int)(short)1, (int)(short)(-1), (int)(short)10);
    testRational0.mysimp((int)(byte)100, (int)(byte)1, (-1), (int)(short)(-1), (int)'#', (int)(byte)(-1));
    testRational0.mysimp(10, 0, (-1), (-1), (int)(byte)0, (int)(short)0);
    testRational0.mysimp((int)(byte)1, (int)(short)0, (int)'#', (int)'#', 10, (int)'#');
    testRational0.mysimp(100, 0, (int)(byte)(-1), (int)(byte)10, (int)(byte)10, (int)(byte)0);

  }

  @Test
  public void test323() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test323"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)'a', (int)(byte)1, (int)(short)100, (int)(byte)1, (int)(short)0, (int)(short)(-1));
    testRational0.mysimp((-1), 1, (int)(byte)0, (-1), 1, (int)'a');
    testRational0.mysimp((int)(short)100, (int)(short)1, 0, 100, (int)(byte)10, 10);
    testRational0.mysimp((int)'a', 0, (int)(byte)0, (int)(short)100, (int)(short)(-1), (int)(short)0);
    testRational0.mysimp((int)(short)100, 1, (int)' ', (int)'a', (int)(short)10, (int)'4');
    testRational0.mysimp(0, 10, 10, 1, 1, (int)(short)10);

  }

  @Test
  public void test324() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test324"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)1, 1, (int)(short)1, 0);
    testRational0.mysimp((int)(byte)100, (int)(byte)100, (int)(short)1, (int)(short)10, (int)(short)1, (int)(short)0);
    testRational0.mysimp((int)'a', (int)(short)0, (int)(byte)1, (int)(byte)10, (int)(byte)100, 0);
    testRational0.mysimp((int)(byte)100, 1, (int)(short)1, (int)'4', (int)(byte)100, (int)(short)100);
    testRational0.mysimp(0, 0, (int)'4', (int)(short)10, (int)'4', (-1));
    testRational0.mysimp(0, (int)(byte)0, (int)(byte)(-1), 0, 0, (int)(byte)1);
    testRational0.mysimp((int)(byte)1, 100, 10, 0, (int)(short)0, (-1));
    testRational0.mysimp((-1), 1, (int)'4', (-1), (int)(byte)0, (int)(short)(-1));
    testRational0.mysimp((int)'4', (int)(short)(-1), (int)(byte)(-1), (int)'#', 100, 10);
    testRational0.mysimp((int)(byte)100, (int)'4', 0, (int)(short)(-1), (int)'a', (int)' ');

  }

  @Test
  public void test325() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test325"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, 100, 100);
    testRational0.mysimp(0, (int)'4', (int)' ', (int)(byte)100, (int)(byte)1, (int)(short)100);
    testRational0.mysimp((int)(short)100, (int)(byte)0, (int)(short)100, (int)' ', 0, (-1));
    testRational0.mysimp((int)' ', (int)(byte)(-1), (int)'4', (int)(byte)(-1), (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)100, 1, 0, 1, (int)'#', (int)(byte)0);
    testRational0.mysimp((int)(byte)10, (int)(byte)0, (int)(byte)(-1), 0, 10, (int)'a');
    testRational0.mysimp((int)(byte)100, (int)(short)100, (int)(short)10, (int)'4', (int)(short)0, (int)' ');
    testRational0.mysimp((int)(byte)100, (int)(short)0, 0, (int)'#', (int)(short)(-1), (int)(short)(-1));

  }

  @Test
  public void test326() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test326"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(byte)100, (int)(byte)1, (int)(byte)(-1), 1, (int)(byte)0, 10);
    testRational0.mysimp((int)(byte)(-1), (int)' ', (int)(byte)10, (int)(byte)0, (int)(short)100, (int)' ');
    testRational0.mysimp((int)(byte)10, (int)(short)100, 10, (int)'4', (int)'4', (int)'a');
    testRational0.mysimp((int)(byte)0, (int)(byte)10, 100, (int)(short)10, (int)(short)1, (int)(short)10);
    testRational0.mysimp(0, 100, (int)(byte)1, (int)'a', (int)(byte)(-1), 1);
    testRational0.mysimp(0, (int)(short)10, (int)(short)10, (int)'a', 10, (int)(byte)0);
    testRational0.mysimp((int)(short)1, (int)' ', (int)'#', (int)'a', 0, (int)(byte)1);
    testRational0.mysimp((int)(byte)10, 10, (int)(short)(-1), (int)(short)100, (int)'4', (int)'#');
    testRational0.mysimp((int)'a', (int)' ', (int)(short)100, (int)(short)100, (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp(0, 100, (int)(byte)0, (int)(byte)0, (int)(short)1, (-1));

  }

  @Test
  public void test327() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test327"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp(100, (int)(byte)100, (int)(byte)10, (int)(short)0, (int)(byte)1, 0);
    testRational0.mysimp((int)'a', (int)(short)1, (int)(short)(-1), (int)(short)(-1), (int)(short)100, (int)'4');
    testRational0.mysimp((int)'a', 100, (int)'a', (int)(short)(-1), (int)(short)1, (int)(short)0);
    testRational0.mysimp((int)(byte)100, (int)(byte)(-1), 1, 0, (int)(byte)(-1), (-1));

  }

  @Test
  public void test328() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test328"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)(short)100, (int)(byte)1, (int)(byte)0, 100, (int)(short)100);
    testRational0.mysimp((int)(short)(-1), 0, (int)(short)0, 10, 0, (int)(byte)10);
    testRational0.mysimp(0, (int)'#', 100, (int)' ', (int)(short)0, (int)(byte)1);
    testRational0.mysimp((int)'#', (int)(byte)1, (int)(short)100, (int)(byte)10, (int)'4', 0);
    testRational0.mysimp((int)'a', 100, 100, (int)(short)1, 1, (int)(short)100);
    testRational0.mysimp((int)'4', 0, (int)(short)0, (int)' ', (int)(short)(-1), 0);
    testRational0.mysimp(0, (int)'4', (int)(short)0, (int)(byte)10, (int)(byte)1, (int)(short)1);

  }

  @Test
  public void test329() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test329"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)1, 1, (int)(short)1, 0);
    testRational0.mysimp((int)(byte)100, (int)(byte)100, (int)(short)1, (int)(short)10, (int)(short)1, (int)(short)0);
    testRational0.mysimp((int)(short)0, (int)(short)100, 100, 0, (int)(short)(-1), (int)(short)10);
    testRational0.mysimp(0, 100, (int)(short)(-1), 100, (int)'#', (int)'a');
    testRational0.mysimp((int)(byte)100, (int)'a', 100, 1, (int)(byte)1, (int)(byte)100);
    testRational0.mysimp(0, (int)(short)(-1), (int)(short)(-1), (int)'a', (-1), (int)(byte)0);
    testRational0.mysimp((int)'a', (int)(byte)10, 0, (int)(byte)(-1), (int)(short)1, (int)(byte)100);
    testRational0.mysimp((int)(byte)10, (int)(short)100, 1, (int)(byte)1, 10, (-1));
    testRational0.mysimp((int)' ', 1, (int)(short)100, (int)(byte)1, (int)(short)(-1), 0);

  }

  @Test
  public void test330() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test330"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(10, (int)(short)100, (int)' ', (int)(byte)1, (int)(short)(-1), 0);
    testRational0.mysimp((int)(byte)100, (int)(short)(-1), (int)(byte)10, (int)(byte)100, (-1), 100);
    testRational0.mysimp((int)(short)10, (int)(byte)(-1), (int)(byte)0, (int)'#', (int)' ', (int)(byte)10);
    testRational0.mysimp((int)'#', (int)(short)10, (int)(short)0, (int)'a', (int)(short)0, (int)(short)1);
    testRational0.mysimp((int)(byte)0, (int)(byte)1, 1, (int)(short)100, (int)(short)100, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)'#', (int)(short)100, (int)(byte)100, (int)'#', (int)(byte)0);
    testRational0.mysimp((int)(short)10, (int)'4', (-1), (int)(byte)1, (int)'4', (int)(byte)1);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)(short)10, (int)(byte)100, (int)'a', (int)(short)0);
    testRational0.mysimp((int)'a', (int)(short)10, (int)(byte)0, (int)'a', 1, (int)(byte)0);
    testRational0.mysimp(100, (int)(byte)10, 0, (int)'4', 10, (int)(byte)0);

  }

  @Test
  public void test331() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test331"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)1, (int)(short)10, 0, 1, (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp((int)'#', 10, 0, (int)(byte)(-1), (int)(short)0, 10);
    testRational0.mysimp((int)(short)10, (int)(byte)0, (int)(short)(-1), (int)'a', (int)'4', (int)(byte)10);
    testRational0.mysimp((int)'a', (int)(short)10, (int)(byte)100, (int)' ', (int)(short)10, 1);
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, (int)(short)100, (int)'#', (int)'a', (int)' ');
    testRational0.mysimp(1, (int)'4', (-1), 100, 0, (int)'a');
    testRational0.mysimp((int)(short)100, (-1), (int)(byte)100, (int)(byte)10, (int)(byte)100, 1);
    testRational0.mysimp((int)'a', (int)' ', (int)(byte)100, 1, (int)(short)1, 0);

  }

  @Test
  public void test332() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test332"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 0, (-1), 100, (int)'a');
    testRational0.mysimp((int)' ', (int)(short)100, (int)(short)10, (-1), (int)'a', (int)(byte)0);
    testRational0.mysimp((int)(short)0, 100, (-1), (int)(byte)10, (int)(byte)100, (int)(short)1);
    testRational0.mysimp((int)(short)1, (int)(byte)(-1), (int)'4', (int)'4', 100, (int)(short)(-1));
    testRational0.mysimp((-1), 100, (int)(byte)(-1), (int)' ', (int)(byte)10, (int)(short)100);
    testRational0.mysimp((int)(short)0, 1, (int)(short)(-1), (int)(short)10, (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp((int)(short)100, 100, (int)(byte)100, (int)(byte)10, 0, (int)'a');
    testRational0.mysimp((-1), (int)' ', (int)'#', (int)(byte)1, (int)(byte)1, 0);
    testRational0.mysimp(10, (int)(short)0, 0, 100, 100, (int)(short)0);
    testRational0.mysimp((int)(short)100, (int)(short)0, (int)'a', 100, (int)(byte)10, (int)(short)1);

  }

  @Test
  public void test333() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test333"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(byte)(-1), (int)(short)(-1), (int)(short)10, 0, (int)(byte)100, 1);
    testRational0.mysimp((int)(byte)100, (int)(short)10, 10, 10, 100, 1);
    testRational0.mysimp(100, (int)(byte)100, 0, (int)'#', (int)'4', (int)(byte)10);
    testRational0.mysimp((int)(short)100, (int)(byte)1, 1, 0, 10, (int)(byte)1);
    testRational0.mysimp(0, (int)(byte)1, (int)'4', (int)(byte)(-1), (int)(short)10, (int)(short)1);

  }

  @Test
  public void test334() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test334"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(10, (int)(byte)100, (int)(byte)10, (int)(short)0, (int)(byte)0, (int)' ');
    testRational0.mysimp((int)(short)10, (int)(byte)10, (int)(short)100, (int)(byte)0, (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp((int)(short)(-1), (int)'#', (int)'#', (int)(short)10, (int)(byte)0, (int)(byte)100);
    testRational0.mysimp(100, 10, 10, (int)(short)10, (int)(short)10, (int)(byte)100);
    testRational0.mysimp((int)(short)1, (int)'4', 100, (-1), 1, 1);
    testRational0.mysimp((int)'a', (int)' ', (int)(short)0, 0, (int)(byte)10, 0);

  }

  @Test
  public void test335() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test335"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, 100, 100);
    testRational0.mysimp((int)(byte)(-1), (int)'a', (-1), (int)'4', (-1), (int)(byte)0);
    testRational0.mysimp((int)' ', 0, (int)'#', (int)(short)100, (int)(short)0, 100);
    testRational0.mysimp(1, 1, 1, (int)' ', (int)'4', (int)'#');
    testRational0.mysimp((int)(byte)0, (int)(byte)1, (int)'4', (int)(byte)10, (int)(byte)10, 0);

  }

  @Test
  public void test336() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test336"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'a', (int)(byte)0, 0, (int)(short)0, 0);
    testRational0.mysimp((int)(short)10, (int)(byte)0, (int)'a', (int)(byte)0, (int)(byte)0, (int)(byte)(-1));
    testRational0.mysimp((int)(short)1, 0, (int)(byte)(-1), (int)(short)1, 10, (int)(short)(-1));
    testRational0.mysimp((int)(short)10, (int)(short)1, (int)'a', (int)(byte)10, (int)(short)1, 1);
    testRational0.mysimp((-1), 0, (int)(short)100, (int)(byte)(-1), 10, (-1));
    testRational0.mysimp((int)(byte)100, 0, 0, 0, 0, 0);
    testRational0.mysimp((int)' ', (-1), (int)(byte)100, (int)'4', (int)(byte)10, (int)'#');
    testRational0.mysimp((int)(byte)100, (int)(short)10, (int)(byte)1, 0, (int)(short)10, (int)(byte)10);

  }

  @Test
  public void test337() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test337"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)'a', 100, 1, (int)(short)1, 0, 10);
    testRational0.mysimp((int)(short)100, 100, 0, 1, (int)(short)(-1), (int)(byte)10);
    testRational0.mysimp(0, (int)'a', (int)(short)1, 0, (int)'#', (int)(short)10);
    testRational0.mysimp((int)(byte)0, (int)(short)1, 100, (int)(byte)0, (int)'#', 0);
    testRational0.mysimp(10, 0, 0, (int)(byte)1, (int)(byte)10, (int)(byte)1);
    testRational0.mysimp(100, (int)(short)1, (int)(byte)1, (int)(byte)10, 0, (int)(short)1);

  }

  @Test
  public void test338() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test338"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)1, 1, (int)(short)1, 0);
    testRational0.mysimp((int)(byte)100, (int)(byte)100, (int)(short)1, (int)(short)10, (int)(short)1, (int)(short)0);
    testRational0.mysimp((int)(short)0, (int)(short)100, 100, 0, (int)(short)(-1), (int)(short)10);
    testRational0.mysimp(0, 100, (int)(short)(-1), 100, (int)'#', (int)'a');
    testRational0.mysimp((int)(byte)(-1), 0, (int)(short)(-1), (int)'a', (int)(short)(-1), (int)(byte)10);
    testRational0.mysimp((int)(short)(-1), 100, (int)(byte)1, (int)'a', (int)(short)10, (int)' ');
    testRational0.mysimp((int)(short)10, (int)'#', (int)'4', (int)(short)1, (int)(short)0, (int)(short)(-1));
    testRational0.mysimp((int)' ', (int)'4', (int)(byte)100, 10, (int)(short)0, (int)'a');

  }

  @Test
  public void test339() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test339"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'a', (int)(byte)0, 0, (int)(short)0, 0);
    testRational0.mysimp((int)(short)10, (int)(byte)0, (int)'a', (int)(byte)0, (int)(byte)0, (int)(byte)(-1));
    testRational0.mysimp((int)(byte)0, 0, (int)(short)10, (int)(short)1, (int)(short)1, (int)(short)(-1));
    testRational0.mysimp((int)(short)0, (int)' ', 10, (int)'#', (int)'a', (int)(byte)100);
    testRational0.mysimp(100, (int)(short)0, (int)(byte)1, (int)(byte)(-1), 1, 1);
    testRational0.mysimp(10, (int)'#', (int)(short)1, (int)(short)10, (int)(byte)0, (int)'#');

  }

  @Test
  public void test340() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test340"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'#', 1, (int)(short)10, (int)'4', (int)(short)1);
    testRational0.mysimp((int)'#', (int)(byte)10, 10, 10, (-1), (int)(short)10);
    testRational0.mysimp((int)(byte)1, 0, (int)(byte)100, (int)'a', (int)(short)0, (int)(byte)1);
    testRational0.mysimp((int)' ', (int)' ', 100, (int)'4', (int)(byte)100, 0);
    testRational0.mysimp((-1), (-1), (int)(byte)0, 0, (int)(byte)10, (int)(short)(-1));
    testRational0.mysimp((int)(short)1, (int)(short)0, (int)(short)10, (-1), (int)'a', (int)'4');
    testRational0.mysimp((int)(byte)(-1), (int)(short)(-1), (-1), (int)(byte)0, (int)(byte)10, (int)'#');

  }

  @Test
  public void test341() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test341"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, 100, 100);
    testRational0.mysimp((int)(byte)(-1), (int)'a', (-1), (int)'4', (-1), (int)(byte)0);
    testRational0.mysimp((int)' ', 0, (int)'#', (int)(short)100, (int)(short)0, 100);
    testRational0.mysimp((int)'a', (int)(short)1, 1, (int)'4', (int)'4', 10);
    testRational0.mysimp((-1), 0, (int)'4', (-1), (int)(byte)0, (int)(short)1);
    testRational0.mysimp(10, 0, (int)(byte)100, (int)(byte)10, (int)(short)1, (int)'#');
    testRational0.mysimp((int)'a', (int)'4', 1, (int)' ', (int)(short)1, (int)'a');
    testRational0.mysimp((int)(byte)10, (int)(byte)1, (int)'a', (int)'#', (int)'#', (int)(byte)100);
    testRational0.mysimp((int)(byte)(-1), (int)(short)(-1), (int)(byte)1, (int)(byte)(-1), (int)(short)10, (int)(short)10);
    testRational0.mysimp((int)(short)1, 10, 1, (int)(byte)(-1), (int)(short)1, (int)'a');
    testRational0.mysimp(10, (int)(short)100, 0, (int)(short)1, (int)(short)(-1), (int)'a');

  }

  @Test
  public void test342() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test342"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp((int)'4', (int)(short)100, 100, 0, (int)(byte)100, 0);
    testRational0.mysimp(100, (int)' ', 100, (int)(short)100, 0, (int)(short)10);
    testRational0.mysimp((int)(short)(-1), 100, 1, (int)(byte)1, (int)(short)100, (int)(byte)(-1));
    testRational0.mysimp(1, (int)(byte)100, (int)(short)100, (int)(byte)10, 100, (int)(short)1);
    testRational0.mysimp((int)(short)0, 1, (int)(byte)1, 100, (int)' ', (int)'4');

  }

  @Test
  public void test343() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test343"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'#', 1, (int)(short)10, (int)'4', (int)(short)1);
    testRational0.mysimp((-1), (int)(short)10, (int)(byte)1, (int)(short)10, (int)(byte)(-1), 0);
    testRational0.mysimp(1, (int)' ', (int)(short)100, (int)(short)100, (int)(byte)(-1), (int)(short)(-1));
    testRational0.mysimp((-1), 100, (int)'a', (int)(short)10, 0, (int)(byte)(-1));
    testRational0.mysimp((int)(byte)0, 100, (int)(byte)1, (int)'#', (int)(byte)100, (int)(short)0);
    testRational0.mysimp((int)(byte)0, (int)(byte)100, (int)(short)0, (int)(byte)1, (int)(short)0, 1);
    testRational0.mysimp((int)'4', (int)(byte)10, 0, 100, (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, 10, (int)(short)0, (int)' ', (int)(byte)0, (int)' ');

  }

  @Test
  public void test344() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test344"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)1, (int)(short)10, 0, 1, (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp((int)'#', 10, 0, (int)(byte)(-1), (int)(short)0, 10);
    testRational0.mysimp((int)'a', (int)' ', (int)'#', 10, (int)(short)100, (int)(short)10);
    testRational0.mysimp(0, (int)(byte)1, (int)(short)10, (-1), 10, (int)(byte)1);

  }

  @Test
  public void test345() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test345"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(10, (int)(short)100, (int)(short)10, (int)(short)100, (int)(byte)10, 0);
    testRational0.mysimp(10, (int)'4', (int)(byte)0, (int)(byte)(-1), 0, 1);
    testRational0.mysimp((int)(short)(-1), (int)(short)(-1), 0, 100, (int)(byte)100, (int)(short)10);
    testRational0.mysimp((int)' ', (int)' ', 10, (int)(byte)0, (int)(short)0, (-1));
    testRational0.mysimp((int)'a', (int)(byte)1, (int)(short)10, (int)'a', (int)(byte)(-1), (int)(short)10);
    testRational0.mysimp((int)(short)(-1), 1, (int)'a', 100, (int)(short)100, (int)(short)100);
    testRational0.mysimp((int)(short)0, (int)(short)100, 1, (int)(short)100, (-1), (int)(byte)0);

  }

  @Test
  public void test346() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test346"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)1, 1, (int)(short)1, 0);
    testRational0.mysimp((int)(byte)100, (int)(byte)100, (int)(short)1, (int)(short)10, (int)(short)1, (int)(short)0);
    testRational0.mysimp((int)'a', (int)(short)0, (int)(byte)1, (int)(byte)10, (int)(byte)100, 0);
    testRational0.mysimp((int)(byte)100, 1, (int)(short)1, (int)'4', (int)(byte)100, (int)(short)100);
    testRational0.mysimp(0, 0, (-1), (int)(short)100, (int)(byte)1, (-1));
    testRational0.mysimp(10, 1, 0, (int)(short)10, (int)' ', 10);
    testRational0.mysimp((int)(byte)100, (int)(byte)100, 0, (int)'#', 1, 0);

  }

  @Test
  public void test347() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test347"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)'a', (int)(byte)1, (int)(short)100, (int)(byte)1, (int)(short)0, (int)(short)(-1));
    testRational0.mysimp((-1), 1, (int)(byte)0, (-1), 1, (int)'a');
    testRational0.mysimp((int)'a', (int)(byte)100, 0, (int)(byte)1, 0, 0);
    testRational0.mysimp((int)'#', (-1), 0, (int)(byte)100, (int)(byte)1, (int)(short)10);
    testRational0.mysimp((int)(byte)100, (int)(short)10, (int)(byte)1, 10, 1, 0);

  }

  @Test
  public void test348() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test348"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)1, 1, (int)(short)1, 0);
    testRational0.mysimp((int)(byte)100, (int)(byte)100, (int)(short)1, (int)(short)10, (int)(short)1, (int)(short)0);
    testRational0.mysimp((int)'a', (int)(short)0, (int)(byte)1, (int)(byte)10, (int)(byte)100, 0);
    testRational0.mysimp((int)(byte)100, 1, (int)(short)1, (int)'4', (int)(byte)100, (int)(short)100);
    testRational0.mysimp(0, 0, (int)'4', (int)(short)10, (int)'4', (-1));
    testRational0.mysimp(0, (int)(byte)0, (int)(byte)(-1), 0, 0, (int)(byte)1);
    testRational0.mysimp((int)(byte)1, 100, 10, 0, (int)(short)0, (-1));
    testRational0.mysimp(100, 0, 1, (-1), (int)(byte)100, 10);
    testRational0.mysimp((int)' ', 100, (int)(short)100, (int)' ', (int)(short)100, 100);

  }

  @Test
  public void test349() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test349"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)(short)1, (int)(byte)10, (int)(byte)100, 1, (int)(byte)10, (int)(byte)(-1));
    testRational0.mysimp(0, (int)(short)(-1), (int)(short)0, (int)(byte)0, (int)' ', 1);
    testRational0.mysimp((int)(byte)100, (int)(short)0, (int)'a', (int)(short)0, (int)(short)1, (int)' ');
    testRational0.mysimp((int)(byte)(-1), (int)(short)10, (int)'#', (int)(short)10, (int)' ', (int)'a');
    testRational0.mysimp(10, (int)(short)10, (int)(byte)10, (int)(short)(-1), 1, (int)(byte)1);
    testRational0.mysimp((int)(byte)0, (int)(byte)1, (int)(byte)100, (int)(short)0, (int)(byte)100, (int)' ');
    testRational0.mysimp((int)(byte)10, (int)'#', (int)'#', (int)'4', 100, 0);
    testRational0.mysimp((int)'a', 0, (int)(short)0, 0, (int)' ', (int)(short)(-1));

  }

  @Test
  public void test350() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test350"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)(byte)100, (int)' ', 10, (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp((int)' ', 1, 1, (int)'a', 0, (int)'#');
    testRational0.mysimp((int)(short)0, (int)'4', 0, (int)'#', (int)'4', (int)' ');
    testRational0.mysimp((int)(byte)1, (int)(byte)0, (int)(byte)1, (int)(byte)10, (int)'#', 0);
    testRational0.mysimp((int)(byte)1, (int)(byte)0, (int)(short)1, (int)(short)1, (int)(byte)0, 0);
    testRational0.mysimp((int)(short)(-1), (int)'#', 0, (int)(short)10, 0, (int)(byte)1);
    testRational0.mysimp((int)'4', (int)(short)1, (int)' ', (int)'a', (int)(short)100, 0);
    testRational0.mysimp(1, (int)(byte)0, (int)'4', (int)(byte)1, (-1), (int)(byte)(-1));
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, (int)(short)10, 10, (int)(short)1, (int)(short)(-1));
    testRational0.mysimp(1, (int)(byte)100, (int)(byte)10, 0, 100, (int)' ');

  }

  @Test
  public void test351() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test351"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)1, (int)(short)10, 0, 1, (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp((int)(short)(-1), 100, (int)(short)0, (int)(byte)1, (int)'4', (int)(short)10);
    testRational0.mysimp((int)(short)(-1), (int)(short)(-1), 100, (int)(byte)0, 10, (int)(short)0);
    testRational0.mysimp((-1), (int)(short)10, (int)(byte)1, (int)(byte)100, 1, (int)'4');
    testRational0.mysimp((int)'4', 0, (int)(short)100, (int)(byte)1, (-1), (int)'a');
    testRational0.mysimp(0, (-1), (int)(short)0, (int)(short)(-1), (int)(short)0, 10);
    testRational0.mysimp((int)'4', (int)(byte)(-1), (int)(short)10, (int)'#', (int)(byte)100, 10);
    testRational0.mysimp((int)(short)0, (int)(byte)10, 1, (int)(byte)1, 1, (int)(byte)100);

  }

  @Test
  public void test352() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test352"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)'a', (int)(byte)1, (int)(short)100, (int)(byte)1, (int)(short)0, (int)(short)(-1));
    testRational0.mysimp((-1), 1, (int)(byte)0, (-1), 1, (int)'a');
    testRational0.mysimp((int)(short)0, (int)'4', (int)' ', (int)(byte)(-1), 100, (int)(short)1);
    testRational0.mysimp((int)'a', (int)'#', (int)(short)100, (int)(byte)1, (int)'#', (int)(byte)1);
    testRational0.mysimp((int)'#', 0, (int)(byte)(-1), (int)(byte)10, 100, (int)(byte)0);
    testRational0.mysimp(0, (int)' ', (int)'4', (int)(short)10, (int)(short)0, (int)(short)0);
    testRational0.mysimp((int)'4', (int)(byte)0, (int)(short)1, (int)(byte)10, (int)(short)0, 1);
    testRational0.mysimp((int)(short)10, 10, (int)(byte)10, 100, (int)(byte)0, 0);

  }

  @Test
  public void test353() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test353"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(10, (int)(short)100, (int)(short)10, (int)(short)100, (int)(byte)10, 0);
    testRational0.mysimp(100, 0, 1, (int)(byte)10, (int)(byte)10, (int)' ');
    testRational0.mysimp((int)'#', (int)(short)10, (int)(byte)(-1), (int)'4', (int)'4', 0);
    testRational0.mysimp((int)(byte)100, (-1), (-1), (int)'#', (int)(byte)(-1), (int)(short)1);
    testRational0.mysimp((int)(byte)100, (int)(byte)100, (int)(byte)10, (int)(byte)100, (int)(short)10, (int)(short)1);
    testRational0.mysimp((int)' ', (int)'#', 0, (int)(short)100, (int)(byte)1, 1);

  }

  @Test
  public void test354() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test354"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(byte)100, (int)(byte)1, (int)(byte)(-1), 1, (int)(byte)0, 10);
    testRational0.mysimp((int)(byte)(-1), 10, (-1), (int)(byte)1, (int)(byte)0, 10);
    testRational0.mysimp((int)(byte)100, (int)'#', (int)(byte)1, 10, 1, (int)(byte)0);
    testRational0.mysimp(0, (int)(short)0, (int)'4', 10, (int)(short)0, (int)(short)10);
    testRational0.mysimp(0, 10, (int)(byte)(-1), 1, (int)(byte)10, (int)(short)1);
    testRational0.mysimp((int)(short)0, (int)(short)100, (int)(short)10, (int)(byte)1, 100, 0);
    testRational0.mysimp((int)'4', 100, (int)(short)1, (int)(short)1, (int)'4', (int)(short)10);
    testRational0.mysimp(100, (int)(short)(-1), (-1), (int)(short)1, (int)(byte)0, (int)(byte)10);
    testRational0.mysimp((int)(byte)(-1), (int)(byte)10, (int)(short)0, (int)(short)10, (int)(byte)1, 10);

  }

  @Test
  public void test355() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test355"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)' ', (int)(byte)0, (int)(byte)1, (int)(byte)100, 10, (int)'4');
    testRational0.mysimp((int)(short)10, (int)(short)100, (int)(short)(-1), 1, (int)(byte)100, (-1));
    testRational0.mysimp((int)(byte)0, 0, 0, (int)'a', (int)' ', (int)'a');
    testRational0.mysimp((int)'4', 100, (int)(short)0, (int)(short)0, (int)(short)1, (-1));
    testRational0.mysimp((int)'4', 10, (int)(byte)10, (-1), (int)(byte)(-1), (int)(short)10);
    testRational0.mysimp((int)'#', 100, 0, (int)(byte)(-1), (int)'a', (int)'#');
    testRational0.mysimp((int)(byte)0, (int)(byte)1, (int)(short)(-1), 0, (int)(short)(-1), 0);
    testRational0.mysimp((int)(byte)100, 10, (int)(byte)0, (int)(byte)(-1), (int)' ', (int)'4');
    testRational0.mysimp((int)'a', (int)'#', (int)'4', (int)(short)100, (int)'#', (int)(short)0);
    testRational0.mysimp((int)(short)10, (int)(short)100, (int)'4', 10, (int)(short)100, (int)'a');

  }

  @Test
  public void test356() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test356"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)100, (int)(short)0, (int)'4', (int)(short)100, 0, (int)(byte)(-1));
    testRational0.mysimp(10, (int)(byte)0, (int)(byte)0, (int)(short)(-1), (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp((int)'a', (int)(short)0, 0, 1, 0, (int)' ');
    testRational0.mysimp((-1), (int)'a', 100, 0, (-1), (int)(byte)100);
    testRational0.mysimp(0, 0, (int)(byte)100, (int)'a', 10, (int)'4');

  }

  @Test
  public void test357() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test357"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(0, 1, (-1), 1, (int)(short)10, (int)(short)1);
    testRational0.mysimp((int)(byte)10, (int)(byte)(-1), (-1), 0, (int)(byte)1, (int)(short)10);

  }

  @Test
  public void test358() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test358"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(10, (int)(short)100, (int)' ', (int)(byte)1, (int)(short)(-1), 0);
    testRational0.mysimp((int)(short)10, (int)(byte)10, (int)(byte)10, (int)(short)1, 10, (int)(byte)0);
    testRational0.mysimp((int)'#', (int)(short)10, (int)' ', 1, (int)' ', (int)(byte)10);
    testRational0.mysimp((int)'a', (int)(short)1, (-1), 10, (-1), (int)(short)100);
    testRational0.mysimp((int)'a', (int)'4', (int)(short)1, (int)(short)(-1), (int)'#', (int)'#');
    testRational0.mysimp((int)' ', (int)(byte)10, (int)(byte)0, (int)'#', (int)'4', (int)(short)100);
    testRational0.mysimp((int)(byte)(-1), (int)(byte)10, (-1), (int)(short)1, (int)'#', (int)(short)1);
    testRational0.mysimp((int)'#', 0, (int)'a', (int)(byte)1, (int)(byte)10, 10);
    testRational0.mysimp((int)'a', (int)(short)0, (int)(byte)0, 100, 1, (int)(byte)0);
    testRational0.mysimp((int)(short)10, 1, (int)(byte)0, (int)(byte)0, (-1), (int)' ');

  }

  @Test
  public void test359() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test359"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)'a', (int)(short)100, (int)(short)10, 0, 100, (int)(short)1);
    testRational0.mysimp(100, (int)(short)1, (int)' ', (int)(byte)10, (int)(short)1, (int)(byte)0);
    testRational0.mysimp((int)'#', (int)'#', (int)'4', (int)(short)(-1), (int)'4', (int)(byte)1);
    testRational0.mysimp(0, 1, (int)' ', (int)'4', (int)(short)(-1), 1);
    testRational0.mysimp((int)'4', (-1), (int)(byte)(-1), (int)(short)0, (int)(short)(-1), 0);
    testRational0.mysimp((int)(byte)0, (int)(short)100, (int)'4', (-1), (int)(short)10, (int)(short)100);
    testRational0.mysimp((-1), 10, (int)(byte)100, (int)(short)(-1), (int)(short)100, 1);
    testRational0.mysimp((int)(short)100, (int)(short)100, 0, (int)(short)(-1), (int)'4', 0);
    testRational0.mysimp((int)(byte)1, (int)(byte)10, (int)(byte)100, 0, (int)' ', (int)(short)1);
    testRational0.mysimp((int)(byte)1, (-1), (int)(short)10, (int)'4', (int)(byte)10, 10);

  }

  @Test
  public void test360() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test360"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 0, (-1), 100, (int)'a');
    testRational0.mysimp(10, (int)(short)0, 100, (int)'4', (-1), 0);
    testRational0.mysimp(0, (int)(byte)(-1), 100, (int)(short)1, (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp((int)(byte)0, (int)'4', 100, (int)(byte)1, (int)(byte)10, 0);
    testRational0.mysimp((int)(byte)0, 0, (int)(short)(-1), (int)'#', (int)(byte)0, (int)(short)1);
    testRational0.mysimp((int)(byte)0, 10, (int)'4', (int)(short)(-1), 1, (int)(byte)(-1));
    testRational0.mysimp((int)(short)100, (int)'a', 0, 10, 0, (int)(short)1);
    testRational0.mysimp(0, (int)(short)0, 0, 0, (int)(short)(-1), 1);
    testRational0.mysimp((int)(short)100, (int)(short)(-1), (int)(byte)0, 0, 0, (int)(short)0);
    testRational0.mysimp((int)'#', (int)(byte)10, (int)'4', (int)(short)10, 0, (int)(short)(-1));
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)100, (int)'a', (int)(byte)1, (int)(byte)100);
    testRational0.mysimp((int)(byte)0, (int)'4', (int)'4', 0, (int)(byte)10, (int)(short)1);

  }

  @Test
  public void test361() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test361"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)' ', 10, (int)' ', (int)(short)0, 0, (int)(short)1);
    testRational0.mysimp((int)(short)1, 1, (int)' ', (int)(byte)10, (int)(short)(-1), 0);
    testRational0.mysimp((int)(short)1, (int)(byte)10, (int)'4', (int)(short)10, (int)(byte)0, 0);
    testRational0.mysimp((-1), (int)'#', (int)(byte)(-1), (-1), (int)(short)10, 1);
    testRational0.mysimp(1, (-1), (int)'4', (-1), (int)'#', (int)(short)0);
    testRational0.mysimp(100, 100, (int)'#', (int)(short)(-1), (int)(short)100, (int)'4');
    testRational0.mysimp((int)'4', (int)' ', (int)'#', (int)(byte)10, (int)(byte)0, (int)(byte)1);
    testRational0.mysimp((int)(short)100, 1, (int)(byte)100, (int)(byte)1, (int)(byte)100, (int)(short)0);
    testRational0.mysimp((int)(short)1, (int)(short)10, 0, (int)(short)(-1), 0, (int)(short)1);

  }

  @Test
  public void test362() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test362"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)(short)(-1), 100, (int)(byte)10, (int)'4', (int)(short)(-1));
    testRational0.mysimp((int)' ', 1, (int)(byte)(-1), (int)(short)1, 10, (int)(byte)0);
    testRational0.mysimp((int)(byte)10, (int)(byte)1, (int)(byte)100, (int)(short)10, (int)(byte)1, (int)'4');
    testRational0.mysimp((int)(short)0, (int)(short)100, (int)'#', 0, (int)(byte)(-1), (int)'a');

  }

  @Test
  public void test363() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test363"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(10, (int)(byte)100, (int)(byte)10, (int)(short)0, (int)(byte)0, (int)' ');
    testRational0.mysimp((int)(short)10, (int)(byte)10, (int)(short)100, (int)(byte)0, (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp((int)'4', (int)(byte)1, (int)(byte)0, (int)'4', (int)(short)1, 0);
    testRational0.mysimp((int)'#', (int)(byte)100, (int)(byte)(-1), 10, (int)(short)100, (int)(byte)(-1));
    testRational0.mysimp(10, (int)(byte)1, (-1), 0, (int)(byte)1, 100);
    testRational0.mysimp((int)'4', (-1), (int)(short)(-1), (int)(short)(-1), 1, 0);
    testRational0.mysimp((int)(short)10, (int)(short)100, 0, (int)'#', (int)(short)10, 0);
    testRational0.mysimp((int)' ', (int)(byte)1, (int)'#', (int)'#', 0, (int)(byte)1);
    testRational0.mysimp((int)(byte)1, (int)'4', (int)(short)10, (int)'4', 100, 10);
    testRational0.mysimp(0, (int)(byte)100, 0, (int)(short)100, (int)(short)10, 1);
    testRational0.mysimp(10, (int)(byte)10, (int)(short)100, (int)(byte)(-1), (int)(byte)(-1), (int)'a');

  }

  @Test
  public void test364() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test364"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(10, (int)(short)100, (int)' ', (int)(byte)1, (int)(short)(-1), 0);
    testRational0.mysimp((int)(short)100, 10, (int)'a', 10, (int)(byte)1, (int)' ');
    testRational0.mysimp((int)'4', (int)(short)10, (int)(byte)0, (int)(byte)1, (int)'#', (int)(byte)(-1));
    testRational0.mysimp((int)(short)(-1), 0, (-1), (int)(byte)0, (int)(short)(-1), (int)(short)1);
    testRational0.mysimp(0, (int)(short)0, 0, 0, (int)(byte)0, (int)(byte)100);
    testRational0.mysimp((int)(short)0, (int)'4', (int)(short)(-1), (int)'#', (int)(byte)0, 0);
    testRational0.mysimp((-1), (int)(byte)100, (int)' ', (int)(byte)100, (int)'a', (int)' ');
    testRational0.mysimp((int)(short)0, (int)(short)(-1), 0, 0, (int)(short)10, (int)(short)1);
    testRational0.mysimp((int)'4', (int)(byte)1, (int)'#', (int)(byte)1, (int)'4', 0);

  }

  @Test
  public void test365() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test365"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)(byte)100, (int)' ', 10, (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp((int)' ', 1, 1, (int)'a', 0, (int)'#');
    testRational0.mysimp((int)(byte)0, (int)' ', (int)(short)1, (int)(short)(-1), (int)(byte)0, 0);
    testRational0.mysimp((int)(byte)100, (int)'a', 0, (int)(short)10, 0, 0);
    testRational0.mysimp((int)(byte)0, (int)'a', (int)'4', (int)(short)(-1), (-1), (int)(byte)10);
    testRational0.mysimp(0, 1, (int)(short)1, 10, 0, (int)'a');
    testRational0.mysimp(100, (int)' ', (int)'a', 0, (-1), 1);
    testRational0.mysimp((-1), 100, (int)(byte)1, (int)'#', (int)(short)100, 0);
    testRational0.mysimp((int)' ', (int)(short)1, (int)(byte)0, 0, (int)(byte)0, (int)(short)10);
    testRational0.mysimp((int)(short)100, (int)'4', 1, (-1), (int)'a', 10);

  }

  @Test
  public void test366() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test366"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(byte)100, (int)(byte)1, (int)(byte)(-1), 1, (int)(byte)0, 10);
    testRational0.mysimp(0, (int)'#', (int)(short)0, (int)'#', 100, (int)(short)100);
    testRational0.mysimp((int)'#', (int)(short)(-1), 0, (int)'a', (int)(byte)100, (-1));
    testRational0.mysimp((int)'4', 1, 100, (int)'4', 0, (int)(short)10);
    testRational0.mysimp((int)(byte)(-1), (int)' ', (-1), (int)(short)0, (int)'4', (int)'4');
    testRational0.mysimp(0, 100, (int)(short)10, 0, (int)(short)100, (int)(byte)100);
    testRational0.mysimp((int)(short)10, 10, (int)'4', (int)(byte)10, 10, (int)(short)(-1));
    testRational0.mysimp((int)'a', (int)(short)100, (int)(byte)1, (int)(short)0, (int)(byte)100, 1);

  }

  @Test
  public void test367() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test367"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)(byte)100, (int)' ', 10, (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp((int)' ', 1, 1, (int)'a', 0, (int)'#');
    testRational0.mysimp((int)(short)0, (int)'4', 0, (int)'#', (int)'4', (int)' ');
    testRational0.mysimp((int)(byte)1, (int)(byte)10, 0, (int)(short)(-1), (int)(short)10, 100);
    testRational0.mysimp((-1), 1, 0, (int)(byte)1, 0, (int)(short)(-1));
    testRational0.mysimp((-1), (int)(byte)0, (int)(short)1, (-1), (int)'a', (int)(byte)0);

  }

  @Test
  public void test368() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test368"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)'a', (int)(byte)1, (int)(short)100, (int)(byte)1, (int)(short)0, (int)(short)(-1));
    testRational0.mysimp((-1), 1, (int)(byte)0, (-1), 1, (int)'a');
    testRational0.mysimp((int)(short)100, (int)(short)1, 0, 100, (int)(byte)10, 10);
    testRational0.mysimp((int)'4', 10, (int)(byte)10, (int)(byte)1, (int)(short)(-1), (int)(short)10);

  }

  @Test
  public void test369() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test369"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)(byte)100, (int)' ', 10, (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp((int)(short)0, (int)' ', (int)'a', (int)(short)10, (int)(short)(-1), (int)(short)100);
    testRational0.mysimp((int)(byte)0, (int)'a', 0, 100, (int)(short)(-1), (int)(short)0);
    testRational0.mysimp((-1), (int)'4', 0, 0, 100, (int)'a');
    testRational0.mysimp((int)(byte)(-1), 100, (-1), 0, 0, (int)(short)1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)1, (int)(byte)1, (int)(byte)100, 0);

  }

  @Test
  public void test370() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test370"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)1, 1, (int)(short)1, 0);
    testRational0.mysimp((int)(byte)100, (int)(byte)100, (int)(short)1, (int)(short)10, (int)(short)1, (int)(short)0);
    testRational0.mysimp((int)(short)0, (int)(short)100, 100, 0, (int)(short)(-1), (int)(short)10);
    testRational0.mysimp(0, 100, (int)(short)(-1), 100, (int)'#', (int)'a');
    testRational0.mysimp((int)(byte)(-1), 0, (int)(short)(-1), (int)'a', (int)(short)(-1), (int)(byte)10);
    testRational0.mysimp((int)(short)(-1), 100, (int)(byte)1, (int)'a', (int)(short)10, (int)' ');
    testRational0.mysimp(100, (int)'#', (int)(short)10, 0, (int)(byte)100, 0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)(byte)1, (int)(byte)100, 1, 0);
    testRational0.mysimp((int)'4', 0, (int)(byte)10, 1, (int)(byte)1, (int)(byte)1);
    testRational0.mysimp((int)(short)100, 0, 1, (int)(short)10, 0, 0);
    testRational0.mysimp((int)(byte)0, (int)(short)0, 0, (int)(byte)100, 100, (int)'4');

  }

  @Test
  public void test371() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test371"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(100, (int)(short)1, 0, (int)(byte)(-1), (int)(byte)1, 0);
    testRational0.mysimp((int)'4', (int)(byte)0, 10, (int)(short)10, (int)(byte)10, (int)(byte)(-1));
    testRational0.mysimp((int)(short)0, (int)'4', (int)' ', (int)(short)100, (int)(short)1, 0);
    testRational0.mysimp((int)' ', 1, (int)'#', (int)(byte)1, 100, (int)(byte)100);
    testRational0.mysimp((int)(short)1, 0, (int)(short)1, (int)(short)0, (int)(short)10, (int)(byte)100);

  }

  @Test
  public void test372() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test372"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp((int)(short)(-1), (int)(short)10, (int)(short)10, 0, (int)'4', (int)(byte)1);
    testRational0.mysimp((-1), (int)' ', (int)'a', (int)'4', (int)(short)0, (-1));
    testRational0.mysimp((int)(short)1, 0, (int)' ', (int)'#', (int)'#', 10);
    testRational0.mysimp((int)(byte)10, (int)' ', (int)(short)(-1), (int)(short)10, (int)'#', (int)' ');
    testRational0.mysimp((int)'4', (int)(short)10, (int)(short)100, 1, (int)(short)(-1), (int)(short)1);

  }

  @Test
  public void test373() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test373"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, 100, 100);
    testRational0.mysimp((int)(byte)(-1), (int)'a', (-1), (int)'4', (-1), (int)(byte)0);
    testRational0.mysimp((int)' ', 0, (int)'#', (int)(short)100, (int)(short)0, 100);
    testRational0.mysimp(0, (int)(byte)1, 0, (int)(byte)10, (-1), 100);
    testRational0.mysimp(100, (int)(short)(-1), 0, (int)' ', (int)(byte)0, (int)'#');

  }

  @Test
  public void test374() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test374"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp((int)(short)(-1), (int)(short)10, (int)(short)10, 0, (int)'4', (int)(byte)1);
    testRational0.mysimp((-1), (int)' ', (int)'a', (int)'4', (int)(short)0, (-1));
    testRational0.mysimp((int)(short)100, (int)'4', (int)(short)100, 1, (int)(byte)100, (int)(byte)10);
    testRational0.mysimp((int)(byte)1, 0, (int)(short)1, (int)(short)(-1), (int)'4', (int)(byte)100);
    testRational0.mysimp((int)(byte)0, (int)'a', (int)(short)(-1), 1, (int)(short)(-1), (int)' ');

  }

  @Test
  public void test375() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test375"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)' ', (int)(byte)0, (int)(byte)1, (int)(byte)100, 10, (int)'4');
    testRational0.mysimp(100, 10, 0, (-1), 0, (int)(byte)1);
    testRational0.mysimp(100, 0, (int)(short)100, (int)(short)1, (int)(byte)(-1), (int)'#');

  }

  @Test
  public void test376() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test376"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp((int)(short)(-1), (int)(short)10, (int)(short)10, 0, (int)'4', (int)(byte)1);
    testRational0.mysimp((-1), (int)' ', (int)'a', (int)'4', (int)(short)0, (-1));
    testRational0.mysimp((int)(short)100, (int)'4', (int)(short)100, 1, (int)(byte)100, (int)(byte)10);
    testRational0.mysimp((int)(byte)1, 0, (int)(short)1, (int)(short)(-1), (int)'4', (int)(byte)100);
    testRational0.mysimp((int)'a', 100, (int)(short)(-1), (int)(byte)1, (-1), 1);
    testRational0.mysimp((int)(byte)0, (int)' ', (int)(short)0, (int)'a', (int)(byte)0, (int)(byte)(-1));
    testRational0.mysimp((-1), 10, (int)(short)10, 100, (int)(short)100, (int)(byte)(-1));

  }

  @Test
  public void test377() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test377"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)'4', (int)(short)0, 0, (int)(short)(-1), (int)(byte)100, (int)'a');
    testRational0.mysimp((int)(short)100, (int)' ', (int)(short)100, 1, (int)(short)100, (int)'#');
    testRational0.mysimp((int)(byte)0, (int)' ', 1, (int)(short)0, (int)(short)0, (int)(short)1);
    testRational0.mysimp((int)'a', (int)(short)100, (int)(short)1, (int)(short)0, 100, (int)(short)(-1));

  }

  @Test
  public void test378() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test378"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp(100, (int)(byte)100, (int)(byte)10, (int)(short)0, (int)(byte)1, 0);
    testRational0.mysimp(100, (int)(short)10, (int)' ', (int)(short)1, (int)(byte)0, (int)(byte)(-1));
    testRational0.mysimp(1, 10, (int)' ', (int)(byte)100, (int)(byte)0, (int)(byte)100);
    testRational0.mysimp((int)'#', (int)'a', 10, (-1), (int)(short)100, (int)(byte)0);
    testRational0.mysimp((int)(short)(-1), (int)(short)(-1), 0, (-1), (int)(byte)0, 0);
    testRational0.mysimp((int)(short)10, (int)(byte)0, (-1), (int)(byte)(-1), (int)(byte)0, (int)'4');
    testRational0.mysimp(0, (int)(byte)1, 1, (int)(short)10, 100, 10);

  }

  @Test
  public void test379() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test379"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, 100, 100);
    testRational0.mysimp((int)'a', (int)(byte)100, (int)(short)100, 10, 100, (int)(byte)1);
    testRational0.mysimp((int)'a', 100, (int)(byte)100, 1, (int)(short)(-1), (int)(short)1);
    testRational0.mysimp((int)(short)1, (int)(byte)(-1), (int)(short)100, (int)(byte)0, (int)(byte)10, (int)(byte)100);

  }

  @Test
  public void test380() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test380"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(byte)100, (int)(byte)1, (int)(byte)(-1), 1, (int)(byte)0, 10);
    testRational0.mysimp((int)(byte)(-1), 10, (-1), (int)(byte)1, (int)(byte)0, 10);
    testRational0.mysimp((int)(byte)100, (int)'#', (int)(byte)1, 10, 1, (int)(byte)0);
    testRational0.mysimp(0, (int)(short)0, (int)'4', 10, (int)(short)0, (int)(short)10);
    testRational0.mysimp(0, 10, (int)(byte)(-1), 1, (int)(byte)10, (int)(short)1);
    testRational0.mysimp((int)(short)0, (int)(short)100, (int)(short)10, (int)(byte)1, 100, 0);
    testRational0.mysimp((int)'4', 100, (int)(short)1, (int)(short)1, (int)'4', (int)(short)10);
    testRational0.mysimp((int)(short)100, (int)(byte)0, (int)(byte)(-1), (int)'#', (int)(byte)1, (int)(short)10);
    testRational0.mysimp((int)(byte)(-1), 0, (int)(byte)(-1), (int)(byte)100, (int)'#', (int)(byte)10);
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 1, (int)(byte)10, (int)(short)100, (int)(byte)100);
    testRational0.mysimp((int)(short)(-1), (int)(short)1, (int)(byte)10, (int)(byte)0, (int)(short)1, (int)(byte)0);

  }

  @Test
  public void test381() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test381"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)1, 1, (int)(short)1, 0);
    testRational0.mysimp((int)(byte)100, (int)(byte)100, (int)(short)1, (int)(short)10, (int)(short)1, (int)(short)0);
    testRational0.mysimp((int)'a', (int)(short)0, (int)(byte)1, (int)(byte)10, (int)(byte)100, 0);
    testRational0.mysimp((int)(byte)100, 1, (int)(short)1, (int)'4', (int)(byte)100, (int)(short)100);
    testRational0.mysimp(0, 0, (int)'4', (int)(short)10, (int)'4', (-1));
    testRational0.mysimp((int)(byte)(-1), (int)(byte)100, (int)'4', 1, (int)(byte)100, 0);
    testRational0.mysimp((int)'#', (int)(byte)10, 10, (int)(byte)100, (int)(byte)(-1), 0);

  }

  @Test
  public void test382() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test382"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(short)(-1), (int)(short)10, (int)' ', 0, (int)(byte)100, (int)' ');
    testRational0.mysimp(0, 0, (int)'4', (int)(byte)(-1), (int)(short)100, (int)(short)10);
    testRational0.mysimp((int)'#', (int)(byte)10, 1, (int)(short)1, (int)(short)0, (int)(short)0);
    testRational0.mysimp((int)'4', (int)'4', (-1), (int)'#', (int)(short)1, 0);
    testRational0.mysimp((int)(byte)100, (int)' ', (int)(byte)0, (int)(short)10, (int)(byte)10, 10);
    testRational0.mysimp(0, (int)(short)10, (-1), (int)'4', 0, (int)(byte)1);

  }

  @Test
  public void test383() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test383"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(10, (int)(short)100, (int)' ', (int)(byte)1, (int)(short)(-1), 0);
    testRational0.mysimp(0, (int)'a', (-1), (int)(byte)10, (int)'#', (int)(byte)1);
    testRational0.mysimp((int)(short)(-1), 0, (int)(short)(-1), (int)(short)0, (int)' ', (int)(short)1);
    testRational0.mysimp((int)(short)1, (int)(short)100, (int)'4', (int)(short)10, (int)(short)1, (int)'a');
    testRational0.mysimp((int)(short)1, (int)(byte)10, 0, (int)(byte)(-1), (-1), (int)(byte)100);

  }

  @Test
  public void test384() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test384"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(short)(-1), (int)(short)10, (int)' ', 0, (int)(byte)100, (int)' ');
    testRational0.mysimp((int)(byte)10, (-1), (int)(short)(-1), (int)' ', (int)'4', (int)'#');
    testRational0.mysimp(0, 0, (int)(short)(-1), (-1), 10, (int)'4');
    testRational0.mysimp((int)' ', 1, (int)'4', 10, (int)(short)1, (int)'4');
    testRational0.mysimp((int)(byte)100, (int)(short)1, (int)(short)1, 1, (int)(short)0, (int)'4');
    testRational0.mysimp((int)'#', 1, 1, (int)(short)(-1), (int)(short)(-1), (int)'a');
    testRational0.mysimp((int)(short)0, (int)(byte)10, (int)'4', (int)(short)100, (int)(byte)(-1), (int)(short)10);
    testRational0.mysimp(0, (int)(byte)(-1), (int)(byte)0, 100, (int)'#', (int)'#');

  }

  @Test
  public void test385() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test385"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, 100, 100);
    testRational0.mysimp(0, (int)'4', (int)' ', (int)(byte)100, (int)(byte)1, (int)(short)100);
    testRational0.mysimp((int)(short)100, (int)(byte)0, (int)(short)100, (int)' ', 0, (-1));
    testRational0.mysimp((int)' ', (int)(byte)(-1), (int)'4', (int)(byte)(-1), (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)100, (int)'4', (int)(short)1, 0, 100, (int)(byte)10);
    testRational0.mysimp((int)(short)1, (int)' ', (int)'#', (int)'#', (int)' ', (int)(short)100);
    testRational0.mysimp(0, (int)(short)100, (int)(byte)(-1), 100, (int)(byte)0, (int)(byte)0);
    testRational0.mysimp((int)(byte)0, (int)(short)(-1), (int)'4', 10, (int)(byte)100, (-1));
    testRational0.mysimp((int)(short)10, (int)(short)10, (int)(short)100, (int)'4', (int)'4', 0);
    testRational0.mysimp((int)'4', (int)'a', (int)(byte)1, 1, (int)(short)10, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)(-1), (int)'#', (int)(byte)1, (int)'a', (int)'4');

  }

  @Test
  public void test386() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test386"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)' ', 10, (int)' ', (int)(short)0, 0, (int)(short)1);
    testRational0.mysimp((int)(short)1, 1, (int)' ', (int)(byte)10, (int)(short)(-1), 0);
    testRational0.mysimp((int)(short)(-1), 10, (int)' ', (int)'4', (int)(short)1, (int)'#');
    testRational0.mysimp((int)(short)100, (int)(short)100, (-1), (int)(byte)0, (int)(byte)100, (int)' ');
    testRational0.mysimp((int)(short)10, 1, (int)(byte)0, (int)(byte)100, (int)(byte)10, (int)(byte)100);
    testRational0.mysimp((int)' ', 10, 100, (int)(short)10, (int)(byte)10, (int)(byte)100);
    testRational0.mysimp((int)(short)10, 100, 100, (int)'a', (int)(byte)10, (int)(short)0);
    testRational0.mysimp(10, 0, (int)(short)100, (int)(short)10, (int)(byte)1, (int)(byte)10);

  }

  @Test
  public void test387() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test387"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'a', (int)(byte)0, 0, (int)(short)0, 0);
    testRational0.mysimp((int)(short)10, (int)(byte)0, (int)'a', (int)(byte)0, (int)(byte)0, (int)(byte)(-1));
    testRational0.mysimp((int)(short)10, 1, (-1), 100, 1, (int)(byte)10);
    testRational0.mysimp((-1), (int)(short)100, (int)(byte)10, (int)(byte)(-1), (int)(byte)(-1), (int)(byte)100);
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)10, 1, (int)(short)1, (int)(short)1);

  }

  @Test
  public void test388() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test388"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp((int)(byte)100, (int)(byte)0, 1, (int)(byte)10, (int)(short)100, 1);
    testRational0.mysimp((-1), (int)(byte)(-1), 0, 0, (int)'#', 1);
    testRational0.mysimp((int)'a', 0, 0, 100, (int)(byte)1, 1);
    testRational0.mysimp((int)(short)100, 0, (int)(short)(-1), (int)'a', (int)(short)(-1), (int)(short)100);
    testRational0.mysimp((-1), (int)(byte)0, 10, (int)'4', (int)' ', (int)(short)10);
    testRational0.mysimp((int)(short)1, 0, (int)(short)(-1), (int)(short)100, (int)'a', 0);
    testRational0.mysimp((int)(short)10, (-1), (int)'a', (int)' ', 10, (int)(byte)(-1));

  }

  @Test
  public void test389() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test389"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp((int)(byte)100, (int)(byte)0, 1, (int)(byte)10, (int)(short)100, 1);
    testRational0.mysimp((int)'#', (int)(byte)0, (int)(byte)100, (int)(byte)10, (int)'4', (int)(byte)(-1));
    testRational0.mysimp((int)(short)0, (int)(byte)10, (int)(byte)10, (int)(byte)10, (-1), 0);
    testRational0.mysimp((int)'4', (int)' ', (int)(short)(-1), (int)(short)100, (int)'4', (int)(short)1);
    testRational0.mysimp((int)(short)10, 1, (int)(byte)1, (int)(short)10, 0, (int)(short)0);
    testRational0.mysimp((int)' ', 0, (int)(short)1, (int)'#', (int)'#', (int)'4');
    testRational0.mysimp((int)(byte)(-1), (int)(byte)1, (int)(short)0, 10, (int)(short)1, (int)'a');

  }

  @Test
  public void test390() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test390"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)(short)0, (int)(short)10, (int)'4', (int)' ', (int)(byte)1, (int)(short)0);
    testRational0.mysimp(0, (int)'#', (int)(short)0, (int)' ', (int)(byte)10, 1);
    testRational0.mysimp((int)(byte)10, 10, (int)' ', 10, 10, 100);

  }

  @Test
  public void test391() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test391"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)' ', 10, (int)' ', (int)(short)0, 0, (int)(short)1);
    testRational0.mysimp((int)'#', 100, (-1), 1, (-1), (int)(byte)(-1));
    testRational0.mysimp(0, 0, (int)'4', 1, 0, (-1));
    testRational0.mysimp((int)(short)(-1), 100, (int)'4', (int)'4', (int)(short)(-1), (int)(byte)10);
    testRational0.mysimp(1, (-1), (int)(byte)1, (int)(byte)100, (int)' ', (int)(short)0);
    testRational0.mysimp(0, (int)(byte)100, (int)(short)(-1), 1, 1, (-1));
    testRational0.mysimp(10, (int)(byte)0, (int)'4', (int)'4', (int)'4', (int)'#');
    testRational0.mysimp((int)' ', (int)'#', (-1), (int)'#', 10, (int)(byte)10);
    testRational0.mysimp((int)(byte)10, (int)(byte)(-1), (int)(byte)10, (int)(byte)100, (int)(short)1, (int)'a');

  }

  @Test
  public void test392() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test392"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(byte)(-1), 1, (int)(byte)(-1), (-1), (int)(short)(-1), 100);
    testRational0.mysimp((-1), 1, (int)(byte)100, (int)' ', (int)(byte)0, (int)(byte)0);
    testRational0.mysimp((int)(byte)100, (int)(byte)0, (int)'a', (int)(byte)1, (int)(byte)0, (int)(short)100);
    testRational0.mysimp((int)(byte)0, (int)(short)10, (int)(short)100, (int)(byte)1, (int)'4', (int)'4');
    testRational0.mysimp(0, (int)'#', (int)'4', (int)(byte)1, (int)(byte)1, (int)(byte)1);

  }

  @Test
  public void test393() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test393"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)'a', (int)(short)100, (int)(short)10, 0, 100, (int)(short)1);
    testRational0.mysimp(100, (int)(short)1, (int)' ', (int)(byte)10, (int)(short)1, (int)(byte)0);
    testRational0.mysimp((int)'#', (int)'#', (int)'4', (int)(short)(-1), (int)'4', (int)(byte)1);
    testRational0.mysimp(0, 1, (int)' ', (int)'4', (int)(short)(-1), 1);
    testRational0.mysimp((int)(byte)10, 10, (int)(byte)1, (int)'4', (int)(byte)(-1), (int)(short)100);

  }

  @Test
  public void test394() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test394"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 0, (-1), 100, (int)'a');
    testRational0.mysimp((int)' ', (int)(short)100, (int)(short)10, (-1), (int)'a', (int)(byte)0);
    testRational0.mysimp((int)(short)0, 100, (-1), (int)(byte)10, (int)(byte)100, (int)(short)1);
    testRational0.mysimp((int)(short)1, (int)(byte)(-1), (int)'4', (int)'4', 100, (int)(short)(-1));
    testRational0.mysimp((-1), 100, (int)(byte)(-1), (int)' ', (int)(byte)10, (int)(short)100);
    testRational0.mysimp((int)(short)0, 1, (int)' ', (int)' ', 1, (int)(short)10);

  }

  @Test
  public void test395() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test395"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)(byte)0, (int)(byte)(-1), (int)'a', 100, (int)' ', (int)(short)(-1));
    testRational0.mysimp((int)(byte)10, (int)' ', (int)(byte)1, (int)(byte)(-1), 0, 100);
    testRational0.mysimp(10, (int)(byte)0, 1, (int)'#', (int)(short)10, 10);
    testRational0.mysimp((int)(byte)1, 100, 10, (int)'#', (int)(byte)0, (int)(short)0);
    testRational0.mysimp((int)(byte)1, (int)(short)(-1), (int)'4', 10, 1, (int)(byte)(-1));
    testRational0.mysimp((int)'#', 0, 0, (int)(byte)(-1), (int)(byte)0, (int)(short)10);

  }

  @Test
  public void test396() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test396"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'a', (int)(byte)0, 0, (int)(short)0, 0);
    testRational0.mysimp(100, (int)(byte)10, (int)(byte)10, 10, 0, (int)(short)1);
    testRational0.mysimp(1, (int)(short)0, (int)(byte)1, (int)(short)(-1), 1, (int)(byte)(-1));
    testRational0.mysimp((int)(short)0, 0, (int)(short)10, 0, (int)'a', (int)(short)10);
    testRational0.mysimp(100, 10, (int)(byte)1, (int)' ', (int)(byte)(-1), (int)(short)(-1));
    testRational0.mysimp((int)'#', (int)(short)1, 10, (int)'#', (int)'a', (int)(byte)10);
    testRational0.mysimp((int)' ', (int)(byte)10, 0, (-1), (int)(short)100, (int)' ');

  }

  @Test
  public void test397() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test397"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)' ', 10, (int)' ', (int)(short)0, 0, (int)(short)1);
    testRational0.mysimp((int)'#', 100, (-1), 1, (-1), (int)(byte)(-1));
    testRational0.mysimp(0, 0, (int)'4', 1, 0, (-1));
    testRational0.mysimp((int)(short)(-1), 100, (int)'4', (int)'4', (int)(short)(-1), (int)(byte)10);
    testRational0.mysimp(1, (-1), (int)(byte)1, (int)(byte)100, (int)' ', (int)(short)0);
    testRational0.mysimp(0, (int)(byte)100, (int)(short)(-1), 1, 1, (-1));
    testRational0.mysimp((int)(byte)0, (int)'4', (-1), (int)'#', (int)'#', (int)'#');

  }

  @Test
  public void test398() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test398"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)1, 1, (int)(short)1, 0);
    testRational0.mysimp((int)' ', (int)' ', (int)(byte)10, (int)'4', (int)'4', (int)(short)10);
    testRational0.mysimp((int)(short)1, (int)'4', (int)(short)10, (int)'#', (int)'#', (int)(short)100);
    testRational0.mysimp((int)(short)10, (int)(byte)0, 100, (-1), (int)'4', (int)(byte)0);
    testRational0.mysimp((int)(short)100, 100, (-1), (int)(short)100, (int)(byte)10, (int)'a');
    testRational0.mysimp((int)'#', (int)(short)1, (int)'#', (int)(byte)0, 0, (int)'4');
    testRational0.mysimp((-1), (int)(byte)(-1), (-1), 0, (int)(byte)1, (int)'4');

  }

  @Test
  public void test399() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test399"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, 100, 100);
    testRational0.mysimp(0, (int)'4', (int)' ', (int)(byte)100, (int)(byte)1, (int)(short)100);
    testRational0.mysimp((int)(short)100, (int)(byte)0, (int)(short)100, (int)' ', 0, (-1));
    testRational0.mysimp((int)' ', (int)(byte)(-1), (int)'4', (int)(byte)(-1), (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)100, 1, 0, 1, (int)'#', (int)(byte)0);
    testRational0.mysimp((int)(byte)10, (int)(byte)0, (int)(byte)(-1), 0, 10, (int)'a');
    testRational0.mysimp(100, (int)(byte)100, (int)'#', (int)(byte)0, (int)(byte)10, (int)(byte)(-1));
    testRational0.mysimp(0, (int)(byte)0, 10, (int)(short)0, 0, (int)' ');
    testRational0.mysimp((int)(short)100, 10, (int)(byte)0, (int)(byte)100, (int)'#', (int)' ');

  }

  @Test
  public void test400() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test400"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)(short)100, (int)(byte)1, (int)(byte)0, 100, (int)(short)100);
    testRational0.mysimp((int)(short)(-1), 0, (int)(short)0, 10, 0, (int)(byte)10);
    testRational0.mysimp(0, (int)'#', 100, (int)' ', (int)(short)0, (int)(byte)1);
    testRational0.mysimp((int)'4', (int)(byte)0, (int)(short)(-1), 0, (int)'#', (int)(short)10);
    testRational0.mysimp((int)(short)0, 10, (int)(byte)10, 1, (int)'a', (int)'4');
    testRational0.mysimp((int)(byte)1, (int)(short)10, (int)(short)(-1), (int)' ', 100, (int)'4');
    testRational0.mysimp(10, (int)(short)0, (int)(short)(-1), (int)(short)100, (int)(byte)10, (int)(short)10);
    testRational0.mysimp((-1), 0, (int)'#', 100, (int)'4', (int)'a');

  }

  @Test
  public void test401() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test401"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)(short)1, (int)(byte)10, (int)(byte)100, 1, (int)(byte)10, (int)(byte)(-1));
    testRational0.mysimp(0, (int)(short)(-1), (int)(short)0, (int)(byte)0, (int)' ', 1);
    testRational0.mysimp((int)(short)1, (int)(byte)100, 10, (int)(byte)0, (int)' ', (int)(byte)0);
    testRational0.mysimp((-1), 10, (int)'4', (int)(byte)0, (int)' ', (-1));
    testRational0.mysimp((int)(short)(-1), 0, 0, (int)(byte)(-1), (int)(short)0, 0);
    testRational0.mysimp((int)(byte)100, (-1), (int)'#', 0, (-1), 0);
    testRational0.mysimp((int)' ', 10, (int)(byte)1, 1, (int)(byte)(-1), (int)(short)100);

  }

  @Test
  public void test402() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test402"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 0, (-1), 100, (int)'a');
    testRational0.mysimp(100, (int)'#', (int)(byte)0, (int)' ', (int)(short)0, (int)(short)10);
    testRational0.mysimp(0, (int)(short)1, 0, (int)'#', (int)(short)1, (int)(byte)10);
    testRational0.mysimp((int)(short)(-1), 10, 100, 0, (int)(byte)1, 1);
    testRational0.mysimp((-1), (int)(short)1, 1, (int)(short)1, (int)(byte)(-1), (int)(short)0);
    testRational0.mysimp((int)'a', 0, (int)(short)0, (int)'a', (int)(short)1, 1);

  }

  @Test
  public void test403() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test403"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 0, (-1), 100, (int)'a');
    testRational0.mysimp(10, (int)(short)0, 100, (int)'4', (-1), 0);
    testRational0.mysimp(0, (int)(byte)(-1), 100, (int)(short)1, (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp(10, (int)' ', 10, (int)'#', 10, 100);
    testRational0.mysimp((int)' ', 10, (int)(short)100, (int)(short)1, (int)(short)0, (int)(byte)100);
    testRational0.mysimp((int)(short)(-1), (int)(short)(-1), (int)(short)(-1), 10, 10, (int)'4');
    testRational0.mysimp((int)(short)10, (int)(short)(-1), (-1), (int)' ', (int)(short)(-1), 0);
    testRational0.mysimp((int)(short)1, (int)(short)100, (int)(short)0, (int)(byte)1, (int)'#', (int)(short)0);
    testRational0.mysimp(10, 100, (int)(short)100, 100, 1, 1);
    testRational0.mysimp((int)(byte)(-1), 100, 10, 10, (int)(short)1, 100);

  }

  @Test
  public void test404() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test404"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp((int)(byte)100, (int)(byte)0, 1, (int)(byte)10, (int)(short)100, 1);
    testRational0.mysimp((int)'#', (int)(byte)0, (int)(byte)100, (int)(byte)10, (int)'4', (int)(byte)(-1));
    testRational0.mysimp((int)(short)0, (int)(byte)10, (int)(byte)10, (int)(byte)10, (-1), 0);
    testRational0.mysimp((-1), (int)(short)100, 0, (int)(short)10, 1, 100);
    testRational0.mysimp((int)(byte)1, (int)(short)0, (int)(short)1, (int)(short)10, (int)'a', (int)' ');

  }

  @Test
  public void test405() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test405"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(byte)100, (int)(byte)1, (int)(byte)(-1), 1, (int)(byte)0, 10);
    testRational0.mysimp(0, (int)'#', (int)(short)0, (int)'#', 100, (int)(short)100);
    testRational0.mysimp((int)(short)1, (int)' ', (int)(short)100, (int)(byte)1, (int)'4', (int)' ');
    testRational0.mysimp((int)(short)1, (int)'#', 0, (int)(short)100, (-1), (int)(byte)100);
    testRational0.mysimp(0, 10, (int)(byte)0, (-1), (int)(byte)100, 0);
    testRational0.mysimp((int)(byte)0, (int)(short)1, (int)(byte)100, 1, (int)(short)10, (int)(short)(-1));
    testRational0.mysimp((int)(short)0, 0, (int)(byte)1, 0, 1, 1);
    testRational0.mysimp((int)(short)0, (int)'4', (int)(short)100, (int)(byte)1, (int)(byte)10, (int)' ');

  }

  @Test
  public void test406() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test406"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 0, (-1), 100, (int)'a');
    testRational0.mysimp(10, (int)(short)0, 100, (int)'4', (-1), 0);
    testRational0.mysimp(0, (int)(byte)(-1), 100, (int)(short)1, (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp((int)(byte)0, (int)'4', 100, (int)(byte)1, (int)(byte)10, 0);
    testRational0.mysimp((int)(byte)0, (int)(byte)1, (int)'4', 100, (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp((int)(short)0, 100, (int)(byte)100, (int)(byte)100, 0, (int)(short)0);
    testRational0.mysimp((int)(short)100, (int)'a', (int)'4', (int)(short)1, (int)(byte)1, 10);
    testRational0.mysimp(0, (-1), 1, (int)(short)0, 0, (int)(short)1);

  }

  @Test
  public void test407() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test407"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(10, (int)'a', (int)(short)10, (int)(short)(-1), (int)(byte)0, (int)'a');
    testRational0.mysimp((int)(byte)100, (int)(short)0, (int)'a', (int)(byte)(-1), 0, (int)(short)(-1));
    testRational0.mysimp((int)(short)10, (int)(short)0, (int)(byte)0, (int)(byte)1, (int)(byte)(-1), (int)(short)100);
    testRational0.mysimp((int)(byte)1, 1, (int)(byte)10, (int)(short)10, (int)'a', (int)(short)10);
    testRational0.mysimp((int)(byte)0, (-1), (int)(short)(-1), 100, (int)(byte)100, (int)(byte)1);
    testRational0.mysimp((int)(short)100, (int)(byte)0, (int)(byte)1, (-1), (int)'a', (int)(short)10);

  }

  @Test
  public void test408() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test408"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)(short)1, (int)(byte)10, (int)(byte)100, 1, (int)(byte)10, (int)(byte)(-1));
    testRational0.mysimp((int)(short)100, 0, (int)'4', (int)'4', (int)(short)1, (int)(byte)(-1));
    testRational0.mysimp(0, (int)' ', (int)(short)(-1), (-1), (int)(short)(-1), (int)' ');
    testRational0.mysimp((int)(byte)(-1), (int)(byte)10, (-1), (-1), (int)' ', (int)'#');
    testRational0.mysimp((int)(short)10, (int)(byte)1, (int)'4', (int)'a', (int)(short)100, (int)(short)10);
    testRational0.mysimp((int)(short)100, (int)'a', (int)(byte)0, (int)(byte)10, (int)(byte)(-1), (int)(short)(-1));
    testRational0.mysimp((int)(byte)0, (int)(byte)10, (int)(byte)100, (int)(short)1, (int)(short)0, 100);

  }

  @Test
  public void test409() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test409"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp((int)(short)(-1), (int)(short)10, (int)(short)10, 0, (int)'4', (int)(byte)1);
    testRational0.mysimp((-1), (int)' ', (int)'a', (int)'4', (int)(short)0, (-1));
    testRational0.mysimp((int)(short)100, (int)'4', (int)(short)100, 1, (int)(byte)100, (int)(byte)10);
    testRational0.mysimp((int)(short)1, (int)(byte)1, (int)(byte)10, (-1), (int)(byte)(-1), (-1));
    testRational0.mysimp((int)(short)0, (-1), 1, 100, (int)'#', (int)(byte)10);
    testRational0.mysimp((int)'a', 1, (int)(byte)0, (int)(short)100, (int)(short)(-1), (int)(short)(-1));
    testRational0.mysimp(0, (int)(short)(-1), 0, (int)' ', (int)'#', (int)(byte)10);
    testRational0.mysimp((int)(byte)10, (int)(short)100, (int)(short)10, (int)(short)(-1), 0, 100);

  }

  @Test
  public void test410() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test410"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)(short)100, (int)(byte)1, (int)(byte)0, 100, (int)(short)100);
    testRational0.mysimp((int)'#', (int)(short)1, 0, (int)(short)0, (int)'a', (int)'#');
    testRational0.mysimp((int)' ', (int)(byte)0, (int)(short)10, 0, 0, (int)(short)(-1));
    testRational0.mysimp((int)(short)0, (int)(byte)1, (-1), (int)(byte)0, 10, (int)(byte)10);
    testRational0.mysimp((int)(byte)10, (int)(byte)100, 1, 100, (int)(byte)0, 0);
    testRational0.mysimp((int)' ', (int)(short)0, 0, (int)(byte)10, (int)(short)0, (int)(short)(-1));

  }

  @Test
  public void test411() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test411"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)10, (int)'#', 0, (-1));
    testRational0.mysimp((int)(byte)1, (int)(byte)100, (int)' ', (int)(short)0, (int)(short)100, 0);
    testRational0.mysimp(1, (int)(short)10, (int)(short)10, (int)(byte)1, (int)(short)1, (int)(short)100);
    testRational0.mysimp((int)(short)1, (int)'a', (int)'#', (int)'#', (int)(byte)0, 100);
    testRational0.mysimp(1, (int)(byte)(-1), (int)(short)100, 100, (int)(byte)(-1), (int)(short)10);
    testRational0.mysimp((int)(short)100, (-1), (int)(short)(-1), (int)(short)1, 10, (int)(byte)1);
    testRational0.mysimp(0, (int)'a', 1, (int)' ', (int)'#', (int)(short)0);

  }

  @Test
  public void test412() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test412"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(100, 100, 0, 1, (int)'a', 0);
    testRational0.mysimp((int)'a', (int)(byte)(-1), (int)(short)10, (int)'a', (int)'a', (int)(byte)0);
    testRational0.mysimp((int)'a', 1, 10, (int)'a', (int)' ', (int)' ');
    testRational0.mysimp((int)(short)100, (int)(byte)1, (int)(short)10, (int)(byte)(-1), (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp(10, (int)(byte)100, (int)(short)(-1), (int)'a', (int)(short)100, 0);
    testRational0.mysimp((-1), (int)' ', (int)(byte)100, 0, 1, (int)(short)(-1));

  }

  @Test
  public void test413() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test413"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)'#', 10, (int)(short)10, (int)(short)0, (int)(short)0, 1);
    testRational0.mysimp((int)(byte)10, 100, (int)(byte)10, (int)(byte)0, 0, (int)(byte)(-1));
    testRational0.mysimp((int)' ', (-1), (int)(byte)100, 0, (int)(short)(-1), (int)'a');
    testRational0.mysimp(100, (int)'a', 10, 100, (int)'a', 1);
    testRational0.mysimp((int)(short)(-1), (int)'4', 1, (int)(byte)(-1), 0, 100);

  }

  @Test
  public void test414() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test414"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(10, (int)(short)100, (int)(short)10, (int)(short)100, (int)(byte)10, 0);
    testRational0.mysimp(10, (int)'4', (int)(byte)0, (int)(byte)(-1), 0, 1);
    testRational0.mysimp((int)(short)(-1), (int)(short)(-1), 0, 100, (int)(byte)100, (int)(short)10);
    testRational0.mysimp((int)(byte)0, 0, (int)(byte)1, (-1), (int)'4', (int)(short)10);
    testRational0.mysimp((int)(short)1, 1, (int)'#', (int)(short)10, 0, (int)(byte)10);
    testRational0.mysimp((int)(short)10, (int)(short)0, (int)(short)100, (int)(short)(-1), (int)'#', (int)(short)10);
    testRational0.mysimp((int)(short)10, 0, (int)'#', 0, (int)'a', 10);
    testRational0.mysimp((int)(byte)100, (int)'#', (int)(short)10, (int)(short)(-1), (int)(byte)10, (-1));
    testRational0.mysimp(10, (int)(short)10, 1, 0, 0, (int)(byte)100);

  }

  @Test
  public void test415() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test415"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp(100, (int)(byte)100, (int)(byte)10, (int)(short)0, (int)(byte)1, 0);
    testRational0.mysimp(100, (int)(short)10, (int)' ', (int)(short)1, (int)(byte)0, (int)(byte)(-1));
    testRational0.mysimp(100, (-1), (int)(byte)100, 10, (-1), (int)'a');
    testRational0.mysimp(1, 0, (int)(byte)1, (int)'a', (int)(byte)10, (int)'#');
    testRational0.mysimp(1, (int)(short)100, 0, (int)(short)(-1), 1, 1);

  }

  @Test
  public void test416() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test416"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)' ', 10, (int)' ', (int)(short)0, 0, (int)(short)1);
    testRational0.mysimp((int)'#', 100, (-1), 1, (-1), (int)(byte)(-1));
    testRational0.mysimp((int)(short)(-1), (int)'#', (int)(short)1, (int)(short)10, (int)(byte)1, 100);
    testRational0.mysimp((int)(byte)0, 0, (int)(short)100, 100, 10, (-1));
    testRational0.mysimp((int)' ', (int)(short)1, (int)(short)0, (int)(byte)100, (int)'#', 100);
    testRational0.mysimp((int)'a', (int)(byte)0, (int)(byte)100, (int)(short)1, (int)(byte)(-1), (int)(short)100);
    testRational0.mysimp((int)(short)0, (int)(byte)(-1), (int)'a', 100, 100, (int)(byte)0);

  }

  @Test
  public void test417() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test417"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'#', 1, (int)(short)10, (int)'4', (int)(short)1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)10, (int)(short)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)'#', (int)(short)0, (int)(short)100, 0, (int)(byte)10, (int)(short)10);
    testRational0.mysimp((int)'a', 0, (-1), (int)(byte)(-1), (int)(short)100, (int)(byte)0);
    testRational0.mysimp((int)' ', 100, (int)(short)(-1), (int)(short)(-1), (int)(byte)0, (int)(short)1);
    testRational0.mysimp((int)(byte)10, (-1), 10, 0, (int)(short)1, 0);
    testRational0.mysimp((int)(byte)100, (int)'4', (-1), (int)'#', (int)' ', (int)(short)(-1));

  }

  @Test
  public void test418() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test418"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(10, (int)(byte)100, (int)(byte)10, (int)(short)0, (int)(byte)0, (int)' ');
    testRational0.mysimp(10, (int)'#', (int)'a', (int)(short)1, 100, (int)(short)1);
    testRational0.mysimp((int)'4', (int)'a', 0, 1, (int)(short)(-1), (int)(byte)10);
    testRational0.mysimp((int)'4', (int)(byte)100, 0, (-1), (int)(byte)0, (int)'#');
    testRational0.mysimp((int)(byte)0, (-1), (int)(short)100, (int)'#', (int)(short)1, (int)(short)(-1));
    testRational0.mysimp((int)'a', (int)'a', (int)(byte)100, (int)(byte)100, (int)'4', 0);
    testRational0.mysimp(0, 0, (int)' ', (int)'4', 0, (int)'a');

  }

  @Test
  public void test419() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test419"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)' ', 10, (int)' ', (int)(short)0, 0, (int)(short)1);
    testRational0.mysimp((int)(short)1, 1, (int)' ', (int)(byte)10, (int)(short)(-1), 0);
    testRational0.mysimp((int)(byte)0, 100, (int)(byte)(-1), (int)(byte)1, (int)(short)(-1), 1);
    testRational0.mysimp((int)(byte)0, (int)(byte)100, (int)(byte)(-1), 0, (int)(short)100, (int)(short)10);
    testRational0.mysimp(0, (int)(short)1, (int)(short)1, (int)(byte)0, (int)(byte)1, 0);
    testRational0.mysimp((int)'4', (int)(short)100, (int)' ', (int)(short)100, (int)'#', (int)'4');

  }

  @Test
  public void test420() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test420"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(10, (int)(short)100, (int)(short)10, (int)(short)100, (int)(byte)10, 0);
    testRational0.mysimp((int)(byte)10, (int)(byte)10, (int)(byte)0, (int)'#', (int)(short)0, 0);
    testRational0.mysimp(10, (int)(short)(-1), (int)(byte)0, 0, (int)(byte)100, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)(byte)100, (int)'#', (-1), 100, (int)(byte)1);
    testRational0.mysimp(100, (int)(short)(-1), (int)(byte)100, (int)(byte)1, 10, 1);
    testRational0.mysimp((int)(byte)10, (int)(short)1, 100, (int)(byte)10, (int)(short)100, 10);

  }

  @Test
  public void test421() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test421"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp((int)(short)(-1), (int)(short)10, (int)(short)10, 0, (int)'4', (int)(byte)1);
    testRational0.mysimp((-1), (int)' ', (int)'a', (int)'4', (int)(short)0, (-1));
    testRational0.mysimp((int)(short)100, (int)'4', (int)(short)100, 1, (int)(byte)100, (int)(byte)10);
    testRational0.mysimp((-1), (int)(byte)100, (int)(short)0, (int)(byte)10, (int)(byte)1, (int)(short)100);
    testRational0.mysimp(100, (int)(short)0, (int)'4', (int)'#', (int)'#', (int)(short)0);
    testRational0.mysimp((int)(short)10, (int)(short)(-1), (int)(short)100, 0, (int)(byte)1, (int)(byte)100);
    testRational0.mysimp((int)(short)(-1), 1, (int)'a', (int)(short)0, (int)'#', (-1));
    testRational0.mysimp((int)'a', (int)'4', (int)(byte)100, 0, (int)(short)100, (int)(short)10);

  }

  @Test
  public void test422() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test422"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)1, 1, (int)(short)1, 0);
    testRational0.mysimp((int)(byte)100, (int)(byte)100, (int)(short)1, (int)(short)10, (int)(short)1, (int)(short)0);
    testRational0.mysimp((int)'a', (int)(short)0, (int)(byte)1, (int)(byte)10, (int)(byte)100, 0);
    testRational0.mysimp((int)(byte)100, 1, (int)(short)1, (int)'4', (int)(byte)100, (int)(short)100);
    testRational0.mysimp((int)(byte)0, (int)(byte)10, 0, (int)(short)0, 100, (int)(byte)10);
    testRational0.mysimp((int)(byte)0, (int)(short)100, (int)'a', (int)'#', (int)(byte)100, (int)(short)1);
    testRational0.mysimp((-1), (-1), (int)' ', 0, (int)'a', (int)(byte)(-1));
    testRational0.mysimp((int)(short)10, 1, (int)'#', 0, (int)(byte)(-1), 1);
    testRational0.mysimp((-1), 10, (int)(byte)0, (int)'#', (int)(short)0, 100);

  }

  @Test
  public void test423() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test423"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, 100, 100);
    testRational0.mysimp(0, (int)'4', (int)' ', (int)(byte)100, (int)(byte)1, (int)(short)100);
    testRational0.mysimp((int)(short)100, (int)(byte)0, (int)(short)100, (int)' ', 0, (-1));
    testRational0.mysimp((int)' ', (int)(byte)(-1), (int)'4', (int)(byte)(-1), (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)10, (int)(short)10, (int)(short)10, (int)'4', 10, (int)(short)1);
    testRational0.mysimp((int)(short)100, (int)(byte)100, (-1), (int)(byte)10, (int)(short)1, (int)(short)10);
    testRational0.mysimp((int)(short)100, (int)'#', (int)' ', (int)'#', 1, 100);
    testRational0.mysimp((int)(byte)10, (int)(byte)1, (-1), (int)(byte)1, (int)(short)0, (int)(short)1);
    testRational0.mysimp((int)'4', (int)(byte)10, 100, 10, (-1), (int)(short)1);
    testRational0.mysimp((int)(byte)100, (int)(short)10, 1, (int)'a', (int)'a', (int)(byte)100);

  }

  @Test
  public void test424() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test424"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)' ', (int)(byte)0, (int)(byte)1, (int)(byte)100, 10, (int)'4');
    testRational0.mysimp((int)(short)(-1), (int)'a', 100, (int)' ', (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp((int)(short)10, 0, (int)'a', (int)'#', (int)'4', (int)(short)0);
    testRational0.mysimp((int)(byte)100, (int)(byte)100, 0, (int)(short)(-1), 100, (int)' ');
    testRational0.mysimp((int)' ', (int)(byte)1, (int)'4', (int)(byte)10, (int)(short)0, (int)(byte)0);
    testRational0.mysimp(10, (int)(short)1, (int)(short)1, (int)(short)0, 0, (int)'4');

  }

  @Test
  public void test425() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test425"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(10, (int)(short)100, (int)' ', (int)(byte)1, (int)(short)(-1), 0);
    testRational0.mysimp((int)(byte)100, (int)(short)(-1), (int)(byte)10, (int)(byte)100, (-1), 100);
    testRational0.mysimp((int)(short)10, (int)(byte)(-1), (int)(byte)0, (int)'#', (int)' ', (int)(byte)10);
    testRational0.mysimp((int)'#', (int)(short)10, (int)(short)0, (int)'a', (int)(short)0, (int)(short)1);
    testRational0.mysimp((int)(byte)0, (int)(byte)1, 1, (int)(short)100, (int)(short)100, (int)(short)0);
    testRational0.mysimp(0, (int)(byte)1, (int)'a', (int)(byte)100, (int)(short)1, 1);
    testRational0.mysimp(10, (int)(byte)100, (int)'#', 0, (int)(short)1, (int)(short)1);
    testRational0.mysimp((int)(byte)1, 0, (int)' ', (int)'4', (int)(byte)(-1), (int)' ');
    testRational0.mysimp(0, 10, (int)(byte)1, 0, (int)(byte)100, (int)(short)1);

  }

  @Test
  public void test426() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test426"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(10, (int)(short)100, (int)(short)10, (int)(short)100, (int)(byte)10, 0);
    testRational0.mysimp(10, (int)'4', (int)(byte)0, (int)(byte)(-1), 0, 1);
    testRational0.mysimp((int)(byte)(-1), 0, (-1), 1, (int)(short)100, (int)(short)100);
    testRational0.mysimp((int)(byte)1, (int)'a', (int)(byte)10, (int)(short)100, (int)(short)100, (int)(byte)100);
    testRational0.mysimp(0, (int)(short)100, (int)' ', (int)'4', 1, (-1));

  }

  @Test
  public void test427() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test427"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)1, 1, (int)(short)1, 0);
    testRational0.mysimp((int)(byte)100, (int)(byte)100, (int)(short)1, (int)(short)10, (int)(short)1, (int)(short)0);
    testRational0.mysimp((int)'a', (int)(short)0, (int)(byte)1, (int)(byte)10, (int)(byte)100, 0);
    testRational0.mysimp((int)(byte)100, 1, (int)(short)1, (int)'4', (int)(byte)100, (int)(short)100);
    testRational0.mysimp(1, (int)' ', 0, (int)(byte)0, (int)'#', (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(byte)0, (int)'#', (int)(short)10, 10, (int)(short)(-1));
    testRational0.mysimp((int)(byte)(-1), (int)' ', (int)(byte)(-1), (int)'a', (int)(short)(-1), (int)'#');
    testRational0.mysimp((int)(byte)1, (-1), (int)(byte)(-1), 10, (int)(byte)100, (int)'#');
    testRational0.mysimp((int)(byte)(-1), 1, 100, (int)'a', (int)(byte)0, 10);
    testRational0.mysimp((int)(short)0, (int)(short)1, (int)(short)0, 0, 1, (int)'4');

  }

  @Test
  public void test428() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test428"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)10, (int)'#', 0, (-1));
    testRational0.mysimp((int)(byte)1, (int)(byte)100, (int)' ', (int)(short)0, (int)(short)100, 0);
    testRational0.mysimp(1, (int)(short)10, (int)(short)10, (int)(byte)1, (int)(short)1, (int)(short)100);
    testRational0.mysimp((int)(byte)(-1), 1, (int)(short)1, 100, (int)(short)0, 0);
    testRational0.mysimp(10, 100, 100, (int)(short)(-1), (int)' ', (int)(short)(-1));
    testRational0.mysimp((int)'4', (int)'a', 100, 1, (int)(byte)0, (int)' ');
    testRational0.mysimp(0, (int)(byte)10, (int)(short)10, (int)(byte)(-1), (int)(byte)10, (int)(byte)0);
    testRational0.mysimp((int)(short)100, 1, (int)(short)0, (int)(short)10, (int)(short)(-1), (int)'a');
    testRational0.mysimp((int)(short)0, (int)(byte)100, (int)(byte)1, (int)(byte)1, (-1), (int)(short)0);

  }

  @Test
  public void test429() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test429"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, 100, 100);
    testRational0.mysimp((int)(byte)(-1), (int)'a', (-1), (int)'4', (-1), (int)(byte)0);
    testRational0.mysimp((int)(short)100, (int)'#', (int)(byte)100, (int)(short)(-1), (int)(short)10, 10);
    testRational0.mysimp(10, (int)(short)1, (int)(short)0, 100, (int)' ', (int)(byte)0);
    testRational0.mysimp(0, (int)(short)10, (int)(byte)(-1), (int)(byte)100, (int)' ', (int)(byte)100);
    testRational0.mysimp((int)(short)1, 10, (int)(byte)(-1), (int)(byte)1, (-1), (int)(short)(-1));
    testRational0.mysimp((int)(byte)1, (int)(short)(-1), (int)(byte)1, (-1), (int)(short)1, 0);
    testRational0.mysimp((int)'#', (int)(byte)(-1), (int)(byte)10, (int)' ', 100, 10);
    testRational0.mysimp((int)(short)10, 0, (int)(short)0, (int)' ', (int)'4', (int)(byte)100);
    testRational0.mysimp((int)(byte)1, 100, (int)(byte)10, (int)(short)0, (int)(short)100, (int)(byte)1);

  }

  @Test
  public void test430() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test430"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'a', (int)(byte)0, 0, (int)(short)0, 0);
    testRational0.mysimp((int)(short)10, (int)(byte)0, (int)'a', (int)(byte)0, (int)(byte)0, (int)(byte)(-1));
    testRational0.mysimp(100, 0, (int)'4', 10, (int)'#', (int)(short)10);
    testRational0.mysimp((int)' ', (int)' ', (int)(short)1, (int)(byte)10, (int)(short)10, 100);
    testRational0.mysimp((int)(short)1, (int)(byte)1, 0, (int)(byte)1, (int)(byte)100, (int)(short)100);
    testRational0.mysimp((int)' ', 0, 0, (int)'4', (int)(short)100, (int)'#');
    testRational0.mysimp((int)(short)100, (int)(short)100, (int)(byte)0, 0, (int)(short)10, (int)(byte)10);
    testRational0.mysimp((int)(byte)1, (-1), (int)(short)1, (int)(short)(-1), (int)'#', 0);

  }

  @Test
  public void test431() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test431"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(10, (int)'a', (int)(short)10, (int)(short)(-1), (int)(byte)0, (int)'a');
    testRational0.mysimp((int)(byte)100, (int)(short)0, (int)'a', (int)(byte)(-1), 0, (int)(short)(-1));
    testRational0.mysimp((int)(byte)10, 0, (int)(short)(-1), (int)(short)1, 0, (int)(byte)0);
    testRational0.mysimp((int)(short)10, (-1), (int)(byte)0, 0, (int)(byte)0, (int)' ');
    testRational0.mysimp(0, (int)(short)1, (int)(byte)(-1), (int)(short)(-1), (int)(short)(-1), 0);
    testRational0.mysimp((int)(short)100, 100, (int)(short)100, (int)'4', 0, (int)(short)10);
    testRational0.mysimp(100, 0, (int)(byte)1, (int)(byte)1, 1, (-1));
    testRational0.mysimp((-1), (int)(short)(-1), (-1), (int)'a', (int)(short)(-1), 1);

  }

  @Test
  public void test432() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test432"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)100, (int)'4', 0, (int)(byte)1, (int)'4', (int)(short)(-1));
    testRational0.mysimp(1, (int)'a', 100, (int)'4', 10, (int)(byte)100);
    testRational0.mysimp((int)(byte)1, (int)(byte)100, (int)(byte)1, (int)'a', (int)(short)0, (-1));
    testRational0.mysimp((int)' ', 0, 0, (int)' ', (int)(byte)(-1), (int)(short)1);
    testRational0.mysimp((int)(short)10, (int)(byte)(-1), (int)'4', 0, 0, (int)(byte)10);

  }

  @Test
  public void test433() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test433"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(10, (int)'a', (int)(short)10, (int)(short)(-1), (int)(byte)0, (int)'a');
    testRational0.mysimp((int)(byte)100, (int)(short)0, (int)'a', (int)(byte)(-1), 0, (int)(short)(-1));
    testRational0.mysimp((int)(byte)0, 1, (int)'4', (int)(short)1, (int)' ', (int)'4');
    testRational0.mysimp(0, (int)(byte)10, 100, 0, (int)'4', (int)(byte)1);
    testRational0.mysimp((int)' ', (int)(byte)100, (int)(byte)10, (int)(short)(-1), 0, (int)' ');
    testRational0.mysimp(1, (int)(short)100, (int)' ', (int)(short)0, 1, (int)(byte)1);
    testRational0.mysimp((int)'a', (int)(byte)1, (int)(short)10, (-1), (int)(byte)(-1), (int)(byte)100);
    testRational0.mysimp(1, (int)(byte)0, (int)(byte)10, (int)(byte)100, 100, (int)(short)1);
    testRational0.mysimp(0, (int)(short)1, (int)'#', (int)(short)100, 0, 0);

  }

  @Test
  public void test434() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test434"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(10, (int)(short)100, (int)' ', (int)(byte)1, (int)(short)(-1), 0);
    testRational0.mysimp((int)(short)10, (int)(byte)10, (int)(byte)10, (int)(short)1, 10, (int)(byte)0);
    testRational0.mysimp((int)'#', (int)(short)10, (int)' ', 1, (int)' ', (int)(byte)10);
    testRational0.mysimp((int)'a', (int)(short)1, (-1), 10, (-1), (int)(short)100);
    testRational0.mysimp((int)'a', (int)'4', (int)(short)1, (int)(short)(-1), (int)'#', (int)'#');
    testRational0.mysimp((int)(short)(-1), 0, (int)'4', 100, 10, (int)(byte)100);
    testRational0.mysimp((int)'a', (int)(short)(-1), (int)' ', (int)'4', (int)(short)100, 0);
    testRational0.mysimp((int)'4', 1, 1, (int)(byte)(-1), 0, 10);
    testRational0.mysimp((-1), (int)(short)10, (int)(short)(-1), (int)(short)1, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)'a', (int)(short)10, (int)(short)100, 1, (int)' ');

  }

  @Test
  public void test435() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test435"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)10, (int)'#', 0, (-1));
    testRational0.mysimp((int)'4', (int)(byte)(-1), (int)(byte)100, (int)(short)1, (int)'#', 100);
    testRational0.mysimp((int)(byte)10, (int)'a', (int)(short)100, (int)'#', (int)(short)10, (int)(short)100);
    testRational0.mysimp((int)(short)0, (int)' ', (int)(short)0, (int)(byte)1, 10, (int)(byte)(-1));
    testRational0.mysimp((int)(byte)10, (int)(short)100, 10, (int)' ', (int)(short)0, (int)' ');
    testRational0.mysimp((int)(short)10, (int)' ', (-1), (int)(short)1, (int)'#', 1);
    testRational0.mysimp((int)(byte)10, 10, 1, (int)(byte)100, (int)(byte)0, (int)(short)0);
    testRational0.mysimp(1, (int)'#', (int)(byte)1, (int)(short)0, (int)(byte)1, (int)(short)1);

  }

  @Test
  public void test436() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test436"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)(short)100, (int)(byte)1, (int)(byte)0, 100, (int)(short)100);
    testRational0.mysimp((int)(short)(-1), 0, (int)(short)0, 10, 0, (int)(byte)10);
    testRational0.mysimp(0, (int)'#', 100, (int)' ', (int)(short)0, (int)(byte)1);
    testRational0.mysimp((int)(short)(-1), 1, 1, (int)(byte)(-1), (int)'#', 10);
    testRational0.mysimp((int)(byte)10, (int)' ', (int)'#', (int)(short)100, (int)(short)(-1), (-1));

  }

  @Test
  public void test437() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test437"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)'a', (int)(byte)1, (int)(short)100, (int)(byte)1, (int)(short)0, (int)(short)(-1));
    testRational0.mysimp((-1), 1, (int)(byte)0, (-1), 1, (int)'a');
    testRational0.mysimp((int)(short)0, (int)'4', (int)' ', (int)(byte)(-1), 100, (int)(short)1);
    testRational0.mysimp((int)'a', (int)'#', (int)(short)100, (int)(byte)1, (int)'#', (int)(byte)1);
    testRational0.mysimp(0, 0, (int)(byte)(-1), (int)'4', (int)(byte)1, 10);

  }

  @Test
  public void test438() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test438"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)(short)1, (int)(byte)10, (int)(byte)100, 1, (int)(byte)10, (int)(byte)(-1));
    testRational0.mysimp(0, (int)(short)(-1), (int)(short)0, (int)(byte)0, (int)' ', 1);
    testRational0.mysimp((int)(byte)0, (int)(byte)0, (int)(short)100, 10, (int)(byte)0, (int)(short)100);
    testRational0.mysimp((int)' ', (int)(short)100, 100, (int)'a', 100, (-1));
    testRational0.mysimp((int)(byte)10, (int)'a', 1, 10, (int)'a', (int)(short)0);
    testRational0.mysimp(0, 10, (int)(byte)100, (int)(short)0, (int)(short)10, (-1));
    testRational0.mysimp((int)(short)(-1), (int)'#', (int)(byte)100, (int)(short)100, (int)(byte)0, (int)(short)(-1));

  }

  @Test
  public void test439() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test439"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)' ', 10, (int)' ', (int)(short)0, 0, (int)(short)1);
    testRational0.mysimp((int)(short)1, (int)(short)(-1), (int)(short)100, (int)'4', 1, (int)(short)100);
    testRational0.mysimp((int)(byte)100, (int)(short)100, (int)(byte)10, (int)'4', (-1), 10);
    testRational0.mysimp((int)(short)0, (-1), (int)'#', (int)'#', (int)(short)1, (int)(byte)1);

  }

  @Test
  public void test440() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test440"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(byte)(-1), (int)(short)(-1), (int)(short)10, 0, (int)(byte)100, 1);
    testRational0.mysimp(100, (int)(byte)(-1), (int)'a', (-1), 0, (int)(short)1);
    testRational0.mysimp((int)(byte)1, (int)(short)(-1), 0, (int)(byte)(-1), (int)(byte)0, 0);
    testRational0.mysimp((int)(byte)1, (int)(short)(-1), (int)(byte)10, 0, (int)'4', (int)'4');
    testRational0.mysimp(0, 10, (int)(byte)1, (int)'a', (int)'a', (int)(byte)(-1));
    testRational0.mysimp(1, (int)(byte)1, (int)'a', (int)' ', (int)(byte)0, (int)(short)10);

  }

  @Test
  public void test441() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test441"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 0, (-1), 100, (int)'a');
    testRational0.mysimp((int)' ', (int)(short)100, (int)(short)10, (-1), (int)'a', (int)(byte)0);
    testRational0.mysimp((int)(short)0, 100, (-1), (int)(byte)10, (int)(byte)100, (int)(short)1);
    testRational0.mysimp((int)'4', (int)(short)1, (int)(byte)0, 0, (-1), 100);
    testRational0.mysimp((int)(byte)0, (int)(short)0, (int)(short)0, (-1), (int)(byte)0, 0);
    testRational0.mysimp((int)(short)1, 1, (-1), (int)'a', (int)(short)10, 0);
    testRational0.mysimp(0, (int)' ', (int)' ', (int)(short)(-1), (int)'4', (int)(short)10);
    testRational0.mysimp(0, (int)(short)(-1), (int)(short)10, (int)(byte)10, (int)(short)(-1), 10);
    testRational0.mysimp((int)'a', (int)(short)1, (int)'a', (int)(short)(-1), 100, (int)(byte)(-1));

  }

  @Test
  public void test442() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test442"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(10, (int)(short)100, (int)(short)10, (int)(short)100, (int)(byte)10, 0);
    testRational0.mysimp(1, (int)'#', 0, (int)(short)0, (int)(byte)1, (int)(byte)1);
    testRational0.mysimp(100, (int)' ', (int)(byte)1, (int)'4', (int)(byte)10, (int)(short)0);
    testRational0.mysimp((int)(byte)1, (int)(short)(-1), 10, (int)(short)0, 100, (int)(short)100);
    testRational0.mysimp((int)(byte)1, (-1), (int)(byte)10, (int)(byte)1, (-1), (int)(short)0);

  }

  @Test
  public void test443() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test443"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)'a', (int)(short)100, (int)(short)10, 0, 100, (int)(short)1);
    testRational0.mysimp(100, (int)(short)1, (int)' ', (int)(byte)10, (int)(short)1, (int)(byte)0);
    testRational0.mysimp((int)'#', (int)'#', (int)'4', (int)(short)(-1), (int)'4', (int)(byte)1);
    testRational0.mysimp((int)'a', (int)(short)100, 0, (int)(byte)1, (int)(byte)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, (int)(byte)0, (int)(byte)0);
    testRational0.mysimp((int)'#', 10, (-1), 0, (int)(short)10, (int)'#');
    testRational0.mysimp(10, 1, 1, (int)'a', (int)' ', (int)(short)100);

  }

  @Test
  public void test444() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test444"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp(10, (int)(short)100, (int)' ', (int)(byte)1, (int)(short)(-1), 0);
    testRational0.mysimp((int)(byte)100, (int)(short)(-1), (int)(byte)10, (int)(byte)100, (-1), 100);
    testRational0.mysimp((int)(short)10, (int)(byte)(-1), (int)(byte)0, (int)'#', (int)' ', (int)(byte)10);
    testRational0.mysimp((int)'#', (int)(short)10, (int)(short)0, (int)'a', (int)(short)0, (int)(short)1);
    testRational0.mysimp((int)(byte)0, (int)(byte)1, 1, (int)(short)100, (int)(short)100, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)'#', (int)(short)100, (int)(byte)100, (int)'#', (int)(byte)0);
    testRational0.mysimp((int)(short)1, (int)(short)100, (int)(short)100, (int)(short)(-1), (int)(short)100, 0);
    testRational0.mysimp(10, 10, (int)(byte)0, (int)(byte)(-1), (int)(byte)(-1), 100);

  }

  @Test
  public void test445() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test445"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)'a', (int)(short)100, (int)(short)10, 0, 100, (int)(short)1);
    testRational0.mysimp(100, (int)(short)1, (int)' ', (int)(byte)10, (int)(short)1, (int)(byte)0);
    testRational0.mysimp((int)'#', (int)'#', (int)'4', (int)(short)(-1), (int)'4', (int)(byte)1);
    testRational0.mysimp((int)(byte)10, 1, 1, (int)(short)0, (int)(byte)(-1), (int)(byte)10);
    testRational0.mysimp((int)(byte)1, (int)(short)0, (int)(byte)1, (int)(short)(-1), (int)(byte)1, (int)'4');
    testRational0.mysimp((int)(byte)1, (int)(short)100, (int)(byte)10, (int)(byte)1, (int)(short)(-1), 0);
    testRational0.mysimp((-1), (int)(byte)0, (int)(short)(-1), (int)(byte)0, (int)(short)100, (int)'a');

  }

  @Test
  public void test446() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test446"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)' ', (int)(byte)0, (int)(byte)1, (int)(byte)100, 10, (int)'4');
    testRational0.mysimp((int)(short)(-1), (int)'a', 100, (int)' ', (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp((int)(short)10, (int)(byte)0, (int)(short)0, (-1), (-1), (int)(short)100);
    testRational0.mysimp((int)(short)0, 10, 1, 10, (-1), (int)'4');
    testRational0.mysimp((int)'4', (-1), 1, (int)'#', 0, 0);

  }

  @Test
  public void test447() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test447"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)10, (int)'#', 0, (-1));
    testRational0.mysimp((int)(byte)1, (int)(byte)100, (int)' ', (int)(short)0, (int)(short)100, 0);
    testRational0.mysimp((int)(byte)100, 0, (int)(short)100, (-1), 1, (int)(byte)100);
    testRational0.mysimp((int)(short)(-1), (int)' ', (int)(short)0, (int)' ', (int)(byte)10, (int)' ');
    testRational0.mysimp((int)(short)0, (int)(short)1, (-1), (int)(byte)100, 0, 0);

  }

  @Test
  public void test448() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test448"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(10, (int)'a', (int)(short)10, (int)(short)(-1), (int)(byte)0, (int)'a');
    testRational0.mysimp((int)(byte)100, (int)(short)0, (int)'a', (int)(byte)(-1), 0, (int)(short)(-1));
    testRational0.mysimp((int)(short)10, (int)(short)0, (int)(byte)0, (int)(byte)1, (int)(byte)(-1), (int)(short)100);
    testRational0.mysimp((int)(short)1, (int)(byte)100, (-1), (int)' ', (int)(byte)(-1), (int)(short)(-1));
    testRational0.mysimp(10, (int)' ', (int)(short)(-1), (int)(short)100, 0, (int)(byte)0);
    testRational0.mysimp((int)(short)1, (int)(byte)10, 0, (int)(short)10, (int)(short)0, (-1));
    testRational0.mysimp((int)(short)0, (int)(short)10, 100, (int)(short)(-1), (int)(byte)100, (int)(short)1);

  }

  @Test
  public void test449() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test449"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, 100, 100);
    testRational0.mysimp((int)(byte)(-1), (int)'a', (-1), (int)'4', (-1), (int)(byte)0);
    testRational0.mysimp((int)' ', 0, (int)'#', (int)(short)100, (int)(short)0, 100);
    testRational0.mysimp((int)'a', (int)(short)1, 1, (int)'4', (int)'4', 10);
    testRational0.mysimp((-1), 0, (int)'4', (-1), (int)(byte)0, (int)(short)1);
    testRational0.mysimp((int)(byte)0, (int)'4', 10, (int)(short)(-1), (int)(short)1, 0);
    testRational0.mysimp(10, (int)'4', (int)(byte)(-1), 10, (int)'a', (int)(short)(-1));
    testRational0.mysimp(10, (int)(byte)0, (int)(byte)100, (int)(short)10, (int)(byte)10, 0);

  }

  @Test
  public void test450() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test450"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)1, 1, (int)(short)1, 0);
    testRational0.mysimp((int)(byte)100, (int)(byte)100, (int)(short)1, (int)(short)10, (int)(short)1, (int)(short)0);
    testRational0.mysimp((int)'a', (int)(short)0, (int)(byte)1, (int)(byte)10, (int)(byte)100, 0);
    testRational0.mysimp((int)(byte)100, 1, (int)(short)1, (int)'4', (int)(byte)100, (int)(short)100);
    testRational0.mysimp(0, 0, (-1), (int)(short)100, (int)(byte)1, (-1));
    testRational0.mysimp((int)(short)10, (int)(short)10, 10, (int)(byte)10, (int)(byte)10, (int)(byte)1);
    testRational0.mysimp((int)(byte)100, (int)(byte)1, 100, (int)(byte)100, (int)' ', (int)(short)(-1));
    testRational0.mysimp((int)(byte)100, (int)'a', 0, (int)(byte)10, (int)(short)100, (int)(short)10);

  }

  @Test
  public void test451() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test451"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)10, (int)'#', 0, (-1));
    testRational0.mysimp((int)(byte)1, (int)(byte)100, (int)' ', (int)(short)0, (int)(short)100, 0);
    testRational0.mysimp((int)(byte)100, 0, (int)(short)100, (-1), 1, (int)(byte)100);
    testRational0.mysimp((int)(byte)(-1), 10, (int)'a', (int)(short)1, (int)(short)0, (int)(byte)1);
    testRational0.mysimp((int)(short)1, (int)(byte)0, (int)' ', (-1), (int)(byte)(-1), 10);
    testRational0.mysimp((-1), 0, (int)(short)100, (int)(byte)100, (int)'4', (int)'a');
    testRational0.mysimp((int)'a', (int)(byte)100, (int)(byte)0, 100, (-1), (int)(short)10);
    testRational0.mysimp((int)(byte)0, (int)(short)0, 1, (int)(short)100, (int)(byte)100, 100);

  }

  @Test
  public void test452() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test452"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, 100, 100);
    testRational0.mysimp(0, (int)'4', (int)' ', (int)(byte)100, (int)(byte)1, (int)(short)100);
    testRational0.mysimp((int)(short)100, (int)(byte)0, (int)(short)100, (int)' ', 0, (-1));
    testRational0.mysimp((int)' ', (int)(byte)(-1), (int)'4', (int)(byte)(-1), (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)10, (int)(short)10, (int)(short)10, (int)'4', 10, (int)(short)1);
    testRational0.mysimp((int)(short)100, 100, (int)(short)1, (int)(short)(-1), (int)(short)(-1), 100);
    testRational0.mysimp((int)'a', 0, (int)'#', (int)(short)(-1), 100, (int)' ');
    testRational0.mysimp(1, (int)(short)1, (int)'4', (int)(short)1, (int)(byte)100, (int)'a');

  }

  @Test
  public void test453() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test453"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(10, (int)(short)100, (int)(short)10, (int)(short)100, (int)(byte)10, 0);
    testRational0.mysimp(10, (int)'4', (int)(byte)0, (int)(byte)(-1), 0, 1);
    testRational0.mysimp((int)(byte)100, (int)(short)(-1), (int)(short)1, (int)(byte)(-1), 0, (int)(byte)100);
    testRational0.mysimp((int)'a', (int)(byte)0, 0, 1, (int)(byte)10, (int)(short)1);
    testRational0.mysimp((int)(short)1, (int)(short)(-1), (int)(byte)0, (-1), (int)'#', (int)'#');
    testRational0.mysimp((int)'#', (int)(byte)100, (int)(short)10, 100, (-1), (-1));
    testRational0.mysimp(1, (int)'4', (int)(short)1, 0, (int)(byte)0, (int)(short)100);
    testRational0.mysimp(0, (int)' ', (int)(short)1, (int)(byte)10, (int)(byte)10, (int)'a');

  }

  @Test
  public void test454() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test454"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(byte)100, (int)(byte)1, (int)(byte)(-1), 1, (int)(byte)0, 10);
    testRational0.mysimp(0, (int)'#', (int)(short)0, (int)'#', 100, (int)(short)100);
    testRational0.mysimp((int)(short)1, (int)' ', (int)(short)100, (int)(byte)1, (int)'4', (int)' ');
    testRational0.mysimp((int)(byte)10, (int)(byte)100, (-1), (-1), 0, (int)(byte)100);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)100, (int)(short)(-1), (int)(short)10, 0);
    testRational0.mysimp((int)(byte)0, (int)'#', (int)' ', (int)(short)1, (int)(short)0, (int)(byte)1);
    testRational0.mysimp((int)'a', (int)(short)1, (int)(short)100, (int)(byte)1, (int)' ', (int)'4');
    testRational0.mysimp((-1), (int)(short)10, (int)(byte)(-1), 0, (int)'#', (int)'4');
    testRational0.mysimp((int)'a', (int)'4', 10, (int)(short)(-1), (int)' ', (int)'a');
    testRational0.mysimp((int)(short)1, (int)' ', (int)(byte)1, (int)(byte)10, (int)(byte)(-1), (int)'4');
    testRational0.mysimp((int)(short)1, (int)(byte)100, 0, 0, (int)(short)100, (int)(byte)10);

  }

  @Test
  public void test455() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test455"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)'a', (int)(byte)(-1), (int)' ', (int)'#', (int)(short)1);
    testRational0.mysimp((int)(byte)1, 1, (int)(short)1, (int)(short)100, (int)(byte)(-1), (int)'#');
    testRational0.mysimp(10, (int)(short)10, (int)' ', (int)(short)10, (int)'a', (int)(byte)(-1));
    testRational0.mysimp((int)(byte)100, (int)(short)10, (int)'a', 100, (int)(byte)100, (-1));
    testRational0.mysimp((int)(short)100, 0, (int)'a', (int)(short)10, 1, (int)(byte)100);
    testRational0.mysimp((int)(byte)1, 0, (int)(byte)1, (int)'4', (int)' ', (int)(byte)1);
    testRational0.mysimp((int)(short)100, (int)'a', (int)(byte)1, (int)(short)0, (int)(byte)1, (int)(byte)(-1));
    testRational0.mysimp((int)'4', (int)(byte)10, 1, 1, 100, (int)'4');

  }

  @Test
  public void test456() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test456"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 0, (-1), 100, (int)'a');
    testRational0.mysimp(10, (int)(short)0, 100, (int)'4', (-1), 0);
    testRational0.mysimp(0, (int)(byte)(-1), 100, (int)(short)1, (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp(10, (int)' ', 10, (int)'#', 10, 100);
    testRational0.mysimp((int)' ', 10, (int)(short)100, (int)(short)1, (int)(short)0, (int)(byte)100);
    testRational0.mysimp((int)(short)(-1), (int)(short)(-1), (int)(short)(-1), 10, 10, (int)'4');
    testRational0.mysimp((int)'#', (int)(short)1, (-1), 1, (int)(short)0, (int)(short)(-1));

  }

  @Test
  public void test457() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test457"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)(short)1, (int)(byte)10, (int)(byte)100, 1, (int)(byte)10, (int)(byte)(-1));
    testRational0.mysimp((int)(byte)100, (int)(short)(-1), 100, (int)' ', (-1), (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)'#', (-1), 10, 100, 0);
    testRational0.mysimp((int)(short)10, (-1), (int)(short)1, (int)(short)10, (int)(byte)0, (int)(byte)(-1));
    testRational0.mysimp((int)(byte)(-1), 0, 0, (int)(byte)100, (int)(short)(-1), (int)(short)0);
    testRational0.mysimp((int)(short)100, (int)' ', 100, (int)(byte)10, (int)' ', (int)(byte)100);
    testRational0.mysimp(0, 0, (int)'#', (int)' ', (int)'4', (int)'a');

  }

  @Test
  public void test458() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test458"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)100, (int)(short)0, (int)'4', (int)(short)100, 0, (int)(byte)(-1));
    testRational0.mysimp((int)(byte)1, (int)(byte)1, (int)(byte)10, 0, (int)'#', (int)(byte)1);
    testRational0.mysimp((int)(short)10, 100, (int)(short)10, (int)(byte)1, (int)'4', (int)(short)10);
    testRational0.mysimp((int)'4', (-1), 0, (int)(short)10, (int)'a', 100);
    testRational0.mysimp(0, (int)(short)10, (int)(byte)100, 100, (int)(byte)0, (int)' ');
    testRational0.mysimp((int)(short)100, 0, 0, 0, (int)'4', (int)(byte)(-1));

  }

  @Test
  public void test459() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test459"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)' ', (int)(byte)0, (int)(byte)1, (int)(byte)100, 10, (int)'4');
    testRational0.mysimp((int)(short)10, (int)(short)100, (int)(short)(-1), 1, (int)(byte)100, (-1));
    testRational0.mysimp((int)(byte)10, (int)(short)(-1), 1, (int)(short)(-1), (int)(short)0, 0);
    testRational0.mysimp((int)(byte)(-1), (int)(byte)1, (int)(byte)(-1), (int)'4', (int)'a', (int)(byte)10);
    testRational0.mysimp((int)(byte)1, (int)'a', (int)(byte)(-1), (int)(short)10, 0, (int)(byte)100);
    testRational0.mysimp((int)(byte)1, 0, 0, (int)(short)(-1), (int)'a', (int)'a');

  }

  @Test
  public void test460() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test460"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp((int)(short)(-1), (int)(short)10, (int)(short)10, 0, (int)'4', (int)(byte)1);
    testRational0.mysimp((int)(short)(-1), (int)'a', (int)(byte)(-1), (int)(byte)1, 0, 0);
    testRational0.mysimp(10, (int)(short)(-1), 0, (int)(short)1, (int)(byte)(-1), (int)'a');
    testRational0.mysimp((int)(byte)0, (int)(short)(-1), (int)(byte)100, (int)(byte)1, 0, (int)(byte)10);
    testRational0.mysimp(100, 10, (int)'a', (int)'4', (int)(byte)100, (int)'#');
    testRational0.mysimp((int)(byte)(-1), (int)'4', (int)(byte)1, (int)' ', (int)' ', (int)(byte)1);

  }

  @Test
  public void test461() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test461"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, 100, 100);
    testRational0.mysimp((int)'a', (int)(byte)100, (int)(short)100, 10, 100, (int)(byte)1);
    testRational0.mysimp((-1), (int)(byte)1, (int)(byte)100, 10, (int)(byte)1, 0);
    testRational0.mysimp((int)(byte)0, 100, 100, (int)(byte)100, 0, (int)(short)(-1));
    testRational0.mysimp(10, 1, (int)(byte)(-1), (int)(short)0, (int)(byte)(-1), (int)'#');
    testRational0.mysimp(100, (int)(byte)1, (int)'4', (int)(short)(-1), (int)(short)10, (int)'4');
    testRational0.mysimp(0, 0, (int)(byte)10, (int)(short)1, 100, (int)(short)10);
    testRational0.mysimp(0, 100, (int)'#', (int)(short)(-1), (int)(short)100, (-1));

  }

  @Test
  public void test462() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test462"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)'a', (int)(byte)1, (int)(short)100, (int)(byte)1, (int)(short)0, (int)(short)(-1));
    testRational0.mysimp((-1), 1, (int)(byte)0, (-1), 1, (int)'a');
    testRational0.mysimp((int)(short)0, (int)'4', (int)' ', (int)(byte)(-1), 100, (int)(short)1);
    testRational0.mysimp((-1), 10, (-1), (int)(short)0, (int)(byte)100, (int)(byte)1);
    testRational0.mysimp((-1), (int)(byte)1, (int)(short)0, 1, (int)'4', (-1));
    testRational0.mysimp((int)(byte)100, (int)(byte)100, (int)(byte)10, (int)(short)10, (int)(byte)100, (int)(short)10);
    testRational0.mysimp(1, (int)' ', (int)(byte)100, (int)' ', (int)(short)100, (int)(byte)100);
    testRational0.mysimp((int)(byte)10, (int)(short)1, (int)'4', (int)(short)0, (int)(short)10, (int)(short)100);

  }

  @Test
  public void test463() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test463"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)10, (int)'#', 0, (-1));
    testRational0.mysimp((int)(byte)1, (int)(byte)100, (int)' ', (int)(short)0, (int)(short)100, 0);
    testRational0.mysimp(1, (int)(short)10, (int)(short)10, (int)(byte)1, (int)(short)1, (int)(short)100);
    testRational0.mysimp((int)(byte)(-1), 1, (int)(short)1, 100, (int)(short)0, 0);
    testRational0.mysimp(10, 100, 100, (int)(short)(-1), (int)' ', (int)(short)(-1));
    testRational0.mysimp((int)'4', (int)'a', 100, 1, (int)(byte)0, (int)' ');
    testRational0.mysimp(0, (int)(short)0, (int)(byte)100, 1, (int)(short)100, (int)(byte)(-1));
    testRational0.mysimp(0, (int)(byte)0, (int)(byte)0, (int)(byte)100, (int)'a', 0);
    testRational0.mysimp((int)(byte)10, (int)(byte)(-1), (int)'a', (int)'4', (int)(byte)1, (int)'#');
    testRational0.mysimp((int)(short)(-1), (int)(short)10, (int)(byte)0, 0, (int)'a', (int)(short)(-1));
    testRational0.mysimp(0, (int)(byte)10, 0, 10, (int)(byte)100, (int)(short)100);
    testRational0.mysimp((int)(byte)0, (int)'#', (int)'a', (int)' ', (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp(0, (int)(short)(-1), (int)(short)10, (int)(short)100, (int)'a', 0);

  }

  @Test
  public void test464() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test464"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'a', (int)(byte)0, 0, (int)(short)0, 0);
    testRational0.mysimp((int)(short)10, (int)(byte)0, (int)'a', (int)(byte)0, (int)(byte)0, (int)(byte)(-1));
    testRational0.mysimp((int)(byte)0, 0, (int)(short)10, (int)(short)1, (int)(short)1, (int)(short)(-1));
    testRational0.mysimp((int)'4', (int)(byte)10, (int)'4', 100, 0, (int)(byte)1);
    testRational0.mysimp((-1), (int)(short)(-1), (int)(byte)10, 100, (int)(short)1, (int)(byte)0);

  }

  @Test
  public void test465() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test465"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)10, (int)'#', 0, (-1));
    testRational0.mysimp((int)'#', (int)'a', (int)(byte)1, (int)' ', 0, (int)'4');
    testRational0.mysimp(0, (int)' ', 100, (int)'4', (int)'a', 0);
    testRational0.mysimp((-1), (int)(short)100, (int)' ', 0, (int)(byte)100, 0);
    testRational0.mysimp((int)'a', (int)(short)100, (-1), (int)(byte)(-1), 100, (int)(byte)100);
    testRational0.mysimp(1, (int)(byte)(-1), 10, 10, (int)'a', (int)(byte)0);

  }

  @Test
  public void test466() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test466"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'a', (int)(byte)0, 0, (int)(short)0, 0);
    testRational0.mysimp((int)(short)0, (int)(short)10, (-1), (int)(short)(-1), (int)(short)0, 0);
    testRational0.mysimp((int)(byte)10, (int)(byte)100, (int)(short)10, (int)(byte)0, (int)'4', (int)(short)10);
    testRational0.mysimp((int)(short)(-1), (int)(short)10, (int)(byte)1, 1, (int)(short)10, (int)' ');
    testRational0.mysimp(0, (int)(short)(-1), 10, (int)(short)10, (int)'a', (int)(byte)0);
    testRational0.mysimp((int)(byte)1, 10, 0, (int)(byte)10, 1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)(short)10, (int)(short)(-1), (int)(byte)(-1), (int)(byte)(-1), 0);

  }

  @Test
  public void test467() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test467"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'#', 1, (int)(short)10, (int)'4', (int)(short)1);
    testRational0.mysimp((-1), (int)(short)10, (int)(byte)1, (int)(short)10, (int)(byte)(-1), 0);
    testRational0.mysimp(1, (int)' ', (int)(short)100, (int)(short)100, (int)(byte)(-1), (int)(short)(-1));
    testRational0.mysimp(10, (int)(short)100, (int)(short)100, 0, (int)(short)1, (int)'#');
    testRational0.mysimp((int)'#', (int)(byte)0, (int)(byte)1, (int)'a', (int)(byte)1, (int)(byte)1);
    testRational0.mysimp((int)(byte)1, 1, 0, (int)(short)100, (int)'a', (-1));

  }

  @Test
  public void test468() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test468"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)1, 1, (int)(short)1, 0);
    testRational0.mysimp((int)(byte)100, (int)(byte)100, (int)(short)1, (int)(short)10, (int)(short)1, (int)(short)0);
    testRational0.mysimp(10, 0, 10, 0, (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp((int)'4', (int)(byte)1, (int)(short)1, 100, 10, (int)(short)100);
    testRational0.mysimp((int)(short)100, (int)(byte)100, (int)(short)10, (int)(short)0, (int)(short)0, (int)' ');

  }

  @Test
  public void test469() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test469"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)(short)(-1), 100, (int)(byte)10, (int)'4', (int)(short)(-1));
    testRational0.mysimp((int)' ', 1, (int)(byte)(-1), (int)(short)1, 10, (int)(byte)0);
    testRational0.mysimp((int)(short)100, (int)(byte)(-1), 0, 0, 100, 100);
    testRational0.mysimp((int)(short)100, 0, (int)(short)(-1), (int)(byte)100, (int)'4', (int)(byte)0);
    testRational0.mysimp((int)(short)(-1), (int)(short)100, 0, (int)(byte)0, 0, 100);
    testRational0.mysimp((int)'4', (int)(short)100, (int)(byte)10, (int)(byte)(-1), 0, 10);

  }

  @Test
  public void test470() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test470"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)(short)100, (int)(byte)1, (int)(byte)0, 100, (int)(short)100);
    testRational0.mysimp((int)(short)(-1), 0, (int)(short)0, 10, 0, (int)(byte)10);
    testRational0.mysimp(0, (int)'#', 100, (int)' ', (int)(short)0, (int)(byte)1);
    testRational0.mysimp((int)'#', (int)(byte)1, (int)(short)100, (int)(byte)10, (int)'4', 0);
    testRational0.mysimp((int)'a', 100, 100, (int)(short)1, 1, (int)(short)100);
    testRational0.mysimp((-1), (int)(byte)0, (int)(byte)100, (int)(byte)0, (int)(byte)10, (int)' ');

  }

  @Test
  public void test471() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test471"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'a', (int)(byte)0, 0, (int)(short)0, 0);
    testRational0.mysimp(100, (int)(byte)10, (int)(byte)10, 10, 0, (int)(short)1);
    testRational0.mysimp((int)(short)10, (int)(short)0, (int)'#', (int)(byte)(-1), (int)'a', 0);
    testRational0.mysimp(10, (int)'a', 0, (int)(short)100, (int)' ', (int)(short)(-1));
    testRational0.mysimp(0, 1, (int)(short)100, (int)(byte)10, (int)'a', (int)(short)100);
    testRational0.mysimp((int)(short)(-1), 100, (int)' ', 0, (int)(byte)1, (int)' ');

  }

  @Test
  public void test472() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test472"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 0, (-1), 100, (int)'a');
    testRational0.mysimp(10, (int)(short)0, 100, (int)'4', (-1), 0);
    testRational0.mysimp(0, (int)(byte)(-1), 100, (int)(short)1, (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp((int)(byte)0, (int)'4', 100, (int)(byte)1, (int)(byte)10, 0);
    testRational0.mysimp((int)(byte)0, 0, (int)(short)(-1), (int)'#', (int)(byte)0, (int)(short)1);
    testRational0.mysimp((int)(byte)0, 10, (int)'4', (int)(short)(-1), 1, (int)(byte)(-1));
    testRational0.mysimp((int)(short)100, (int)'a', 0, 10, 0, (int)(short)1);
    testRational0.mysimp((int)(short)1, 10, 0, 10, (int)(byte)1, (int)' ');
    testRational0.mysimp((int)(byte)1, (-1), (-1), (int)(short)1, 10, (int)(byte)(-1));
    testRational0.mysimp((int)(short)100, (int)(byte)1, 0, 1, (int)(byte)0, (int)(short)100);

  }

  @Test
  public void test473() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test473"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(10, (int)'a', (int)(short)10, (int)(short)(-1), (int)(byte)0, (int)'a');
    testRational0.mysimp((int)(byte)100, (int)(short)0, (int)'a', (int)(byte)(-1), 0, (int)(short)(-1));
    testRational0.mysimp((int)(byte)10, 0, (int)(short)(-1), (int)(short)1, 0, (int)(byte)0);
    testRational0.mysimp((int)(short)10, (-1), (int)(byte)0, 0, (int)(byte)0, (int)' ');
    testRational0.mysimp(0, (int)(short)1, (int)(byte)(-1), (int)(short)(-1), (int)(short)(-1), 0);
    testRational0.mysimp((int)(short)100, 100, (int)(short)100, (int)'4', 0, (int)(short)10);
    testRational0.mysimp(100, (int)(short)0, 1, (int)' ', (int)(short)10, (int)'a');
    testRational0.mysimp((int)(short)10, (int)(byte)100, (int)'a', 1, (int)(short)(-1), (int)(short)1);

  }

  @Test
  public void test474() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test474"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)(byte)100, (int)' ', 10, (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp((int)(byte)0, (int)'#', (int)'#', (int)(byte)0, (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp((int)(short)(-1), (int)' ', (int)'4', (int)(byte)1, (int)(byte)10, (int)(byte)100);

  }

  @Test
  public void test475() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test475"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp((int)(short)(-1), (int)(short)10, (int)(short)10, 0, (int)'4', (int)(byte)1);
    testRational0.mysimp((-1), (int)' ', (int)'a', (int)'4', (int)(short)0, (-1));
    testRational0.mysimp((int)(short)100, (int)'4', (int)(short)100, 1, (int)(byte)100, (int)(byte)10);
    testRational0.mysimp((int)(short)1, (int)(byte)1, (int)(byte)10, (-1), (int)(byte)(-1), (-1));
    testRational0.mysimp((int)(short)0, (-1), 1, 100, (int)'#', (int)(byte)10);
    testRational0.mysimp(0, (int)'a', 0, (int)(short)0, (int)(short)0, (int)(short)1);

  }

  @Test
  public void test476() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test476"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(10, (int)(byte)100, (int)(byte)10, (int)(short)0, (int)(byte)0, (int)' ');
    testRational0.mysimp((int)(short)10, (int)(byte)10, (int)(short)100, (int)(byte)0, (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp((int)(short)(-1), (int)'#', (int)'#', (int)(short)10, (int)(byte)0, (int)(byte)100);
    testRational0.mysimp((int)(byte)1, 10, (int)(short)0, (int)(byte)1, 0, 0);
    testRational0.mysimp((int)(byte)10, 0, (-1), (int)(byte)1, 0, (int)(short)10);
    testRational0.mysimp((int)(byte)(-1), (int)(short)100, 100, (int)(short)1, (int)(short)(-1), (int)'#');
    testRational0.mysimp((int)'4', (int)'4', (int)(short)1, 1, (int)(short)100, 10);

  }

  @Test
  public void test477() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test477"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'#', 1, (int)(short)10, (int)'4', (int)(short)1);
    testRational0.mysimp((-1), (int)(short)10, (int)(byte)1, (int)(short)10, (int)(byte)(-1), 0);
    testRational0.mysimp(1, (int)' ', (int)(short)100, (int)(short)100, (int)(byte)(-1), (int)(short)(-1));
    testRational0.mysimp(0, (int)(byte)(-1), (int)'4', (int)(byte)10, (int)(byte)0, 100);
    testRational0.mysimp((int)(short)0, (int)(byte)100, (int)(byte)0, (int)(short)(-1), (int)'#', (int)(short)10);
    testRational0.mysimp((int)(short)100, (int)'4', (int)(short)100, (int)(short)1, (int)(byte)0, (int)'4');
    testRational0.mysimp((int)' ', 0, (-1), (int)(short)1, 10, (int)(short)0);

  }

  @Test
  public void test478() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test478"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)1, 1, (int)(short)1, 0);
    testRational0.mysimp((int)(byte)100, (int)(byte)100, (int)(short)1, (int)(short)10, (int)(short)1, (int)(short)0);
    testRational0.mysimp((int)(short)0, (int)(short)100, 100, 0, (int)(short)(-1), (int)(short)10);
    testRational0.mysimp(100, 0, (-1), (int)(byte)(-1), (int)(byte)100, (int)(byte)10);
    testRational0.mysimp((int)(byte)(-1), (int)(byte)1, 0, 0, (-1), (int)(short)100);
    testRational0.mysimp((int)(byte)0, (int)'#', (int)(short)1, (int)'4', (-1), 100);
    testRational0.mysimp((int)(short)100, (int)'4', (-1), (int)(byte)(-1), (int)' ', (int)(byte)100);
    testRational0.mysimp((int)(byte)100, 0, (int)'a', (int)(byte)10, (int)(byte)(-1), (-1));

  }

  @Test
  public void test479() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test479"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, 100, 100);
    testRational0.mysimp((int)(byte)(-1), (int)'a', (-1), (int)'4', (-1), (int)(byte)0);
    testRational0.mysimp((int)' ', 0, (int)'#', (int)(short)100, (int)(short)0, 100);
    testRational0.mysimp((int)'a', (int)(short)1, 1, (int)'4', (int)'4', 10);
    testRational0.mysimp((-1), 0, (int)'4', (-1), (int)(byte)0, (int)(short)1);
    testRational0.mysimp(10, 0, (int)(byte)100, (int)(byte)10, (int)(short)1, (int)'#');
    testRational0.mysimp((int)(byte)1, (int)(byte)10, (int)'#', (int)(byte)10, (int)(short)100, 1);
    testRational0.mysimp((int)(byte)1, (int)'a', 100, (int)'#', (int)'#', 0);
    testRational0.mysimp((int)'#', (int)(byte)10, (int)(byte)1, (int)(short)1, (int)(short)1, (int)(short)1);
    testRational0.mysimp((int)(short)(-1), (int)(short)100, (int)(byte)(-1), (int)(short)1, 10, 10);

  }

  @Test
  public void test480() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test480"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(10, (int)(short)100, (int)(short)10, (int)(short)100, (int)(byte)10, 0);
    testRational0.mysimp((int)(byte)10, (int)(byte)10, (int)(byte)0, (int)'#', (int)(short)0, 0);
    testRational0.mysimp((int)' ', (int)'#', (int)(short)0, 1, (int)'#', (int)'4');
    testRational0.mysimp(0, (int)(short)0, (int)(short)0, (int)' ', 0, (int)(byte)100);
    testRational0.mysimp(0, (int)'#', (int)(byte)(-1), (int)(byte)100, 0, 0);
    testRational0.mysimp((int)(short)100, (-1), (int)(short)10, (int)(short)0, (int)(byte)0, 1);
    testRational0.mysimp(100, (int)(byte)0, (int)(short)(-1), (int)(byte)10, (int)'#', (int)(byte)100);
    testRational0.mysimp((int)(byte)(-1), 0, 100, (int)(short)1, 10, 1);
    testRational0.mysimp((int)(short)1, (int)(byte)(-1), (-1), (int)(byte)10, 100, (int)(short)(-1));

  }

  @Test
  public void test481() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test481"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)1, 1, (int)(short)1, 0);
    testRational0.mysimp((int)' ', (int)' ', (int)(byte)10, (int)'4', (int)'4', (int)(short)10);
    testRational0.mysimp((int)(short)1, (int)'4', (int)(short)10, (int)'#', (int)'#', (int)(short)100);
    testRational0.mysimp((int)(short)10, (int)(byte)0, 100, (-1), (int)'4', (int)(byte)0);
    testRational0.mysimp((int)(short)100, 100, (-1), (int)(short)100, (int)(byte)10, (int)'a');
    testRational0.mysimp((int)'#', (int)(short)1, (int)'#', (int)(byte)0, 0, (int)'4');
    testRational0.mysimp(1, (int)(byte)0, (int)(byte)1, (-1), 100, (int)(short)1);

  }

  @Test
  public void test482() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test482"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp((int)(short)(-1), (int)(short)10, (int)(short)10, 0, (int)'4', (int)(byte)1);
    testRational0.mysimp((-1), (int)' ', (int)'a', (int)'4', (int)(short)0, (-1));
    testRational0.mysimp((int)(short)1, 0, (int)' ', (int)'#', (int)'#', 10);
    testRational0.mysimp((-1), (-1), (-1), (int)(short)10, (int)(byte)100, (int)(short)100);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)(short)10, (int)'#', (int)(short)(-1), (int)'4');
    testRational0.mysimp((int)' ', (int)(short)1, (int)(short)10, (int)(byte)(-1), (int)(byte)100, (int)(byte)0);
    testRational0.mysimp((int)'4', (int)(byte)100, (int)(short)100, (int)(short)1, (int)'4', (int)'4');
    testRational0.mysimp((int)(short)1, (int)(short)0, (int)'a', 100, (int)(short)10, (int)(short)10);
    testRational0.mysimp(0, (int)(byte)0, (int)(byte)100, (int)(byte)0, 1, 1);

  }

  @Test
  public void test483() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test483"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)1, (int)(short)10, 0, 1, (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp((int)(short)(-1), 100, (int)(short)0, (int)(byte)1, (int)'4', (int)(short)10);
    testRational0.mysimp((int)(short)(-1), (int)(short)(-1), 100, (int)(byte)0, 10, (int)(short)0);
    testRational0.mysimp((-1), (int)(short)10, (int)(byte)1, (int)(byte)100, 1, (int)'4');
    testRational0.mysimp((int)'4', 0, (int)(short)100, (int)(byte)1, (-1), (int)'a');
    testRational0.mysimp((int)(short)1, 100, (int)(byte)0, (-1), (int)'4', (int)(byte)(-1));
    testRational0.mysimp((int)'a', 0, (-1), 0, (int)(short)1, (int)'4');

  }

  @Test
  public void test484() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test484"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)(byte)0, (int)(byte)(-1), (int)'a', 100, (int)' ', (int)(short)(-1));
    testRational0.mysimp((int)(short)100, (int)(byte)1, (int)(short)0, 1, (int)(short)100, (int)(byte)10);
    testRational0.mysimp((int)(byte)100, (int)(byte)10, 0, (int)'4', 0, (int)(byte)(-1));
    testRational0.mysimp((int)(short)(-1), 0, (-1), 1, 0, (int)(byte)0);
    testRational0.mysimp((int)' ', (int)(short)0, (int)(byte)100, (int)'#', 100, (int)(short)10);

  }

  @Test
  public void test485() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test485"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)(byte)100, (int)' ', 10, (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp((int)' ', 1, 1, (int)'a', 0, (int)'#');
    testRational0.mysimp((int)(short)1, (int)'#', (int)(short)(-1), (-1), 100, (int)(byte)100);
    testRational0.mysimp(10, (int)(short)100, (int)(byte)10, 1, (int)'a', 1);
    testRational0.mysimp((int)' ', (int)(short)100, 0, (int)'4', 0, (int)(byte)1);

  }

  @Test
  public void test486() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test486"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)10, (int)'#', 0, (-1));
    testRational0.mysimp((int)(byte)1, (int)(byte)100, (int)' ', (int)(short)0, (int)(short)100, 0);
    testRational0.mysimp(1, (int)(short)10, (int)(short)10, (int)(byte)1, (int)(short)1, (int)(short)100);
    testRational0.mysimp((int)(byte)(-1), 1, (int)(short)1, 100, (int)(short)0, 0);
    testRational0.mysimp(10, 100, 100, (int)(short)(-1), (int)' ', (int)(short)(-1));
    testRational0.mysimp((int)'4', (int)'a', 100, 1, (int)(byte)0, (int)' ');
    testRational0.mysimp(0, (int)(short)0, (int)(byte)100, 1, (int)(short)100, (int)(byte)(-1));
    testRational0.mysimp(100, (int)'a', (int)(byte)0, (int)(short)(-1), 100, (int)'#');
    testRational0.mysimp((int)(short)0, (int)'4', (int)'#', (int)'4', 10, (int)(byte)(-1));
    testRational0.mysimp((int)(short)1, (int)(short)10, 0, (int)(byte)100, (-1), (int)(short)0);

  }

  @Test
  public void test487() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test487"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)' ', 10, (int)' ', (int)(short)0, 0, (int)(short)1);
    testRational0.mysimp((int)'#', 100, (-1), 1, (-1), (int)(byte)(-1));
    testRational0.mysimp((int)(short)(-1), (int)'#', (int)(short)1, (int)(short)10, (int)(byte)1, 100);
    testRational0.mysimp((int)(short)0, (int)(byte)1, (int)(byte)1, (int)'a', 1, (int)(short)10);
    testRational0.mysimp(0, (int)(byte)10, (int)' ', (int)(short)100, 1, (int)(short)(-1));
    testRational0.mysimp((int)(byte)100, 1, (int)(short)0, (int)'4', (int)' ', 100);

  }

  @Test
  public void test488() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test488"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)1, (int)' ', (int)(short)1, 1, (int)(short)1, 0);
    testRational0.mysimp((int)(byte)100, (int)(byte)100, (int)(short)1, (int)(short)10, (int)(short)1, (int)(short)0);
    testRational0.mysimp((int)'a', (int)(short)0, (int)(byte)1, (int)(byte)10, (int)(byte)100, 0);
    testRational0.mysimp((int)(byte)100, 1, (int)(short)1, (int)'4', (int)(byte)100, (int)(short)100);
    testRational0.mysimp(0, 0, (-1), (int)(short)100, (int)(byte)1, (-1));
    testRational0.mysimp(0, 1, (int)(byte)(-1), (int)(byte)1, (int)(short)(-1), 10);
    testRational0.mysimp((int)' ', 100, (int)'#', (int)' ', (int)(short)100, (int)(short)10);
    testRational0.mysimp((-1), 0, (-1), 0, (int)(short)0, (int)(short)1);
    testRational0.mysimp((int)(short)(-1), (int)(byte)100, (int)(byte)100, 0, (int)(short)0, (int)(short)1);

  }

  @Test
  public void test489() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test489"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)1, (int)(short)10, 0, 1, (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp((int)(short)(-1), 100, (int)(short)0, (int)(byte)1, (int)'4', (int)(short)10);
    testRational0.mysimp((int)(short)(-1), (int)(short)(-1), 100, (int)(byte)0, 10, (int)(short)0);
    testRational0.mysimp((int)(byte)10, (int)'a', (int)(byte)1, (int)(short)0, (int)(short)(-1), 0);
    testRational0.mysimp((int)'a', (-1), (int)(short)1, (int)'#', (int)(byte)100, (int)(short)1);
    testRational0.mysimp((int)(byte)10, (int)(short)10, (int)(byte)10, (int)(byte)100, 1, (int)(short)0);
    testRational0.mysimp((int)'#', (int)(byte)10, (-1), (int)(byte)1, 100, (int)' ');
    testRational0.mysimp((int)'#', 10, 100, (int)'4', (int)(short)1, (-1));
    testRational0.mysimp(10, 0, 0, (int)(short)10, (int)(short)10, 1);
    testRational0.mysimp(0, (int)(byte)(-1), (int)(byte)1, (int)(byte)10, 100, (int)(byte)(-1));

  }

  @Test
  public void test490() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test490"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)1, (int)(short)10, 0, 1, (int)(short)(-1), (int)(byte)100);
    testRational0.mysimp((int)(short)(-1), 100, (int)(short)0, (int)(byte)1, (int)'4', (int)(short)10);
    testRational0.mysimp((int)(short)(-1), (int)(short)(-1), 100, (int)(byte)0, 10, (int)(short)0);
    testRational0.mysimp((-1), (int)(short)10, (int)(byte)1, (int)(byte)100, 1, (int)'4');
    testRational0.mysimp((int)(byte)0, (int)(byte)1, (int)(short)100, (int)(byte)(-1), (int)'a', (int)'#');
    testRational0.mysimp(0, (int)(byte)100, 0, 100, (int)(short)1, (int)'#');
    testRational0.mysimp(0, 1, (int)(short)10, (int)(short)(-1), 1, (int)'a');

  }

  @Test
  public void test491() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test491"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)'a', (int)(byte)(-1), (int)' ', (int)'#', (int)(short)1);
    testRational0.mysimp((int)(byte)1, 1, (int)(short)1, (int)(short)100, (int)(byte)(-1), (int)'#');
    testRational0.mysimp(0, (int)(short)1, (int)(short)100, 100, (int)(byte)100, (int)'4');
    testRational0.mysimp((int)'#', (int)(short)0, 0, (int)(short)0, (int)(byte)10, (int)(short)10);
    testRational0.mysimp((int)(short)0, (int)'4', (int)(byte)1, (int)' ', (int)'#', 100);

  }

  @Test
  public void test492() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test492"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(0, (int)(byte)10, (int)(byte)0, 1, 100, 100);
    testRational0.mysimp(0, (int)'4', (int)' ', (int)(byte)100, (int)(byte)1, (int)(short)100);
    testRational0.mysimp((int)(byte)0, (int)(byte)100, (int)(byte)100, (int)'4', (int)(short)0, (int)(short)(-1));
    testRational0.mysimp((-1), (-1), (int)'4', (int)(byte)100, 0, (int)(short)0);
    testRational0.mysimp((-1), (int)'4', (-1), (int)' ', (int)(short)10, (int)(short)1);

  }

  @Test
  public void test493() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test493"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp((int)(byte)100, (int)(byte)0, 1, (int)(byte)10, (int)(short)100, 1);
    testRational0.mysimp((int)'#', (int)(byte)0, (int)(byte)100, (int)(byte)10, (int)'4', (int)(byte)(-1));
    testRational0.mysimp((int)(short)0, (int)(byte)10, (int)(byte)10, (int)(byte)10, (-1), 0);
    testRational0.mysimp((int)'4', (int)' ', (int)(short)(-1), (int)(short)100, (int)'4', (int)(short)1);
    testRational0.mysimp((int)(short)100, (int)'4', (int)(short)1, (int)' ', (int)'#', (int)(byte)100);
    testRational0.mysimp(1, (-1), (-1), 100, (int)(byte)1, 0);
    testRational0.mysimp((int)(byte)(-1), (int)(byte)(-1), (int)(byte)(-1), (-1), (int)(short)100, 100);
    testRational0.mysimp(1, (int)(short)(-1), 100, 100, (int)' ', (int)'a');

  }

  @Test
  public void test494() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test494"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp(100, 10, (int)(short)10, (int)' ', 0, (int)(short)0);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(byte)(-1), (int)(short)1, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4');
    testRational0.mysimp(1, (int)(short)0, (int)(short)100, (int)(byte)(-1), (int)(short)10, (int)(short)(-1));
    testRational0.mysimp(0, (int)'#', 1, (int)(short)10, (int)'4', (int)(short)1);
    testRational0.mysimp((-1), (int)(short)10, (int)(byte)1, (int)(short)10, (int)(byte)(-1), 0);
    testRational0.mysimp(1, (int)' ', (int)(short)100, (int)(short)100, (int)(byte)(-1), (int)(short)(-1));
    testRational0.mysimp((-1), 100, (int)'a', (int)(short)10, 0, (int)(byte)(-1));
    testRational0.mysimp((int)(byte)0, 100, (int)(byte)1, (int)'#', (int)(byte)100, (int)(short)0);
    testRational0.mysimp(100, (int)(short)(-1), (int)'4', (int)'a', (int)(byte)100, 10);

  }

  @Test
  public void test495() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test495"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)'4', (int)(short)10, 0, (int)(short)10, 100, (int)(byte)1);
    testRational0.mysimp((int)(short)0, (int)(byte)100, (int)' ', 10, (int)(short)(-1), (int)(byte)0);
    testRational0.mysimp((int)' ', 1, 1, (int)'a', 0, (int)'#');
    testRational0.mysimp((int)(short)1, (int)'#', (int)(short)(-1), (-1), 100, (int)(byte)100);
    testRational0.mysimp(0, (int)'a', 10, (int)'a', (int)(byte)100, 1);
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, 10, (int)(short)0, 1, (int)(short)0);

  }

  @Test
  public void test496() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test496"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp(10, (int)(short)1, (int)(short)10, (int)(byte)10, (int)(byte)0, 1);
    testRational0.mysimp((int)(byte)0, (int)'#', 0, (int)(short)10, (int)(byte)0, (int)'#');
    testRational0.mysimp((int)'4', (int)(short)100, 100, 0, (int)(byte)100, 0);
    testRational0.mysimp(100, (int)' ', 100, (int)(short)100, 0, (int)(short)10);
    testRational0.mysimp((int)(short)(-1), 100, 1, (int)(byte)1, (int)(short)100, (int)(byte)(-1));
    testRational0.mysimp((int)(short)0, (int)(short)(-1), (int)(byte)10, (int)(byte)10, (int)(short)0, 100);
    testRational0.mysimp((int)(byte)10, (int)' ', (int)'a', (int)'4', (int)(byte)0, (int)(short)1);
    testRational0.mysimp((int)(short)100, 1, (int)(short)1, (int)'4', 1, (int)(short)10);
    testRational0.mysimp((int)(short)1, 0, 100, 10, (int)(byte)0, (int)' ');

  }

  @Test
  public void test497() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test497"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp((int)(short)1, (int)(byte)10, (int)(byte)100, 1, (int)(byte)10, (int)(byte)(-1));
    testRational0.mysimp((int)(short)100, 0, (int)'4', (int)'4', (int)(short)1, (int)(byte)(-1));
    testRational0.mysimp(100, (int)(short)0, 100, (int)(short)0, (int)'#', 0);
    testRational0.mysimp((int)'4', (int)'4', (int)(byte)0, (int)(short)100, (int)(short)(-1), (int)(byte)10);
    testRational0.mysimp((int)' ', (int)(short)1, 10, (int)(byte)10, 1, 100);
    testRational0.mysimp(1, (int)'a', 10, (int)(byte)(-1), (-1), (-1));

  }

  @Test
  public void test498() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test498"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 0, (-1), 100, (int)'a');
    testRational0.mysimp(10, (int)(short)0, 100, (int)'4', (-1), 0);
    testRational0.mysimp(0, (int)(byte)(-1), 100, (int)(short)1, (int)(byte)(-1), (int)(byte)(-1));
    testRational0.mysimp((int)(byte)0, (int)'4', 100, (int)(byte)1, (int)(byte)10, 0);
    testRational0.mysimp((int)(byte)0, 0, (int)(short)(-1), (int)'#', (int)(byte)0, (int)(short)1);
    testRational0.mysimp((int)(byte)0, 10, (int)'4', (int)(short)(-1), 1, (int)(byte)(-1));
    testRational0.mysimp((int)(short)100, (int)'a', 0, 10, 0, (int)(short)1);
    testRational0.mysimp((int)(short)100, (int)(byte)1, (int)(byte)0, (int)(short)1, (int)(byte)100, (int)(short)(-1));
    testRational0.mysimp((-1), (int)' ', (int)'a', (-1), (int)(short)1, (int)(short)100);
    testRational0.mysimp(10, (int)(byte)0, (int)(short)(-1), (int)' ', 10, (int)(byte)(-1));
    testRational0.mysimp(0, 100, (int)(byte)1, (int)(short)10, (int)(byte)10, 0);
    testRational0.mysimp((int)'4', (int)(byte)10, (int)(short)(-1), (int)(short)100, 0, (int)(short)1);

  }

  @Test
  public void test499() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test499"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(short)(-1), (int)(byte)10, 0, (-1), 100, (int)'a');
    testRational0.mysimp(0, (int)'4', (int)(byte)0, (int)(short)0, 0, (int)(short)100);
    testRational0.mysimp((int)(short)1, (int)(short)(-1), (int)(short)0, 0, 10, (int)(byte)0);
    testRational0.mysimp(1, (int)(short)(-1), (int)(byte)10, (int)(byte)0, (int)(byte)100, (int)(short)1);
    testRational0.mysimp((-1), (int)'4', (int)'4', 10, (int)'4', 0);
    testRational0.mysimp(100, (int)(byte)1, (int)(short)100, (int)'a', (int)(byte)100, (int)(byte)10);
    testRational0.mysimp(1, 10, (int)(byte)0, (int)(short)10, 0, (int)(byte)1);
    testRational0.mysimp(100, (int)(short)0, (int)' ', 0, (int)(byte)0, (-1));

  }

  @Test
  public void test500() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest8.test500"); }


    edu.utexas.testsource.TestRational testRational0 = new edu.utexas.testsource.TestRational();
    testRational0.mysimp((int)(short)(-1), (int)'4', (int)(short)1, (int)'a', (int)'#', 1);
    testRational0.mysimp(100, (int)(short)1, 0, 0, (int)(short)0, (int)'a');
    testRational0.mysimp((int)(byte)(-1), (int)(short)1, (int)'4', (int)(byte)1, (int)(short)10, (int)'4');
    testRational0.mysimp((int)(short)(-1), (int)(short)10, (int)' ', 0, (int)(byte)100, (int)' ');
    testRational0.mysimp((int)' ', 0, (int)(byte)100, 100, (int)(byte)10, 0);
    testRational0.mysimp(0, (int)(byte)(-1), 1, (int)(byte)1, (int)(byte)(-1), (int)'a');
    testRational0.mysimp((int)(byte)10, 10, (int)(byte)(-1), (-1), (int)(byte)100, 0);
    testRational0.mysimp(10, (int)(byte)0, 10, (int)(short)(-1), (int)(short)0, 10);
    testRational0.mysimp(1, (int)'4', (int)'#', (int)'4', 0, (int)(short)(-1));
    testRational0.mysimp((int)(short)10, (int)'a', 0, 0, (int)' ', (int)(byte)(-1));
    testRational0.mysimp((int)(short)1, (int)(short)1, (int)(short)(-1), 0, (int)(short)100, 1);
    testRational0.mysimp((int)(short)0, (int)(byte)100, 0, (int)'#', (int)(byte)10, (int)(short)10);

  }

}
