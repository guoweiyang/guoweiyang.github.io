
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

  public static boolean debug = false;

  @Test
  public void test01() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest2.test01"); }


    tcas.TestTCAS testTCAS0 = new tcas.TestTCAS();
    int i13 = testTCAS0.run((int)(short)0, false, false, (int)'#', (int)(short)0, 0, (int)'#', (int)(byte)100, (int)(short)(-1), (int)(byte)10, 0, true);
    int i26 = testTCAS0.run((int)' ', true, true, (int)(short)0, 100, 100, 10, (int)(short)10, (int)' ', 0, (int)(short)0, false);
    int i39 = testTCAS0.run((int)(short)(-1), false, true, 0, (int)(short)10, (int)(byte)10, (int)(byte)10, (-1), (int)(short)(-1), (int)(byte)0, (int)(byte)1, false);
    int i52 = testTCAS0.run((int)(byte)(-1), false, false, (int)(short)100, 0, (int)(byte)0, 10, 0, (int)(short)0, 1, (int)'#', false);
    int i65 = testTCAS0.run((int)'#', true, false, (int)'#', 0, (int)(short)10, 0, (int)(short)10, (int)' ', (int)' ', 1, false);
    int i78 = testTCAS0.run((int)' ', true, false, (int)(short)0, (-1), (int)(short)100, (int)(short)1, (int)(short)100, (int)(short)100, (int)(short)1, 1, true);
    int i91 = testTCAS0.run(0, true, true, (-1), 100, (int)(byte)10, 10, 0, (int)' ', (int)(short)0, 1, true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i52 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i65 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i78 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i91 == 0);

  }

  @Test
  public void test02() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest2.test02"); }


    tcas.TestTCAS testTCAS0 = new tcas.TestTCAS();
    int i13 = testTCAS0.run((int)(short)0, false, false, (int)'#', (int)(short)0, 0, (int)'#', (int)(byte)100, (int)(short)(-1), (int)(byte)10, 0, true);
    int i26 = testTCAS0.run((int)'a', true, false, (int)(byte)(-1), (int)'4', (int)(byte)100, (int)(byte)1, (int)(short)100, (int)(byte)1, (int)' ', 10, false);
    int i39 = testTCAS0.run((int)'#', false, false, (int)'a', (int)(byte)0, 10, (int)(byte)100, (int)'a', (int)' ', (int)' ', (int)(byte)0, false);
    int i52 = testTCAS0.run((int)(short)(-1), false, false, 100, (int)(byte)100, (int)'a', (int)(byte)(-1), (-1), (int)(short)100, (int)(byte)1, 1, false);
    int i65 = testTCAS0.run(1, false, false, 1, (int)'a', (int)(byte)1, 100, (int)'#', (int)(byte)10, (int)(short)10, (int)' ', true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i52 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i65 == 0);

  }

  @Test
  public void test03() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest2.test03"); }


    tcas.TestTCAS testTCAS0 = new tcas.TestTCAS();
    int i13 = testTCAS0.run((int)(short)(-1), true, false, (int)'a', (int)'#', 1, (int)(short)100, (int)(byte)0, 1, (int)(short)(-1), 0, true);
    int i26 = testTCAS0.run((int)'a', false, false, (int)' ', (int)(short)0, 0, (int)(short)1, (int)(byte)10, (int)'#', (int)'a', 100, true);
    int i39 = testTCAS0.run(1, false, true, (int)(short)0, (int)'#', (int)(short)(-1), (int)'#', (-1), (int)'4', (int)'#', (int)'a', true);
    int i52 = testTCAS0.run((int)(short)100, false, true, 0, (int)(byte)0, (int)'#', (int)(byte)100, (int)(short)0, (int)'4', (int)(short)100, 0, false);
    int i65 = testTCAS0.run((int)(byte)0, false, false, (int)(byte)1, (int)(byte)100, (int)(short)(-1), (int)(byte)100, (int)'4', (int)(short)10, 0, 10, true);
    int i78 = testTCAS0.run(0, false, false, (int)(byte)1, (int)(short)0, (int)(short)0, (int)'4', (int)(byte)1, (int)(short)10, (int)(byte)10, (int)(short)10, true);
    int i91 = testTCAS0.run(1, true, true, (int)(byte)10, (int)' ', (int)(byte)100, (int)(short)100, (int)(short)(-1), (int)(short)(-1), (int)(short)(-1), (int)(byte)1, true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i52 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i65 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i78 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i91 == 0);

  }

  @Test
  public void test04() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest2.test04"); }


    tcas.TestTCAS testTCAS0 = new tcas.TestTCAS();
    int i13 = testTCAS0.run((int)(short)0, false, false, (int)'#', (int)(short)0, 0, (int)'#', (int)(byte)100, (int)(short)(-1), (int)(byte)10, 0, true);
    int i26 = testTCAS0.run((int)(short)0, true, false, (int)(byte)100, (-1), (-1), (int)(short)100, (int)(short)10, 100, 10, (int)(byte)10, false);
    int i39 = testTCAS0.run((int)(short)10, false, true, (int)(byte)10, (int)(byte)0, (int)(byte)100, 0, (int)' ', (int)(byte)0, (-1), (int)(byte)0, true);
    int i52 = testTCAS0.run((int)' ', true, false, (int)(byte)0, (int)(byte)1, (int)(short)10, (int)'#', 10, 100, (int)(short)1, (int)' ', true);
    int i65 = testTCAS0.run(0, true, true, (int)(short)1, 1, (int)(short)100, (int)(byte)1, (int)' ', 1, 0, (int)(short)1, true);
    int i78 = testTCAS0.run((-1), true, false, (int)'a', (int)'#', (int)(byte)100, (int)'a', 0, (int)(short)10, 0, (int)(byte)(-1), true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i52 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i65 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i78 == 0);

  }

  @Test
  public void test05() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest2.test05"); }


    tcas.TestTCAS testTCAS0 = new tcas.TestTCAS();
    int i13 = testTCAS0.run((int)(short)0, false, false, (int)'#', (int)(short)0, 0, (int)'#', (int)(byte)100, (int)(short)(-1), (int)(byte)10, 0, true);
    int i26 = testTCAS0.run(100, false, false, 0, 10, (int)(byte)10, 0, (int)(byte)1, (int)'#', (int)(byte)(-1), (int)(byte)10, false);
    int i39 = testTCAS0.run((int)'4', true, false, 0, (int)(byte)100, (int)(byte)100, (int)' ', (int)'4', (int)(byte)100, (int)(short)100, (int)(byte)(-1), false);
    int i52 = testTCAS0.run(1, true, false, (int)(short)100, 100, 0, (-1), (int)' ', 10, 100, (int)(byte)0, false);
    int i65 = testTCAS0.run(0, false, false, (int)(short)0, (int)(byte)10, 1, (int)(byte)100, 0, 100, (int)'#', (int)(short)100, false);
    int i78 = testTCAS0.run((int)(byte)(-1), true, true, (int)(short)0, (int)(byte)1, (int)'a', 100, (int)' ', (int)' ', (int)'#', (int)(byte)0, false);
    int i91 = testTCAS0.run(100, false, false, 100, (int)(short)10, (int)' ', (int)(short)(-1), 100, (int)'a', (int)'a', 0, true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i52 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i65 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i78 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i91 == 0);

  }

  @Test
  public void test06() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest2.test06"); }


    tcas.TestTCAS testTCAS0 = new tcas.TestTCAS();
    int i13 = testTCAS0.run((int)(short)(-1), true, false, (int)'a', (int)'#', 1, (int)(short)100, (int)(byte)0, 1, (int)(short)(-1), 0, true);
    int i26 = testTCAS0.run((int)(short)1, false, true, (int)(short)100, (int)(byte)10, (-1), (int)(short)10, (int)(short)1, (int)(byte)100, (int)(short)100, (int)' ', false);
    int i39 = testTCAS0.run((int)'4', false, true, (int)(byte)10, 1, (int)' ', 100, (int)(short)100, 0, 1, (int)'a', false);
    int i52 = testTCAS0.run((int)(short)10, false, false, (int)(byte)0, 10, (int)' ', (int)'a', (int)(byte)(-1), (int)(byte)(-1), 1, (int)'4', false);
    int i65 = testTCAS0.run((-1), false, false, (int)(short)(-1), 10, (int)(short)10, (int)(byte)10, 0, (int)(byte)100, (int)'a', (int)'#', false);
    int i78 = testTCAS0.run(10, true, false, (int)'a', (int)(short)0, (int)(byte)10, (int)(short)10, (int)'#', (int)(byte)10, (int)(short)100, (int)(short)1, true);
    int i91 = testTCAS0.run(100, false, true, 0, (int)(short)10, (int)(short)100, (int)(byte)10, (-1), (int)'#', (int)' ', 0, false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i52 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i65 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i78 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i91 == 0);

  }

  @Test
  public void test07() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest2.test07"); }


    tcas.TestTCAS testTCAS0 = new tcas.TestTCAS();
    int i13 = testTCAS0.run((int)(short)0, false, false, (int)'#', (int)(short)0, 0, (int)'#', (int)(byte)100, (int)(short)(-1), (int)(byte)10, 0, true);
    int i26 = testTCAS0.run((int)(byte)1, false, false, (int)(short)100, (int)(byte)100, (int)(byte)(-1), (int)'4', (int)(byte)1, (int)(short)1, (int)(byte)1, (int)'4', false);
    int i39 = testTCAS0.run((int)(short)(-1), true, true, 1, 0, (int)(short)(-1), (int)(short)0, (int)(byte)0, (int)' ', 1, (int)(short)100, true);
    int i52 = testTCAS0.run((int)(byte)10, false, true, (int)(byte)1, (int)(short)1, (int)(byte)0, 100, (int)(byte)10, (int)(short)1, (int)(byte)10, (-1), false);
    int i65 = testTCAS0.run((int)' ', true, false, (int)(short)0, 10, (int)(byte)(-1), (int)'a', 10, (-1), (int)'#', (int)(byte)0, true);
    int i78 = testTCAS0.run((int)(short)10, false, false, (int)(short)1, (int)' ', (int)(byte)0, (int)(short)(-1), 1, (int)(byte)(-1), 10, 0, false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i52 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i65 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i78 == 0);

  }

  @Test
  public void test08() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest2.test08"); }


    tcas.TestTCAS testTCAS0 = new tcas.TestTCAS();
    int i13 = testTCAS0.run((int)'a', true, false, (int)(byte)10, (int)(byte)10, 0, (int)(short)(-1), 0, 0, (int)'#', 100, false);
    int i26 = testTCAS0.run((int)(short)1, false, false, 1, (int)(byte)100, (int)(short)0, (int)(short)0, (int)(short)0, (int)' ', 0, (int)(byte)100, true);
    int i39 = testTCAS0.run((int)(short)1, true, false, (int)'#', (int)'#', 10, (-1), (int)(short)1, (int)(short)0, (int)(short)1, (int)(short)10, true);
    int i52 = testTCAS0.run((int)(byte)100, false, false, (int)(byte)100, (int)'#', 0, (int)(byte)10, (int)(short)1, (int)'4', 10, 0, false);
    int i65 = testTCAS0.run((int)'a', true, true, (int)'4', (int)(short)10, (int)(short)1, (int)(byte)100, 10, (int)(byte)0, (int)(byte)(-1), 10, false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i52 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i65 == 0);

  }

  @Test
  public void test09() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest2.test09"); }


    tcas.TestTCAS testTCAS0 = new tcas.TestTCAS();
    int i13 = testTCAS0.run((int)(short)0, false, false, (int)'#', (int)(short)0, 0, (int)'#', (int)(byte)100, (int)(short)(-1), (int)(byte)10, 0, true);
    int i26 = testTCAS0.run((int)(byte)1, false, false, (int)(short)100, (int)(byte)100, (int)(byte)(-1), (int)'4', (int)(byte)1, (int)(short)1, (int)(byte)1, (int)'4', false);
    int i39 = testTCAS0.run((int)'4', false, true, 0, (int)(byte)0, (int)'4', (int)'4', 0, (int)'4', 1, (int)' ', true);
    int i52 = testTCAS0.run(0, true, true, 0, (int)(byte)0, (int)'4', (int)'#', 10, (int)(byte)(-1), 0, (int)(short)1, false);
    int i65 = testTCAS0.run((int)'4', true, true, (int)(byte)10, 10, (int)(short)(-1), (int)'4', (int)(byte)100, 0, (int)'#', (int)'#', true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i52 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i65 == 0);

  }

  @Test
  public void test10() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest2.test10"); }


    tcas.TestTCAS testTCAS0 = new tcas.TestTCAS();
    int i13 = testTCAS0.run((int)(short)(-1), true, false, (int)'a', (int)'#', 1, (int)(short)100, (int)(byte)0, 1, (int)(short)(-1), 0, true);
    int i26 = testTCAS0.run((int)'a', false, false, (int)' ', (int)(short)0, 0, (int)(short)1, (int)(byte)10, (int)'#', (int)'a', 100, true);
    int i39 = testTCAS0.run((int)(short)(-1), false, false, (int)(byte)0, (int)'4', (int)(byte)1, (int)(short)(-1), (int)(short)1, (int)(short)(-1), (int)(short)0, (int)(byte)1, true);
    int i52 = testTCAS0.run((int)'4', false, true, 10, 0, (int)(short)(-1), (int)'4', (int)(short)100, (int)' ', (int)(short)100, 0, true);
    int i65 = testTCAS0.run((int)(short)10, false, true, (int)(short)0, (int)(short)0, (int)' ', (int)(byte)(-1), 0, (int)'4', (int)(short)0, 0, true);
    int i78 = testTCAS0.run((int)(byte)0, true, false, (int)(byte)10, (int)(short)0, (int)'#', 10, 100, (int)(byte)0, (int)(short)10, 100, true);
    int i91 = testTCAS0.run((int)(byte)(-1), false, false, 1, (int)(short)100, 10, (int)(byte)0, 10, (int)(byte)1, (int)(byte)0, 0, true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i52 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i65 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i78 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i91 == 0);

  }

  @Test
  public void test11() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest2.test11"); }


    tcas.TestTCAS testTCAS0 = new tcas.TestTCAS();
    int i13 = testTCAS0.run((int)(short)(-1), true, false, (int)'a', (int)'#', 1, (int)(short)100, (int)(byte)0, 1, (int)(short)(-1), 0, true);
    int i26 = testTCAS0.run((int)'a', false, false, (int)' ', (int)(short)0, 0, (int)(short)1, (int)(byte)10, (int)'#', (int)'a', 100, true);
    int i39 = testTCAS0.run((-1), false, false, 0, (int)' ', (int)(byte)(-1), (int)(byte)100, (-1), (int)(short)(-1), (int)(short)1, (-1), true);
    int i52 = testTCAS0.run((int)(short)10, false, true, (int)(short)(-1), 0, 0, (int)'a', (int)'#', (-1), 100, (int)(byte)1, true);
    int i65 = testTCAS0.run((int)(byte)10, false, false, 100, 10, (int)'#', (int)'#', (int)(short)(-1), (int)(byte)100, 0, (int)(byte)1, true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i52 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i65 == 0);

  }

  @Test
  public void test12() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest2.test12"); }


    tcas.TestTCAS testTCAS0 = new tcas.TestTCAS();
    int i13 = testTCAS0.run((int)(short)(-1), true, false, (int)'a', (int)'#', 1, (int)(short)100, (int)(byte)0, 1, (int)(short)(-1), 0, true);
    int i26 = testTCAS0.run((int)'a', false, false, (int)' ', (int)(short)0, 0, (int)(short)1, (int)(byte)10, (int)'#', (int)'a', 100, true);
    int i39 = testTCAS0.run((int)(short)0, true, true, (int)(short)1, 1, (int)(short)1, 10, 10, (int)(byte)1, 10, (int)(byte)(-1), true);
    int i52 = testTCAS0.run((int)(byte)(-1), false, false, (int)(byte)0, (int)'4', (int)(byte)1, 100, (int)(byte)(-1), (int)'#', (int)(byte)0, 10, false);
    int i65 = testTCAS0.run((int)(short)10, true, true, (-1), (int)(short)10, (int)(short)10, (int)(byte)1, 100, 100, (int)(short)100, (int)(short)1, false);
    int i78 = testTCAS0.run(1, false, false, 0, 0, (int)' ', 10, (int)' ', (int)(byte)(-1), (int)' ', (int)(byte)(-1), false);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i52 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i65 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i78 == 0);

  }

  @Test
  public void test13() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest2.test13"); }


    tcas.TestTCAS testTCAS0 = new tcas.TestTCAS();
    int i13 = testTCAS0.run((int)(short)0, false, false, (int)'#', (int)(short)0, 0, (int)'#', (int)(byte)100, (int)(short)(-1), (int)(byte)10, 0, true);
    int i26 = testTCAS0.run((int)(byte)1, false, false, (int)(short)100, (int)(byte)100, (int)(byte)(-1), (int)'4', (int)(byte)1, (int)(short)1, (int)(byte)1, (int)'4', false);
    int i39 = testTCAS0.run((int)'4', false, true, 0, (int)(byte)0, (int)'4', (int)'4', 0, (int)'4', 1, (int)' ', true);
    int i52 = testTCAS0.run((int)(byte)10, true, true, (int)'a', (int)(byte)10, (int)(byte)1, 0, 0, (int)'4', (int)(short)0, (int)' ', true);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    org.junit.Assert.assertTrue(i52 == 0);

  }

}
