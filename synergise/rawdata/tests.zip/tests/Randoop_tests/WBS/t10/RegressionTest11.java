
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest11 {

  public static boolean debug = false;

  @Test
  public void test001() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test001"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)1, true, true, 0, false, true);
    testWBS0.launch((int)(byte)(-1), true, false, (int)(short)(-1), false, false, (int)' ', false, false);
    testWBS0.launch((-1), false, false, (int)(byte)0, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, true, (int)(short)100, true, true, (int)'#', true, false);
    testWBS0.launch((int)(short)100, false, false, 0, true, false, 0, false, true);
    testWBS0.launch((int)(short)10, false, false, (int)(short)10, false, true, 0, false, false);

  }

  @Test
  public void test002() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test002"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)10, false, true, 0, true, false, (int)(short)10, true, false);
    testWBS0.launch((int)(short)10, true, false, (int)' ', true, false, (int)(byte)(-1), false, true);
    testWBS0.launch((int)(short)10, true, true, 100, true, true, (int)(short)100, false, false);

  }

  @Test
  public void test003() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test003"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch(1, true, false, 1, true, false, 100, false, false);
    testWBS0.launch((-1), false, false, (int)(short)0, true, true, (int)(short)10, false, false);
    testWBS0.launch((int)(short)(-1), true, false, (-1), false, false, (int)(byte)10, false, true);
    testWBS0.launch((-1), true, false, (int)(short)1, false, true, (int)(byte)1, true, false);
    testWBS0.launch((int)'a', true, true, (int)(byte)100, true, true, (int)(byte)(-1), false, false);
    testWBS0.launch((int)(byte)0, true, false, (int)' ', true, false, (int)(short)100, false, false);
    testWBS0.launch((int)(short)10, true, true, (int)(byte)100, false, true, 0, false, false);

  }

  @Test
  public void test004() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test004"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)' ', false, false, (int)(short)1, false, false, (int)' ', true, true);
    testWBS0.launch((int)(byte)0, false, false, 100, true, true, (int)(short)1, true, false);
    testWBS0.launch(1, false, true, (int)(short)100, false, true, (int)(byte)1, false, true);
    testWBS0.launch((int)(byte)(-1), false, true, 0, false, true, (int)(byte)0, true, false);
    testWBS0.launch((int)(short)1, true, false, (int)(short)1, true, false, 10, false, true);
    testWBS0.launch((int)(byte)100, true, false, (int)(short)100, true, false, (int)(short)(-1), false, true);

  }

  @Test
  public void test005() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test005"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(short)100, false, false, (int)(short)(-1), false, false, (int)' ', false, false);
    testWBS0.launch((int)'a', false, true, (int)(byte)1, true, true, 1, false, false);
    testWBS0.launch((int)' ', false, true, (int)(byte)1, false, false, 10, false, false);
    testWBS0.launch((int)(byte)100, true, false, (int)(byte)100, false, false, (int)(byte)1, false, true);
    testWBS0.launch((int)'#', false, true, (int)(short)0, true, false, (int)(byte)1, false, true);
    testWBS0.launch((int)(short)(-1), true, false, (int)(byte)(-1), false, true, 0, true, true);

  }

  @Test
  public void test006() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test006"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, false, true, 0, true, true, (int)(byte)0, true, false);
    testWBS0.launch((-1), true, true, (int)(byte)0, true, true, (int)'#', true, false);
    testWBS0.launch((int)'4', false, true, (int)'#', true, true, (int)(short)100, true, true);
    testWBS0.launch((int)(short)(-1), false, false, (int)(short)1, true, true, (int)'#', false, true);
    testWBS0.launch((int)(short)100, false, true, 100, true, true, (int)' ', false, true);

  }

  @Test
  public void test007() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test007"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(10, true, true, (int)(byte)0, true, false, (int)'a', false, true);
    testWBS0.launch((int)(short)10, false, false, (int)(byte)0, true, false, (int)(short)(-1), true, true);
    testWBS0.launch((-1), true, true, (int)(byte)10, false, true, (int)(byte)0, true, true);
    testWBS0.launch((int)' ', true, false, (int)(byte)1, true, false, 100, true, false);
    testWBS0.launch((int)(short)100, false, false, 10, true, true, (-1), false, true);
    testWBS0.launch((int)(short)1, true, true, (int)(short)1, false, false, (int)(byte)1, true, false);
    testWBS0.launch(0, false, false, (int)(byte)100, false, false, (int)(byte)0, true, true);

  }

  @Test
  public void test008() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test008"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(byte)(-1), false, false, 1, true, false, (int)(byte)10, true, false);
    testWBS0.launch((int)(short)1, false, false, (int)(short)0, false, true, 0, false, true);
    testWBS0.launch((int)(byte)1, false, false, (int)'#', false, true, 0, false, false);
    testWBS0.launch((int)(short)(-1), true, true, (int)(byte)10, true, false, (int)(short)(-1), false, true);
    testWBS0.launch((int)(byte)1, true, true, (int)'#', false, false, (int)(short)10, false, false);
    testWBS0.launch(100, false, false, (int)' ', false, true, (int)(short)0, false, false);

  }

  @Test
  public void test009() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test009"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)1, false, false, (int)(short)0, true, false, 10, false, true);
    testWBS0.launch((int)'#', true, true, (int)(short)0, true, true, (int)(short)10, true, true);
    testWBS0.launch(1, false, true, (int)(byte)(-1), false, true, (int)(byte)10, false, true);
    testWBS0.launch(1, true, true, (int)(byte)1, false, true, 100, false, true);
    testWBS0.launch((int)(byte)100, true, true, (int)'a', false, true, (-1), true, false);

  }

  @Test
  public void test010() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test010"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(byte)(-1), false, false, 1, true, false, (int)(byte)10, true, false);
    testWBS0.launch(0, false, false, (int)(short)0, true, false, 100, false, false);

  }

  @Test
  public void test011() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test011"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch((-1), true, false, (int)(short)100, false, false, 1, true, true);
    testWBS0.launch(1, true, true, (int)'4', false, false, (int)(byte)0, false, true);
    testWBS0.launch((int)(short)10, false, true, (int)'a', false, false, (int)(short)1, false, false);
    testWBS0.launch((int)'a', true, true, (int)(byte)(-1), true, false, 10, false, true);

  }

  @Test
  public void test012() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test012"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, true, false, (int)(short)0, false, true);
    testWBS0.launch(100, true, true, (int)(byte)(-1), false, false, 10, false, false);
    testWBS0.launch((int)'a', true, true, (int)(byte)100, false, true, (int)' ', false, false);
    testWBS0.launch(100, false, false, (int)(short)10, false, false, (int)(short)0, true, true);
    testWBS0.launch(0, false, false, (int)(short)(-1), true, true, (int)'a', true, false);
    testWBS0.launch(0, true, false, (int)'#', true, false, (int)(short)(-1), true, false);
    testWBS0.launch(100, false, false, (-1), true, true, 0, true, true);

  }

  @Test
  public void test013() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test013"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)1, false, false, (int)(short)1, false, true, 0, true, true);
    testWBS0.launch((int)(byte)0, true, true, (int)(short)(-1), false, false, (int)(byte)1, false, true);
    testWBS0.launch((int)(byte)0, false, true, (int)' ', true, false, 1, true, false);
    testWBS0.launch((int)(byte)100, false, true, (int)(short)100, true, true, (int)'#', false, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(short)100, true, false, (int)'a', false, true);
    testWBS0.launch((int)(short)1, false, true, (int)(short)100, false, true, (int)(byte)0, false, false);

  }

  @Test
  public void test014() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test014"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch(1, true, false, (int)'#', false, false, (int)(byte)(-1), false, false);
    testWBS0.launch((int)(short)1, true, true, 100, true, true, (int)'#', true, false);
    testWBS0.launch((int)(short)1, true, true, 1, false, false, (int)(short)100, false, true);
    testWBS0.launch((int)(byte)10, false, true, (int)(byte)(-1), true, true, (int)(short)10, false, true);

  }

  @Test
  public void test015() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test015"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((-1), false, true, 10, false, false, 1, true, true);
    testWBS0.launch((int)(byte)0, true, false, 0, false, false, (int)(short)(-1), false, false);
    testWBS0.launch((-1), false, false, (int)(short)(-1), false, false, (int)'#', true, true);
    testWBS0.launch((int)(byte)10, false, false, (int)(byte)100, false, false, 0, true, false);
    testWBS0.launch(0, false, false, (int)(byte)1, true, false, (int)(short)100, true, true);
    testWBS0.launch(1, true, true, (int)'a', false, false, (-1), true, true);
    testWBS0.launch(10, false, true, (int)' ', true, false, (-1), false, false);
    testWBS0.launch((int)(byte)1, true, true, (int)' ', false, true, (int)'#', false, false);

  }

  @Test
  public void test016() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test016"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, true, false, (int)(short)0, false, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)100, false, false, 10, false, false);
    testWBS0.launch((int)'a', true, false, 100, false, true, (int)(short)0, false, false);
    testWBS0.launch((int)(byte)1, false, true, 10, false, true, (int)(short)10, true, false);
    testWBS0.launch((-1), true, false, (int)(byte)(-1), false, false, 0, false, true);
    testWBS0.launch((int)(short)1, true, false, 100, false, false, (int)'4', false, true);
    testWBS0.launch((int)'4', true, true, (int)(short)(-1), true, false, (int)' ', false, true);

  }

  @Test
  public void test017() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test017"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch(0, true, true, 100, true, false, (-1), false, false);
    testWBS0.launch((int)(short)10, true, false, (int)(short)0, false, false, 0, true, false);
    testWBS0.launch((int)(byte)0, false, true, (int)'#', true, true, (int)(byte)0, true, false);
    testWBS0.launch((int)(short)(-1), true, true, (-1), true, true, (int)(short)100, false, true);
    testWBS0.launch(0, true, false, (int)(short)10, false, false, 100, false, true);
    testWBS0.launch((int)'4', false, true, (int)(short)10, false, false, (int)(byte)1, false, false);

  }

  @Test
  public void test018() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test018"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(10, true, true, (int)(byte)0, true, false, (int)'a', false, true);
    testWBS0.launch((int)(short)10, false, false, (int)(byte)0, true, false, (int)(short)(-1), true, true);
    testWBS0.launch((int)(byte)0, false, true, (int)(short)0, false, true, (int)(short)100, true, true);
    testWBS0.launch((int)(short)100, false, true, 0, false, false, (int)(short)100, false, true);
    testWBS0.launch((int)(short)1, true, false, (int)(short)1, true, false, (int)'a', false, true);
    testWBS0.launch((int)(byte)(-1), false, false, (int)(byte)1, true, true, (int)(byte)(-1), false, false);
    testWBS0.launch((int)(byte)10, false, false, 0, false, true, (int)(short)10, false, true);

  }

  @Test
  public void test019() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test019"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch(0, true, false, (int)(byte)100, true, true, 100, true, false);
    testWBS0.launch((int)(byte)1, true, false, 0, true, false, (int)(short)1, false, true);
    testWBS0.launch((int)(short)10, false, false, (int)'4', false, false, (int)'a', false, false);
    testWBS0.launch((int)'a', true, false, (int)'4', false, true, (int)(short)0, true, true);
    testWBS0.launch((int)'4', false, false, 0, true, true, 100, false, true);
    testWBS0.launch(1, true, false, (int)(short)10, false, false, (int)(short)0, false, true);

  }

  @Test
  public void test020() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test020"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, true, false, (int)(short)0, false, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)100, false, false, 10, false, false);
    testWBS0.launch(100, false, true, 0, true, false, (int)(byte)(-1), false, false);
    testWBS0.launch((int)(short)10, false, true, (int)(byte)(-1), false, true, 100, false, false);
    testWBS0.launch((int)(short)(-1), false, false, (int)(byte)100, true, false, (int)(byte)100, false, false);
    testWBS0.launch(1, false, false, (int)'4', false, false, 100, false, false);
    testWBS0.launch((int)(byte)100, true, false, (int)(byte)100, true, false, (int)(short)100, false, true);

  }

  @Test
  public void test021() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test021"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)1, false, false, (int)(short)1, false, true, 0, true, true);
    testWBS0.launch((int)(short)100, false, false, (int)'4', true, true, (int)'#', false, false);
    testWBS0.launch((int)'#', false, false, (int)'4', true, false, (int)(byte)100, true, false);
    testWBS0.launch((int)(short)100, false, false, 10, false, false, 1, true, false);
    testWBS0.launch(10, false, true, (int)(byte)100, true, true, 10, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)100, true, false, 10, true, false);

  }

  @Test
  public void test022() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test022"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)0, false, false, (int)'#', false, true, (int)'4', false, false);
    testWBS0.launch((int)(byte)(-1), false, true, 100, true, true, (int)(short)100, false, false);
    testWBS0.launch(1, false, true, (int)'#', false, true, 10, true, false);
    testWBS0.launch((int)'a', false, true, (int)'a', false, false, (int)(byte)1, true, true);
    testWBS0.launch(1, false, true, (int)(byte)10, false, true, (int)(short)1, false, true);
    testWBS0.launch(10, false, true, (int)(byte)100, false, true, (int)' ', false, false);
    testWBS0.launch((int)'#', true, true, 0, true, false, (int)(short)(-1), false, true);
    testWBS0.launch((int)(byte)100, false, false, (-1), true, false, 0, false, false);
    testWBS0.launch((int)'#', false, true, (-1), false, false, (int)(byte)1, false, true);

  }

  @Test
  public void test023() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test023"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)0, false, true, (-1), false, false, (-1), true, true);
    testWBS0.launch((int)(short)(-1), true, false, (int)(byte)(-1), true, false, 1, true, false);
    testWBS0.launch((int)'a', true, false, (int)(byte)(-1), false, false, (int)'#', true, false);
    testWBS0.launch((int)'a', true, false, (int)(byte)0, true, false, (int)(short)0, false, false);
    testWBS0.launch((int)(short)10, false, false, (int)(short)(-1), true, true, (int)(short)1, false, true);

  }

  @Test
  public void test024() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test024"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((-1), false, true, 10, false, false, 1, true, true);
    testWBS0.launch((int)(byte)0, true, false, 0, false, false, (int)(short)(-1), false, false);
    testWBS0.launch((-1), false, false, (int)(short)(-1), false, false, (int)'#', true, true);
    testWBS0.launch((int)'a', true, true, (int)(short)0, false, true, (-1), false, true);
    testWBS0.launch((int)(short)(-1), true, true, (int)(short)(-1), true, true, 0, false, true);
    testWBS0.launch((int)'a', true, true, (int)(byte)10, false, false, (-1), false, true);
    testWBS0.launch(0, false, false, (int)(short)(-1), false, true, (int)'a', false, false);
    testWBS0.launch(100, false, false, 0, true, false, (int)(byte)10, false, false);

  }

  @Test
  public void test025() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test025"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch(0, false, true, (int)(byte)10, false, false, 1, false, false);
    testWBS0.launch((int)(byte)100, false, false, 100, false, false, (int)(byte)100, false, true);
    testWBS0.launch((-1), true, false, 100, false, false, (int)'4', false, true);
    testWBS0.launch((int)(short)0, true, true, (int)(short)100, false, false, (int)(byte)10, true, true);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)10, false, true, (int)' ', false, false);
    testWBS0.launch((int)(byte)100, true, true, (int)(short)1, true, true, (int)(short)1, false, false);

  }

  @Test
  public void test026() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test026"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch(0, true, true, (int)(byte)10, false, false, 0, true, false);
    testWBS0.launch((int)' ', false, false, 10, false, true, 100, false, true);
    testWBS0.launch((-1), false, false, 0, false, false, 0, false, false);
    testWBS0.launch((int)'#', false, false, (int)(short)0, false, true, (int)(short)0, false, true);
    testWBS0.launch((int)(short)100, false, true, 10, true, true, (int)(byte)(-1), true, false);
    testWBS0.launch((int)(byte)100, false, true, 1, false, false, (int)(byte)10, false, false);

  }

  @Test
  public void test027() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test027"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)1, false, false, (int)(short)1, false, true, 0, true, true);
    testWBS0.launch((int)(byte)0, false, false, (int)(short)10, true, true, (int)(byte)10, true, true);
    testWBS0.launch((int)(short)100, false, true, (int)(short)(-1), false, true, (int)(short)100, true, true);
    testWBS0.launch((int)(short)(-1), false, true, 1, true, true, 1, true, true);
    testWBS0.launch((int)'#', false, true, 1, true, true, (int)'a', true, false);
    testWBS0.launch((int)(byte)1, true, true, (int)'4', true, true, (int)(short)0, false, true);

  }

  @Test
  public void test028() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test028"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(10, true, true, (int)(byte)0, true, false, (int)'a', false, true);
    testWBS0.launch((int)(short)10, false, false, (int)(byte)0, true, false, (int)(short)(-1), true, true);
    testWBS0.launch((int)(byte)0, false, true, (int)(short)0, false, true, (int)(short)100, true, true);
    testWBS0.launch((int)'4', false, true, (int)'a', false, false, (int)(short)0, true, true);
    testWBS0.launch((int)(short)1, true, true, 0, true, true, (int)(short)1, true, false);

  }

  @Test
  public void test029() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test029"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, false, true, 0, true, true, (int)(byte)0, true, false);
    testWBS0.launch((int)(short)100, true, true, (int)' ', true, false, (int)(short)100, false, false);
    testWBS0.launch((int)(byte)(-1), true, true, (-1), true, true, (int)'4', false, true);
    testWBS0.launch((-1), false, false, (int)(byte)(-1), true, false, 1, true, true);

  }

  @Test
  public void test030() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test030"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch((-1), true, false, (int)(short)100, false, false, 1, true, true);
    testWBS0.launch(1, true, true, (int)'4', false, false, (int)(byte)0, false, true);
    testWBS0.launch((int)(byte)1, false, false, 0, false, false, (int)(byte)(-1), true, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(short)0, true, true, 0, true, true);
    testWBS0.launch((int)(byte)0, false, true, (-1), true, false, (int)(byte)0, false, false);
    testWBS0.launch((int)'a', true, false, (int)(short)10, true, true, (int)(short)0, false, false);

  }

  @Test
  public void test031() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test031"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch(0, true, false, (int)(short)1, true, false, (int)' ', true, false);
    testWBS0.launch((int)'#', true, true, 100, false, true, (int)(short)1, true, false);
    testWBS0.launch((int)(short)100, true, true, (int)(short)(-1), true, false, 10, false, true);
    testWBS0.launch((int)'4', true, false, (int)'#', false, false, (int)(byte)0, false, true);

  }

  @Test
  public void test032() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test032"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(byte)10, true, false, (int)'4', false, false);
    testWBS0.launch(10, false, true, (int)(short)0, false, false, (int)(byte)10, true, false);
    testWBS0.launch(1, true, false, (int)'4', true, true, (int)(short)10, true, true);
    testWBS0.launch((int)(short)0, true, false, (int)(byte)1, false, false, (-1), true, false);
    testWBS0.launch(1, false, false, (int)'4', false, false, 0, true, true);
    testWBS0.launch((int)(short)100, true, true, 0, true, false, (int)(short)1, true, false);

  }

  @Test
  public void test033() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test033"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)1, false, false, (int)(short)1, false, true, 0, true, true);
    testWBS0.launch((int)(byte)10, false, true, (int)(short)1, false, false, (int)'4', true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(short)1, true, true);
    testWBS0.launch((int)(byte)100, true, false, 0, false, true, (int)(short)100, false, true);

  }

  @Test
  public void test034() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test034"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)1, false, false, (int)(short)0, true, false, 10, false, true);
    testWBS0.launch((int)'#', false, false, (int)' ', false, true, (int)'#', false, true);
    testWBS0.launch((int)' ', false, true, 1, true, true, (int)'4', true, false);
    testWBS0.launch((int)'4', true, false, (int)(byte)(-1), false, true, 0, false, true);
    testWBS0.launch(100, true, false, (int)'a', true, true, (int)(short)0, true, true);
    testWBS0.launch(10, false, false, (int)(byte)(-1), true, true, (int)'#', false, false);

  }

  @Test
  public void test035() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test035"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(10, true, true, (int)(byte)0, true, false, (int)'a', false, true);
    testWBS0.launch((int)(short)10, false, false, (int)(byte)0, true, false, (int)(short)(-1), true, true);
    testWBS0.launch(0, true, false, 10, false, true, (int)(short)10, true, true);
    testWBS0.launch(100, false, true, 1, true, true, (int)(short)100, false, false);
    testWBS0.launch(10, true, true, 100, false, true, (int)(byte)10, false, true);
    testWBS0.launch((int)(byte)10, true, true, (int)' ', true, true, (int)'#', true, false);

  }

  @Test
  public void test036() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test036"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch(1, false, true, (int)(short)0, false, false, (int)'#', true, false);
    testWBS0.launch(100, false, false, 1, true, true, (int)' ', true, false);
    testWBS0.launch(0, false, false, 10, true, false, (int)' ', false, false);
    testWBS0.launch((int)(byte)1, false, false, (int)(byte)1, true, true, 0, false, true);
    testWBS0.launch((int)'#', true, false, (int)' ', false, true, 0, true, true);
    testWBS0.launch(100, true, false, (int)(short)0, false, true, (int)(byte)0, false, true);
    testWBS0.launch(0, true, true, (int)(byte)10, false, false, (int)'#', true, true);

  }

  @Test
  public void test037() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test037"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((-1), false, true, 10, false, false, 1, true, true);
    testWBS0.launch((int)(byte)0, true, false, 0, false, false, (int)(short)(-1), false, false);
    testWBS0.launch(1, false, true, (int)(byte)0, false, true, (int)' ', true, false);
    testWBS0.launch((int)(short)10, true, false, (int)'#', false, false, (int)(short)(-1), true, true);
    testWBS0.launch((int)(short)10, true, false, 10, true, false, (int)(short)0, false, false);
    testWBS0.launch((int)'a', true, true, (int)'4', false, false, (int)(byte)1, false, false);

  }

  @Test
  public void test038() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test038"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(10, true, true, (int)(byte)0, true, false, (int)'a', false, true);
    testWBS0.launch(0, true, false, 10, true, false, (-1), true, false);
    testWBS0.launch(0, true, true, 100, true, true, (int)(byte)100, true, false);
    testWBS0.launch((int)'#', true, false, 0, false, true, (int)(byte)1, false, false);
    testWBS0.launch((-1), false, true, 100, false, false, (int)(byte)(-1), true, true);
    testWBS0.launch((int)(byte)1, true, false, (int)(byte)10, true, false, (int)(byte)1, false, false);
    testWBS0.launch((int)(byte)1, false, false, (int)(byte)100, false, false, 0, true, true);

  }

  @Test
  public void test039() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test039"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch(0, false, true, (int)(byte)100, true, true, (int)(short)10, true, false);
    testWBS0.launch((int)(byte)10, false, false, 10, false, true, (int)(byte)(-1), true, false);
    testWBS0.launch((int)(byte)100, true, false, (int)(byte)(-1), true, false, 1, false, false);
    testWBS0.launch(10, false, false, (int)(short)0, true, true, (int)'#', true, true);

  }

  @Test
  public void test040() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test040"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)1, false, false, (int)(short)0, true, false, 10, false, true);
    testWBS0.launch((int)(byte)100, true, false, (int)(short)10, true, false, 0, true, true);
    testWBS0.launch((int)(byte)10, false, false, 0, false, true, (int)(short)1, false, true);
    testWBS0.launch((int)(short)1, false, false, 100, true, false, (int)(short)1, false, false);
    testWBS0.launch((int)(short)(-1), false, false, (int)(short)0, false, false, 10, true, true);

  }

  @Test
  public void test041() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test041"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)100, true, false, (int)(short)100, true, true, (int)(short)0, true, false);
    testWBS0.launch(1, true, true, (-1), true, false, 10, true, true);
    testWBS0.launch((int)(short)(-1), true, true, (int)(byte)10, true, true, (int)(short)0, true, false);
    testWBS0.launch((int)'#', false, false, (int)'#', false, true, (int)(short)(-1), false, true);
    testWBS0.launch((int)(byte)0, false, true, (int)' ', false, false, (int)(short)10, true, false);
    testWBS0.launch((int)(byte)1, true, true, (int)'4', true, false, (int)'4', false, true);
    testWBS0.launch((int)(byte)(-1), false, true, (int)(short)100, true, true, (int)(byte)0, false, false);

  }

  @Test
  public void test042() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test042"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)10, false, true, 0, true, false, (int)(short)10, true, false);
    testWBS0.launch((int)(short)1, true, false, (int)(byte)(-1), true, true, (int)(byte)1, false, false);
    testWBS0.launch((int)(byte)(-1), false, false, 1, true, true, (int)(short)0, true, true);
    testWBS0.launch((int)(byte)10, true, false, (int)'a', true, false, (int)(byte)100, false, true);
    testWBS0.launch(0, true, false, 100, false, false, (int)(short)10, true, true);
    testWBS0.launch((int)(byte)0, true, true, (int)' ', false, true, (int)(byte)100, true, true);
    testWBS0.launch((int)(short)1, true, false, (int)(short)0, false, true, 1, true, true);

  }

  @Test
  public void test043() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test043"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)1, false, false, (int)(short)1, false, true, 0, true, true);
    testWBS0.launch(100, true, false, (int)(short)10, false, false, (int)(byte)100, true, true);
    testWBS0.launch((int)(byte)(-1), false, true, (int)(short)0, true, true, 10, true, false);
    testWBS0.launch((int)(byte)10, true, false, 100, false, true, (-1), false, true);
    testWBS0.launch((-1), true, false, 100, false, false, (int)'4', false, false);
    testWBS0.launch((int)(short)10, true, false, 0, false, true, (int)'4', false, true);
    testWBS0.launch((int)' ', true, false, (int)(byte)0, true, true, (int)(byte)(-1), false, false);

  }

  @Test
  public void test044() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test044"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)'a', true, false, (int)(short)1, false, false, (int)(byte)10, true, true);
    testWBS0.launch(1, false, true, (int)(byte)10, true, false, 0, true, true);
    testWBS0.launch((int)(byte)0, false, true, (int)' ', false, false, (int)' ', true, true);
    testWBS0.launch((-1), true, false, (int)(byte)10, true, true, 0, false, false);
    testWBS0.launch((int)(byte)100, false, true, (int)(byte)100, false, false, (int)'4', true, false);
    testWBS0.launch((int)'4', false, true, (int)(short)1, true, false, (int)(byte)0, false, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(short)1, true, false, (int)(byte)1, false, false);
    testWBS0.launch((int)(short)100, false, false, (int)(byte)0, true, false, (int)(byte)0, false, false);

  }

  @Test
  public void test045() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test045"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)'a', true, false, (int)(short)1, false, false, (int)(byte)10, true, true);
    testWBS0.launch(1, false, true, (int)(byte)10, true, false, 0, true, true);
    testWBS0.launch((int)'a', false, true, (int)(byte)10, false, true, 1, false, true);
    testWBS0.launch((int)(byte)1, true, true, (int)(byte)100, true, true, (int)(short)0, false, false);
    testWBS0.launch((int)(byte)10, false, true, (int)(short)100, true, false, (int)' ', true, false);

  }

  @Test
  public void test046() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test046"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)10, false, true, 0, true, false, (int)(short)10, true, false);
    testWBS0.launch((int)(short)1, true, false, (int)(byte)(-1), true, true, (int)(byte)1, false, false);
    testWBS0.launch((int)(byte)(-1), false, false, 1, true, true, (int)(short)0, true, true);
    testWBS0.launch(10, false, true, (int)(byte)100, true, false, (int)(byte)100, false, false);
    testWBS0.launch((int)(byte)10, true, true, (int)' ', true, true, (int)(byte)1, true, false);
    testWBS0.launch((int)(short)(-1), false, false, (int)(short)100, true, true, 10, false, false);
    testWBS0.launch(100, false, true, (int)(byte)10, false, true, (int)(byte)1, false, true);

  }

  @Test
  public void test047() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test047"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(byte)10, true, false, (int)'4', false, false);
    testWBS0.launch(0, true, false, 0, true, true, (int)(short)10, true, false);
    testWBS0.launch((int)(byte)(-1), true, true, (int)(short)0, true, false, (int)(byte)10, true, false);
    testWBS0.launch((int)(byte)100, false, true, (int)(byte)10, false, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(short)1, false, false, (-1), false, true, (int)(short)1, true, true);
    testWBS0.launch(10, false, true, (int)'#', true, false, (int)(byte)10, true, false);
    testWBS0.launch((int)(short)100, false, false, 0, true, true, (int)(byte)100, true, false);

  }

  @Test
  public void test048() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test048"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch(1, true, false, 100, true, false, 0, true, true);
    testWBS0.launch((int)(short)1, false, true, (int)(byte)0, true, false, (int)'a', false, true);
    testWBS0.launch((int)(byte)1, true, false, 0, false, false, (int)'4', false, true);
    testWBS0.launch((int)(byte)(-1), false, true, 100, false, true, (int)(short)100, true, false);

  }

  @Test
  public void test049() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test049"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch(0, false, true, (int)(byte)10, false, false, 1, false, false);
    testWBS0.launch(0, true, false, (int)'#', true, true, (int)(byte)10, false, false);
    testWBS0.launch((int)(short)(-1), true, false, (int)(short)0, true, false, (int)(short)100, false, false);
    testWBS0.launch(100, false, true, (int)(short)10, true, true, 0, false, false);
    testWBS0.launch(1, false, true, (int)(byte)1, false, true, (int)'4', true, true);
    testWBS0.launch((int)(byte)0, true, false, (int)'4', false, true, (int)'4', true, true);

  }

  @Test
  public void test050() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test050"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)1, true, true, 0, false, true);
    testWBS0.launch((int)'4', true, true, (int)' ', true, false, (int)(byte)0, true, true);
    testWBS0.launch(0, true, false, (int)(short)0, true, false, (int)(short)1, false, true);
    testWBS0.launch((int)(short)10, true, true, 0, true, false, (int)(byte)10, false, true);
    testWBS0.launch((int)(byte)1, false, false, (int)(short)1, true, true, (int)(short)1, false, true);
    testWBS0.launch((int)(short)0, false, false, (int)'a', false, false, (int)(byte)(-1), true, true);
    testWBS0.launch(10, false, false, 0, false, true, (int)(short)(-1), true, true);

  }

  @Test
  public void test051() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test051"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch(0, true, true, (-1), false, false, (-1), true, false);
    testWBS0.launch(10, false, false, 10, false, false, 0, false, false);
    testWBS0.launch(10, false, true, (int)(short)1, false, true, 1, false, false);
    testWBS0.launch((int)(short)0, false, false, 0, false, false, 0, false, false);
    testWBS0.launch(10, true, true, (int)(short)0, true, true, (int)' ', false, false);
    testWBS0.launch((int)(byte)100, true, false, (int)'4', false, false, (int)(short)100, false, false);

  }

  @Test
  public void test052() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test052"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)1, true, true, 0, false, true);
    testWBS0.launch((int)'4', true, true, (int)' ', true, false, (int)(byte)0, true, true);
    testWBS0.launch(0, false, false, (int)' ', false, false, (int)'4', false, true);
    testWBS0.launch(1, false, false, 100, true, true, (int)(short)100, false, true);
    testWBS0.launch((int)'4', false, false, (int)'4', false, true, (int)'#', true, false);
    testWBS0.launch((int)(byte)100, false, true, (int)' ', false, true, 10, true, false);
    testWBS0.launch(0, true, true, (int)(byte)0, true, true, (int)(byte)1, false, true);

  }

  @Test
  public void test053() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test053"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch(0, true, true, (int)(byte)10, false, false, 0, true, false);
    testWBS0.launch((int)(short)(-1), true, true, 0, false, false, (int)'a', false, true);
    testWBS0.launch((int)(short)(-1), true, true, 0, false, false, (int)(byte)0, true, false);
    testWBS0.launch((-1), false, false, (int)(short)10, true, true, (int)(byte)10, true, false);

  }

  @Test
  public void test054() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test054"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)'a', true, false, (int)(short)1, false, false, (int)(byte)10, true, true);
    testWBS0.launch(10, true, false, 100, false, true, (int)(short)(-1), true, false);
    testWBS0.launch((int)'a', true, false, (int)' ', true, false, (int)'a', false, true);
    testWBS0.launch((int)(byte)10, false, true, 10, true, false, (int)(byte)100, true, true);
    testWBS0.launch(1, true, false, 0, false, true, 1, false, true);

  }

  @Test
  public void test055() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test055"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)'a', true, false, (int)(short)1, false, false, (int)(byte)10, true, true);
    testWBS0.launch(10, true, false, 100, false, true, (int)(short)(-1), true, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(byte)10, false, true, (int)(byte)1, false, false);
    testWBS0.launch(100, true, true, (int)(byte)(-1), true, false, (int)'4', true, false);
    testWBS0.launch(10, false, true, (int)'4', false, true, (int)(byte)0, false, true);
    testWBS0.launch(100, false, true, (int)' ', true, false, (int)'a', true, false);
    testWBS0.launch((int)'#', false, false, 10, true, false, (int)(short)10, true, true);

  }

  @Test
  public void test056() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test056"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch(0, true, true, 100, true, false, (-1), false, false);
    testWBS0.launch((int)'#', true, false, (int)'a', true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)'4', true, false, (int)(short)100, true, false, (int)(byte)(-1), true, true);
    testWBS0.launch(1, false, false, (int)(byte)0, true, false, (int)(byte)10, true, true);
    testWBS0.launch(1, true, true, (int)'a', false, false, 100, true, true);
    testWBS0.launch(10, true, false, (int)(short)(-1), false, true, (int)(short)(-1), false, false);
    testWBS0.launch((int)'#', true, false, (int)(byte)0, false, false, (int)'4', true, false);

  }

  @Test
  public void test057() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test057"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(10, true, true, (int)(byte)0, true, false, (int)'a', false, true);
    testWBS0.launch((int)(short)10, false, false, (int)(byte)0, true, false, (int)(short)(-1), true, true);
    testWBS0.launch((-1), true, true, (int)(byte)10, false, true, (int)(byte)0, true, true);
    testWBS0.launch((int)(short)0, true, true, 100, false, false, (int)' ', true, false);
    testWBS0.launch((int)' ', false, true, (int)(byte)0, false, false, 0, false, false);
    testWBS0.launch(100, true, true, (int)'4', true, true, (int)'#', true, true);
    testWBS0.launch(100, false, false, (int)'4', false, false, (int)(short)1, false, true);
    testWBS0.launch((int)(short)1, true, true, (int)'#', false, false, 1, false, true);
    testWBS0.launch((int)(short)1, true, true, 100, true, true, (int)'#', false, false);

  }

  @Test
  public void test058() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test058"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)'a', true, false, (int)(short)1, false, false, (int)(byte)10, true, true);
    testWBS0.launch((int)(short)100, true, true, (int)(byte)10, false, true, (int)(short)0, false, false);
    testWBS0.launch(0, true, true, 100, false, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(short)0, true, true, (int)(short)10, false, false, (int)(byte)(-1), true, false);

  }

  @Test
  public void test059() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test059"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((-1), false, true, 10, false, false, 1, true, true);
    testWBS0.launch((int)(byte)0, true, false, 0, false, false, (int)(short)(-1), false, false);
    testWBS0.launch(100, true, true, (int)(byte)(-1), false, false, (int)(byte)1, true, false);
    testWBS0.launch(1, true, false, (int)'a', true, true, (int)(byte)0, true, true);
    testWBS0.launch((int)(byte)(-1), false, true, (int)(byte)0, true, true, (int)(short)1, true, false);
    testWBS0.launch(10, false, false, (int)'#', true, true, 0, true, true);
    testWBS0.launch((int)(short)10, true, true, (int)' ', true, false, (int)' ', false, false);

  }

  @Test
  public void test060() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test060"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, true, false, (int)(short)0, false, true);
    testWBS0.launch((int)(byte)0, true, false, (int)(byte)1, false, false, (int)'4', true, true);
    testWBS0.launch((int)(byte)10, false, false, (int)(short)(-1), false, true, (int)(byte)100, true, true);
    testWBS0.launch((int)(short)1, false, true, (int)'4', true, true, 10, true, true);
    testWBS0.launch((int)(byte)(-1), true, false, (int)(short)1, false, true, (int)(byte)10, true, true);
    testWBS0.launch((int)(byte)100, true, true, (int)'4', false, true, 0, false, false);

  }

  @Test
  public void test061() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test061"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((-1), false, true, 10, false, false, 1, true, true);
    testWBS0.launch((int)(byte)0, false, true, (int)(byte)(-1), true, true, (int)'#', false, false);
    testWBS0.launch((int)(short)0, true, false, 0, true, false, 100, true, false);
    testWBS0.launch((int)' ', false, false, (int)(byte)10, true, false, (int)(short)(-1), true, false);
    testWBS0.launch(10, true, false, 0, true, false, 1, true, true);

  }

  @Test
  public void test062() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test062"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)10, false, false, 100, false, true, 0, true, true);
    testWBS0.launch((int)'4', true, false, (int)(byte)(-1), false, false, (int)(byte)(-1), true, true);
    testWBS0.launch(1, true, true, (int)(byte)(-1), true, true, (int)(short)100, false, false);
    testWBS0.launch((int)'4', false, false, (int)'#', false, false, 10, true, false);
    testWBS0.launch((int)' ', true, true, (int)' ', false, false, 100, false, false);
    testWBS0.launch(0, false, true, 0, true, false, (int)(byte)1, true, false);

  }

  @Test
  public void test063() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test063"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(10, true, true, (int)(byte)0, true, false, (int)'a', false, true);
    testWBS0.launch((int)(short)0, false, false, (int)'#', false, false, 1, true, false);
    testWBS0.launch((int)(short)0, false, true, (int)'4', false, false, (int)(byte)0, true, true);
    testWBS0.launch((-1), true, true, (int)(short)100, true, false, (int)(short)1, false, false);
    testWBS0.launch((int)' ', false, false, 1, true, true, (int)(short)(-1), false, true);

  }

  @Test
  public void test064() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test064"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch(0, true, true, 100, true, false, (-1), false, false);
    testWBS0.launch((-1), false, true, (int)'a', false, true, 0, false, false);
    testWBS0.launch((-1), true, false, (int)(short)(-1), false, true, 0, true, true);
    testWBS0.launch((int)(short)10, false, true, (int)(short)0, true, false, (int)(short)100, false, false);
    testWBS0.launch((int)'#', false, false, (int)(short)0, true, false, (int)(byte)0, false, false);

  }

  @Test
  public void test065() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test065"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, false, true, 0, true, true, (int)(byte)0, true, false);
    testWBS0.launch((int)(short)0, false, false, 1, true, false, (int)(byte)1, true, false);
    testWBS0.launch((int)(byte)(-1), true, true, (int)(byte)10, false, false, (-1), false, true);
    testWBS0.launch(0, true, true, (int)(short)(-1), true, true, (int)(byte)(-1), false, false);

  }

  @Test
  public void test066() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test066"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch(0, true, true, 100, true, false, (-1), false, false);
    testWBS0.launch((int)'#', true, false, (int)'a', true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)'4', true, false, (int)(short)100, true, false, (int)(byte)(-1), true, true);
    testWBS0.launch((int)(byte)10, true, true, 10, true, true, (int)'#', false, true);

  }

  @Test
  public void test067() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test067"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)(byte)1, true, false, (int)(byte)0, true, true, (int)(short)(-1), true, true);
    testWBS0.launch((int)'#', false, false, 1, false, true, 0, false, true);
    testWBS0.launch(10, false, true, (int)'4', true, false, (int)(byte)10, true, false);
    testWBS0.launch((-1), true, true, (int)(short)0, true, false, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)100, true, true, (int)(byte)10, true, true, (int)(short)10, false, false);

  }

  @Test
  public void test068() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test068"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(0, false, false, (int)(short)1, false, true, (int)'#', false, false);
    testWBS0.launch((int)(short)1, true, false, (int)(byte)0, true, true, (int)(short)(-1), true, true);
    testWBS0.launch((int)(byte)(-1), false, false, 0, false, false, (int)(short)(-1), true, true);
    testWBS0.launch((int)(short)0, false, false, (int)(short)(-1), true, false, 0, true, true);
    testWBS0.launch((int)(short)100, true, true, (int)' ', false, false, (int)(byte)10, false, false);
    testWBS0.launch((int)'#', false, true, (int)(byte)0, true, false, (int)'a', true, false);
    testWBS0.launch((int)' ', false, true, (int)(byte)1, true, true, 0, false, true);
    testWBS0.launch((int)(short)1, true, true, (int)(short)1, false, false, (-1), true, false);

  }

  @Test
  public void test069() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test069"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(10, true, true, (int)(byte)0, true, false, (int)'a', false, true);
    testWBS0.launch(0, true, false, 10, true, false, (-1), true, false);
    testWBS0.launch((int)(short)(-1), false, false, (int)(short)(-1), true, true, (int)(short)0, false, false);
    testWBS0.launch((-1), false, false, (int)' ', false, false, (int)(byte)10, true, true);
    testWBS0.launch((int)(short)100, false, true, 0, true, false, (int)(byte)10, true, true);
    testWBS0.launch((int)' ', false, false, (int)(short)(-1), false, false, (int)(byte)10, true, false);

  }

  @Test
  public void test070() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test070"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(byte)10, true, false, (int)'4', false, false);
    testWBS0.launch(10, false, true, (int)' ', false, true, 10, true, false);
    testWBS0.launch((int)'a', false, false, (int)'4', false, false, 0, true, false);
    testWBS0.launch((int)(short)100, true, true, (int)'#', true, true, (int)(short)100, false, false);
    testWBS0.launch((int)(short)(-1), false, false, 0, true, false, 0, true, true);

  }

  @Test
  public void test071() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test071"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(byte)10, false, false, 1, false, false, (-1), true, false);
    testWBS0.launch((int)(short)10, true, false, (int)(short)(-1), false, true, 0, true, false);
    testWBS0.launch(0, false, true, (int)(short)0, false, true, (int)'4', false, false);
    testWBS0.launch((int)' ', true, true, (int)(byte)100, true, true, (int)(byte)100, true, false);
    testWBS0.launch(0, false, true, (int)(short)(-1), false, false, 10, true, true);

  }

  @Test
  public void test072() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test072"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(byte)10, true, false, (int)'4', false, false);
    testWBS0.launch(0, true, false, 0, true, true, (int)(short)10, true, false);
    testWBS0.launch((int)(short)0, true, true, (int)(short)100, true, true, (int)(byte)(-1), false, false);
    testWBS0.launch((int)(byte)0, true, true, (int)(byte)10, true, false, (int)(short)100, true, false);
    testWBS0.launch((int)(short)100, true, false, (int)(short)10, false, true, (int)(short)(-1), true, true);
    testWBS0.launch((int)(short)100, false, false, (int)' ', true, false, 1, false, true);

  }

  @Test
  public void test073() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test073"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)100, false, false, (int)'#', false, true, (int)'a', false, false);
    testWBS0.launch(0, false, false, 100, true, false, (int)' ', true, false);
    testWBS0.launch((int)(byte)10, true, false, (int)' ', false, true, 10, true, true);
    testWBS0.launch((int)(short)(-1), true, true, (int)' ', false, false, (int)(short)0, false, false);
    testWBS0.launch((int)(short)100, true, false, (int)(byte)100, false, false, 1, false, false);
    testWBS0.launch((int)(short)100, false, true, 0, false, false, (int)(short)100, false, false);
    testWBS0.launch(1, false, true, (int)(short)100, true, false, (int)(short)100, true, true);

  }

  @Test
  public void test074() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test074"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)10, false, true, 0, true, false, (int)(short)10, true, false);
    testWBS0.launch((int)(short)1, true, false, (int)(byte)(-1), true, true, (int)(byte)1, false, false);
    testWBS0.launch((int)(byte)(-1), false, false, 1, true, true, (int)(short)0, true, true);
    testWBS0.launch((int)(byte)10, true, false, (int)'a', true, false, (int)(byte)100, false, true);
    testWBS0.launch(0, true, false, 100, false, false, (int)(short)10, true, true);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)10, true, false, (int)(byte)100, true, true);
    testWBS0.launch((int)(short)100, true, false, (int)(short)10, false, true, (int)(byte)(-1), false, false);
    testWBS0.launch((int)(short)(-1), false, false, (int)(short)(-1), true, true, 10, false, true);

  }

  @Test
  public void test075() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test075"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((-1), false, true, 10, false, false, 1, true, true);
    testWBS0.launch((int)(byte)0, true, false, 0, false, false, (int)(short)(-1), false, false);
    testWBS0.launch(1, false, true, (int)(byte)0, false, true, (int)' ', true, false);
    testWBS0.launch((int)'a', true, true, (int)(short)(-1), true, false, (int)(byte)100, false, false);
    testWBS0.launch((int)(short)10, true, true, (int)'a', true, true, (int)(short)(-1), true, true);
    testWBS0.launch((int)(byte)(-1), false, false, (int)(short)(-1), true, false, (int)(byte)(-1), true, true);
    testWBS0.launch((int)(short)0, true, false, (int)(byte)1, true, false, (int)(short)10, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(byte)(-1), true, false);

  }

  @Test
  public void test076() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test076"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)'a', true, false, (int)(short)1, false, false, (int)(byte)10, true, true);
    testWBS0.launch((int)(short)10, true, true, (int)(byte)100, false, false, 10, false, true);
    testWBS0.launch((int)'#', true, false, (int)(byte)(-1), true, false, (int)' ', true, false);
    testWBS0.launch(1, true, true, 1, false, true, (int)'4', true, true);
    testWBS0.launch(10, false, false, 100, false, true, (int)' ', false, false);
    testWBS0.launch(100, true, false, 0, false, true, (int)'4', false, true);
    testWBS0.launch((int)'#', false, false, (int)(short)0, false, false, (int)(short)1, true, true);

  }

  @Test
  public void test077() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test077"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)1, false, false, (int)(short)0, true, false, 10, false, true);
    testWBS0.launch((int)'#', true, true, (int)(short)0, true, true, (int)(short)10, true, true);
    testWBS0.launch((int)(short)10, false, true, (-1), false, true, 100, true, false);
    testWBS0.launch(10, false, false, (int)'#', true, true, (int)'#', false, false);
    testWBS0.launch((int)' ', false, true, (int)(byte)1, false, false, (int)'a', true, true);
    testWBS0.launch((int)' ', false, false, (int)(short)10, true, true, (int)(short)0, true, false);
    testWBS0.launch(10, false, false, (int)(short)(-1), true, false, (int)'a', true, false);

  }

  @Test
  public void test078() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test078"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((-1), false, true, 10, false, false, 1, true, true);
    testWBS0.launch((int)(byte)0, true, false, 0, false, false, (int)(short)(-1), false, false);
    testWBS0.launch((-1), false, false, (int)(short)(-1), false, false, (int)'#', true, true);
    testWBS0.launch((int)(byte)10, false, false, (int)(byte)100, false, false, 0, true, false);
    testWBS0.launch(0, false, false, (int)(byte)1, true, false, (int)(short)100, true, true);
    testWBS0.launch(0, true, false, (int)(byte)10, true, true, (int)(short)10, true, true);
    testWBS0.launch((int)(byte)1, true, true, 10, false, true, (int)' ', true, false);
    testWBS0.launch((int)'a', true, true, 0, true, false, (int)(short)100, true, false);

  }

  @Test
  public void test079() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test079"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch(0, false, true, (int)(byte)100, true, true, (int)(short)10, true, false);
    testWBS0.launch(0, true, true, (int)(short)100, false, false, 0, false, false);
    testWBS0.launch((int)'a', true, false, 10, false, false, (int)(byte)10, false, true);
    testWBS0.launch((int)(byte)0, false, true, (int)'a', true, true, (int)'a', false, false);
    testWBS0.launch(0, false, false, (int)(short)1, false, false, (int)(short)1, true, false);
    testWBS0.launch((-1), false, true, (int)(byte)1, false, false, (int)(byte)(-1), false, true);

  }

  @Test
  public void test080() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test080"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((-1), false, true, 10, false, false, 1, true, true);
    testWBS0.launch((int)(byte)0, true, false, 0, false, false, (int)(short)(-1), false, false);
    testWBS0.launch(1, false, true, (int)(byte)0, false, true, (int)' ', true, false);
    testWBS0.launch((int)(short)0, true, true, 10, true, true, (int)'a', true, true);
    testWBS0.launch((int)(byte)100, false, false, (int)(byte)0, true, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)100, true, false, 0, true, false);
    testWBS0.launch((int)(byte)10, true, true, 100, true, false, (int)(short)10, true, false);
    testWBS0.launch((int)' ', false, true, (int)(byte)0, true, false, 100, false, false);

  }

  @Test
  public void test081() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test081"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)1, true, true, 0, false, true);
    testWBS0.launch((int)(byte)(-1), true, false, (int)(short)(-1), false, false, (int)' ', false, false);
    testWBS0.launch((int)(byte)0, true, false, 10, true, true, (int)(short)100, true, true);
    testWBS0.launch((int)(byte)0, false, true, (int)(short)1, true, true, 100, false, true);
    testWBS0.launch((int)(short)10, false, false, (int)'#', true, true, (int)(byte)0, false, true);
    testWBS0.launch((int)'#', false, true, (int)(byte)10, true, false, (int)'#', false, false);

  }

  @Test
  public void test082() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test082"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch(0, true, true, 100, true, false, (-1), false, false);
    testWBS0.launch((-1), false, true, (int)'a', false, true, 0, false, false);
    testWBS0.launch(0, false, true, 1, false, true, (int)(short)100, true, true);
    testWBS0.launch(1, false, true, 100, true, false, (int)'a', true, false);
    testWBS0.launch(0, true, false, (int)'#', false, false, 1, true, true);

  }

  @Test
  public void test083() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test083"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)1, true, true, 0, false, true);
    testWBS0.launch((int)'4', true, true, (int)' ', true, false, (int)(byte)0, true, true);
    testWBS0.launch(0, true, false, (int)(short)0, true, false, (int)(short)1, false, true);
    testWBS0.launch(1, true, true, (int)(short)100, false, false, (int)'4', true, true);
    testWBS0.launch((int)(short)(-1), false, false, (int)(byte)0, false, false, (int)(short)0, true, false);
    testWBS0.launch((int)(short)100, true, false, 0, false, true, (int)'#', false, true);

  }

  @Test
  public void test084() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test084"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch((int)(byte)0, true, false, 1, false, true, 100, true, false);
    testWBS0.launch((int)(short)0, false, true, (int)(byte)100, false, false, 0, false, false);
    testWBS0.launch((int)(short)0, false, false, (int)(byte)(-1), false, false, 10, false, true);
    testWBS0.launch((int)(byte)(-1), true, true, (int)' ', true, true, (int)(byte)1, false, false);
    testWBS0.launch((int)(short)1, true, true, (int)(byte)(-1), true, true, (int)(byte)10, false, false);

  }

  @Test
  public void test085() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test085"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(0, false, false, (int)(short)1, false, true, (int)'#', false, false);
    testWBS0.launch((-1), true, false, (int)' ', true, false, (int)(short)100, false, false);
    testWBS0.launch((int)(byte)0, true, true, (-1), true, false, 0, false, true);
    testWBS0.launch((int)(byte)(-1), true, false, (int)'#', false, false, (int)(short)1, false, true);

  }

  @Test
  public void test086() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test086"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)1, false, false, (int)(short)1, false, true, 0, true, true);
    testWBS0.launch((int)(byte)0, true, true, (int)(short)(-1), false, false, (int)(byte)1, false, true);
    testWBS0.launch((int)(byte)0, false, true, (int)' ', true, false, 1, true, false);
    testWBS0.launch((int)(byte)100, false, true, (int)(short)100, true, true, (int)'#', false, false);
    testWBS0.launch((int)(short)10, true, false, (int)(byte)0, true, false, 0, true, true);
    testWBS0.launch((int)(short)1, true, true, (int)'a', false, false, (int)(byte)1, false, true);

  }

  @Test
  public void test087() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test087"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)100, true, true, (int)(byte)100, true, true, (int)(byte)0, true, true);
    testWBS0.launch((int)(short)10, true, false, (int)(byte)10, true, false, (int)(byte)(-1), true, false);
    testWBS0.launch(100, false, false, 10, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((-1), true, false, 0, false, false, (int)(short)(-1), false, false);

  }

  @Test
  public void test088() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test088"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(10, true, true, (int)(byte)0, true, false, (int)'a', false, true);
    testWBS0.launch((int)(short)10, false, false, (int)(byte)0, true, false, (int)(short)(-1), true, true);
    testWBS0.launch((-1), true, true, (int)(byte)10, false, true, (int)(byte)0, true, true);
    testWBS0.launch((int)(short)0, true, true, 100, false, false, (int)' ', true, false);
    testWBS0.launch((int)' ', false, true, (int)(byte)0, false, false, 0, false, false);
    testWBS0.launch((int)(byte)10, false, true, (int)'a', true, false, (int)(short)(-1), true, true);
    testWBS0.launch((int)'4', true, false, (int)(short)(-1), true, true, (int)(short)10, false, false);
    testWBS0.launch((-1), false, false, (int)(byte)1, false, true, (int)' ', false, false);
    testWBS0.launch(1, false, true, 0, true, false, (int)(byte)1, false, false);

  }

  @Test
  public void test089() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test089"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)' ', false, false, (int)(short)1, false, false, (int)' ', true, true);
    testWBS0.launch((int)(short)100, true, true, (int)'a', true, false, 0, false, false);
    testWBS0.launch((-1), true, false, (-1), false, true, (int)(short)100, true, false);
    testWBS0.launch((-1), true, true, 1, false, true, (int)' ', false, true);

  }

  @Test
  public void test090() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test090"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((-1), false, true, 10, false, false, 1, true, true);
    testWBS0.launch((int)'a', true, true, (int)'4', true, true, 100, true, true);
    testWBS0.launch((int)'a', true, false, (int)(short)0, false, false, 1, false, true);
    testWBS0.launch(0, true, false, 10, false, false, 10, false, false);
    testWBS0.launch((int)(byte)1, false, false, (int)'#', false, true, 1, true, false);
    testWBS0.launch(1, true, false, (int)(byte)1, false, true, (int)(short)10, true, false);

  }

  @Test
  public void test091() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test091"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, true, false, (int)(short)0, false, true);
    testWBS0.launch((int)(byte)0, true, false, (int)(byte)1, false, false, (int)'4', true, true);
    testWBS0.launch((int)'a', true, false, (int)(short)10, false, true, (-1), true, false);
    testWBS0.launch((int)(byte)10, false, false, (int)(short)10, false, false, 0, false, false);
    testWBS0.launch(0, false, true, 10, true, false, (-1), true, false);

  }

  @Test
  public void test092() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test092"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)1, false, false, (int)(short)0, true, false, 10, false, true);
    testWBS0.launch((int)'#', false, false, (int)' ', false, true, (int)'#', false, true);
    testWBS0.launch((int)' ', false, true, 1, true, true, (int)'4', true, false);
    testWBS0.launch((int)'#', true, true, (int)(short)10, true, false, 0, false, false);
    testWBS0.launch((int)'a', false, false, (int)(byte)0, false, false, 100, true, true);
    testWBS0.launch((int)'a', false, true, (int)'4', true, false, (int)(short)1, false, true);
    testWBS0.launch((int)(short)100, true, false, (int)(short)(-1), false, false, (int)'4', false, true);

  }

  @Test
  public void test093() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test093"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)'a', true, false, (int)(short)1, false, false, (int)(byte)10, true, true);
    testWBS0.launch((int)(byte)10, true, true, (int)'#', true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(short)0, true, true, (int)(short)0, true, false, (int)(byte)0, false, false);
    testWBS0.launch(0, false, true, 100, false, true, (int)(byte)(-1), true, true);
    testWBS0.launch(10, true, false, 100, false, true, (int)'#', true, true);
    testWBS0.launch((int)' ', true, true, (int)'4', false, true, (int)' ', false, true);

  }

  @Test
  public void test094() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test094"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((-1), false, true, 10, false, false, 1, true, true);
    testWBS0.launch((int)(byte)0, true, false, 0, false, false, (int)(short)(-1), false, false);
    testWBS0.launch(1, false, true, (int)(byte)0, false, true, (int)' ', true, false);
    testWBS0.launch((int)'a', true, true, (int)(short)(-1), true, false, (int)(byte)100, false, false);
    testWBS0.launch((int)(short)10, true, false, (int)(byte)(-1), false, true, 0, false, false);
    testWBS0.launch(1, true, false, (int)(byte)10, false, false, 10, false, true);
    testWBS0.launch(0, false, true, (int)'4', true, true, (int)(byte)10, false, false);
    testWBS0.launch((int)'#', true, true, (int)(short)0, true, false, 10, true, true);

  }

  @Test
  public void test095() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test095"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)1, false, false, (int)(short)0, true, false, 10, false, true);
    testWBS0.launch((int)'#', false, false, (int)' ', false, true, (int)'#', false, true);
    testWBS0.launch((int)' ', false, true, 1, true, true, (int)'4', true, false);
    testWBS0.launch((int)(short)(-1), false, false, (int)(short)1, true, false, (int)(byte)(-1), false, true);
    testWBS0.launch((int)(byte)100, true, false, 100, true, true, 100, false, false);
    testWBS0.launch((int)(short)100, false, true, (int)(byte)0, false, true, (int)(byte)100, true, true);
    testWBS0.launch(100, false, false, 0, true, true, 10, true, false);

  }

  @Test
  public void test096() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test096"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(byte)10, true, false, (int)'4', false, false);
    testWBS0.launch(0, true, false, 0, true, true, (int)(short)10, true, false);
    testWBS0.launch((int)(short)0, true, true, (int)(short)100, true, true, (int)(byte)(-1), false, false);
    testWBS0.launch(0, true, false, (-1), false, false, (int)' ', false, true);

  }

  @Test
  public void test097() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test097"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 100, false, true, (int)(byte)1, true, false);
    testWBS0.launch(0, false, false, (-1), false, true, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)(-1), true, false, 0, true, false, (int)(byte)(-1), false, false);
    testWBS0.launch(10, false, true, (int)(short)1, true, false, (int)(byte)100, false, false);
    testWBS0.launch(0, false, false, (-1), false, true, (int)' ', true, false);
    testWBS0.launch((int)'#', false, true, 100, true, true, (-1), true, true);
    testWBS0.launch((int)'a', false, true, (int)(byte)0, false, false, (int)' ', true, false);
    testWBS0.launch((int)(short)(-1), false, false, (int)(byte)1, true, false, (int)'4', false, false);

  }

  @Test
  public void test098() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test098"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)' ', false, true, (int)(byte)10, true, true, (-1), false, true);
    testWBS0.launch((int)(short)100, true, false, (int)'4', true, true, 0, false, false);
    testWBS0.launch((int)(byte)0, false, true, (int)(byte)0, false, false, (int)' ', false, false);
    testWBS0.launch((-1), true, true, 100, true, true, (int)(byte)0, false, true);
    testWBS0.launch((int)(short)1, true, true, 10, true, false, (int)'a', false, false);

  }

  @Test
  public void test099() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test099"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)10, false, false, 100, false, true, 0, true, true);
    testWBS0.launch((int)'4', true, false, (int)(byte)(-1), false, false, (int)(byte)(-1), true, true);
    testWBS0.launch(0, true, true, (int)(short)0, false, false, (int)(short)100, true, false);
    testWBS0.launch((int)'4', true, true, (int)(byte)10, true, true, (int)'#', false, true);
    testWBS0.launch((int)(short)0, true, false, (int)(byte)10, true, false, (int)'4', false, true);
    testWBS0.launch((int)(short)10, true, true, (int)(byte)0, true, false, (-1), false, false);
    testWBS0.launch(0, false, false, (int)(byte)10, true, false, 0, true, false);

  }

  @Test
  public void test100() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test100"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)100, false, false, (int)'#', false, true, (int)'a', false, false);
    testWBS0.launch(0, false, false, 100, true, false, (int)' ', true, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)10, false, false, (-1), false, false);
    testWBS0.launch((int)' ', true, true, (int)'a', false, true, (-1), false, true);
    testWBS0.launch(10, true, false, (int)(short)(-1), false, true, (int)(byte)1, false, false);

  }

  @Test
  public void test101() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test101"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch(1, true, false, 1, true, false, 100, false, false);
    testWBS0.launch((-1), false, false, (int)(short)0, true, true, (int)(short)10, false, false);
    testWBS0.launch((int)(short)(-1), false, true, 10, false, true, (-1), false, true);
    testWBS0.launch((int)(byte)1, false, true, 1, true, true, (int)'4', false, true);

  }

  @Test
  public void test102() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test102"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)1, false, false, (int)(short)1, false, true, 0, true, true);
    testWBS0.launch((int)(byte)0, true, true, (int)(short)(-1), false, false, (int)(byte)1, false, true);
    testWBS0.launch((int)(short)10, false, false, (int)(byte)100, false, false, (int)(byte)(-1), true, true);
    testWBS0.launch((int)(byte)0, true, false, (int)'4', false, true, (int)'4', true, false);
    testWBS0.launch((int)' ', false, true, (int)(short)(-1), true, true, (int)' ', false, true);
    testWBS0.launch(100, false, false, (int)(short)100, false, false, (int)(byte)1, true, true);

  }

  @Test
  public void test103() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test103"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((-1), false, true, 10, false, false, 1, true, true);
    testWBS0.launch((int)'a', false, true, (int)'a', true, false, 100, true, true);
    testWBS0.launch(10, true, false, (int)(short)0, false, false, (int)'#', false, false);
    testWBS0.launch(0, false, false, (-1), false, false, 100, false, true);

  }

  @Test
  public void test104() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test104"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(byte)1, false, true, 1, false, false, (-1), false, true);
    testWBS0.launch((int)(short)0, false, false, (int)(short)0, true, false, (int)'4', true, false);
    testWBS0.launch(10, true, false, 1, true, true, (int)'a', true, true);
    testWBS0.launch((int)'a', false, true, (int)'a', true, false, (int)'#', true, false);
    testWBS0.launch(100, true, true, 0, false, true, (int)(short)10, false, true);
    testWBS0.launch((int)(byte)10, false, false, (int)' ', false, false, (int)(short)0, true, false);

  }

  @Test
  public void test105() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test105"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)10, false, true, 0, true, false, (int)(short)10, true, false);
    testWBS0.launch((int)(short)1, true, false, (int)(byte)(-1), true, true, (int)(byte)1, false, false);
    testWBS0.launch(1, false, false, 0, true, true, (int)' ', false, true);
    testWBS0.launch((int)(byte)0, false, false, (int)'4', true, false, (int)(short)1, false, true);
    testWBS0.launch(0, true, false, 0, false, false, (int)(byte)(-1), true, false);
    testWBS0.launch((int)(short)0, false, true, 10, false, false, (int)(byte)0, false, false);
    testWBS0.launch((int)(byte)10, false, false, 1, false, true, (int)' ', true, false);

  }

  @Test
  public void test106() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test106"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)100, false, false, (int)'#', false, true, (int)'a', false, false);
    testWBS0.launch(0, false, false, 100, true, false, (int)' ', true, false);
    testWBS0.launch((int)(byte)(-1), false, true, (int)(short)1, false, true, (int)(short)0, true, true);
    testWBS0.launch((int)(byte)10, false, false, 10, true, true, (int)(byte)(-1), true, true);
    testWBS0.launch((int)' ', false, true, 0, true, true, (int)' ', true, true);

  }

  @Test
  public void test107() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test107"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)1, false, false, (int)(short)1, false, true, 0, true, true);
    testWBS0.launch((int)(short)100, false, false, (int)'4', true, true, (int)'#', false, false);
    testWBS0.launch((int)'#', false, false, (int)'4', true, false, (int)(byte)100, true, false);
    testWBS0.launch(1, false, false, (int)' ', false, true, 10, true, true);
    testWBS0.launch((int)'#', false, false, (int)(byte)0, false, false, 100, false, false);

  }

  @Test
  public void test108() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test108"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(0, false, false, (int)(short)1, false, true, (int)'#', false, false);
    testWBS0.launch((int)'a', true, false, 0, true, false, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)(-1), false, true, (int)(short)10, true, false, 0, false, true);

  }

  @Test
  public void test109() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test109"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)' ', true, true, (int)(byte)0, false, false, (int)(byte)0, true, false);
    testWBS0.launch((int)(byte)(-1), false, true, (int)(byte)1, true, false, (int)(byte)100, false, false);
    testWBS0.launch((int)(byte)1, true, false, 10, true, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)(-1), false, true, 1, false, false, 100, false, false);
    testWBS0.launch((int)(short)10, true, false, 10, false, false, (int)'a', false, true);
    testWBS0.launch((int)(byte)1, false, false, (int)(byte)10, false, false, (int)'#', false, false);

  }

  @Test
  public void test110() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test110"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(10, false, false, (int)(byte)10, false, false, (int)'4', true, true);
    testWBS0.launch((int)(short)1, true, true, (int)'4', false, false, (int)(short)10, false, false);
    testWBS0.launch((int)(byte)1, false, true, (int)(short)1, false, true, (int)'a', false, false);
    testWBS0.launch((int)(short)100, false, false, (int)(byte)1, false, false, (int)(short)100, true, false);
    testWBS0.launch((int)(short)100, true, true, (int)(short)(-1), false, true, (int)(short)1, false, true);

  }

  @Test
  public void test111() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test111"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)' ', true, true, (int)(byte)0, false, false, (int)(byte)0, true, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)10, true, false, (int)' ', true, false);
    testWBS0.launch((int)'4', true, true, (int)(byte)1, true, false, (int)(byte)10, false, false);
    testWBS0.launch((int)(short)(-1), false, false, (int)(byte)(-1), true, false, (int)'#', true, true);

  }

  @Test
  public void test112() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test112"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch(0, true, true, 100, true, false, (-1), false, false);
    testWBS0.launch((int)' ', false, true, (int)'#', false, true, (int)'#', false, false);
    testWBS0.launch((int)(short)(-1), true, false, (int)(byte)100, true, true, (int)(short)0, true, true);
    testWBS0.launch(100, true, false, (int)' ', false, true, (int)'4', false, true);

  }

  @Test
  public void test113() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test113"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)'a', true, false, (int)(short)1, false, false, (int)(byte)10, true, true);
    testWBS0.launch(10, true, false, 100, false, true, (int)(short)(-1), true, false);
    testWBS0.launch((int)(byte)(-1), false, false, (int)(short)(-1), false, true, 0, true, false);
    testWBS0.launch((int)(byte)1, false, true, 100, false, true, (int)(short)100, false, false);
    testWBS0.launch((int)'#', true, true, 10, true, false, (int)(short)1, true, true);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)(-1), false, false, (int)(byte)1, true, true);
    testWBS0.launch(0, false, true, (int)(byte)100, false, true, (int)(short)0, false, true);
    testWBS0.launch((int)(byte)0, false, false, (-1), true, false, (int)'4', true, true);

  }

  @Test
  public void test114() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test114"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch(0, true, false, (int)(short)1, true, false, (int)' ', true, false);
    testWBS0.launch(0, true, false, (int)'4', false, false, (int)(short)100, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(short)(-1), true, true, (int)(byte)10, true, true);

  }

  @Test
  public void test115() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test115"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(10, true, true, (int)(byte)0, true, false, (int)'a', false, true);
    testWBS0.launch((int)(short)10, false, false, (int)(byte)0, true, false, (int)(short)(-1), true, true);
    testWBS0.launch((int)(byte)(-1), true, true, (-1), false, true, 100, true, true);
    testWBS0.launch((int)(byte)1, false, false, (int)(byte)1, true, true, (int)(short)100, false, false);
    testWBS0.launch(10, false, true, (int)(byte)10, false, false, (int)'4', false, true);

  }

  @Test
  public void test116() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test116"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)1, false, false, (int)(short)0, true, false, 10, false, true);
    testWBS0.launch((int)(byte)100, true, false, (int)(short)10, true, false, 0, true, true);
    testWBS0.launch(100, false, false, (int)(byte)100, false, true, 0, true, true);
    testWBS0.launch((int)(byte)0, false, false, (int)'#', true, true, 0, true, false);

  }

  @Test
  public void test117() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test117"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(byte)1, false, true, 1, false, false, (-1), false, true);
    testWBS0.launch(0, false, true, 1, false, false, (int)(byte)10, true, false);
    testWBS0.launch(0, false, true, (int)(byte)(-1), true, false, 1, true, true);
    testWBS0.launch((int)(short)100, false, false, (int)(short)0, true, true, (int)(byte)(-1), false, true);
    testWBS0.launch(10, true, true, (int)(byte)1, true, true, (int)'a', true, true);
    testWBS0.launch((int)(short)10, false, true, (int)(byte)100, true, false, (int)' ', true, true);

  }

  @Test
  public void test118() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test118"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)10, false, true, 0, true, false, (int)(short)10, true, false);
    testWBS0.launch((int)(short)(-1), false, false, (int)'a', false, true, (int)(short)100, false, true);
    testWBS0.launch((int)(short)100, true, false, (int)(byte)100, true, false, (int)(short)100, false, true);
    testWBS0.launch((int)(short)0, true, false, 100, true, false, (int)(short)10, true, true);
    testWBS0.launch((int)(short)10, false, false, (int)(short)0, false, true, (int)(byte)(-1), false, false);
    testWBS0.launch((int)(short)0, true, false, (int)(short)(-1), true, false, (int)'4', false, false);
    testWBS0.launch(0, true, false, (-1), false, false, 0, true, true);

  }

  @Test
  public void test119() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test119"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)1, false, false, (int)(short)0, true, false, 10, false, true);
    testWBS0.launch((int)'#', true, true, (int)(short)0, true, true, (int)(short)10, true, true);
    testWBS0.launch((int)(short)10, true, true, 1, true, false, (int)(byte)1, false, true);
    testWBS0.launch((int)(byte)1, false, false, 10, false, true, (int)(short)0, true, true);
    testWBS0.launch(1, false, true, 0, false, true, (int)(byte)1, true, false);
    testWBS0.launch((-1), false, false, (int)(byte)(-1), true, false, 0, true, false);
    testWBS0.launch((int)'#', true, true, (-1), false, false, (int)(byte)100, false, true);

  }

  @Test
  public void test120() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test120"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(byte)10, false, false, 1, false, false, (-1), true, false);
    testWBS0.launch((int)(short)100, false, true, 10, false, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, (int)(short)1, false, true, 10, false, true);
    testWBS0.launch((int)(byte)10, false, false, 0, true, true, (int)(short)(-1), false, false);
    testWBS0.launch((int)'a', false, true, (int)'#', true, true, (int)(short)1, true, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(byte)10, false, true, (int)'a', false, false);

  }

  @Test
  public void test121() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test121"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch(0, true, true, 100, true, false, (-1), false, false);
    testWBS0.launch((-1), false, true, (int)'a', false, true, 0, false, false);
    testWBS0.launch(0, false, true, 1, false, true, (int)(short)100, true, true);
    testWBS0.launch((int)'#', false, true, 0, false, true, 100, false, true);
    testWBS0.launch(100, false, true, (int)(short)0, false, true, (int)(short)0, true, true);
    testWBS0.launch(100, false, false, (int)(short)1, false, false, (int)'a', true, true);
    testWBS0.launch(10, false, true, 100, false, false, (int)(byte)0, false, false);

  }

  @Test
  public void test122() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test122"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, true, false, (int)(short)0, false, true);
    testWBS0.launch((int)(short)1, true, false, (int)(short)0, true, true, (int)(byte)0, true, false);
    testWBS0.launch(0, true, false, (int)(byte)0, false, false, (int)(short)10, false, false);
    testWBS0.launch(10, false, false, 100, true, false, 10, false, false);
    testWBS0.launch((int)(byte)0, true, false, 1, false, false, (int)(short)(-1), true, false);
    testWBS0.launch(100, false, false, (-1), true, true, (-1), false, true);
    testWBS0.launch((int)' ', true, false, (int)(short)1, true, true, (int)'a', false, false);

  }

  @Test
  public void test123() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test123"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)'a', true, false, (int)(short)1, false, false, (int)(byte)10, true, true);
    testWBS0.launch(10, true, false, 100, false, true, (int)(short)(-1), true, false);
    testWBS0.launch((int)'a', true, false, (int)' ', true, false, (int)'a', false, true);
    testWBS0.launch((int)(short)100, true, false, 100, false, true, 1, true, true);

  }

  @Test
  public void test124() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test124"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((-1), false, true, 10, false, false, 1, true, true);
    testWBS0.launch((int)(byte)0, true, false, 0, false, false, (int)(short)(-1), false, false);
    testWBS0.launch((-1), false, false, (int)(short)(-1), false, false, (int)'#', true, true);
    testWBS0.launch((int)'4', true, false, 1, false, true, (int)(byte)10, true, false);
    testWBS0.launch((int)(byte)10, true, false, 100, false, false, (int)(byte)100, false, true);
    testWBS0.launch((int)'#', true, false, 0, true, true, 0, true, true);
    testWBS0.launch((int)' ', false, false, 1, true, false, 100, true, true);
    testWBS0.launch((int)(short)1, false, true, 0, false, false, 1, false, true);

  }

  @Test
  public void test125() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test125"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)10, false, true, 0, true, false, (int)(short)10, true, false);
    testWBS0.launch((int)(short)10, true, false, (int)' ', true, false, (int)(byte)(-1), false, true);
    testWBS0.launch((int)(short)0, false, true, (int)(short)100, false, true, (int)(byte)1, false, true);
    testWBS0.launch((int)(byte)1, false, false, (int)(byte)0, true, true, (-1), true, false);
    testWBS0.launch((int)(byte)100, false, true, (int)(byte)10, false, true, 0, false, true);
    testWBS0.launch((int)(byte)1, true, true, (int)(short)10, false, false, (int)'#', true, false);
    testWBS0.launch((int)(short)(-1), false, false, (int)(short)1, true, false, (int)(short)10, true, true);

  }

  @Test
  public void test126() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test126"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch(1, false, true, (int)(short)0, false, false, (int)'#', true, false);
    testWBS0.launch((int)'4', false, false, (int)'a', false, true, (int)(byte)10, false, true);
    testWBS0.launch((int)(short)1, true, false, (int)(byte)0, false, true, (-1), false, true);
    testWBS0.launch((int)(byte)100, true, true, (int)(byte)10, false, false, (int)(short)1, true, true);
    testWBS0.launch((int)(short)10, true, true, 0, false, true, (int)(short)(-1), false, true);

  }

  @Test
  public void test127() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test127"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(byte)10, false, false, 1, false, false, (-1), true, false);
    testWBS0.launch((int)'4', true, false, (int)(short)(-1), true, true, (int)(short)100, true, true);
    testWBS0.launch(0, true, true, (int)(byte)0, true, true, (int)(byte)0, false, true);
    testWBS0.launch(0, false, false, (int)(byte)(-1), false, false, (-1), false, false);
    testWBS0.launch(1, false, false, (int)(short)0, false, true, 0, false, false);

  }

  @Test
  public void test128() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test128"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(byte)10, true, false, (int)'4', false, false);
    testWBS0.launch((int)' ', false, false, (int)(byte)(-1), false, false, 0, false, false);
    testWBS0.launch((int)(byte)0, false, false, 100, false, true, (int)' ', true, false);
    testWBS0.launch(10, true, true, 10, false, false, (int)(short)100, true, false);
    testWBS0.launch(0, false, false, (int)'#', false, true, (int)(byte)0, true, false);

  }

  @Test
  public void test129() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test129"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch(0, false, true, (int)(byte)100, true, true, (int)(short)10, true, false);
    testWBS0.launch((int)'4', true, false, 0, false, false, (int)(byte)100, false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(byte)(-1), false, true, 0, false, true);
    testWBS0.launch((int)'#', false, false, (int)(short)(-1), false, false, 10, false, false);
    testWBS0.launch((int)' ', false, true, (int)(short)(-1), true, false, (int)(short)100, true, true);

  }

  @Test
  public void test130() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test130"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)10, false, false, 100, false, true, 0, true, true);
    testWBS0.launch((int)'4', true, false, (int)(byte)(-1), false, false, (int)(byte)(-1), true, true);
    testWBS0.launch(1, true, true, (int)(byte)(-1), true, true, (int)(short)100, false, false);
    testWBS0.launch((int)(byte)100, false, true, (int)'4', true, true, 1, false, true);
    testWBS0.launch((-1), false, true, 0, false, false, (int)(short)1, true, false);
    testWBS0.launch((int)(byte)0, true, true, (int)(byte)10, false, true, (int)(short)1, false, false);

  }

  @Test
  public void test131() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test131"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(10, false, false, (int)(byte)10, false, false, (int)'4', true, true);
    testWBS0.launch((int)'a', true, true, (int)' ', false, true, (int)(byte)(-1), false, false);
    testWBS0.launch((-1), false, false, (int)(byte)(-1), true, false, (int)(short)0, true, false);
    testWBS0.launch((int)(short)10, true, false, 1, true, true, (int)'#', false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(byte)100, false, true, (int)(short)10, true, false);
    testWBS0.launch((int)(short)10, false, true, (int)(byte)0, true, true, (int)(short)1, true, true);

  }

  @Test
  public void test132() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test132"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, true, false, (int)(short)0, false, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)100, false, false, 10, false, false);
    testWBS0.launch(100, false, true, 0, true, false, (int)(byte)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(short)100, true, true);
    testWBS0.launch(100, false, true, (int)(short)(-1), false, false, (int)'#', true, false);

  }

  @Test
  public void test133() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test133"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)'a', true, false, (int)(short)1, false, false, (int)(byte)10, true, true);
    testWBS0.launch(10, true, false, 100, false, true, (int)(short)(-1), true, false);
    testWBS0.launch((int)(byte)(-1), false, false, (int)(short)(-1), false, true, 0, true, false);
    testWBS0.launch((int)(byte)1, false, true, 100, false, true, (int)(short)100, false, false);
    testWBS0.launch((int)'4', true, false, (int)(byte)1, true, false, (int)(short)1, false, true);
    testWBS0.launch((int)(byte)0, true, false, (int)(byte)10, true, true, (int)(byte)10, true, false);
    testWBS0.launch((int)(short)0, true, false, (int)(byte)0, true, true, (int)'#', true, false);

  }

  @Test
  public void test134() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test134"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch(1, true, false, 1, false, true, 0, false, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(byte)0, false, true, (int)(short)(-1), false, true);
    testWBS0.launch((int)(byte)(-1), true, false, 0, false, false, 1, true, false);
    testWBS0.launch((int)(short)10, true, false, (int)(byte)(-1), true, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)(-1), false, true, 10, false, true, (int)'a', false, true);
    testWBS0.launch((int)'#', false, true, (int)(byte)1, true, false, (int)(byte)0, false, false);

  }

  @Test
  public void test135() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test135"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch(1, true, false, (int)'#', false, false, (int)(byte)(-1), false, false);
    testWBS0.launch(0, true, false, (int)(short)(-1), false, false, (int)(short)0, true, false);
    testWBS0.launch((int)(short)100, true, true, 1, true, false, (int)(byte)100, false, true);
    testWBS0.launch((int)'#', true, true, (int)'4', false, false, (int)(byte)1, false, true);
    testWBS0.launch((int)(byte)(-1), false, false, 1, false, true, (int)' ', false, false);

  }

  @Test
  public void test136() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test136"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(byte)10, true, false, (int)'4', false, false);
    testWBS0.launch(0, true, false, 0, true, true, (int)(short)10, true, false);
    testWBS0.launch((int)(short)0, true, true, (int)(short)100, true, true, (int)(byte)(-1), false, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)100, false, false, (int)'#', false, true);
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', false, false, (int)(byte)100, false, false);
    testWBS0.launch((-1), false, false, 100, false, true, (int)(byte)0, true, false);

  }

  @Test
  public void test137() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test137"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)10, false, true, 0, true, false, (int)(short)10, true, false);
    testWBS0.launch((int)(short)1, true, false, (int)(byte)(-1), true, true, (int)(byte)1, false, false);
    testWBS0.launch((int)(byte)(-1), false, false, 1, true, true, (int)(short)0, true, true);
    testWBS0.launch(10, false, true, (int)(byte)100, true, false, (int)(byte)100, false, false);
    testWBS0.launch((int)(byte)10, true, true, (int)' ', true, true, (int)(byte)1, true, false);
    testWBS0.launch((int)(short)(-1), false, false, (int)(short)100, true, true, 10, false, false);
    testWBS0.launch(0, false, true, 10, true, false, (int)(short)(-1), false, true);
    testWBS0.launch((int)(byte)(-1), true, false, 1, true, false, (int)(byte)100, true, true);

  }

  @Test
  public void test138() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test138"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)10, false, true, 0, true, false, (int)(short)10, true, false);
    testWBS0.launch(10, true, false, (int)(short)100, false, true, (int)(byte)10, true, false);
    testWBS0.launch((-1), true, true, 0, false, false, (int)(short)10, true, false);
    testWBS0.launch((int)(short)10, true, false, (int)(short)(-1), false, false, (int)'#', false, true);
    testWBS0.launch((int)(byte)10, false, true, 1, true, true, 0, false, false);
    testWBS0.launch(1, true, true, (int)(byte)100, false, true, 10, false, false);
    testWBS0.launch(0, false, true, (int)(short)0, false, false, (int)(byte)(-1), false, true);

  }

  @Test
  public void test139() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test139"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)1, true, true, 0, false, true);
    testWBS0.launch((int)(short)0, true, false, (int)'4', true, false, (int)(short)10, true, true);
    testWBS0.launch((int)' ', false, false, (int)'a', false, true, (int)' ', true, false);

  }

  @Test
  public void test140() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test140"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, true, false, (int)(short)0, false, true);
    testWBS0.launch(100, true, true, (int)(byte)(-1), false, false, 10, false, false);
    testWBS0.launch(0, false, true, (int)(byte)0, true, false, (-1), false, false);
    testWBS0.launch((int)(byte)100, false, true, (int)(byte)10, true, true, 100, true, false);
    testWBS0.launch((-1), true, true, (int)(short)(-1), false, true, 1, true, true);
    testWBS0.launch((int)'a', false, false, (int)'#', false, false, (int)(byte)(-1), false, true);

  }

  @Test
  public void test141() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test141"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)10, false, false, 100, false, true, 0, true, true);
    testWBS0.launch((int)'4', true, false, (int)(byte)(-1), false, false, (int)(byte)(-1), true, true);
    testWBS0.launch(0, true, true, (int)(short)0, false, false, (int)(short)100, true, false);
    testWBS0.launch((int)(short)10, false, true, (int)(byte)0, false, true, (int)(short)(-1), true, true);
    testWBS0.launch((int)(short)0, false, true, (int)(byte)10, true, true, (int)(short)1, true, false);
    testWBS0.launch((int)(short)0, false, false, (int)(short)(-1), false, false, (-1), true, true);

  }

  @Test
  public void test142() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test142"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)1, true, true, 0, false, true);
    testWBS0.launch((int)'4', true, true, (int)' ', true, false, (int)(byte)0, true, true);
    testWBS0.launch(0, false, false, (int)' ', false, false, (int)'4', false, true);
    testWBS0.launch((int)(byte)0, true, true, 0, false, true, (int)(short)1, true, false);
    testWBS0.launch(10, false, false, (int)(short)100, false, false, (int)'a', false, false);

  }

  @Test
  public void test143() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test143"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, true, false, (int)(short)0, false, true);
    testWBS0.launch((int)(short)1, true, false, (int)(short)0, true, true, (int)(byte)0, true, false);
    testWBS0.launch(0, true, true, (-1), false, false, 1, true, false);
    testWBS0.launch((int)(short)(-1), false, false, (int)'#', false, false, 1, true, false);
    testWBS0.launch((int)(short)0, false, false, (int)(short)0, true, false, (int)'a', false, true);
    testWBS0.launch((int)(byte)0, true, false, (int)(short)0, false, true, (int)(short)0, false, true);
    testWBS0.launch(0, false, true, (int)'#', true, false, 100, true, false);

  }

  @Test
  public void test144() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test144"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(byte)10, false, false, (int)'a', false, true);
    testWBS0.launch((int)'#', true, true, 0, true, false, (int)(byte)100, true, true);
    testWBS0.launch((int)(short)10, false, true, 0, true, true, (int)'#', false, true);
    testWBS0.launch((int)'a', true, false, 10, false, false, (int)(byte)1, false, true);
    testWBS0.launch(100, true, false, (int)' ', false, false, (int)(short)10, false, false);

  }

  @Test
  public void test145() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test145"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)10, false, false, 100, false, true, 0, true, true);
    testWBS0.launch((int)'4', true, false, (int)(byte)(-1), false, false, (int)(byte)(-1), true, true);
    testWBS0.launch(100, true, false, (int)(byte)1, false, true, (int)'a', false, true);
    testWBS0.launch((int)(byte)(-1), false, true, (int)' ', true, true, 0, false, false);
    testWBS0.launch(0, true, false, (int)(byte)(-1), true, true, (int)(byte)(-1), false, true);

  }

  @Test
  public void test146() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test146"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, true, false, (int)(short)0, false, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)100, false, false, 10, false, false);
    testWBS0.launch((int)(byte)(-1), true, false, 100, true, false, (int)(byte)1, false, true);
    testWBS0.launch((int)(short)(-1), true, false, (int)' ', false, false, 100, true, true);
    testWBS0.launch((int)(short)0, false, true, (int)' ', true, true, 1, false, true);

  }

  @Test
  public void test147() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test147"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)1, false, false, (int)(short)0, true, false, 10, false, true);
    testWBS0.launch((int)'#', false, false, (int)' ', false, true, (int)'#', false, true);
    testWBS0.launch((int)' ', false, true, 1, true, true, (int)'4', true, false);
    testWBS0.launch((int)'#', true, true, (int)(short)10, true, false, 0, false, false);
    testWBS0.launch((int)(short)10, false, false, (int)(byte)(-1), true, false, (int)(short)(-1), true, true);
    testWBS0.launch((int)(byte)(-1), false, false, (int)(byte)(-1), true, true, (int)(byte)1, false, false);
    testWBS0.launch((int)(byte)1, true, false, (int)(byte)(-1), false, false, 10, true, true);

  }

  @Test
  public void test148() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test148"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch(0, false, true, (int)(byte)100, true, true, (int)(short)10, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(short)1, true, false, (int)'#', true, true);
    testWBS0.launch(10, true, false, 0, true, true, (int)(short)100, false, true);
    testWBS0.launch((int)(short)1, true, false, (int)(byte)1, true, true, (int)'a', false, false);

  }

  @Test
  public void test149() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test149"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)1, false, false, (int)(short)0, true, false, 10, false, true);
    testWBS0.launch((int)(byte)100, true, false, (int)(short)10, true, false, 0, true, true);
    testWBS0.launch((int)(byte)100, true, false, 0, false, true, (int)(byte)(-1), false, false);
    testWBS0.launch(0, false, false, (int)(short)(-1), false, false, (int)' ', false, true);
    testWBS0.launch(1, false, false, (int)(byte)10, true, true, 0, true, true);
    testWBS0.launch((int)(byte)10, false, true, (int)(short)100, false, false, 100, true, false);

  }

  @Test
  public void test150() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test150"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch(0, true, true, 100, true, false, (-1), false, false);
    testWBS0.launch((int)(short)10, true, false, (int)(short)0, false, false, 0, true, false);
    testWBS0.launch((int)(byte)100, true, true, (int)(byte)10, true, true, (int)(short)1, false, false);
    testWBS0.launch((int)' ', false, false, (int)(short)0, true, false, (int)' ', false, false);

  }

  @Test
  public void test151() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test151"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)0, true, false, (int)'a', false, false, (int)(short)0, true, false);
    testWBS0.launch((int)'a', false, true, 0, false, false, 1, true, true);
    testWBS0.launch((int)'#', false, false, (int)'4', true, false, (int)' ', true, false);
    testWBS0.launch(1, true, false, (int)'a', true, false, (int)(byte)100, true, false);

  }

  @Test
  public void test152() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test152"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, true, false, (int)(short)0, false, true);
    testWBS0.launch((int)(byte)0, true, false, (int)(byte)1, false, false, (int)'4', true, true);
    testWBS0.launch((int)'a', true, false, (int)(short)10, false, true, (-1), true, false);
    testWBS0.launch((int)(byte)100, true, true, (-1), false, true, 1, false, false);
    testWBS0.launch((int)(short)100, false, false, (int)'a', true, true, 0, true, true);
    testWBS0.launch((int)' ', false, false, (int)(byte)1, false, true, (int)'a', true, true);

  }

  @Test
  public void test153() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test153"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, true, false, (int)(short)0, false, true);
    testWBS0.launch((int)(short)1, true, false, (int)(short)0, true, true, (int)(byte)0, true, false);
    testWBS0.launch(100, true, false, (-1), false, false, (int)(byte)10, true, false);
    testWBS0.launch((int)' ', true, false, (int)' ', true, true, (int)(short)(-1), true, true);
    testWBS0.launch((int)(short)(-1), false, false, (int)(short)10, false, false, (-1), false, false);
    testWBS0.launch(10, true, true, (int)(byte)100, false, true, (-1), true, true);

  }

  @Test
  public void test154() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test154"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)'a', false, false, (int)(byte)0, false, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, true, (int)'4', true, false, (int)(byte)0, true, false);
    testWBS0.launch((int)' ', false, false, (int)(byte)10, false, true, (int)'4', false, false);
    testWBS0.launch(10, false, true, 10, false, true, 1, true, true);
    testWBS0.launch((int)(short)10, false, false, (int)(byte)1, true, false, (int)(short)0, true, false);

  }

  @Test
  public void test155() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test155"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(byte)10, true, false, (int)'4', false, false);
    testWBS0.launch(10, false, true, (int)(short)0, false, false, (int)(byte)10, true, false);
    testWBS0.launch(1, true, false, (int)'4', true, true, (int)(short)10, true, true);
    testWBS0.launch(100, false, true, (int)(byte)(-1), false, true, (int)(short)100, true, true);
    testWBS0.launch(1, true, true, 1, true, true, 100, true, false);
    testWBS0.launch((int)(short)(-1), true, false, (int)(byte)10, true, true, (int)(byte)(-1), false, false);
    testWBS0.launch((int)(byte)10, false, false, 10, true, true, (int)'4', false, false);

  }

  @Test
  public void test156() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test156"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch(0, true, false, (int)(byte)100, true, true, 100, true, false);
    testWBS0.launch((int)(short)0, false, true, 10, false, false, (int)'a', false, true);
    testWBS0.launch(100, false, true, 10, false, false, 0, false, true);

  }

  @Test
  public void test157() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test157"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((-1), false, true, 10, false, false, 1, true, true);
    testWBS0.launch(10, true, false, (int)' ', true, false, (int)(short)(-1), true, false);
    testWBS0.launch((int)(short)10, true, true, 10, true, false, (-1), false, true);
    testWBS0.launch((int)'4', true, true, (int)(short)10, true, true, (int)(byte)1, true, false);
    testWBS0.launch((int)(short)10, false, true, (-1), true, true, (int)(byte)100, false, true);

  }

  @Test
  public void test158() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test158"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, true, false, (int)(short)0, false, true);
    testWBS0.launch(100, true, true, (int)(byte)(-1), false, false, 10, false, false);
    testWBS0.launch(0, false, true, (int)(byte)0, true, false, (-1), false, false);
    testWBS0.launch((int)(byte)1, true, false, (int)'#', false, true, (int)'4', false, true);
    testWBS0.launch((int)(byte)1, false, true, (int)(byte)0, false, true, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)(-1), false, true, (int)(short)100, true, false, (int)(short)100, true, true);
    testWBS0.launch(10, true, false, (int)(byte)10, true, false, (-1), true, false);

  }

  @Test
  public void test159() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test159"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)10, false, false, 100, false, true, 0, true, true);
    testWBS0.launch((int)'4', true, false, (int)(byte)(-1), false, false, (int)(byte)(-1), true, true);
    testWBS0.launch(0, true, true, (int)(short)0, false, false, (int)(short)100, true, false);
    testWBS0.launch((int)' ', false, true, (int)(byte)1, true, false, 0, true, false);
    testWBS0.launch(10, true, false, 1, true, true, (int)'4', false, true);
    testWBS0.launch((int)(byte)100, false, true, (int)'#', true, false, 10, false, true);
    testWBS0.launch((int)'4', true, false, (-1), false, false, (int)(short)10, true, true);

  }

  @Test
  public void test160() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test160"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, true, false, (int)(short)0, false, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)100, false, false, 10, false, false);
    testWBS0.launch((int)(byte)(-1), true, false, 100, true, false, (int)(byte)1, false, true);
    testWBS0.launch((int)'a', true, false, (int)(byte)(-1), false, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)0, true, false, (int)'#', false, false, (int)'4', false, false);
    testWBS0.launch((int)(byte)10, false, false, 0, true, false, 10, false, true);
    testWBS0.launch(0, false, false, (int)(byte)1, false, true, (int)'#', true, false);

  }

  @Test
  public void test161() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test161"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)10, false, true, 0, true, false, (int)(short)10, true, false);
    testWBS0.launch((int)(short)(-1), false, false, (int)'a', false, true, (int)(short)100, false, true);
    testWBS0.launch((int)(short)100, true, false, (int)(byte)100, true, false, (int)(short)100, false, true);
    testWBS0.launch((int)(short)0, true, false, 100, true, false, (int)(short)10, true, true);
    testWBS0.launch((int)'#', false, false, (int)(short)10, true, false, 1, true, true);
    testWBS0.launch((int)(byte)1, true, true, (int)'#', true, false, (int)'#', false, false);
    testWBS0.launch((int)(short)10, false, true, (int)'a', false, false, (int)' ', false, true);

  }

  @Test
  public void test162() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test162"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch(1, false, true, (int)(short)0, false, false, (int)'#', true, false);
    testWBS0.launch((int)'4', false, false, (int)'a', false, true, (int)(byte)10, false, true);
    testWBS0.launch((int)(short)1, true, false, (int)(byte)0, false, true, (-1), false, true);
    testWBS0.launch(10, true, true, 0, true, false, (int)(byte)100, true, false);
    testWBS0.launch((-1), true, false, 100, true, false, (-1), true, false);
    testWBS0.launch((int)(byte)1, true, false, (int)' ', false, true, (int)'a', false, false);

  }

  @Test
  public void test163() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test163"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(byte)(-1), false, false, 1, true, false, (int)(byte)10, true, false);
    testWBS0.launch((-1), false, true, 100, true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)100, true, true, 10, false, true, (int)(byte)100, true, false);
    testWBS0.launch((int)(short)10, true, false, (int)(short)10, true, true, (int)'a', false, true);
    testWBS0.launch((int)(short)10, true, true, 10, true, false, 0, false, false);
    testWBS0.launch((int)'4', true, false, (int)(byte)10, false, false, (int)(byte)10, true, false);

  }

  @Test
  public void test164() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test164"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((-1), false, true, 10, false, false, 1, true, true);
    testWBS0.launch(0, true, false, 0, true, true, (int)(byte)100, true, false);

  }

  @Test
  public void test165() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test165"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, true, false, (int)(short)0, false, true);
    testWBS0.launch(100, true, true, (int)(byte)(-1), false, false, 10, false, false);
    testWBS0.launch(0, false, true, (int)(byte)0, true, false, (-1), false, false);
    testWBS0.launch(0, false, true, (int)(byte)1, false, true, (int)(short)0, false, true);
    testWBS0.launch((int)'a', true, false, 1, false, false, (int)(short)1, false, false);
    testWBS0.launch(0, false, true, 0, true, false, (int)(short)10, false, false);

  }

  @Test
  public void test166() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test166"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, true, false, (int)(short)0, false, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)100, false, false, 10, false, false);
    testWBS0.launch((int)'a', true, false, 100, false, true, (int)(short)0, false, false);
    testWBS0.launch(0, false, true, (int)'4', true, false, 1, false, true);
    testWBS0.launch((int)(byte)1, false, true, (int)'a', true, false, (int)'4', true, true);

  }

  @Test
  public void test167() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test167"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(byte)10, true, false, (int)'4', false, false);
    testWBS0.launch(0, true, false, 0, true, true, (int)(short)10, true, false);
    testWBS0.launch((int)(byte)100, true, false, 0, true, true, (int)(short)(-1), false, false);
    testWBS0.launch((int)'4', true, false, (int)(short)(-1), true, false, (int)' ', false, false);
    testWBS0.launch((int)(short)(-1), false, true, 10, false, true, (int)'#', false, false);
    testWBS0.launch((int)(byte)1, true, true, (-1), true, true, (int)(short)10, false, false);

  }

  @Test
  public void test168() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test168"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)10, false, true, 0, true, false, (int)(short)10, true, false);
    testWBS0.launch((int)(short)10, true, false, (int)' ', true, false, (int)(byte)(-1), false, true);
    testWBS0.launch((int)(short)0, false, true, (int)(short)100, false, true, (int)(byte)1, false, true);
    testWBS0.launch((int)(byte)1, false, false, (int)(byte)0, true, true, (-1), true, false);
    testWBS0.launch((int)(byte)100, false, true, (int)(byte)10, false, true, 0, false, true);
    testWBS0.launch((int)'#', false, true, (int)' ', true, true, (int)(short)(-1), true, false);
    testWBS0.launch((-1), false, true, 0, true, true, (int)(byte)100, true, false);
    testWBS0.launch(100, false, false, (int)(byte)0, false, false, 0, false, true);

  }

  @Test
  public void test169() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test169"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)10, false, false, 100, false, true, 0, true, true);
    testWBS0.launch((int)'4', true, false, (int)(byte)(-1), false, false, (int)(byte)(-1), true, true);
    testWBS0.launch((int)(short)(-1), false, true, 1, true, false, (int)(short)0, true, true);
    testWBS0.launch((int)'4', false, true, (int)(byte)1, false, true, (int)'#', true, false);
    testWBS0.launch(10, false, true, 0, true, true, 0, true, false);
    testWBS0.launch((int)(short)0, true, true, 10, false, false, (int)(short)1, true, false);
    testWBS0.launch((int)'a', true, false, (int)' ', true, true, (int)(short)(-1), true, true);

  }

  @Test
  public void test170() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test170"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)1, true, true, 0, false, true);
    testWBS0.launch((int)(byte)(-1), true, false, (int)(short)(-1), false, false, (int)' ', false, false);
    testWBS0.launch((-1), false, false, (int)(byte)0, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, true, (int)(short)100, true, true, (int)'#', true, false);
    testWBS0.launch(0, false, true, (int)(short)(-1), true, false, (int)(byte)(-1), false, true);
    testWBS0.launch((int)'a', false, true, (int)(short)(-1), true, false, (int)'4', true, true);
    testWBS0.launch((int)(byte)1, false, true, (-1), false, true, (int)(byte)10, true, false);

  }

  @Test
  public void test171() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test171"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)'a', false, false, (int)(byte)0, false, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)100, true, true, (-1), false, true, (int)(short)10, true, false);
    testWBS0.launch((int)'a', false, false, 10, true, false, 1, true, false);
    testWBS0.launch((int)(byte)(-1), false, false, (-1), false, true, (int)(byte)(-1), true, true);

  }

  @Test
  public void test172() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test172"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(byte)1, false, true, 1, false, false, (-1), false, true);
    testWBS0.launch((int)(short)10, true, false, (int)(byte)10, false, false, (int)(short)10, true, false);
    testWBS0.launch(100, true, false, 100, false, false, 10, true, false);
    testWBS0.launch((int)'a', false, true, 0, false, true, 0, false, true);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)10, false, true, 0, true, false);

  }

  @Test
  public void test173() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test173"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch(0, false, true, (int)(byte)10, false, false, 1, false, false);
    testWBS0.launch(0, true, false, (int)'#', true, true, (int)(byte)10, false, false);
    testWBS0.launch(0, true, false, (int)(short)(-1), false, true, (int)'#', false, true);
    testWBS0.launch((int)(short)100, false, false, (int)'4', false, true, (int)'a', false, true);
    testWBS0.launch(100, false, false, (int)(short)(-1), true, false, 0, false, false);

  }

  @Test
  public void test174() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test174"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch(100, false, false, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)(byte)0, true, true, (int)(short)10, true, true, 0, false, true);
    testWBS0.launch((int)'4', false, true, (int)'#', true, true, 10, false, false);
    testWBS0.launch(0, false, true, 10, true, true, (int)(byte)1, true, false);

  }

  @Test
  public void test175() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test175"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch(10, true, true, 100, false, false, 0, false, false);
    testWBS0.launch((-1), false, false, (-1), true, false, (int)'a', true, false);
    testWBS0.launch((int)(byte)10, false, true, (int)(short)(-1), false, false, (int)(byte)10, false, true);
    testWBS0.launch(0, true, false, 1, false, true, (int)(byte)0, false, false);
    testWBS0.launch((int)'#', false, false, (-1), false, true, 0, false, true);

  }

  @Test
  public void test176() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test176"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, false, true, 0, true, true, (int)(byte)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, 10, false, true, (int)(short)(-1), true, true);
    testWBS0.launch(100, true, false, (int)(byte)0, true, false, (int)(byte)100, true, true);
    testWBS0.launch(10, false, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)0, true, true, (int)'4', true, false, (int)(short)10, true, true);

  }

  @Test
  public void test177() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test177"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)10, false, true, 0, true, false, (int)(short)10, true, false);
    testWBS0.launch((int)(byte)10, false, false, 1, true, true, (int)(short)100, false, true);
    testWBS0.launch(0, true, true, (int)'#', true, false, (int)(short)(-1), true, true);
    testWBS0.launch((int)(byte)10, false, true, (int)(short)(-1), true, false, 100, true, false);
    testWBS0.launch((int)(byte)1, false, true, (int)'4', true, true, (int)(short)10, true, true);

  }

  @Test
  public void test178() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test178"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch(0, false, true, (int)(byte)10, false, false, 1, false, false);
    testWBS0.launch(0, true, false, (int)'#', true, true, (int)(byte)10, false, false);
    testWBS0.launch(0, true, false, (int)(byte)1, true, false, (int)(byte)0, false, false);
    testWBS0.launch(1, true, true, (int)'4', true, false, (int)'#', true, false);
    testWBS0.launch(10, false, true, 1, true, false, (int)'4', true, false);
    testWBS0.launch((int)(short)1, false, false, (int)(short)1, true, false, 0, false, false);

  }

  @Test
  public void test179() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test179"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)1, false, false, (int)(short)1, false, true, 0, true, true);
    testWBS0.launch((int)(short)100, false, false, (int)'4', true, true, (int)'#', false, false);
    testWBS0.launch((int)'#', false, false, (int)'4', true, false, (int)(byte)100, true, false);
    testWBS0.launch((int)(short)100, false, false, 10, false, false, 1, true, false);
    testWBS0.launch(10, false, true, (int)(byte)100, true, true, 10, true, false);
    testWBS0.launch((int)(short)1, false, true, (int)(short)1, false, true, (int)(short)100, false, true);

  }

  @Test
  public void test180() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test180"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(byte)(-1), false, false, 1, true, false, (int)(byte)10, true, false);
    testWBS0.launch((int)(short)1, false, false, (int)(short)0, false, true, 0, false, true);
    testWBS0.launch((int)(short)(-1), false, true, (int)'a', false, true, 10, true, true);
    testWBS0.launch((int)(short)10, false, true, (int)(short)0, false, true, (int)(short)(-1), false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, true, (int)(byte)1, false, true);

  }

  @Test
  public void test181() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test181"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(byte)1, false, true, 1, false, false, (-1), false, true);
    testWBS0.launch((-1), false, false, (int)'4', true, false, 0, true, true);
    testWBS0.launch((int)(byte)0, true, false, (int)' ', false, true, (int)'#', true, true);
    testWBS0.launch((int)(short)100, false, false, 1, true, false, (int)(short)0, true, false);
    testWBS0.launch((int)'4', true, true, (int)(byte)(-1), false, false, 10, false, false);

  }

  @Test
  public void test182() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test182"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch(0, false, true, (int)(byte)100, true, true, (int)(short)10, true, false);
    testWBS0.launch((int)'4', true, false, 0, false, false, (int)(byte)100, false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(byte)(-1), false, true, 0, false, true);
    testWBS0.launch((int)'#', false, false, (int)(short)(-1), false, false, 10, false, false);
    testWBS0.launch((int)(byte)1, false, false, (int)'4', false, true, (int)'#', false, false);

  }

  @Test
  public void test183() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test183"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, false, true, 0, true, true, (int)(byte)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, 10, false, true, (int)(short)(-1), true, true);
    testWBS0.launch(100, true, false, (int)(byte)0, true, false, (int)(byte)100, true, true);
    testWBS0.launch((int)(short)0, false, true, (int)(short)1, false, true, (int)(short)0, false, true);
    testWBS0.launch(10, true, true, (int)(byte)100, false, false, (int)'4', false, true);

  }

  @Test
  public void test184() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test184"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)1, true, true, 0, false, true);
    testWBS0.launch((int)(byte)(-1), true, false, (int)(short)(-1), false, false, (int)' ', false, false);
    testWBS0.launch((int)(byte)(-1), true, false, (int)(byte)100, false, true, (int)(byte)10, false, false);
    testWBS0.launch((int)(short)0, false, false, 0, true, false, (-1), true, true);

  }

  @Test
  public void test185() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test185"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)1, true, true, 0, false, true);
    testWBS0.launch((int)(byte)(-1), true, false, (int)(short)(-1), false, false, (int)' ', false, false);
    testWBS0.launch((-1), false, false, (int)(byte)0, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, true, (int)(short)100, true, true, (int)'#', true, false);
    testWBS0.launch((int)(byte)1, false, true, (int)(byte)0, false, true, (int)(short)1, false, true);
    testWBS0.launch((int)(byte)1, false, false, (int)(short)1, true, false, 100, false, true);

  }

  @Test
  public void test186() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test186"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 100, false, true, (int)(byte)1, true, false);
    testWBS0.launch(0, false, false, (-1), false, true, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)(-1), true, false, 0, true, false, (int)(byte)(-1), false, false);
    testWBS0.launch((int)(short)100, true, true, (int)'4', true, true, (int)'a', false, true);
    testWBS0.launch((int)(byte)100, true, false, (int)(byte)1, false, false, (int)(byte)10, true, true);
    testWBS0.launch((int)'#', false, false, 1, false, true, (int)(short)10, false, false);
    testWBS0.launch(100, false, false, 10, false, false, (-1), true, false);
    testWBS0.launch(0, true, true, 10, true, true, 0, false, false);

  }

  @Test
  public void test187() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test187"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch((int)(byte)0, true, false, 1, false, true, 100, true, false);
    testWBS0.launch((int)(short)0, false, true, (int)(byte)100, false, false, 0, false, false);
    testWBS0.launch((int)(short)0, false, false, (int)(byte)(-1), false, false, 10, false, true);
    testWBS0.launch((int)'#', false, false, (int)(short)10, true, false, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), true, false, 0, true, true, 0, false, false);

  }

  @Test
  public void test188() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test188"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)1, true, true, 0, false, true);
    testWBS0.launch((int)(short)(-1), false, false, (int)(byte)(-1), true, true, 100, false, true);
    testWBS0.launch((int)(short)100, false, true, 1, true, true, (int)(byte)(-1), false, false);
    testWBS0.launch((int)'a', true, true, 0, false, false, (int)(byte)0, true, false);

  }

  @Test
  public void test189() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test189"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)10, false, false, (int)(byte)100, true, true);
    testWBS0.launch((-1), false, true, (int)(short)0, false, true, 0, false, true);
    testWBS0.launch((int)(short)1, false, true, (int)' ', false, false, 100, true, false);
    testWBS0.launch((int)(byte)10, true, false, (int)'a', false, false, (-1), true, true);

  }

  @Test
  public void test190() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test190"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(short)0, true, false, (int)(short)(-1), false, false, 0, true, true);
    testWBS0.launch((int)'#', true, false, (int)(byte)1, false, false, (int)(short)100, false, true);
    testWBS0.launch((int)' ', true, true, (int)(short)100, true, true, (-1), true, true);

  }

  @Test
  public void test191() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test191"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)0, true, false, (int)'a', false, false, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)1, true, true, 0, false, true, (int)(short)100, false, false);
    testWBS0.launch((int)'a', true, false, (int)(byte)0, false, false, 100, false, true);

  }

  @Test
  public void test192() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test192"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)0, false, true, (-1), false, false, (-1), true, true);
    testWBS0.launch((int)'a', false, false, 1, false, true, (int)(byte)1, false, false);
    testWBS0.launch((int)'4', false, false, (int)(short)1, false, false, (int)' ', false, true);
    testWBS0.launch(0, false, true, 10, true, true, (int)(byte)0, false, true);

  }

  @Test
  public void test193() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test193"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(byte)10, false, false, 1, false, false, (-1), true, false);
    testWBS0.launch((int)'4', true, false, (int)(short)(-1), true, true, (int)(short)100, true, true);
    testWBS0.launch((int)(byte)10, false, false, 0, true, true, (int)(byte)(-1), false, false);
    testWBS0.launch((int)(byte)100, true, false, (int)'#', true, false, 10, false, false);
    testWBS0.launch((int)(short)1, false, false, (int)(short)0, false, true, (int)'#', true, false);

  }

  @Test
  public void test194() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test194"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch((-1), true, false, (int)(short)100, false, false, 1, true, true);
    testWBS0.launch(1, true, false, (int)'a', true, true, 10, true, true);
    testWBS0.launch(100, false, false, 0, false, false, 0, false, false);
    testWBS0.launch((int)(short)1, true, false, (-1), true, false, 0, false, false);

  }

  @Test
  public void test195() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test195"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((-1), false, true, 10, false, false, 1, true, true);
    testWBS0.launch(10, true, false, (int)' ', true, false, (int)(short)(-1), true, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(short)100, true, false, (int)(short)100, true, true);
    testWBS0.launch(10, false, false, 1, false, false, (int)(byte)(-1), false, false);
    testWBS0.launch((-1), false, false, (int)(short)1, true, true, 1, true, false);
    testWBS0.launch((int)(short)1, true, true, (int)(short)10, true, false, (-1), false, true);
    testWBS0.launch((int)(byte)(-1), true, true, (int)(short)(-1), false, true, (int)(short)0, true, false);
    testWBS0.launch((int)'4', false, false, (int)(short)0, false, false, 0, false, false);

  }

  @Test
  public void test196() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test196"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(0, false, false, (int)(short)1, false, true, (int)'#', false, false);
    testWBS0.launch((int)(short)1, true, false, (int)(byte)0, true, true, (int)(short)(-1), true, true);
    testWBS0.launch((int)(byte)(-1), false, false, 0, false, false, (int)(short)(-1), true, true);
    testWBS0.launch((int)(byte)(-1), false, false, (int)(byte)1, true, true, (int)(byte)100, false, false);
    testWBS0.launch((int)(byte)1, false, true, (int)(short)100, false, false, (int)(byte)10, true, true);
    testWBS0.launch((-1), true, false, (int)(byte)100, false, true, (int)'4', false, false);
    testWBS0.launch((int)' ', false, true, (int)(short)1, true, true, (int)'4', false, false);
    testWBS0.launch((int)(byte)1, false, true, 100, false, true, (int)(short)(-1), true, true);

  }

  @Test
  public void test197() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test197"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, true, false, (int)(short)0, false, true);
    testWBS0.launch(100, true, true, (int)(byte)(-1), false, false, 10, false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)100, false, false, 0, false, true);
    testWBS0.launch((int)'#', true, true, 0, true, false, 1, false, true);
    testWBS0.launch(10, false, false, (-1), false, false, (int)(byte)1, false, false);

  }

  @Test
  public void test198() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test198"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(byte)10, true, false, (int)'4', false, false);
    testWBS0.launch(10, false, true, (int)(short)0, false, false, (int)(byte)10, true, false);
    testWBS0.launch((int)(short)10, false, false, 1, true, true, (int)(byte)(-1), true, true);
    testWBS0.launch((int)' ', true, true, (int)(byte)100, true, true, (-1), false, true);
    testWBS0.launch((int)'a', true, true, 0, false, false, (int)(byte)10, true, true);
    testWBS0.launch((int)(short)1, false, true, (int)(short)0, false, false, 0, false, false);
    testWBS0.launch((int)(byte)0, true, true, 10, true, true, (int)(byte)1, false, false);

  }

  @Test
  public void test199() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test199"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)'a', false, false, (int)(byte)0, false, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)100, true, true, (-1), false, true, (int)(short)10, true, false);
    testWBS0.launch(1, true, true, (int)' ', false, true, (int)(short)1, false, false);

  }

  @Test
  public void test200() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test200"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)10, false, false, 100, false, true, 0, true, true);
    testWBS0.launch((int)'4', true, false, (int)(byte)(-1), false, false, (int)(byte)(-1), true, true);
    testWBS0.launch(0, true, true, (int)(byte)10, false, false, 100, false, false);
    testWBS0.launch((int)'4', true, true, (int)' ', false, false, (int)(short)10, false, false);
    testWBS0.launch((int)(byte)1, true, true, 0, false, true, (int)(short)100, false, false);

  }

  @Test
  public void test201() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test201"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)'a', true, false, (int)(short)1, false, false, (int)(byte)10, true, true);
    testWBS0.launch(1, false, true, (int)(byte)10, true, false, 0, true, true);
    testWBS0.launch((int)(byte)0, false, true, (int)' ', false, false, (int)' ', true, true);
    testWBS0.launch((int)(short)(-1), false, true, 1, false, true, (int)(byte)(-1), true, false);
    testWBS0.launch((int)(short)0, false, false, (int)(byte)0, true, true, (int)'#', false, false);
    testWBS0.launch(0, true, false, 0, true, true, 10, true, false);
    testWBS0.launch((int)'a', true, false, 0, true, false, (int)'4', true, false);

  }

  @Test
  public void test202() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test202"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch((-1), true, false, (int)(short)100, false, false, 1, true, true);
    testWBS0.launch((int)(short)1, false, false, 10, true, false, 100, true, true);
    testWBS0.launch((int)'4', false, true, (int)'#', true, false, (-1), true, false);
    testWBS0.launch((-1), true, false, (int)(short)0, true, false, (int)'4', true, false);

  }

  @Test
  public void test203() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test203"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, false, true, 0, true, true, (int)(byte)0, true, false);
    testWBS0.launch((int)(byte)(-1), false, false, (int)(short)0, true, false, (int)(short)1, true, false);
    testWBS0.launch((int)'a', false, false, 10, false, false, (int)' ', false, true);
    testWBS0.launch((int)'4', true, true, (int)'a', false, false, 10, true, true);
    testWBS0.launch((int)(short)(-1), false, false, (int)' ', true, false, (int)(short)0, false, false);

  }

  @Test
  public void test204() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test204"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)0, false, true, (-1), false, false, (-1), true, true);
    testWBS0.launch((int)(short)10, false, false, (int)(short)100, true, true, (int)(short)100, true, true);
    testWBS0.launch((int)(short)100, false, false, (int)'#', true, false, 0, true, true);
    testWBS0.launch((int)(byte)100, false, true, (int)'a', true, false, (int)(short)0, false, false);
    testWBS0.launch((int)(short)10, true, false, (int)(byte)0, false, false, 10, true, false);

  }

  @Test
  public void test205() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test205"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)1, false, false, (int)(short)0, true, false, 10, false, true);
    testWBS0.launch((int)'#', false, false, (int)' ', false, true, (int)'#', false, true);
    testWBS0.launch((int)' ', false, true, 1, true, true, (int)'4', true, false);
    testWBS0.launch((int)'a', true, false, (int)(byte)100, false, true, 0, false, true);
    testWBS0.launch(1, false, false, (int)'#', true, false, (int)(byte)0, false, false);
    testWBS0.launch(0, false, false, (int)(byte)100, true, true, (int)(short)10, false, true);

  }

  @Test
  public void test206() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test206"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(byte)10, true, false, (int)'4', false, false);
    testWBS0.launch(0, true, false, 0, true, true, (int)(short)10, true, false);
    testWBS0.launch((int)(byte)100, true, false, 0, true, true, (int)(short)(-1), false, false);
    testWBS0.launch(1, false, false, 100, true, false, (int)(short)10, true, false);
    testWBS0.launch((int)'4', false, true, (int)(short)(-1), true, false, (int)(short)10, false, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)0, true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)1, true, true, (int)(byte)1, false, true, (int)(byte)100, false, true);

  }

  @Test
  public void test207() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test207"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)1, true, true, 0, false, true);
    testWBS0.launch((int)(byte)100, true, false, (-1), true, true, 10, false, true);
    testWBS0.launch((int)(short)1, true, true, (int)(byte)0, false, false, (int)(byte)0, true, true);
    testWBS0.launch(10, true, true, (int)(short)1, true, false, (int)(short)0, false, false);
    testWBS0.launch(0, false, false, (int)(byte)10, false, true, 10, false, true);
    testWBS0.launch((int)(short)(-1), true, false, (int)' ', false, false, 0, false, true);
    testWBS0.launch((int)(short)0, true, false, (int)(byte)(-1), true, false, (int)(byte)0, true, false);

  }

  @Test
  public void test208() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test208"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, true, false, (int)(short)0, false, true);
    testWBS0.launch(100, true, true, (int)(byte)(-1), false, false, 10, false, false);
    testWBS0.launch(0, false, true, (int)(byte)0, true, false, (-1), false, false);
    testWBS0.launch(0, false, true, (int)(byte)1, false, true, (int)(short)0, false, true);
    testWBS0.launch((int)(byte)1, true, true, (int)(byte)10, true, true, 10, true, true);
    testWBS0.launch(1, true, false, (int)(short)10, false, false, (int)(byte)0, false, false);
    testWBS0.launch((int)' ', false, false, (int)(byte)(-1), true, true, (int)(short)10, true, false);

  }

  @Test
  public void test209() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test209"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch(1, true, false, (int)'#', false, false, (int)(byte)(-1), false, false);
    testWBS0.launch(0, false, true, (int)(byte)100, true, false, (int)'#', true, true);
    testWBS0.launch((int)'#', false, true, (int)' ', false, true, 0, true, true);
    testWBS0.launch((int)(short)(-1), true, false, (int)' ', true, false, (int)(byte)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)10, false, true, 10, true, true);

  }

  @Test
  public void test210() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test210"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch(1, true, false, 1, true, false, 100, false, false);
    testWBS0.launch((-1), false, false, (int)(short)0, true, true, (int)(short)10, false, false);
    testWBS0.launch((int)(short)10, false, false, 100, true, true, (int)(byte)10, true, true);
    testWBS0.launch((int)(short)10, true, false, 0, true, false, (int)(byte)10, true, true);

  }

  @Test
  public void test211() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test211"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(byte)10, true, false, (int)'4', false, false);
    testWBS0.launch(10, false, true, (int)(short)0, false, false, (int)(byte)10, true, false);
    testWBS0.launch(1, true, false, (int)'4', true, true, (int)(short)10, true, true);
    testWBS0.launch((int)(short)0, true, false, (int)(byte)1, false, false, (-1), true, false);
    testWBS0.launch(1, true, false, (int)'a', true, false, 1, false, true);
    testWBS0.launch((-1), true, false, 100, true, true, (int)'#', false, true);

  }

  @Test
  public void test212() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test212"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(short)0, true, true, (-1), false, true, (int)(short)100, true, false);
    testWBS0.launch((int)(short)0, true, true, (int)'#', false, true, (-1), true, false);
    testWBS0.launch((int)(short)0, true, true, (int)(short)(-1), true, false, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)0, true, false, (int)(byte)(-1), true, true);

  }

  @Test
  public void test213() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test213"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)1, false, false, (int)(short)0, true, false, 10, false, true);
    testWBS0.launch((int)'#', false, false, (int)' ', false, true, (int)'#', false, true);
    testWBS0.launch((int)' ', false, true, 1, true, true, (int)'4', true, false);
    testWBS0.launch((int)'#', true, true, (int)(short)10, true, false, 0, false, false);
    testWBS0.launch((int)'a', false, false, (int)(byte)0, false, false, 100, true, true);
    testWBS0.launch((int)'a', false, true, (int)'4', true, false, (int)(short)1, false, true);
    testWBS0.launch((int)'4', false, false, 0, true, false, (-1), false, true);

  }

  @Test
  public void test214() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test214"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)'a', true, false, (int)(short)1, false, false, (int)(byte)10, true, true);
    testWBS0.launch((int)(short)10, true, false, (int)'a', false, false, (int)(short)10, true, true);
    testWBS0.launch((int)(byte)10, false, true, (int)(short)100, true, false, (int)'a', true, false);
    testWBS0.launch((int)(short)100, false, true, (int)(byte)1, false, true, (int)(byte)0, false, true);
    testWBS0.launch((int)'4', true, false, (int)'a', true, false, (-1), false, false);
    testWBS0.launch((int)'4', true, true, 0, false, true, 0, true, false);
    testWBS0.launch(1, false, true, 0, false, true, (int)(byte)100, true, false);
    testWBS0.launch((int)(short)(-1), true, false, (int)(short)(-1), false, false, 0, true, true);

  }

  @Test
  public void test215() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test215"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((-1), false, true, 10, false, false, 1, true, true);
    testWBS0.launch((int)(byte)0, true, false, 0, false, false, (int)(short)(-1), false, false);
    testWBS0.launch(100, true, true, (int)(byte)(-1), false, false, (int)(byte)1, true, false);
    testWBS0.launch(1, true, false, (int)'a', true, true, (int)(byte)0, true, true);
    testWBS0.launch((-1), true, false, (int)(byte)10, false, false, (int)(short)10, false, true);
    testWBS0.launch((int)(byte)1, false, true, (int)(byte)1, true, false, (int)(byte)0, false, true);
    testWBS0.launch((int)(short)0, true, true, 1, false, true, (int)(byte)1, false, true);

  }

  @Test
  public void test216() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test216"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(10, true, true, (int)(byte)0, true, false, (int)'a', false, true);
    testWBS0.launch((int)(short)10, false, false, (int)(byte)0, true, false, (int)(short)(-1), true, true);
    testWBS0.launch((-1), true, true, (int)(byte)10, false, true, (int)(byte)0, true, true);
    testWBS0.launch((int)(short)0, true, true, 100, false, false, (int)' ', true, false);
    testWBS0.launch((int)' ', false, true, (int)(byte)0, false, false, 0, false, false);
    testWBS0.launch(10, true, true, 10, false, false, 10, false, false);
    testWBS0.launch(0, true, true, 1, false, true, (int)'#', true, false);

  }

  @Test
  public void test217() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test217"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)1, false, false, (int)(short)1, false, true, 0, true, true);
    testWBS0.launch((int)(byte)10, false, true, (int)(short)1, false, false, (int)'4', true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(short)1, true, true);
    testWBS0.launch((-1), true, false, 10, true, false, (int)'#', true, false);

  }

  @Test
  public void test218() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test218"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch(1, false, true, (int)(short)0, false, false, (int)'#', true, false);
    testWBS0.launch(100, false, false, 1, true, true, (int)' ', true, false);
    testWBS0.launch((int)(short)10, true, true, 100, false, true, 0, true, false);
    testWBS0.launch(0, false, true, (int)(byte)10, true, false, (int)(short)100, false, true);

  }

  @Test
  public void test219() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test219"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, true, false, (int)(short)0, false, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)100, false, false, 10, false, false);
    testWBS0.launch(100, false, true, 0, true, false, (int)(byte)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)10, true, false, (int)(short)1, false, true);
    testWBS0.launch((int)(short)1, true, false, 1, true, true, 0, true, false);

  }

  @Test
  public void test220() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test220"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)1, true, true, 0, false, true);
    testWBS0.launch((int)(byte)100, true, false, (-1), true, true, 10, false, true);
    testWBS0.launch((int)(short)1, true, true, (int)(byte)0, false, false, (int)(byte)0, true, true);
    testWBS0.launch((int)(byte)100, false, true, (int)' ', false, false, (int)(byte)(-1), true, true);
    testWBS0.launch(1, true, true, 0, false, true, 100, false, false);
    testWBS0.launch((int)(short)(-1), false, false, 1, true, false, (int)'4', false, true);

  }

  @Test
  public void test221() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test221"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch(0, true, true, 100, true, false, (-1), false, false);
    testWBS0.launch((int)'#', true, false, (int)'a', true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)'a', true, true, (int)(short)10, true, true, (int)'a', true, false);
    testWBS0.launch(0, false, true, (int)(byte)1, false, false, 10, false, false);
    testWBS0.launch((int)(short)100, false, true, (int)'#', false, true, (int)(short)10, true, false);
    testWBS0.launch((int)(byte)100, true, true, 0, false, false, 1, false, false);

  }

  @Test
  public void test222() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test222"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)10, false, true, 0, true, false, (int)(short)10, true, false);
    testWBS0.launch((int)(short)1, true, false, (int)(byte)(-1), true, true, (int)(byte)1, false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)100, true, true, (int)'4', true, true);
    testWBS0.launch((int)(short)0, false, false, 100, true, false, (int)(byte)0, false, true);
    testWBS0.launch((int)(byte)100, false, false, 1, false, true, (int)(byte)100, false, true);
    testWBS0.launch((int)'4', true, true, (int)(short)100, true, false, (int)(byte)(-1), true, true);

  }

  @Test
  public void test223() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test223"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(short)0, true, true, (-1), false, true, (int)(short)100, true, false);
    testWBS0.launch((int)(short)0, false, true, (-1), true, false, 10, false, true);
    testWBS0.launch((int)(byte)100, false, false, (int)'4', true, false, (int)'4', false, false);
    testWBS0.launch((int)(short)100, true, false, 1, true, false, 1, false, true);
    testWBS0.launch(100, false, false, 10, false, false, (int)'a', false, true);

  }

  @Test
  public void test224() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test224"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)100, false, false, (int)'#', false, true, (int)'a', false, false);
    testWBS0.launch((-1), true, true, (int)'#', false, true, (int)(short)(-1), false, false);
    testWBS0.launch(0, true, false, (int)(byte)100, true, false, (int)(byte)0, false, true);
    testWBS0.launch((int)(short)0, false, false, (int)(byte)0, false, true, 0, true, true);
    testWBS0.launch((int)(short)100, false, true, 0, false, true, (int)(byte)1, false, false);

  }

  @Test
  public void test225() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test225"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch(0, false, true, (int)(byte)10, false, false, 1, false, false);
    testWBS0.launch(0, true, false, (int)'#', true, true, (int)(byte)10, false, false);
    testWBS0.launch(0, true, false, (int)(byte)1, true, false, (int)(byte)0, false, false);
    testWBS0.launch(1, true, true, (int)'4', true, false, (int)'#', true, false);
    testWBS0.launch((int)(short)100, false, false, (int)(byte)(-1), true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(byte)1, true, true, (int)(byte)1, true, false, 0, false, true);

  }

  @Test
  public void test226() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test226"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(short)0, true, true, (-1), false, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)10, true, true, (int)'4', true, false, (int)(short)0, false, false);
    testWBS0.launch((int)(short)1, true, true, (int)(short)100, false, true, 0, true, false);
    testWBS0.launch((int)(short)1, true, false, 0, false, true, (int)(byte)(-1), false, false);
    testWBS0.launch((int)(short)(-1), true, true, 100, false, true, 100, false, false);
    testWBS0.launch((int)(short)1, false, true, 0, false, true, 0, false, true);

  }

  @Test
  public void test227() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test227"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(10, false, false, (int)(byte)10, false, false, (int)'4', true, true);
    testWBS0.launch((int)(short)1, true, true, (int)'4', false, false, (int)(short)10, false, false);
    testWBS0.launch((int)(byte)1, false, true, (int)(short)1, false, true, (int)'a', false, false);
    testWBS0.launch((int)(short)100, false, false, (int)(byte)1, false, false, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)10, false, true, (int)'#', true, false, (int)'#', false, true);
    testWBS0.launch((-1), true, false, (-1), false, false, 100, false, false);
    testWBS0.launch(100, true, true, 100, true, false, 100, true, false);

  }

  @Test
  public void test228() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test228"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)0, false, true, (-1), false, false, (-1), true, true);
    testWBS0.launch((int)(short)(-1), true, false, (int)(byte)(-1), true, false, 1, true, false);
    testWBS0.launch((int)(short)1, false, true, (int)(short)10, true, false, 0, true, false);
    testWBS0.launch(0, false, false, (int)(byte)100, false, false, 100, false, true);
    testWBS0.launch((int)(byte)100, false, false, (int)(byte)10, false, false, (int)' ', false, true);
    testWBS0.launch((int)(byte)0, true, true, (int)(byte)0, false, true, 100, false, true);

  }

  @Test
  public void test229() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test229"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)1, false, false, (int)(short)0, true, false, 10, false, true);
    testWBS0.launch((int)'#', false, false, (int)' ', false, true, (int)'#', false, true);
    testWBS0.launch((int)' ', false, true, 1, true, true, (int)'4', true, false);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)10, false, false, 0, true, true);
    testWBS0.launch((int)' ', true, true, 10, false, false, (int)(byte)0, true, false);
    testWBS0.launch(1, true, true, (int)(short)100, false, false, (int)(byte)0, true, false);
    testWBS0.launch(0, true, false, (int)(short)0, true, true, (int)(byte)0, false, false);

  }

  @Test
  public void test230() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test230"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch(0, false, true, (int)(byte)100, true, true, (int)(short)10, true, false);
    testWBS0.launch((int)'4', true, false, 0, false, false, (int)(byte)100, false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(byte)(-1), false, true, 0, false, true);
    testWBS0.launch(100, false, false, (int)(short)10, false, false, 0, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)'#', false, false, (int)(byte)(-1), true, false);

  }

  @Test
  public void test231() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test231"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(byte)10, true, false, (int)'4', false, false);
    testWBS0.launch(0, true, false, 0, true, true, (int)(short)10, true, false);
    testWBS0.launch((int)(short)0, true, true, (int)(short)100, true, true, (int)(byte)(-1), false, false);
    testWBS0.launch((int)(byte)0, true, true, (int)(byte)10, true, false, (int)(short)100, true, false);
    testWBS0.launch((int)'4', false, true, (int)(byte)1, true, false, 10, true, true);

  }

  @Test
  public void test232() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test232"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(0, false, false, (int)(short)1, false, true, (int)'#', false, false);
    testWBS0.launch(10, false, false, 1, false, false, (int)(byte)100, false, true);
    testWBS0.launch(10, false, true, (int)' ', true, false, (int)(short)10, true, true);
    testWBS0.launch((int)(byte)(-1), false, false, (int)(byte)1, false, true, 100, false, true);
    testWBS0.launch((int)'#', true, false, 0, false, true, (int)'4', false, false);
    testWBS0.launch(0, true, false, (int)(short)0, true, false, (-1), false, false);

  }

  @Test
  public void test233() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test233"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)'a', true, false, (int)(short)1, false, false, (int)(byte)10, true, true);
    testWBS0.launch((int)(short)10, true, true, (int)(byte)100, false, false, 10, false, true);
    testWBS0.launch((int)(short)1, false, true, (int)(byte)100, true, false, (int)(short)(-1), true, true);

  }

  @Test
  public void test234() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test234"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)'a', true, false, (int)(short)1, false, false, (int)(byte)10, true, true);
    testWBS0.launch((int)(short)10, true, true, (int)(byte)100, false, false, 10, false, true);
    testWBS0.launch((int)'#', true, false, (int)(byte)(-1), true, false, (int)' ', true, false);
    testWBS0.launch(1, true, true, 1, false, true, (int)'4', true, true);
    testWBS0.launch(0, true, false, (int)(short)100, false, false, 0, false, false);
    testWBS0.launch(1, false, false, (int)(byte)100, false, false, 100, false, true);
    testWBS0.launch((int)(short)(-1), false, false, (int)(byte)1, false, false, (int)(short)1, true, true);

  }

  @Test
  public void test235() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test235"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(0, false, false, (int)(short)1, false, true, (int)'#', false, false);
    testWBS0.launch((-1), true, false, (int)' ', true, false, (int)(short)100, false, false);
    testWBS0.launch((int)' ', false, false, (int)(byte)100, false, false, (int)(byte)10, true, true);
    testWBS0.launch((int)(byte)0, true, true, (int)(short)10, true, true, (int)(short)100, false, true);
    testWBS0.launch((int)(byte)10, false, false, (int)(short)(-1), false, false, 1, true, true);
    testWBS0.launch(10, true, true, (int)(byte)0, false, true, (int)(byte)100, true, false);
    testWBS0.launch((int)(short)10, true, true, 0, true, false, (int)(short)10, true, true);

  }

  @Test
  public void test236() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test236"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)0, false, true, (-1), false, false, (-1), true, true);
    testWBS0.launch((int)(short)(-1), true, false, (int)(byte)(-1), true, false, 1, true, false);
    testWBS0.launch((int)(short)1, false, true, (int)(short)10, true, false, 0, true, false);
    testWBS0.launch((int)(short)0, false, true, (int)(short)(-1), false, true, (int)'a', false, false);
    testWBS0.launch((int)(short)100, true, true, 0, false, true, (int)(short)10, true, false);
    testWBS0.launch((int)(byte)0, false, true, (int)'a', true, true, 100, true, false);

  }

  @Test
  public void test237() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test237"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(byte)1, false, true, 1, false, false, (-1), false, true);
    testWBS0.launch((int)'#', false, false, 0, false, false, 100, false, false);
    testWBS0.launch((int)(short)10, false, true, 0, false, true, (int)(short)10, false, false);
    testWBS0.launch((int)(short)1, true, true, (int)(short)0, true, true, 100, false, false);
    testWBS0.launch(100, false, false, (int)(short)100, false, true, (int)'a', false, false);

  }

  @Test
  public void test238() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test238"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)' ', true, true, (int)(byte)0, false, false, (int)(byte)0, true, false);
    testWBS0.launch(0, true, true, (int)(short)1, true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(byte)(-1), false, true, (int)'4', false, true, (int)(short)1, true, true);
    testWBS0.launch((int)(short)10, true, false, 1, false, false, (int)' ', false, true);
    testWBS0.launch((int)(short)(-1), false, false, (-1), true, false, (-1), false, false);

  }

  @Test
  public void test239() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test239"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)1, false, false, (int)(short)1, false, true, 0, true, true);
    testWBS0.launch((int)(byte)0, true, true, (int)(short)(-1), false, false, (int)(byte)1, false, true);
    testWBS0.launch((int)(short)10, false, false, (int)(byte)100, false, false, (int)(byte)(-1), true, true);
    testWBS0.launch((int)(byte)0, true, false, (int)'4', false, true, (int)'4', true, false);
    testWBS0.launch((int)' ', false, true, (int)(short)(-1), true, true, (int)' ', false, true);
    testWBS0.launch((int)(short)10, false, true, 1, false, true, (int)(byte)0, false, false);
    testWBS0.launch((int)'4', false, true, (int)' ', false, false, (int)'#', true, true);

  }

  @Test
  public void test240() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test240"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)1, false, false, (int)(short)0, true, false, 10, false, true);
    testWBS0.launch((int)'#', false, false, (int)' ', false, true, (int)'#', false, true);
    testWBS0.launch((int)' ', false, true, 1, true, true, (int)'4', true, false);
    testWBS0.launch((int)(byte)1, false, false, (int)'a', true, false, 0, false, true);
    testWBS0.launch((int)(short)(-1), true, true, (int)(short)0, true, true, (int)(byte)0, true, false);
    testWBS0.launch((int)(byte)100, false, true, 0, false, true, (int)(byte)100, false, false);
    testWBS0.launch(0, true, false, (-1), true, false, (int)'a', true, false);

  }

  @Test
  public void test241() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test241"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch((-1), true, false, (int)(short)100, false, false, 1, true, true);
    testWBS0.launch(1, true, true, (int)'4', false, false, (int)(byte)0, false, true);
    testWBS0.launch((int)'#', false, true, 1, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)' ', true, true, (int)(byte)(-1), false, true, (int)'a', true, true);
    testWBS0.launch((int)(byte)(-1), true, true, (int)' ', true, true, (int)(byte)100, true, true);
    testWBS0.launch((int)(short)1, false, true, (int)(byte)10, false, true, (int)(byte)1, false, false);

  }

  @Test
  public void test242() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test242"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)10, false, true, 0, true, false, (int)(short)10, true, false);
    testWBS0.launch((int)(short)10, true, false, (int)' ', true, false, (int)(byte)(-1), false, true);
    testWBS0.launch((int)(short)0, false, true, (int)(short)100, false, true, (int)(byte)1, false, true);
    testWBS0.launch((int)(byte)10, false, false, (int)(short)(-1), false, false, (int)'4', true, false);
    testWBS0.launch((int)'#', true, true, (int)(byte)1, true, true, (int)(byte)1, false, false);

  }

  @Test
  public void test243() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test243"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)1, false, false, (int)(short)0, true, false, 10, false, true);
    testWBS0.launch((int)(byte)100, false, true, (int)'#', false, false, (int)'a', false, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(short)100, true, false, (int)'4', true, false);
    testWBS0.launch(100, true, true, 0, true, false, 1, false, false);

  }

  @Test
  public void test244() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test244"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)1, false, false, (int)(short)0, true, false, 10, false, true);
    testWBS0.launch((int)(byte)100, false, true, (int)'#', false, false, (int)'a', false, false);
    testWBS0.launch((int)(short)10, false, true, (int)(byte)1, true, true, (int)(short)(-1), false, true);
    testWBS0.launch((int)(byte)10, false, true, 0, true, false, (int)(short)(-1), false, false);

  }

  @Test
  public void test245() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test245"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, true, false, (int)(short)0, false, true);
    testWBS0.launch(100, true, true, (int)(byte)(-1), false, false, 10, false, false);
    testWBS0.launch((int)'4', true, true, (int)' ', true, true, (int)(byte)10, false, false);
    testWBS0.launch(100, false, false, 0, false, false, (int)'4', false, false);
    testWBS0.launch((int)(byte)10, false, false, (int)(short)(-1), false, true, (int)(byte)(-1), false, true);
    testWBS0.launch((int)(byte)(-1), false, true, (int)'#', true, true, 100, true, true);
    testWBS0.launch((int)' ', true, true, (int)(short)1, true, true, 1, true, false);

  }

  @Test
  public void test246() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test246"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 100, false, true, (int)(byte)1, true, false);
    testWBS0.launch((int)(byte)10, true, false, 0, true, false, (int)(byte)0, false, true);
    testWBS0.launch((-1), false, false, (int)(byte)100, true, false, (int)(byte)1, false, true);
    testWBS0.launch((-1), true, true, (int)(byte)0, false, false, (int)'4', true, false);
    testWBS0.launch((int)(short)100, true, false, (int)(byte)100, true, true, (int)(byte)0, true, true);

  }

  @Test
  public void test247() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test247"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)1, false, false, (int)(short)1, false, true, 0, true, true);
    testWBS0.launch((int)(byte)0, false, false, (int)(short)10, true, true, (int)(byte)10, true, true);
    testWBS0.launch((int)(byte)10, false, true, (int)(short)0, false, true, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)0, false, true, (-1), true, false, (int)(short)100, false, false);
    testWBS0.launch((int)(byte)(-1), false, false, 1, false, false, 100, false, false);
    testWBS0.launch((int)' ', false, false, (int)(byte)100, true, false, (int)'a', false, false);

  }

  @Test
  public void test248() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test248"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, true, false, (int)(short)0, false, true);
    testWBS0.launch((int)(byte)0, true, false, (int)(byte)1, false, false, (int)'4', true, true);
    testWBS0.launch((int)(byte)10, false, false, (int)(short)(-1), false, true, (int)(byte)100, true, true);
    testWBS0.launch((int)(byte)100, true, false, (int)(byte)100, false, false, (int)(byte)(-1), true, true);
    testWBS0.launch(100, true, false, (int)(byte)0, true, false, 10, false, true);

  }

  @Test
  public void test249() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test249"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(10, true, true, (int)(byte)0, true, false, (int)'a', false, true);
    testWBS0.launch((int)(short)10, false, false, (int)(byte)0, true, false, (int)(short)(-1), true, true);
    testWBS0.launch((-1), true, true, (int)(byte)10, false, true, (int)(byte)0, true, true);
    testWBS0.launch((int)(short)0, true, true, 100, false, false, (int)' ', true, false);
    testWBS0.launch((int)' ', false, true, (int)(byte)0, false, false, 0, false, false);
    testWBS0.launch(10, true, true, 10, false, false, 10, false, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, false, true, 0, true, false);

  }

  @Test
  public void test250() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test250"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)100, true, false, (int)(short)100, true, true, (int)(short)0, true, false);
    testWBS0.launch(1, true, true, (-1), true, false, 10, true, true);
    testWBS0.launch(0, false, false, (int)(short)10, true, true, 0, true, true);
    testWBS0.launch((int)(byte)10, true, false, (int)(byte)100, false, true, (int)(byte)0, true, false);
    testWBS0.launch((int)(short)0, true, true, 1, true, true, 0, true, false);
    testWBS0.launch((int)(byte)(-1), true, false, (int)'4', false, true, (-1), true, true);
    testWBS0.launch((int)'#', false, false, (int)'#', true, false, (int)(short)100, true, false);
    testWBS0.launch((int)(short)(-1), false, false, (int)(short)100, false, false, (int)(byte)100, false, false);

  }

  @Test
  public void test251() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test251"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(10, true, true, (int)(byte)0, true, false, (int)'a', false, true);
    testWBS0.launch(0, true, false, 10, true, false, (-1), true, false);
    testWBS0.launch(0, true, true, 100, true, true, (int)(byte)100, true, false);
    testWBS0.launch((int)'#', true, false, 0, false, true, (int)(byte)1, false, false);
    testWBS0.launch((int)'a', false, false, (int)'4', true, true, (int)(byte)100, true, false);
    testWBS0.launch(0, true, false, (int)(short)(-1), true, true, (int)(short)1, true, false);

  }

  @Test
  public void test252() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test252"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)10, false, true, 0, true, false, (int)(short)10, true, false);
    testWBS0.launch((int)(byte)10, false, false, 1, true, true, (int)(short)100, false, true);
    testWBS0.launch((int)'a', false, true, (int)(byte)100, true, false, (int)(byte)1, false, true);
    testWBS0.launch((int)'a', false, true, 10, false, true, (int)(short)0, false, true);
    testWBS0.launch((int)(short)1, false, true, 0, false, true, (int)'a', false, false);
    testWBS0.launch((int)(short)100, false, true, (int)(short)(-1), false, true, (int)(short)0, false, false);
    testWBS0.launch(10, true, false, (int)(byte)(-1), true, false, (int)(byte)1, false, true);

  }

  @Test
  public void test253() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test253"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, true, false, (int)(short)0, false, true);
    testWBS0.launch(100, true, true, (int)(byte)(-1), false, false, 10, false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)100, false, false, 0, false, true);
    testWBS0.launch((int)(short)0, true, true, (int)'#', true, false, (int)'a', true, true);
    testWBS0.launch((int)(byte)1, true, false, (int)'4', false, false, 10, false, false);
    testWBS0.launch((int)(short)1, false, true, (int)(short)0, false, true, (-1), true, true);

  }

  @Test
  public void test254() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test254"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)'a', true, false, (int)(short)1, false, false, (int)(byte)10, true, true);
    testWBS0.launch(1, false, true, (int)(byte)10, true, false, 0, true, true);
    testWBS0.launch((int)(byte)0, false, true, (int)' ', false, false, (int)' ', true, true);
    testWBS0.launch((int)(short)(-1), false, true, 1, false, true, (int)(byte)(-1), true, false);
    testWBS0.launch((int)(short)0, false, false, (int)(byte)0, true, true, (int)'#', false, false);
    testWBS0.launch((int)'a', false, true, (int)(short)10, true, true, (int)' ', true, false);
    testWBS0.launch((-1), false, false, (int)(byte)10, true, false, (int)(byte)1, true, false);
    testWBS0.launch((int)(short)0, false, false, 0, false, false, (int)'a', false, false);

  }

  @Test
  public void test255() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test255"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch(100, false, false, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)(byte)10, false, false, (int)(byte)1, false, true, 10, true, false);
    testWBS0.launch((int)'#', false, false, (int)(short)(-1), false, true, (int)(short)1, true, false);

  }

  @Test
  public void test256() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test256"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, true, false, (int)(short)0, false, true);
    testWBS0.launch(100, true, true, (int)(byte)(-1), false, false, 10, false, false);
    testWBS0.launch((int)'a', true, true, (int)(byte)100, false, true, (int)' ', false, false);
    testWBS0.launch(100, false, false, (int)(short)10, false, false, (int)(short)0, true, true);
    testWBS0.launch(0, false, false, (int)(short)(-1), true, true, (int)'a', true, false);
    testWBS0.launch((int)(byte)0, true, true, (int)(short)10, true, true, (int)(byte)1, true, true);
    testWBS0.launch(0, true, false, 1, false, false, (int)(byte)0, false, false);

  }

  @Test
  public void test257() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test257"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)1, false, false, (int)(short)0, true, false, 10, false, true);
    testWBS0.launch((int)'#', false, false, (int)' ', false, true, (int)'#', false, true);
    testWBS0.launch((int)' ', false, true, 1, true, true, (int)'4', true, false);
    testWBS0.launch((int)'#', true, true, (int)(short)10, true, false, 0, false, false);
    testWBS0.launch((int)(short)10, true, true, 10, true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(short)(-1), false, false, (int)(short)(-1), true, false, (int)(short)10, false, false);

  }

  @Test
  public void test258() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test258"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)(byte)1, true, false, (int)(byte)0, true, true, (int)(short)(-1), true, true);
    testWBS0.launch((int)' ', true, false, (int)(short)100, false, false, 100, true, true);
    testWBS0.launch((int)(short)10, true, false, (int)(short)10, false, false, (int)' ', false, false);
    testWBS0.launch(0, false, true, (int)(byte)0, false, false, (int)'#', false, false);

  }

  @Test
  public void test259() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test259"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)1, false, false, (int)(short)0, true, false, 10, false, true);
    testWBS0.launch((int)'#', true, true, (int)(short)0, true, true, (int)(short)10, true, true);
    testWBS0.launch((int)(short)10, true, true, 1, true, false, (int)(byte)1, false, true);
    testWBS0.launch((int)(byte)1, false, false, 10, false, true, (int)(short)0, true, true);
    testWBS0.launch(1, false, true, 0, false, true, (int)(byte)1, true, false);
    testWBS0.launch((int)(short)0, false, true, (int)(short)1, true, true, 100, false, false);
    testWBS0.launch((int)(byte)0, true, true, (int)(short)0, false, true, 10, false, true);

  }

  @Test
  public void test260() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test260"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch(0, false, true, (int)(byte)100, true, true, (int)(short)10, true, false);
    testWBS0.launch((int)'4', true, false, 0, false, false, (int)(byte)100, false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(byte)(-1), false, true, 0, false, true);
    testWBS0.launch(1, true, true, 10, false, true, (int)(byte)100, true, true);

  }

  @Test
  public void test261() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test261"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)1, false, false, (int)(short)0, true, false, 10, false, true);
    testWBS0.launch((int)(byte)100, true, false, (int)(short)10, true, false, 0, true, true);
    testWBS0.launch(100, false, false, 100, false, true, 1, false, true);
    testWBS0.launch((int)(byte)(-1), true, true, (int)(byte)1, true, false, (int)(byte)100, false, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(short)1, true, false, (int)(short)1, true, false);
    testWBS0.launch((int)'#', false, false, (int)(byte)0, true, true, 100, true, false);

  }

  @Test
  public void test262() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test262"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)'a', true, false, (int)(short)1, false, false, (int)(byte)10, true, true);
    testWBS0.launch((int)(short)10, true, true, (int)(byte)100, false, false, 10, false, true);
    testWBS0.launch((int)'#', false, true, 1, false, true, (int)(byte)(-1), false, false);
    testWBS0.launch((int)(short)10, false, true, (int)(short)100, false, true, (int)(short)0, false, true);
    testWBS0.launch((int)(short)10, false, false, (int)(byte)1, true, false, (int)(byte)100, true, true);
    testWBS0.launch((int)(short)1, true, false, (int)'#', true, false, 10, true, false);
    testWBS0.launch(0, false, false, (int)(byte)100, true, true, 100, false, true);
    testWBS0.launch((int)(byte)(-1), true, true, (int)'a', true, false, 100, false, true);

  }

  @Test
  public void test263() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test263"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(byte)10, true, false, (int)'4', false, false);
    testWBS0.launch(10, false, true, (int)' ', false, true, 10, true, false);
    testWBS0.launch((int)'a', false, false, (int)'4', false, false, 0, true, false);
    testWBS0.launch((int)(short)100, true, true, (int)'#', true, true, (int)(short)100, false, false);
    testWBS0.launch((int)(short)100, true, true, (int)(byte)100, true, false, (int)'#', false, false);
    testWBS0.launch(100, false, false, 1, true, true, (int)(short)1, false, true);

  }

  @Test
  public void test264() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test264"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)' ', false, true, (int)(byte)10, true, true, (-1), false, true);
    testWBS0.launch((int)(short)100, true, false, (int)'4', true, true, 0, false, false);
    testWBS0.launch((int)(byte)0, false, true, (int)(byte)0, false, false, (int)' ', false, false);
    testWBS0.launch((int)'4', false, true, (int)(byte)(-1), false, false, (int)'a', false, false);
    testWBS0.launch((int)'a', false, true, 0, true, false, 0, true, false);
    testWBS0.launch(1, false, true, 0, true, false, (int)(byte)10, true, true);

  }

  @Test
  public void test265() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test265"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)10, false, false, 100, false, true, 0, true, true);
    testWBS0.launch((int)'4', true, false, (int)(byte)(-1), false, false, (int)(byte)(-1), true, true);
    testWBS0.launch((int)(byte)100, true, true, (int)(short)0, true, true, 0, false, false);
    testWBS0.launch((int)(byte)10, false, false, (int)' ', false, false, (int)(byte)0, true, true);
    testWBS0.launch((int)'4', false, true, (int)(short)0, false, true, 10, false, true);
    testWBS0.launch((int)(byte)1, false, false, (-1), false, true, 1, true, false);

  }

  @Test
  public void test266() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test266"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)10, false, true, 0, true, false, (int)(short)10, true, false);
    testWBS0.launch((int)(short)1, true, false, (int)(byte)(-1), true, true, (int)(byte)1, false, false);
    testWBS0.launch((int)(byte)(-1), false, false, 1, true, true, (int)(short)0, true, true);
    testWBS0.launch(100, true, false, (int)(byte)100, false, true, (int)(byte)100, false, false);
    testWBS0.launch((int)(byte)1, false, true, (int)(byte)0, true, false, (int)'#', true, false);

  }

  @Test
  public void test267() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test267"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)10, false, false, 100, false, true, 0, true, true);
    testWBS0.launch((int)'4', true, false, (int)(byte)(-1), false, false, (int)(byte)(-1), true, true);
    testWBS0.launch(100, true, false, (int)(byte)1, false, true, (int)'a', false, true);
    testWBS0.launch((int)(short)100, true, true, (int)(short)(-1), false, true, (int)(short)100, false, true);
    testWBS0.launch((int)(byte)1, true, false, 0, false, false, 0, true, true);
    testWBS0.launch((int)(byte)0, true, false, 0, true, true, (int)(short)100, true, true);

  }

  @Test
  public void test268() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test268"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch(0, false, true, (int)(byte)100, true, true, (int)(short)10, true, false);
    testWBS0.launch(0, true, true, (int)(short)100, false, false, 0, false, false);
    testWBS0.launch((int)(byte)100, true, false, (int)(short)100, true, true, 10, true, true);
    testWBS0.launch(0, true, true, (int)(short)100, false, false, (-1), true, true);
    testWBS0.launch(1, true, true, (int)(short)(-1), false, false, (int)'a', false, false);
    testWBS0.launch(100, false, true, (int)(short)100, true, false, 0, false, true);

  }

  @Test
  public void test269() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test269"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(byte)10, false, false, 1, false, false, (-1), true, false);
    testWBS0.launch((int)(short)100, false, true, 10, false, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, (int)(short)1, false, true, 10, false, true);
    testWBS0.launch(0, false, false, (int)(byte)10, false, false, (int)(short)(-1), false, true);
    testWBS0.launch(0, false, true, (int)(short)0, false, false, (int)(short)100, true, false);

  }

  @Test
  public void test270() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test270"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch(1, true, false, (int)'#', false, false, (int)(byte)(-1), false, false);
    testWBS0.launch(0, false, false, 0, true, true, (int)(short)10, true, false);

  }

  @Test
  public void test271() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test271"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(byte)1, false, true, 1, false, false, (-1), false, true);
    testWBS0.launch((int)'#', false, false, 0, false, false, 100, false, false);
    testWBS0.launch((int)(short)10, false, true, 0, false, true, (int)(short)10, false, false);
    testWBS0.launch((int)(short)0, false, true, (int)(short)(-1), true, true, (int)(short)10, true, true);

  }

  @Test
  public void test272() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test272"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch(0, true, true, 100, true, false, (-1), false, false);
    testWBS0.launch((int)'#', true, false, (int)'a', true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)'4', true, false, (int)(short)100, true, false, (int)(byte)(-1), true, true);
    testWBS0.launch((int)(short)1, true, true, (int)(short)(-1), true, false, (int)(byte)(-1), false, false);
    testWBS0.launch(0, true, true, (int)(short)100, false, false, (int)(short)10, false, false);
    testWBS0.launch(0, true, false, 100, false, false, (int)'a', true, true);
    testWBS0.launch(0, false, true, (int)'#', true, false, 0, false, false);

  }

  @Test
  public void test273() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test273"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch(10, false, false, 1, false, false, (int)'a', false, false);
    testWBS0.launch((int)'a', true, true, (int)(short)0, false, false, (int)(short)1, true, false);
    testWBS0.launch((int)(byte)(-1), true, false, (int)'#', false, true, (int)'#', true, false);
    testWBS0.launch((int)(short)100, true, false, (int)(byte)0, false, true, (int)(byte)0, true, false);
    testWBS0.launch((int)(short)100, true, true, (int)(short)1, false, false, (-1), true, false);

  }

  @Test
  public void test274() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test274"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch(0, false, true, (int)(byte)100, true, true, (int)(short)10, true, false);
    testWBS0.launch((int)(byte)10, false, false, 10, false, true, (int)(byte)(-1), true, false);
    testWBS0.launch(10, true, true, (int)(short)0, true, false, (int)(byte)0, true, false);
    testWBS0.launch((int)'a', true, false, (int)(byte)10, false, false, (int)(byte)(-1), true, true);
    testWBS0.launch((int)(byte)10, false, false, (int)(byte)100, false, false, (int)'a', true, false);
    testWBS0.launch((int)'a', true, false, (int)(byte)1, true, true, 10, true, true);

  }

  @Test
  public void test275() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test275"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)'a', true, false, (int)(short)1, false, false, (int)(byte)10, true, true);
    testWBS0.launch((int)(short)10, true, true, (int)(byte)100, false, false, 10, false, true);
    testWBS0.launch((int)'#', true, false, (int)(byte)(-1), true, false, (int)' ', true, false);
    testWBS0.launch((int)(short)0, false, true, (int)(byte)10, false, false, (int)(byte)0, false, true);
    testWBS0.launch((int)'#', false, true, 10, false, true, 10, true, true);
    testWBS0.launch((int)(short)(-1), true, true, (int)(byte)1, false, false, (int)(byte)1, true, true);

  }

  @Test
  public void test276() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test276"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)'a', true, false, (int)(short)1, false, false, (int)(byte)10, true, true);
    testWBS0.launch(1, false, true, (int)(byte)10, true, false, 0, true, true);
    testWBS0.launch((int)(byte)0, false, true, (int)' ', false, false, (int)' ', true, true);
    testWBS0.launch((-1), true, false, (int)(byte)10, true, true, 0, false, false);
    testWBS0.launch((int)(byte)100, false, true, (int)(byte)100, false, false, (int)'4', true, false);
    testWBS0.launch(0, false, true, (int)(byte)(-1), false, false, (int)(byte)100, false, false);
    testWBS0.launch((int)(short)(-1), false, false, (int)'a', true, false, 100, false, false);

  }

  @Test
  public void test277() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test277"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(short)0, true, true, (-1), false, true, (int)(short)100, true, false);
    testWBS0.launch((int)(short)0, false, true, (-1), true, false, 10, false, true);
    testWBS0.launch((int)(byte)100, false, false, (int)'4', true, false, (int)'4', false, false);
    testWBS0.launch((-1), false, false, 0, false, true, 10, false, false);

  }

  @Test
  public void test278() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test278"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((-1), false, true, 10, false, false, 1, true, true);
    testWBS0.launch(10, true, false, (int)' ', true, false, (int)(short)(-1), true, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(short)100, true, false, (int)(short)100, true, true);
    testWBS0.launch(10, false, false, 1, false, false, (int)(byte)(-1), false, false);
    testWBS0.launch(100, false, false, (int)'4', true, true, 0, false, false);
    testWBS0.launch((int)(short)1, true, true, (int)'4', true, false, 10, true, false);
    testWBS0.launch((int)(short)(-1), true, false, (int)(byte)1, false, true, (int)(short)10, false, true);
    testWBS0.launch((int)'4', false, true, (int)(byte)0, false, true, 1, false, true);

  }

  @Test
  public void test279() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test279"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)10, false, true, 0, true, false, (int)(short)10, true, false);
    testWBS0.launch((int)(short)10, true, false, (int)' ', true, false, (int)(byte)(-1), false, true);
    testWBS0.launch(10, false, true, (int)(short)(-1), false, false, 0, true, true);
    testWBS0.launch(1, true, true, (int)'#', false, false, (int)(byte)(-1), false, true);
    testWBS0.launch((int)(short)0, false, true, (int)(byte)0, false, true, (int)(byte)0, false, true);
    testWBS0.launch((int)(short)100, false, true, 100, true, true, (int)'#', true, false);

  }

  @Test
  public void test280() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test280"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, true, false, (int)(short)0, false, true);
    testWBS0.launch((int)(byte)0, true, false, (int)(byte)1, false, false, (int)'4', true, true);
    testWBS0.launch((int)(short)10, false, true, (int)'4', false, true, (int)'#', true, false);
    testWBS0.launch((int)'a', false, true, (int)(byte)100, true, false, (int)'a', false, false);
    testWBS0.launch(10, false, true, (int)(short)(-1), false, true, (int)(byte)(-1), false, false);

  }

  @Test
  public void test281() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test281"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)1, true, true, 0, false, true);
    testWBS0.launch((int)(byte)(-1), true, false, (int)(short)(-1), false, false, (int)' ', false, false);
    testWBS0.launch((-1), false, false, (int)(byte)0, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)(-1), false, false, (int)'a', true, false, (int)'a', false, false);
    testWBS0.launch((int)'4', true, false, (int)(short)1, true, false, (int)'4', false, false);
    testWBS0.launch(0, true, true, (int)'a', true, true, (int)'4', false, false);

  }

  @Test
  public void test282() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test282"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(byte)1, false, true, 1, false, false, (-1), false, true);
    testWBS0.launch((int)(short)10, true, false, (int)(byte)10, false, false, (int)(short)10, true, false);
    testWBS0.launch(100, true, false, 100, false, false, 10, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)100, false, false, (int)(short)(-1), false, true);

  }

  @Test
  public void test283() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test283"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)1, true, true, 0, false, true);
    testWBS0.launch(100, true, false, (int)'a', false, false, 10, true, true);
    testWBS0.launch((int)(byte)(-1), true, true, (int)(byte)10, true, true, 100, true, true);
    testWBS0.launch((int)(byte)0, false, true, (int)(byte)10, true, false, (int)'a', false, false);
    testWBS0.launch((int)(byte)1, true, true, (-1), false, true, (-1), true, false);

  }

  @Test
  public void test284() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test284"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)'a', false, false, (int)(byte)0, false, true, (int)(short)100, true, false);
    testWBS0.launch((int)'#', true, true, 1, false, true, (int)'a', true, false);
    testWBS0.launch((int)(byte)1, false, true, (int)(byte)1, true, true, (-1), true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(short)(-1), true, true, (int)'#', false, false);
    testWBS0.launch((int)(short)100, true, false, (int)(byte)0, true, false, 10, true, true);
    testWBS0.launch((int)(short)(-1), true, true, (int)(short)(-1), false, true, (int)(short)10, true, false);

  }

  @Test
  public void test285() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test285"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch((-1), true, false, (int)(short)100, false, false, 1, true, true);
    testWBS0.launch(1, true, true, (int)'4', false, false, (int)(byte)0, false, true);
    testWBS0.launch((int)'#', false, true, 1, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)' ', true, true, (int)(byte)(-1), false, true, (int)'a', true, true);
    testWBS0.launch((int)(byte)(-1), false, true, (int)'#', false, false, (int)(byte)10, true, false);

  }

  @Test
  public void test286() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test286"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)1, false, false, (int)(short)1, false, true, 0, true, true);
    testWBS0.launch((int)(byte)(-1), true, false, (int)'a', false, true, 100, true, true);
    testWBS0.launch(100, true, false, (int)(byte)(-1), true, false, 0, false, false);

  }

  @Test
  public void test287() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test287"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch(0, true, true, 100, true, false, (-1), false, false);
    testWBS0.launch((int)'#', true, false, (int)'a', true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)'4', true, false, (int)(short)100, true, false, (int)(byte)(-1), true, true);
    testWBS0.launch(1, false, false, (int)(byte)0, true, false, (int)(byte)10, true, true);
    testWBS0.launch(0, true, false, (int)(byte)(-1), true, true, (int)(byte)0, false, false);
    testWBS0.launch(0, false, true, (int)(short)100, true, true, (int)(short)0, false, true);
    testWBS0.launch((int)(short)0, true, true, (int)'4', false, true, (int)(short)100, false, true);

  }

  @Test
  public void test288() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test288"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(10, false, false, (int)(byte)10, false, false, (int)'4', true, true);
    testWBS0.launch((int)'a', true, true, (int)' ', false, true, (int)(byte)(-1), false, false);
    testWBS0.launch((-1), false, false, (int)(byte)(-1), true, false, (int)(short)0, true, false);
    testWBS0.launch((int)(short)10, true, false, 1, true, true, (int)'#', false, false);
    testWBS0.launch(10, true, false, (int)(byte)0, true, false, (int)'#', false, true);
    testWBS0.launch(0, false, false, (int)(short)1, false, true, 0, false, true);

  }

  @Test
  public void test289() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test289"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(10, true, true, (int)(byte)0, true, false, (int)'a', false, true);
    testWBS0.launch((int)(short)10, false, false, (int)(byte)0, true, false, (int)(short)(-1), true, true);
    testWBS0.launch((int)' ', true, false, (int)(short)1, true, false, (int)(short)(-1), false, true);
    testWBS0.launch((int)'4', true, false, (int)(byte)10, false, false, (int)(short)(-1), true, false);
    testWBS0.launch(0, true, true, (int)(byte)1, true, true, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)(-1), false, false, 1, false, true, 100, true, false);
    testWBS0.launch((-1), false, false, 0, false, true, 0, false, true);

  }

  @Test
  public void test290() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test290"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(10, true, true, (int)(byte)0, true, false, (int)'a', false, true);
    testWBS0.launch((int)(short)10, false, false, (int)(byte)0, true, false, (int)(short)(-1), true, true);
    testWBS0.launch((int)' ', true, false, (int)(short)1, true, false, (int)(short)(-1), false, true);
    testWBS0.launch((int)'4', true, false, (int)(byte)10, false, false, (int)(short)(-1), true, false);
    testWBS0.launch(0, true, true, (int)(byte)1, true, true, (int)(short)(-1), false, false);
    testWBS0.launch((int)'4', false, true, (-1), false, false, (int)(short)1, true, false);

  }

  @Test
  public void test291() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test291"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((-1), false, true, 10, false, false, 1, true, true);
    testWBS0.launch((int)(byte)0, false, true, (int)(byte)(-1), true, true, (int)'#', false, false);
    testWBS0.launch((int)(short)(-1), false, false, (int)(byte)1, false, false, (int)'#', false, false);
    testWBS0.launch((int)(byte)(-1), true, false, (int)(short)10, true, true, (int)(short)(-1), true, false);
    testWBS0.launch((int)'a', true, false, (-1), false, false, (int)(byte)100, false, false);

  }

  @Test
  public void test292() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test292"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)1, true, true, 0, false, true);
    testWBS0.launch((int)'4', true, true, (int)' ', true, false, (int)(byte)0, true, true);
    testWBS0.launch(0, false, false, (int)' ', false, false, (int)'4', false, true);
    testWBS0.launch(1, false, false, 100, true, true, (int)(short)100, false, true);
    testWBS0.launch(0, false, false, (int)(short)(-1), true, true, (int)(byte)100, false, true);
    testWBS0.launch((int)(short)0, false, false, (int)(short)1, true, false, (int)(byte)1, false, false);

  }

  @Test
  public void test293() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test293"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)10, false, true, 0, true, false, (int)(short)10, true, false);
    testWBS0.launch((int)(short)1, true, false, (int)(byte)(-1), true, true, (int)(byte)1, false, false);
    testWBS0.launch((int)(byte)(-1), false, false, 1, true, true, (int)(short)0, true, true);
    testWBS0.launch((int)(byte)10, true, false, (int)'a', true, false, (int)(byte)100, false, true);
    testWBS0.launch(0, true, false, 100, false, false, (int)(short)10, true, true);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)10, true, false, (int)(byte)100, true, true);
    testWBS0.launch((int)(short)100, true, false, (int)(short)10, false, true, (int)(byte)(-1), false, false);
    testWBS0.launch((int)(byte)0, false, false, 0, false, false, (int)'#', false, false);

  }

  @Test
  public void test294() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test294"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch((int)(byte)0, true, false, 1, false, true, 100, true, false);
    testWBS0.launch((int)(short)10, false, true, (int)(byte)0, true, false, 0, true, false);
    testWBS0.launch((int)(short)1, true, false, (int)(byte)1, false, false, (int)'a', false, true);
    testWBS0.launch((int)'#', true, true, 0, true, true, (int)(short)(-1), true, false);
    testWBS0.launch(0, true, false, (int)(byte)10, false, true, 1, false, false);

  }

  @Test
  public void test295() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test295"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(0, false, false, (int)(short)1, false, true, (int)'#', false, false);
    testWBS0.launch((-1), true, false, (int)' ', true, false, (int)(short)100, false, false);
    testWBS0.launch((int)' ', false, false, (int)(byte)100, false, false, (int)(byte)10, true, true);
    testWBS0.launch((int)(short)10, true, true, (int)'4', false, false, (int)' ', true, false);
    testWBS0.launch((int)'#', false, false, (-1), true, false, 1, false, false);

  }

  @Test
  public void test296() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test296"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)1, false, false, (int)(short)1, false, true, 0, true, true);
    testWBS0.launch(100, true, false, (int)(short)10, false, false, (int)(byte)100, true, true);
    testWBS0.launch((int)(byte)(-1), false, true, (int)(short)0, true, true, 10, true, false);
    testWBS0.launch((int)(byte)1, true, true, (-1), false, false, (int)' ', false, false);
    testWBS0.launch((int)'#', false, true, 10, false, true, 100, false, false);
    testWBS0.launch((int)(short)0, true, true, (int)'a', false, true, (int)'4', false, true);
    testWBS0.launch((int)(short)100, true, false, 10, true, true, 0, false, true);

  }

  @Test
  public void test297() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test297"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(10, true, true, (int)(byte)0, true, false, (int)'a', false, true);
    testWBS0.launch(0, true, false, 10, true, false, (-1), true, false);
    testWBS0.launch(1, true, true, 0, false, false, (int)'a', true, true);
    testWBS0.launch((int)'#', false, false, (int)(byte)100, false, false, (int)'4', false, true);
    testWBS0.launch((int)(short)10, false, true, (int)(short)0, false, true, (int)' ', true, false);
    testWBS0.launch((int)(byte)0, false, true, (int)'a', false, true, (-1), true, true);
    testWBS0.launch((int)(short)(-1), false, true, 100, false, false, (int)(byte)100, false, false);

  }

  @Test
  public void test298() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test298"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)1, true, true, 0, false, true);
    testWBS0.launch((int)'4', true, true, (int)' ', true, false, (int)(byte)0, true, true);
    testWBS0.launch(0, true, false, (int)(short)0, true, false, (int)(short)1, false, true);
    testWBS0.launch((int)(short)10, true, true, 0, true, false, (int)(byte)10, false, true);
    testWBS0.launch((int)(byte)1, false, false, (int)(short)1, true, true, (int)(short)1, false, true);
    testWBS0.launch((int)(short)0, false, false, (int)'a', false, false, (int)(byte)(-1), true, true);
    testWBS0.launch((int)(byte)1, true, true, 10, true, false, (int)(byte)0, true, false);

  }

  @Test
  public void test299() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test299"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(byte)10, false, false, 1, false, false, (-1), true, false);
    testWBS0.launch((int)(short)10, true, false, (int)(short)(-1), false, true, 0, true, false);
    testWBS0.launch(1, true, false, (int)'#', true, true, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)0, false, true, (int)(short)0, false, false, (int)(short)100, false, false);
    testWBS0.launch((int)'a', false, true, (-1), false, false, (int)(byte)(-1), false, true);
    testWBS0.launch(100, true, true, (int)(short)100, false, false, (int)(byte)10, true, true);

  }

  @Test
  public void test300() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test300"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch(1, false, true, (int)(short)0, false, false, (int)'#', true, false);
    testWBS0.launch(100, false, false, 1, true, true, (int)' ', true, false);
    testWBS0.launch((int)'#', true, true, (int)(short)(-1), false, true, (int)(byte)100, false, true);
    testWBS0.launch((-1), false, true, (int)(short)10, false, false, (int)(short)(-1), true, false);
    testWBS0.launch((int)(short)0, false, true, (int)(short)(-1), false, false, (int)(short)1, false, true);
    testWBS0.launch((int)'#', true, false, (int)(byte)0, false, false, 0, true, true);

  }

  @Test
  public void test301() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test301"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)' ', true, true, (int)(byte)0, false, false, (int)(byte)0, true, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)10, true, false, (int)' ', true, false);
    testWBS0.launch(10, false, true, 0, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', false, true, 0, false, true, (int)(byte)(-1), false, false);
    testWBS0.launch((-1), true, true, (int)(short)(-1), false, false, (int)(short)(-1), true, false);
    testWBS0.launch((int)' ', true, false, (int)(short)100, false, false, (-1), false, true);
    testWBS0.launch((int)(short)100, false, true, (int)(short)0, false, true, (int)(short)0, true, true);

  }

  @Test
  public void test302() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test302"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch(0, true, true, 100, true, false, (-1), false, false);
    testWBS0.launch((int)'#', true, false, (int)'a', true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)'4', true, false, (int)(short)100, true, false, (int)(byte)(-1), true, true);
    testWBS0.launch(1, false, false, (int)(byte)0, true, false, (int)(byte)10, true, true);
    testWBS0.launch(1, true, true, (int)'a', false, false, 100, true, true);
    testWBS0.launch((int)(byte)10, false, true, 10, false, true, (-1), true, false);
    testWBS0.launch((-1), false, false, (int)(byte)0, true, true, (int)(byte)(-1), false, true);

  }

  @Test
  public void test303() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test303"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)100, false, false, (int)'#', false, true, (int)'a', false, false);
    testWBS0.launch(0, false, false, 100, true, false, (int)' ', true, false);
    testWBS0.launch((int)(byte)(-1), false, true, (int)(short)1, false, true, (int)(short)0, true, true);
    testWBS0.launch((-1), false, true, (int)'a', true, true, 100, true, true);
    testWBS0.launch((-1), true, true, (int)(short)100, true, true, (int)'#', false, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)100, false, false, 0, true, true);
    testWBS0.launch((int)(short)1, true, false, (int)(byte)10, false, true, 1, false, true);

  }

  @Test
  public void test304() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test304"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(byte)10, true, false, (int)'4', false, false);
    testWBS0.launch(0, true, false, 0, true, true, (int)(short)10, true, false);
    testWBS0.launch((int)(byte)(-1), false, false, (int)(byte)100, false, false, (int)(short)10, true, true);
    testWBS0.launch(1, false, false, (int)'#', false, false, (int)(byte)0, false, true);
    testWBS0.launch((int)' ', false, true, 0, false, true, (int)(byte)1, false, false);
    testWBS0.launch(1, false, false, (int)(short)100, false, false, (-1), false, false);

  }

  @Test
  public void test305() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test305"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)1, false, false, (int)(short)0, true, false, 10, false, true);
    testWBS0.launch((int)(byte)100, true, false, (int)(short)10, true, false, 0, true, true);
    testWBS0.launch(100, false, false, (int)(byte)100, false, true, 0, true, true);
    testWBS0.launch((int)(byte)0, true, false, (int)' ', false, true, 0, false, true);
    testWBS0.launch((-1), false, true, 10, false, true, (int)(short)100, true, true);
    testWBS0.launch((-1), false, false, (-1), true, true, 10, true, true);

  }

  @Test
  public void test306() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test306"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)1, false, false, (int)(short)0, true, false, 10, false, true);
    testWBS0.launch((int)(byte)100, true, false, (int)(short)10, true, false, 0, true, true);
    testWBS0.launch(100, false, false, (int)(byte)100, false, true, 0, true, true);
    testWBS0.launch((int)'a', true, true, 0, false, true, (int)(byte)100, false, true);
    testWBS0.launch((int)(byte)(-1), true, true, 0, true, true, (int)(byte)10, true, false);
    testWBS0.launch((int)(short)(-1), false, false, 0, false, true, 1, false, false);
    testWBS0.launch(1, true, true, (int)' ', true, false, (int)(byte)1, true, true);

  }

  @Test
  public void test307() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test307"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, true, false, (int)(short)0, false, true);
    testWBS0.launch(100, true, true, (int)(byte)(-1), false, false, 10, false, false);
    testWBS0.launch((int)(byte)10, false, false, (int)(byte)0, true, true, (int)(short)100, false, false);
    testWBS0.launch(1, true, false, (int)'#', false, false, (int)'4', false, false);
    testWBS0.launch((int)'a', true, false, (int)'4', true, true, (int)(short)10, true, true);
    testWBS0.launch((int)(short)100, true, true, (int)(short)0, true, true, (int)'4', true, true);

  }

  @Test
  public void test308() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test308"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(short)0, true, true, (-1), false, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)10, true, true, (int)'4', true, false, (int)(short)0, false, false);
    testWBS0.launch(100, false, true, (int)(byte)0, false, true, (int)(byte)0, false, true);
    testWBS0.launch((int)'4', true, true, 0, false, false, (int)'a', false, false);
    testWBS0.launch(10, true, true, (int)(short)10, true, false, 1, false, false);
    testWBS0.launch(1, true, false, (int)(short)100, false, true, 0, false, false);

  }

  @Test
  public void test309() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test309"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)1, true, true, 0, false, true);
    testWBS0.launch((int)'4', true, true, (int)' ', true, false, (int)(byte)0, true, true);
    testWBS0.launch(0, true, false, (int)(short)0, true, false, (int)(short)1, false, true);
    testWBS0.launch((int)(byte)(-1), false, false, 1, false, false, (-1), true, true);
    testWBS0.launch((int)'a', true, true, (int)' ', false, false, 0, false, true);
    testWBS0.launch((int)(byte)1, true, true, (int)' ', false, true, 1, true, true);
    testWBS0.launch((int)(short)1, true, false, (int)(byte)1, true, false, (int)(short)1, true, false);

  }

  @Test
  public void test310() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test310"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)'a', true, false, (int)(short)1, false, false, (int)(byte)10, true, true);
    testWBS0.launch((int)(byte)10, true, true, (int)'#', true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)(-1), false, true, (int)(byte)0, false, true, (int)'4', true, false);
    testWBS0.launch((int)' ', false, false, (int)(short)0, true, false, (int)'#', false, false);
    testWBS0.launch(100, false, false, 0, false, false, 0, false, false);
    testWBS0.launch((int)'a', true, false, 0, true, true, (-1), false, false);
    testWBS0.launch((int)(byte)(-1), false, false, (int)(byte)100, false, true, (-1), true, true);

  }

  @Test
  public void test311() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test311"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, true, false, (int)(short)0, false, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)100, false, false, 10, false, false);
    testWBS0.launch((int)'a', true, false, 100, false, true, (int)(short)0, false, false);
    testWBS0.launch(0, false, true, (int)'4', true, false, 1, false, true);
    testWBS0.launch(10, true, true, 0, false, false, (int)(byte)1, false, true);
    testWBS0.launch((int)' ', true, false, (int)(byte)100, false, false, (int)'4', false, true);
    testWBS0.launch((int)(short)10, false, true, (int)'#', true, false, 0, false, false);

  }

  @Test
  public void test312() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test312"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)100, false, false, (int)'#', false, true, (int)'a', false, false);
    testWBS0.launch(0, false, false, 100, true, false, (int)' ', true, false);
    testWBS0.launch((int)(byte)10, true, false, (int)' ', false, true, 10, true, true);
    testWBS0.launch(10, true, false, (int)'#', true, true, (-1), false, true);
    testWBS0.launch((int)'a', false, true, (int)(byte)100, false, false, 0, true, true);
    testWBS0.launch(100, false, false, (int)(short)10, true, false, (int)' ', false, false);
    testWBS0.launch((int)(byte)(-1), true, false, 10, true, false, (int)' ', false, false);

  }

  @Test
  public void test313() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test313"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)1, false, true, 1, true, true, (int)'4', true, false);
    testWBS0.launch((int)(byte)10, false, false, 0, false, true, (int)(byte)10, true, true);
    testWBS0.launch((int)(short)0, false, false, (-1), true, true, (int)(byte)100, false, true);

  }

  @Test
  public void test314() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test314"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)1, true, true, 0, false, true);
    testWBS0.launch((int)'4', true, true, (int)' ', true, false, (int)(byte)0, true, true);
    testWBS0.launch((int)(short)100, false, false, (int)(short)0, false, true, (int)(short)100, true, true);
    testWBS0.launch((int)'4', false, true, 0, true, false, (int)(short)1, true, false);
    testWBS0.launch((-1), true, false, (int)(short)0, true, true, 0, false, false);
    testWBS0.launch(10, true, false, (int)'a', false, false, (int)'a', false, false);
    testWBS0.launch(100, false, false, (int)(byte)1, false, true, 0, false, false);

  }

  @Test
  public void test315() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test315"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(byte)1, false, true, 1, false, false, (-1), false, true);
    testWBS0.launch((int)(short)10, true, false, (int)(byte)10, false, false, (int)(short)10, true, false);
    testWBS0.launch(100, true, false, 100, false, false, 10, true, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(short)10, true, false, (int)(short)100, false, false);
    testWBS0.launch((int)(byte)1, false, false, 10, false, false, (int)(byte)(-1), false, true);
    testWBS0.launch((int)(byte)10, false, false, (int)' ', true, true, (int)'a', false, true);

  }

  @Test
  public void test316() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test316"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)'a', false, false, (int)(byte)0, false, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, true, (int)'4', true, false, (int)(byte)0, true, false);
    testWBS0.launch((int)(byte)0, false, true, (int)'#', true, false, (int)(byte)0, false, true);
    testWBS0.launch((int)(short)1, true, true, (int)'#', false, false, (-1), false, false);
    testWBS0.launch((int)(short)10, true, false, (int)'#', true, true, (int)'a', false, false);

  }

  @Test
  public void test317() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test317"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)' ', false, true, (int)(byte)10, true, true, (-1), false, true);
    testWBS0.launch((int)(short)100, true, false, (int)'4', true, true, 0, false, false);
    testWBS0.launch((-1), false, false, (int)(byte)10, false, false, (int)(byte)0, true, true);
    testWBS0.launch((int)(byte)10, false, false, (int)' ', true, true, (int)' ', true, true);
    testWBS0.launch((int)'4', false, true, (int)'#', false, false, (int)(short)10, false, true);
    testWBS0.launch(0, false, false, 0, false, false, (int)'#', false, true);
    testWBS0.launch(0, false, false, (-1), true, false, (int)(byte)1, true, false);

  }

  @Test
  public void test318() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test318"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch((-1), true, false, (int)(short)100, false, false, 1, true, true);
    testWBS0.launch(1, true, true, (int)'4', false, false, (int)(byte)0, false, true);
    testWBS0.launch((int)(byte)1, false, false, 0, false, false, (int)(byte)(-1), true, false);
    testWBS0.launch(10, false, false, (int)' ', false, false, (int)(byte)100, true, true);
    testWBS0.launch((int)(byte)0, false, false, 0, true, false, 0, false, true);
    testWBS0.launch(10, true, true, (int)(byte)0, false, true, (int)(short)0, false, false);

  }

  @Test
  public void test319() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test319"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)0, false, true, (-1), false, false, (-1), true, true);
    testWBS0.launch((int)'a', false, false, 1, false, true, (int)(byte)1, false, false);
    testWBS0.launch(1, true, true, (int)(short)0, true, false, (int)'4', true, false);

  }

  @Test
  public void test320() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test320"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)10, false, false, 100, false, true, 0, true, true);
    testWBS0.launch((int)'4', true, false, (int)(byte)(-1), false, false, (int)(byte)(-1), true, true);
    testWBS0.launch(100, true, false, (int)(byte)1, false, true, (int)'a', false, true);
    testWBS0.launch((int)(byte)(-1), false, true, (int)' ', true, true, 0, false, false);
    testWBS0.launch((int)(short)1, true, false, (int)'#', true, false, 10, false, true);
    testWBS0.launch(0, true, false, (int)(byte)1, false, true, (int)(short)10, true, false);

  }

  @Test
  public void test321() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test321"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)1, false, false, (int)(short)0, true, false, 10, false, true);
    testWBS0.launch((int)(byte)100, true, false, (int)(short)10, true, false, 0, true, true);
    testWBS0.launch((int)(byte)(-1), true, false, (int)(short)10, true, true, (int)(short)1, true, false);
    testWBS0.launch((int)' ', false, true, (int)(short)(-1), true, false, (int)(byte)0, false, false);
    testWBS0.launch(0, false, false, (int)'a', false, true, (int)(short)0, false, false);
    testWBS0.launch((int)(byte)10, false, true, (int)(byte)10, true, false, (int)(byte)100, true, false);

  }

  @Test
  public void test322() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test322"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(byte)10, true, false, (int)'4', false, false);
    testWBS0.launch((int)' ', false, false, (int)(byte)(-1), false, false, 0, false, false);
    testWBS0.launch((int)(byte)0, false, false, 100, false, true, (int)' ', true, false);
    testWBS0.launch(0, true, true, (int)'#', false, false, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)1, true, true, (int)'a', true, false, (int)(short)1, false, true);
    testWBS0.launch((int)(byte)1, false, false, (int)(short)100, true, true, (int)(short)0, false, true);
    testWBS0.launch((int)(byte)(-1), true, true, 1, false, true, (int)(short)(-1), true, true);

  }

  @Test
  public void test323() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test323"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch(0, true, true, 100, true, false, (-1), false, false);
    testWBS0.launch((int)' ', true, false, 1, true, false, (-1), false, true);
    testWBS0.launch(1, true, false, (int)(short)0, false, false, (int)'a', true, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)100, true, true, (int)(byte)1, true, false);
    testWBS0.launch((int)(byte)10, false, true, (int)(byte)10, true, false, 1, false, true);

  }

  @Test
  public void test324() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test324"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)'a', true, false, (int)(short)1, false, false, (int)(byte)10, true, true);
    testWBS0.launch((int)(short)10, true, true, (int)(byte)100, false, false, 10, false, true);
    testWBS0.launch((int)'#', true, false, (int)(byte)(-1), true, false, (int)' ', true, false);
    testWBS0.launch(1, true, true, 1, false, true, (int)'4', true, true);
    testWBS0.launch(10, false, false, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)(short)10, true, false, (int)'#', true, true, 10, false, true);
    testWBS0.launch((int)(byte)0, false, true, (int)' ', true, true, (int)(short)(-1), true, false);
    testWBS0.launch((int)(short)(-1), false, false, 1, true, false, 0, true, false);

  }

  @Test
  public void test325() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test325"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)1, false, false, (int)(short)1, false, true, 0, true, true);
    testWBS0.launch((int)(byte)0, true, true, (int)(short)(-1), false, false, (int)(byte)1, false, true);
    testWBS0.launch(10, true, true, (int)(short)100, true, false, 1, false, true);
    testWBS0.launch((int)(short)100, true, false, (int)'#', true, false, (int)'#', true, true);
    testWBS0.launch((-1), false, false, (int)(byte)100, true, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)1, true, true, (int)(byte)(-1), true, false, (int)(short)1, true, false);

  }

  @Test
  public void test326() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test326"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(0, false, false, (int)(short)1, false, true, (int)'#', false, false);
    testWBS0.launch(1, true, false, (int)(short)1, false, true, (-1), true, true);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)(-1), false, false, (int)(byte)0, true, true);

  }

  @Test
  public void test327() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test327"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)1, true, true, 0, false, true);
    testWBS0.launch(100, true, false, (int)'a', false, false, 10, true, true);
    testWBS0.launch((int)(byte)(-1), true, true, (int)(byte)10, true, true, 100, true, true);
    testWBS0.launch((int)(byte)0, false, true, (int)(byte)10, true, false, (int)'a', false, false);
    testWBS0.launch((int)(byte)10, true, false, 10, true, false, (int)'4', false, false);
    testWBS0.launch((int)(byte)10, false, true, (int)(byte)0, false, false, (int)(byte)0, true, true);

  }

  @Test
  public void test328() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test328"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch((int)(byte)0, true, false, 1, false, true, 100, true, false);
    testWBS0.launch((int)(short)0, false, true, (int)(byte)100, false, false, 0, false, false);
    testWBS0.launch((int)(short)10, false, true, 100, true, true, (int)(byte)(-1), false, true);
    testWBS0.launch((int)(short)1, true, false, (int)'4', true, true, (int)(byte)100, true, true);

  }

  @Test
  public void test329() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test329"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch(1, true, false, 1, true, false, 100, false, false);
    testWBS0.launch((-1), false, false, (int)(short)0, true, true, (int)(short)10, false, false);
    testWBS0.launch((int)(short)(-1), true, false, (-1), false, false, (int)(byte)10, false, true);
    testWBS0.launch((-1), true, false, (int)(short)1, false, true, (int)(byte)1, true, false);
    testWBS0.launch((int)'a', true, true, (int)(byte)100, true, true, (int)(byte)(-1), false, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(byte)10, false, true, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)(-1), true, true, (int)(byte)1, false, false, (int)(short)10, false, false);

  }

  @Test
  public void test330() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test330"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((-1), false, true, 10, false, false, 1, true, true);
    testWBS0.launch((int)(byte)0, true, false, 0, false, false, (int)(short)(-1), false, false);
    testWBS0.launch((-1), false, false, (int)(short)(-1), false, false, (int)'#', true, true);
    testWBS0.launch((int)'4', true, false, 1, false, true, (int)(byte)10, true, false);
    testWBS0.launch((int)(short)10, false, false, (int)(short)(-1), false, true, (int)(byte)1, true, false);
    testWBS0.launch((int)(short)1, true, true, (int)(byte)0, false, true, (int)(short)1, true, true);
    testWBS0.launch((int)'a', true, false, 1, true, false, (int)(byte)0, true, true);

  }

  @Test
  public void test331() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test331"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch(1, true, false, 1, true, false, 100, false, false);
    testWBS0.launch(1, true, false, (int)(short)1, true, true, (int)' ', true, false);
    testWBS0.launch((int)'a', false, false, (int)'#', false, true, (int)(short)1, true, true);
    testWBS0.launch(0, true, false, (int)(short)1, true, true, 10, true, false);
    testWBS0.launch((int)'4', false, false, (int)(short)100, false, true, (int)(byte)(-1), true, false);
    testWBS0.launch((int)(short)100, true, false, 0, false, false, (int)(short)100, true, true);
    testWBS0.launch((-1), true, false, (-1), true, false, (int)(short)(-1), true, false);

  }

  @Test
  public void test332() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test332"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(byte)10, true, false, (int)'4', false, false);
    testWBS0.launch((int)' ', false, false, (int)(byte)(-1), false, false, 0, false, false);
    testWBS0.launch((int)(byte)0, false, false, 100, false, true, (int)' ', true, false);
    testWBS0.launch(0, true, true, (int)'#', false, false, (int)(short)0, true, false);
    testWBS0.launch((int)(short)100, false, true, (int)(short)1, true, true, (int)(short)(-1), false, true);
    testWBS0.launch(0, true, true, (int)(short)100, false, false, (int)(short)(-1), true, true);
    testWBS0.launch(10, false, false, (int)(short)100, true, false, (int)'#', false, false);

  }

  @Test
  public void test333() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test333"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(short)0, true, true, (-1), false, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)10, false, true, (int)'4', false, false, 0, false, false);
    testWBS0.launch((int)' ', true, false, (int)(byte)100, false, false, (int)'4', true, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(byte)10, false, false, (int)'a', true, false);
    testWBS0.launch((int)' ', false, true, (int)'#', false, true, 100, false, false);

  }

  @Test
  public void test334() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test334"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch(0, false, true, (int)(byte)10, false, false, 1, false, false);
    testWBS0.launch((int)(byte)100, false, false, 100, false, false, (int)(byte)100, false, true);
    testWBS0.launch((int)(byte)10, false, true, (int)'#', true, true, (int)(byte)(-1), false, true);
    testWBS0.launch((int)(byte)(-1), false, true, (int)(short)0, true, false, (int)(byte)1, false, true);
    testWBS0.launch((int)(byte)1, true, true, 10, true, false, 0, false, true);
    testWBS0.launch((int)'a', false, true, (-1), true, false, (int)'a', true, false);

  }

  @Test
  public void test335() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test335"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch(1, true, false, 1, false, true, 0, false, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(byte)0, false, true, (int)(short)(-1), false, true);
    testWBS0.launch((int)(byte)(-1), true, false, 0, false, false, 1, true, false);
    testWBS0.launch((int)'4', true, false, (int)(byte)1, false, true, (-1), false, false);

  }

  @Test
  public void test336() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test336"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(byte)10, true, false, (int)'4', false, false);
    testWBS0.launch(10, false, true, (int)(short)0, false, false, (int)(byte)10, true, false);
    testWBS0.launch((int)(short)10, false, false, 1, true, true, (int)(byte)(-1), true, true);
    testWBS0.launch(10, false, true, 0, false, true, (int)(short)0, false, true);
    testWBS0.launch((int)(short)0, false, false, (int)(short)1, true, true, (int)'a', false, false);

  }

  @Test
  public void test337() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test337"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch(10, false, false, 1, false, false, (int)'a', false, false);
    testWBS0.launch((int)(short)(-1), true, true, (int)'a', false, true, (int)(short)(-1), false, true);
    testWBS0.launch((int)'a', true, true, (int)(byte)(-1), true, true, (int)(byte)1, true, false);
    testWBS0.launch((int)(short)1, false, true, 0, false, true, (int)'4', true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(short)100, true, false, (int)(short)10, false, false);
    testWBS0.launch(1, false, false, (-1), true, false, (int)(byte)100, false, false);
    testWBS0.launch((int)(short)(-1), true, false, (int)(short)10, true, true, (int)(byte)0, false, false);

  }

  @Test
  public void test338() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test338"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, true, false, (int)(short)0, false, true);
    testWBS0.launch(100, true, true, (int)(byte)(-1), false, false, 10, false, false);
    testWBS0.launch((int)(short)1, false, true, (int)(short)0, true, false, (int)'#', true, false);
    testWBS0.launch((int)(short)0, false, false, 1, true, false, 10, false, true);
    testWBS0.launch((int)(byte)100, false, true, (int)'a', false, true, 0, true, true);
    testWBS0.launch((-1), true, false, (int)(short)(-1), false, true, (int)(byte)(-1), true, false);

  }

  @Test
  public void test339() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test339"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)1, true, true, 0, false, true);
    testWBS0.launch((int)'4', true, true, (int)' ', true, false, (int)(byte)0, true, true);
    testWBS0.launch(0, true, false, (int)(short)0, true, false, (int)(short)1, false, true);
    testWBS0.launch((int)(byte)100, true, true, 100, false, false, (int)(byte)0, false, true);
    testWBS0.launch((int)(byte)0, true, false, (int)(byte)10, true, true, (int)(short)(-1), false, true);

  }

  @Test
  public void test340() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test340"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((-1), false, true, 10, false, false, 1, true, true);
    testWBS0.launch((int)(byte)0, true, false, 0, false, false, (int)(short)(-1), false, false);
    testWBS0.launch((-1), false, false, (int)(short)(-1), false, false, (int)'#', true, true);
    testWBS0.launch((int)(byte)1, true, true, (int)(short)100, true, true, (int)(short)1, true, false);
    testWBS0.launch(10, true, false, (int)(byte)0, true, true, (int)(byte)100, false, false);
    testWBS0.launch((int)(byte)(-1), true, true, (int)(short)100, true, true, 0, false, false);
    testWBS0.launch((int)(byte)100, true, false, 10, true, false, (int)(byte)(-1), false, true);
    testWBS0.launch((int)(byte)100, true, false, (int)'#', true, false, 100, false, false);

  }

  @Test
  public void test341() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test341"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)' ', true, true, (int)(byte)0, false, false, (int)(byte)0, true, false);
    testWBS0.launch((int)(byte)(-1), false, true, (int)(byte)1, true, false, (int)(byte)100, false, false);
    testWBS0.launch((int)(short)0, false, true, (int)'4', true, true, (int)'4', false, false);
    testWBS0.launch((int)(byte)0, true, true, (int)(short)10, false, true, 1, true, true);
    testWBS0.launch((int)(short)1, false, true, (int)(byte)1, false, true, 1, true, false);

  }

  @Test
  public void test342() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test342"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)' ', true, true, (int)(byte)0, false, false, (int)(byte)0, true, false);
    testWBS0.launch((int)(byte)1, false, false, (int)'4', true, false, (int)(byte)1, false, false);
    testWBS0.launch((-1), false, false, 0, false, false, (int)(short)(-1), false, true);
    testWBS0.launch((int)(short)(-1), false, true, 10, true, true, (int)(byte)100, true, false);
    testWBS0.launch((int)(byte)(-1), true, false, (int)(short)100, false, true, (int)'4', false, true);
    testWBS0.launch(0, false, true, (int)(short)100, true, true, (int)'#', false, true);
    testWBS0.launch((int)(byte)0, false, true, (int)(byte)0, false, true, 10, false, false);

  }

  @Test
  public void test343() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test343"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch(1, true, false, 100, true, false, 0, true, true);
    testWBS0.launch(100, true, false, (int)(byte)1, false, true, (int)(byte)100, false, true);
    testWBS0.launch((int)(short)0, true, false, (-1), true, true, (int)'#', false, false);
    testWBS0.launch((int)(short)10, false, false, 0, true, true, (int)(short)0, false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)(-1), false, true, 100, true, false);

  }

  @Test
  public void test344() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test344"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)100, false, false, (int)'#', false, true, (int)'a', false, false);
    testWBS0.launch(0, false, false, 100, true, false, (int)' ', true, false);
    testWBS0.launch((int)(short)0, true, true, 1, true, false, (int)(byte)0, true, false);
    testWBS0.launch(0, false, true, (int)(byte)10, false, false, (-1), false, true);
    testWBS0.launch((int)'#', true, true, 0, true, true, 100, true, true);

  }

  @Test
  public void test345() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test345"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)' ', true, true, (int)(byte)0, false, false, (int)(byte)0, true, false);
    testWBS0.launch((int)(byte)(-1), false, true, (int)(byte)1, true, false, (int)(byte)100, false, false);
    testWBS0.launch((int)(byte)1, true, false, 10, true, false, (int)(byte)1, true, true);
    testWBS0.launch((int)'a', true, true, 0, true, false, (int)'#', false, true);
    testWBS0.launch((int)(short)1, false, true, (int)'a', true, true, (int)(byte)10, true, true);
    testWBS0.launch(1, false, false, (-1), false, false, 1, true, true);
    testWBS0.launch((int)(short)0, true, false, (int)(short)(-1), false, false, 10, true, true);

  }

  @Test
  public void test346() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test346"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((-1), false, true, 10, false, false, 1, true, true);
    testWBS0.launch((int)(byte)0, true, false, 0, false, false, (int)(short)(-1), false, false);
    testWBS0.launch((-1), false, false, (int)(short)(-1), false, false, (int)'#', true, true);
    testWBS0.launch((int)(byte)(-1), false, true, (int)(byte)10, true, false, (int)(byte)0, true, true);

  }

  @Test
  public void test347() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test347"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch(0, false, true, (int)(byte)10, false, false, 1, false, false);
    testWBS0.launch(0, true, false, (int)'#', true, true, (int)(byte)10, false, false);
    testWBS0.launch(0, true, false, (int)(short)(-1), false, true, (int)'#', false, true);
    testWBS0.launch(0, true, false, (int)'4', true, false, (int)(short)0, false, true);
    testWBS0.launch((int)' ', true, true, (int)(byte)(-1), false, false, (int)(byte)1, false, true);

  }

  @Test
  public void test348() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test348"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, false, true, 0, true, true, (int)(byte)0, true, false);
    testWBS0.launch((int)(short)0, false, false, 1, true, false, (int)(byte)1, true, false);
    testWBS0.launch((int)(byte)(-1), true, true, (int)(byte)10, false, false, (-1), false, true);
    testWBS0.launch((-1), false, true, (int)(byte)0, false, true, (int)' ', false, true);

  }

  @Test
  public void test349() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test349"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch(0, false, true, (int)(byte)10, false, false, 1, false, false);
    testWBS0.launch((int)(byte)100, false, false, 100, false, false, (int)(byte)100, false, true);
    testWBS0.launch(0, false, false, (int)(byte)100, true, true, 1, false, true);
    testWBS0.launch(0, false, false, (int)(byte)0, false, false, (int)(short)10, true, false);
    testWBS0.launch((int)(short)1, false, true, (int)'a', true, false, 0, true, false);

  }

  @Test
  public void test350() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test350"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)1, true, true, 0, false, true);
    testWBS0.launch((int)'4', true, true, (int)' ', true, false, (int)(byte)0, true, true);
    testWBS0.launch((int)(short)100, false, false, (int)(short)0, false, true, (int)(short)100, true, true);
    testWBS0.launch((int)'4', false, true, 0, true, false, (int)(short)1, true, false);
    testWBS0.launch((-1), true, false, (int)(short)0, true, true, 0, false, false);
    testWBS0.launch(0, false, false, (int)(byte)1, false, true, (int)(byte)10, true, false);

  }

  @Test
  public void test351() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test351"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)1, false, false, (int)(short)1, false, true, 0, true, true);
    testWBS0.launch(100, true, false, (int)(short)10, false, false, (int)(byte)100, true, true);
    testWBS0.launch((int)(byte)(-1), false, true, (int)(short)0, true, true, 10, true, false);
    testWBS0.launch((int)(short)0, true, false, (int)'4', true, false, (int)'4', false, true);
    testWBS0.launch((int)(short)0, false, false, (int)(short)1, false, true, (int)' ', true, false);

  }

  @Test
  public void test352() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test352"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)100, false, false, (int)'#', false, true, (int)'a', false, false);
    testWBS0.launch(0, false, false, 100, true, false, (int)' ', true, false);
    testWBS0.launch((int)(short)0, true, true, 1, true, false, (int)(byte)0, true, false);
    testWBS0.launch(0, false, true, 0, false, true, (int)(short)10, true, false);
    testWBS0.launch((int)(byte)0, true, true, (int)(short)(-1), false, false, (int)(byte)10, false, false);

  }

  @Test
  public void test353() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test353"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((-1), false, true, 10, false, false, 1, true, true);
    testWBS0.launch((int)(byte)0, true, false, 0, false, false, (int)(short)(-1), false, false);
    testWBS0.launch(100, true, true, (int)(byte)(-1), false, false, (int)(byte)1, true, false);
    testWBS0.launch(1, true, false, (int)'a', true, true, (int)(byte)0, true, true);
    testWBS0.launch(100, false, true, (int)(short)1, false, false, 1, true, false);
    testWBS0.launch(100, true, true, (int)'a', false, false, (int)(byte)100, true, false);

  }

  @Test
  public void test354() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test354"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)10, false, false, 100, false, true, 0, true, true);
    testWBS0.launch((int)'4', true, false, (int)(byte)(-1), false, false, (int)(byte)(-1), true, true);
    testWBS0.launch(0, true, true, (int)(short)0, false, false, (int)(short)100, true, false);
    testWBS0.launch((int)(short)10, false, true, (int)(byte)0, false, true, (int)(short)(-1), true, true);
    testWBS0.launch(10, false, true, 100, false, true, (int)(byte)0, true, true);
    testWBS0.launch((int)(byte)10, true, true, 10, true, false, (int)(short)0, false, false);

  }

  @Test
  public void test355() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test355"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, true, false, (int)(short)0, false, true);
    testWBS0.launch((int)(short)1, true, false, (int)(short)0, true, true, (int)(byte)0, true, false);
    testWBS0.launch(0, true, true, (-1), false, false, 1, true, false);
    testWBS0.launch((int)(short)(-1), false, false, (int)'#', false, false, 1, true, false);
    testWBS0.launch((int)(short)0, false, false, (int)(short)0, true, false, (int)'a', false, true);
    testWBS0.launch((int)(short)100, true, true, (int)(byte)(-1), false, true, (-1), false, false);

  }

  @Test
  public void test356() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test356"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)0, false, true, (-1), false, false, (-1), true, true);
    testWBS0.launch((int)(short)(-1), true, false, (int)(byte)(-1), true, false, 1, true, false);
    testWBS0.launch((int)(short)1, false, true, (int)(short)10, true, false, 0, true, false);
    testWBS0.launch(0, true, false, 10, false, false, (int)'a', true, true);
    testWBS0.launch(100, true, true, (int)(short)(-1), true, true, (int)(short)100, true, true);
    testWBS0.launch((int)(short)(-1), false, true, (int)'4', false, true, (int)(short)1, false, false);

  }

  @Test
  public void test357() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test357"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch((-1), true, false, (int)(short)100, false, false, 1, true, true);
    testWBS0.launch((int)(byte)(-1), true, false, (int)(byte)100, false, false, (int)(byte)10, false, false);
    testWBS0.launch((int)' ', true, true, (int)' ', true, false, 100, false, true);

  }

  @Test
  public void test358() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test358"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)'a', true, false, (int)(short)1, false, false, (int)(byte)10, true, true);
    testWBS0.launch((int)(byte)10, true, true, (int)'#', true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)(-1), false, true, (int)(byte)0, false, true, (int)'4', true, false);
    testWBS0.launch((int)(short)10, true, false, (int)(byte)0, false, false, 10, true, false);
    testWBS0.launch((int)(short)(-1), true, false, (int)'#', false, false, (int)(byte)100, true, true);

  }

  @Test
  public void test359() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test359"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)10, false, false, 100, false, true, 0, true, true);
    testWBS0.launch((int)'4', true, false, (int)(byte)(-1), false, false, (int)(byte)(-1), true, true);
    testWBS0.launch(0, true, true, (int)(short)0, false, false, (int)(short)100, true, false);
    testWBS0.launch((int)(short)10, false, true, (int)(byte)0, false, true, (int)(short)(-1), true, true);
    testWBS0.launch((int)(short)100, false, true, 1, false, true, (int)(byte)1, false, false);
    testWBS0.launch((int)(byte)10, true, true, 0, false, true, 1, true, true);
    testWBS0.launch((int)(short)10, false, true, (int)'4', false, true, (int)' ', true, true);

  }

  @Test
  public void test360() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test360"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, false, true, 0, true, true, (int)(byte)0, true, false);
    testWBS0.launch((-1), true, true, (int)(byte)0, true, true, (int)'#', true, false);
    testWBS0.launch((int)(byte)10, false, false, (int)(byte)1, false, false, (int)(short)0, true, false);
    testWBS0.launch((-1), false, false, (int)(byte)1, true, false, 100, false, false);
    testWBS0.launch((int)'4', false, false, (int)' ', false, true, (int)(short)100, false, false);
    testWBS0.launch((int)(byte)0, true, true, (int)'a', true, true, 0, false, false);
    testWBS0.launch(10, false, false, 10, true, true, (-1), true, true);

  }

  @Test
  public void test361() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test361"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(byte)1, false, true, 1, false, false, (-1), false, true);
    testWBS0.launch((int)'#', false, false, 0, false, false, 100, false, false);
    testWBS0.launch((int)(short)10, false, true, 0, false, true, (int)(short)10, false, false);
    testWBS0.launch(10, false, false, (int)(short)10, false, true, (int)'4', false, true);
    testWBS0.launch((int)' ', true, true, (int)(byte)1, true, false, 100, false, false);
    testWBS0.launch((int)(short)10, false, false, (int)' ', true, true, (-1), true, false);

  }

  @Test
  public void test362() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test362"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)1, false, false, (int)(short)1, false, true, 0, true, true);
    testWBS0.launch((int)(byte)0, false, false, (int)(short)10, true, true, (int)(byte)10, true, true);
    testWBS0.launch((int)(short)100, false, true, (int)(short)(-1), false, true, (int)(short)100, true, true);
    testWBS0.launch((int)'4', true, false, (int)'a', false, false, (int)(byte)100, true, true);
    testWBS0.launch((int)(byte)0, true, false, (int)(short)(-1), false, true, (int)'a', true, true);
    testWBS0.launch(0, true, false, (int)'a', false, true, (int)(short)(-1), false, true);
    testWBS0.launch(1, true, false, (int)(short)1, false, false, (int)(byte)100, false, true);

  }

  @Test
  public void test363() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test363"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)(byte)1, true, false, (int)(byte)0, true, true, (int)(short)(-1), true, true);
    testWBS0.launch((int)' ', true, false, (int)(short)100, false, false, 100, true, true);
    testWBS0.launch((int)'4', true, true, 1, false, true, (int)'#', false, true);
    testWBS0.launch((-1), true, true, (int)(byte)(-1), false, false, 10, false, false);
    testWBS0.launch(10, false, false, (int)'4', false, true, (int)'a', true, true);
    testWBS0.launch((int)'#', false, true, 100, true, true, 0, true, true);

  }

  @Test
  public void test364() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test364"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(byte)10, true, false, (int)'4', false, false);
    testWBS0.launch(0, true, false, 0, true, true, (int)(short)10, true, false);
    testWBS0.launch((int)(byte)100, true, false, 0, true, true, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)0, true, true, 100, false, true, (int)(byte)1, false, false);
    testWBS0.launch((int)' ', true, false, 0, false, true, (int)'a', false, false);

  }

  @Test
  public void test365() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test365"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch(1, true, false, (int)'#', false, false, (int)(byte)(-1), false, false);
    testWBS0.launch(0, false, true, (int)(byte)100, true, false, (int)'#', true, true);
    testWBS0.launch((int)(short)0, true, false, (int)(byte)0, true, true, (int)'#', true, false);
    testWBS0.launch((int)'a', true, true, (int)'#', false, false, 100, true, false);
    testWBS0.launch((-1), false, true, 10, false, true, 0, true, false);
    testWBS0.launch((int)(byte)(-1), true, true, (int)'a', true, false, (int)'#', true, false);
    testWBS0.launch((-1), false, true, 0, true, false, 100, false, false);

  }

  @Test
  public void test366() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test366"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)1, false, false, (int)(short)0, true, false, 10, false, true);
    testWBS0.launch((int)(byte)(-1), true, false, (int)' ', false, true, (int)(byte)1, true, true);
    testWBS0.launch((int)'4', true, true, (int)(short)0, true, false, (int)(short)100, true, false);
    testWBS0.launch(100, false, true, (-1), false, true, 1, false, false);

  }

  @Test
  public void test367() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test367"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)100, false, false, (int)'#', false, true, (int)'a', false, false);
    testWBS0.launch(0, false, false, 100, true, false, (int)' ', true, false);
    testWBS0.launch((int)(byte)10, true, false, (int)' ', false, true, 10, true, true);
    testWBS0.launch((int)(short)(-1), true, true, (int)' ', false, false, (int)(short)0, false, false);
    testWBS0.launch((int)(short)100, true, false, (int)(byte)100, false, false, 1, false, false);
    testWBS0.launch((int)(short)100, false, true, 0, false, false, (int)(short)100, false, false);
    testWBS0.launch((int)'4', true, false, (int)(short)0, true, false, (int)'a', true, false);

  }

  @Test
  public void test368() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test368"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)10, false, true, 0, true, false, (int)(short)10, true, false);
    testWBS0.launch((int)(short)1, true, false, (int)(byte)(-1), true, true, (int)(byte)1, false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)100, true, true, (int)'4', true, true);
    testWBS0.launch((int)(short)0, true, false, (-1), false, false, (-1), false, false);
    testWBS0.launch((-1), false, true, (int)(short)0, false, false, 0, false, false);
    testWBS0.launch((int)(byte)100, false, false, 1, true, true, (-1), true, true);

  }

  @Test
  public void test369() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test369"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)'a', true, false, (int)(short)1, false, false, (int)(byte)10, true, true);
    testWBS0.launch((int)(short)10, true, true, (int)(byte)100, false, false, 10, false, true);
    testWBS0.launch((int)'#', true, false, (int)(byte)(-1), true, false, (int)' ', true, false);
    testWBS0.launch((int)'a', true, false, (-1), true, true, (int)(short)(-1), true, false);
    testWBS0.launch((int)' ', true, true, (int)(byte)0, false, false, 0, false, false);
    testWBS0.launch(0, false, false, (-1), false, false, (-1), true, false);

  }

  @Test
  public void test370() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test370"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((-1), false, true, 10, false, false, 1, true, true);
    testWBS0.launch((int)(byte)0, true, false, 0, false, false, (int)(short)(-1), false, false);
    testWBS0.launch(1, false, true, (int)(byte)0, false, true, (int)' ', true, false);
    testWBS0.launch((int)'a', true, true, (int)(short)(-1), true, false, (int)(byte)100, false, false);
    testWBS0.launch((int)(short)10, true, false, (int)(byte)(-1), false, true, 0, false, false);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)10, true, false, (-1), false, true, (int)(short)100, true, false);

  }

  @Test
  public void test371() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test371"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)100, false, false, (int)'#', false, true, (int)'a', false, false);
    testWBS0.launch(0, false, false, 100, true, false, (int)' ', true, false);
    testWBS0.launch((int)(byte)(-1), false, true, (int)(short)1, false, true, (int)(short)0, true, true);
    testWBS0.launch((-1), false, true, (int)'a', true, true, 100, true, true);
    testWBS0.launch((int)(byte)100, false, false, (int)(byte)1, true, false, (int)' ', false, false);
    testWBS0.launch((int)(short)1, false, true, (int)(byte)100, true, false, (int)(byte)(-1), true, false);

  }

  @Test
  public void test372() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test372"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(byte)1, false, true, 1, false, false, (-1), false, true);
    testWBS0.launch((-1), false, false, (int)'4', true, false, 0, true, true);
    testWBS0.launch((int)(byte)(-1), true, false, 100, false, false, (-1), false, false);
    testWBS0.launch((int)(byte)1, false, false, (int)(byte)(-1), false, false, 1, false, true);
    testWBS0.launch(1, true, false, (int)'#', true, false, 100, true, false);

  }

  @Test
  public void test373() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test373"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)'a', true, false, (int)(short)1, false, false, (int)(byte)10, true, true);
    testWBS0.launch((int)(short)10, true, true, (int)(byte)100, false, false, 10, false, true);
    testWBS0.launch((int)'#', true, false, (int)(byte)(-1), true, false, (int)' ', true, false);
    testWBS0.launch(0, true, false, (int)(short)0, false, true, 0, true, true);
    testWBS0.launch((int)(byte)(-1), true, false, (int)(byte)100, true, false, (int)(byte)0, true, false);

  }

  @Test
  public void test374() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test374"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)' ', true, true, (int)(byte)0, false, false, (int)(byte)0, true, false);
    testWBS0.launch((int)(byte)(-1), false, true, (int)(byte)1, true, false, (int)(byte)100, false, false);
    testWBS0.launch((int)(short)0, false, true, (int)'4', true, true, (int)'4', false, false);
    testWBS0.launch((int)(short)100, false, true, (int)(byte)1, false, true, 1, true, true);
    testWBS0.launch((int)'4', true, false, 100, true, false, (int)(short)1, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, false, (int)' ', true, true);
    testWBS0.launch(0, false, false, (int)(short)10, true, false, (int)(byte)10, true, false);

  }

  @Test
  public void test375() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test375"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)0, false, true, (-1), false, false, (-1), true, true);
    testWBS0.launch((int)(byte)(-1), false, true, (-1), false, false, 1, false, false);
    testWBS0.launch(100, false, true, (int)' ', false, false, (int)(short)1, true, true);
    testWBS0.launch(10, false, false, (int)(short)100, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(short)1, true, true, (int)(short)1, false, false, 0, false, true);
    testWBS0.launch((-1), true, true, (int)(byte)1, true, false, 0, false, false);
    testWBS0.launch((int)(byte)0, false, true, (int)(byte)10, true, false, 1, false, false);

  }

  @Test
  public void test376() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test376"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)0, false, true, (-1), false, false, (-1), true, true);
    testWBS0.launch((int)(short)(-1), true, false, (int)(byte)(-1), true, false, 1, true, false);
    testWBS0.launch((int)(short)1, false, true, (int)(short)10, true, false, 0, true, false);
    testWBS0.launch((int)(short)0, false, true, (int)(short)(-1), false, true, (int)'a', false, false);
    testWBS0.launch((int)(short)100, false, false, (int)(byte)(-1), false, true, 0, true, false);
    testWBS0.launch(0, false, false, (int)(byte)10, false, false, (int)(short)10, false, true);
    testWBS0.launch((int)' ', false, true, (int)'a', true, true, (int)(byte)1, false, true);

  }

  @Test
  public void test377() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test377"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch(0, false, true, (int)(byte)100, true, true, (int)(short)10, true, false);
    testWBS0.launch((int)(short)(-1), true, false, 10, false, true, (int)(short)0, false, true);
    testWBS0.launch((int)' ', false, true, 1, false, false, (int)'#', true, false);
    testWBS0.launch(0, false, false, (int)(short)100, false, true, 0, false, true);
    testWBS0.launch(1, true, false, (int)(short)1, false, true, 100, false, false);

  }

  @Test
  public void test378() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test378"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)'a', true, false, (int)(short)1, false, false, (int)(byte)10, true, true);
    testWBS0.launch(1, false, true, (int)(byte)10, true, false, 0, true, true);
    testWBS0.launch((int)(byte)0, false, true, (int)' ', false, false, (int)' ', true, true);
    testWBS0.launch((int)(short)(-1), false, true, 1, false, true, (int)(byte)(-1), true, false);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, true, true, (int)(byte)10, false, true);
    testWBS0.launch((int)(short)0, true, true, (int)'4', true, false, (int)'a', true, false);

  }

  @Test
  public void test379() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test379"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)0, false, true, (-1), false, false, (-1), true, true);
    testWBS0.launch((int)(short)(-1), true, false, (int)(byte)(-1), true, false, 1, true, false);
    testWBS0.launch((int)'a', true, false, (int)(byte)(-1), false, false, (int)'#', true, false);
    testWBS0.launch((int)(short)0, true, false, 100, false, false, (int)(short)1, true, false);
    testWBS0.launch((int)(byte)0, true, false, (int)(byte)100, true, false, 1, true, true);

  }

  @Test
  public void test380() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test380"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(byte)(-1), true, true, (int)(byte)1, true, true, (int)(byte)1, false, true);
    testWBS0.launch((int)(byte)(-1), false, false, (int)(byte)1, false, false, 100, false, false);
    testWBS0.launch((int)(short)0, false, true, (int)(byte)(-1), true, false, (int)' ', true, false);
    testWBS0.launch((int)(short)1, false, true, (int)(short)(-1), true, false, (int)' ', true, false);
    testWBS0.launch((int)(short)10, false, true, (int)(byte)100, false, true, (int)(short)10, false, false);

  }

  @Test
  public void test381() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test381"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)'a', true, false, (int)(short)1, false, false, (int)(byte)10, true, true);
    testWBS0.launch((int)(short)10, true, true, (int)(byte)100, false, false, 10, false, true);
    testWBS0.launch((int)'#', true, false, (int)(byte)(-1), true, false, (int)' ', true, false);
    testWBS0.launch(10, false, true, 10, false, false, (int)'#', false, false);
    testWBS0.launch((int)'a', true, true, (int)(short)(-1), true, false, 100, false, false);
    testWBS0.launch((int)(short)10, false, true, (int)'#', true, true, (-1), true, false);
    testWBS0.launch((int)'4', true, true, 100, true, false, (int)' ', false, false);

  }

  @Test
  public void test382() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test382"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, true, false, (int)(short)0, false, true);
    testWBS0.launch(100, true, true, (int)(byte)(-1), false, false, 10, false, false);
    testWBS0.launch(10, false, true, (int)(short)(-1), true, false, 100, true, true);

  }

  @Test
  public void test383() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test383"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((-1), false, true, 10, false, false, 1, true, true);
    testWBS0.launch((int)(byte)0, true, false, 0, false, false, (int)(short)(-1), false, false);
    testWBS0.launch((-1), false, false, (int)(short)(-1), false, false, (int)'#', true, true);
    testWBS0.launch((int)(byte)10, false, false, (int)(byte)100, false, false, 0, true, false);
    testWBS0.launch(0, false, false, (int)(byte)1, true, false, (int)(short)100, true, true);
    testWBS0.launch((int)(short)(-1), false, true, 0, false, false, (int)(short)(-1), true, true);
    testWBS0.launch((int)(short)(-1), true, false, (int)(byte)10, false, true, 0, false, false);

  }

  @Test
  public void test384() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test384"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)'a', true, false, (int)(short)1, false, false, (int)(byte)10, true, true);
    testWBS0.launch((int)(byte)10, true, true, (int)'#', true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)(-1), false, true, (int)(byte)0, false, true, (int)'4', true, false);
    testWBS0.launch((int)' ', false, false, (int)(short)0, true, false, (int)'#', false, false);
    testWBS0.launch(100, false, false, 0, false, false, 0, false, false);
    testWBS0.launch((int)(short)100, false, false, (int)' ', false, false, 100, true, true);
    testWBS0.launch((int)(short)100, false, false, (int)(short)10, true, false, (int)(short)(-1), false, false);

  }

  @Test
  public void test385() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test385"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch(0, false, false, (int)(short)0, true, true, 1, true, false);
    testWBS0.launch((int)(short)(-1), false, false, (int)'a', true, true, (int)(byte)1, true, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(byte)0, false, true, (int)(byte)1, false, true);
    testWBS0.launch((-1), true, true, 1, false, true, (int)(short)100, true, true);

  }

  @Test
  public void test386() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test386"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)10, false, true, 0, true, false, (int)(short)10, true, false);
    testWBS0.launch((int)(short)10, true, false, (int)' ', true, false, (int)(byte)(-1), false, true);
    testWBS0.launch((int)(short)0, false, true, (int)(short)100, false, true, (int)(byte)1, false, true);
    testWBS0.launch((int)(byte)10, false, false, (int)(short)(-1), false, false, (int)'4', true, false);
    testWBS0.launch((int)(short)(-1), false, true, 100, false, true, (int)(short)100, false, true);

  }

  @Test
  public void test387() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test387"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch(0, true, true, (-1), false, false, (-1), true, false);
    testWBS0.launch((int)' ', false, true, (int)(byte)(-1), false, true, (int)'#', true, false);
    testWBS0.launch(0, false, false, 1, true, true, 1, true, false);

  }

  @Test
  public void test388() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test388"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)10, false, true, 0, true, false, (int)(short)10, true, false);
    testWBS0.launch((int)(short)1, true, false, (int)(byte)(-1), true, true, (int)(byte)1, false, false);
    testWBS0.launch((int)(byte)(-1), false, false, 1, true, true, (int)(short)0, true, true);
    testWBS0.launch((int)(byte)10, true, false, (int)'a', true, false, (int)(byte)100, false, true);
    testWBS0.launch(1, false, false, (int)(short)1, false, false, (int)(short)0, true, true);
    testWBS0.launch(100, true, false, 10, false, false, (int)'a', false, false);
    testWBS0.launch((int)(byte)0, false, true, 10, true, false, (int)(byte)0, true, false);
    testWBS0.launch((int)' ', true, true, (int)(byte)10, true, false, (int)(byte)0, true, true);

  }

  @Test
  public void test389() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test389"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)1, true, true, 0, false, true);
    testWBS0.launch((int)(byte)(-1), true, false, (int)(short)(-1), false, false, (int)' ', false, false);
    testWBS0.launch((int)(byte)0, true, false, 10, true, true, (int)(short)100, true, true);
    testWBS0.launch((int)' ', true, true, (int)(short)1, false, false, (-1), false, false);
    testWBS0.launch((int)(short)(-1), true, true, (int)(short)1, false, false, (int)(byte)0, false, false);
    testWBS0.launch((int)(byte)0, false, true, (int)(short)10, true, true, 100, false, false);

  }

  @Test
  public void test390() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test390"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(byte)10, false, false, 1, false, false, (-1), true, false);
    testWBS0.launch((int)(short)100, false, true, 10, false, true, (int)(short)100, true, false);
    testWBS0.launch((int)(short)10, false, true, (int)'a', false, true, (int)(byte)0, false, false);
    testWBS0.launch(0, true, true, 100, true, true, (-1), true, true);
    testWBS0.launch((int)(byte)(-1), false, false, 10, false, false, (int)(short)1, true, true);
    testWBS0.launch((-1), true, false, (int)'a', true, false, (int)(short)0, true, false);

  }

  @Test
  public void test391() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test391"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)0, true, false, (int)'a', false, false, (int)(short)0, true, false);
    testWBS0.launch(0, false, false, (int)(byte)(-1), true, true, 0, true, false);
    testWBS0.launch((-1), false, true, (int)(short)10, true, true, (int)'a', true, false);
    testWBS0.launch((int)(short)0, true, true, (int)(short)1, false, false, (int)(byte)0, true, true);
    testWBS0.launch((int)(byte)10, true, false, (int)(byte)10, false, true, (int)(byte)0, false, true);
    testWBS0.launch((int)(short)1, false, true, (int)(byte)(-1), false, false, 100, true, false);

  }

  @Test
  public void test392() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test392"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)10, false, false, 100, false, true, 0, true, true);
    testWBS0.launch((int)'4', true, false, (int)(byte)(-1), false, false, (int)(byte)(-1), true, true);
    testWBS0.launch((int)(byte)100, true, true, (int)(short)0, true, true, 0, false, false);
    testWBS0.launch((int)(byte)10, false, false, (int)' ', false, false, (int)(byte)0, true, true);
    testWBS0.launch((int)'4', false, true, (int)(short)0, false, true, 10, false, true);
    testWBS0.launch((int)'4', true, false, (int)(short)10, true, true, 1, true, true);

  }

  @Test
  public void test393() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test393"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, true, false, (int)(short)0, false, true);
    testWBS0.launch(100, true, true, (int)(byte)(-1), false, false, 10, false, false);
    testWBS0.launch((int)'4', true, true, (int)' ', true, true, (int)(byte)10, false, false);
    testWBS0.launch(100, false, false, 0, false, false, (int)'4', false, false);
    testWBS0.launch((int)(short)100, false, true, 1, false, true, (int)(short)10, false, true);
    testWBS0.launch(1, true, true, (int)(short)1, true, false, (int)(short)10, false, true);
    testWBS0.launch((int)(byte)100, false, true, (-1), false, true, (int)(short)0, true, false);

  }

  @Test
  public void test394() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test394"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch(0, true, true, 100, true, false, (-1), false, false);
    testWBS0.launch((int)'#', true, false, (int)'a', true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)'4', true, false, (int)(short)100, true, false, (int)(byte)(-1), true, true);
    testWBS0.launch(1, false, false, (int)(byte)0, true, false, (int)(byte)10, true, true);
    testWBS0.launch(0, true, false, (int)(byte)(-1), true, true, (int)(byte)0, false, false);
    testWBS0.launch(0, false, true, (int)(short)100, true, true, (int)(short)0, false, true);
    testWBS0.launch((int)(byte)1, true, false, (int)(byte)100, true, false, (int)(short)0, false, true);

  }

  @Test
  public void test395() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test395"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, true, false, 0, true, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)0, true, true, (int)(byte)0, false, false);
    testWBS0.launch((int)(short)0, true, true, (-1), false, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)10, false, true, (int)'4', false, false, 0, false, false);
    testWBS0.launch((int)' ', true, false, (int)(byte)100, false, false, (int)'4', true, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(byte)10, false, false, (int)'a', true, false);
    testWBS0.launch((int)(short)100, false, false, (int)(short)1, false, true, (int)'#', false, true);
    testWBS0.launch((int)(short)0, false, false, (int)'4', true, true, 100, false, false);

  }

  @Test
  public void test396() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test396"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)10, false, true, 0, true, false, (int)(short)10, true, false);
    testWBS0.launch((int)(short)1, true, false, (int)(byte)(-1), true, true, (int)(byte)1, false, false);
    testWBS0.launch((int)(byte)(-1), false, false, 1, true, true, (int)(short)0, true, true);
    testWBS0.launch((int)'4', true, true, (int)' ', true, true, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)100, false, false, (int)(short)(-1), true, true, 100, true, true);
    testWBS0.launch(0, true, false, (int)(short)100, false, false, 0, false, false);

  }

  @Test
  public void test397() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test397"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((-1), false, true, 10, false, false, 1, true, true);
    testWBS0.launch((int)(byte)0, true, false, 0, false, false, (int)(short)(-1), false, false);
    testWBS0.launch(1, false, true, (int)(byte)0, false, true, (int)' ', true, false);
    testWBS0.launch((int)(short)10, true, false, (int)'#', false, false, (int)(short)(-1), true, true);
    testWBS0.launch((int)(short)(-1), false, false, (int)(short)100, false, false, 100, false, false);
    testWBS0.launch((int)'4', false, false, (int)(short)0, false, true, (-1), true, true);
    testWBS0.launch((int)(byte)1, false, true, (int)(short)(-1), true, false, (int)(short)10, false, true);

  }

  @Test
  public void test398() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test398"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(byte)1, true, false, (int)(short)0, false, true);
    testWBS0.launch((int)(byte)0, true, true, (int)(short)10, false, true, 1, true, false);
    testWBS0.launch(100, true, false, (int)(short)10, true, false, (int)'4', false, true);

  }

  @Test
  public void test399() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test399"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(byte)10, true, true, (int)(short)1, true, true, 0, false, true);
    testWBS0.launch((int)(byte)(-1), true, false, (int)(short)(-1), false, false, (int)' ', false, false);
    testWBS0.launch((int)(byte)0, true, false, 10, true, true, (int)(short)100, true, true);
    testWBS0.launch((int)(short)10, false, true, 100, false, false, (-1), true, false);
    testWBS0.launch((int)' ', false, false, (int)'#', false, true, 0, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)'a', true, false, (int)(short)(-1), false, true);
    testWBS0.launch(0, false, false, (int)(byte)1, false, false, 0, true, false);

  }

  @Test
  public void test400() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test400"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)100, false, false, (int)'#', false, true, (int)'a', false, false);
    testWBS0.launch(0, false, false, 100, true, false, (int)' ', true, false);
    testWBS0.launch((int)(byte)10, true, false, (int)' ', false, true, 10, true, true);
    testWBS0.launch(10, true, false, (int)'#', true, true, (-1), false, true);
    testWBS0.launch((int)'a', false, true, (int)(byte)100, false, false, 0, true, true);
    testWBS0.launch(100, false, false, (int)(short)10, true, false, (int)' ', false, false);
    testWBS0.launch((int)'#', false, true, 0, true, false, (int)' ', true, false);

  }

  @Test
  public void test401() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test401"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)10, false, false, 100, false, true, 0, true, true);
    testWBS0.launch((int)'4', true, false, (int)(byte)(-1), false, false, (int)(byte)(-1), true, true);
    testWBS0.launch(0, true, true, (int)(short)0, false, false, (int)(short)100, true, false);
    testWBS0.launch((int)(short)10, false, true, (int)(byte)0, false, true, (int)(short)(-1), true, true);
    testWBS0.launch((int)(short)100, false, true, 1, false, true, (int)(byte)1, false, false);
    testWBS0.launch((int)(byte)10, true, true, 0, false, true, 1, true, true);
    testWBS0.launch((int)(byte)1, true, true, (int)(byte)0, false, true, (int)'a', true, true);

  }

  @Test
  public void test402() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test402"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)'a', true, false, (int)(short)1, false, false, (int)(byte)10, true, true);
    testWBS0.launch(10, true, false, 100, false, true, (int)(short)(-1), true, false);
    testWBS0.launch((int)(byte)(-1), false, false, (int)(short)(-1), false, true, 0, true, false);
    testWBS0.launch((int)(byte)1, false, true, 100, false, true, (int)(short)100, false, false);
    testWBS0.launch((int)'#', true, true, 10, true, false, (int)(short)1, true, true);
    testWBS0.launch(0, true, false, (int)'#', false, false, 10, false, true);
    testWBS0.launch((int)(short)1, false, true, (int)'#', true, false, (int)(short)1, true, false);
    testWBS0.launch((int)'#', false, false, (int)(short)0, false, false, (int)' ', false, true);

  }

  @Test
  public void test403() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test403"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((-1), false, true, 10, false, false, 1, true, true);
    testWBS0.launch((int)(short)(-1), false, false, (int)(short)100, false, true, (-1), true, true);
    testWBS0.launch((int)(short)0, false, false, (int)'#', false, true, (int)(byte)0, false, true);
    testWBS0.launch((int)'a', true, true, (int)(byte)100, true, false, (int)(byte)(-1), false, false);
    testWBS0.launch(1, false, true, (int)(byte)1, true, false, (int)(byte)(-1), true, false);
    testWBS0.launch(100, false, false, (int)(short)0, true, false, 1, false, false);

  }

  @Test
  public void test404() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test404"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(0, false, false, (int)(short)1, false, true, (int)'#', false, false);
    testWBS0.launch(10, false, false, 1, false, false, (int)(byte)100, false, true);
    testWBS0.launch(10, false, true, (int)' ', true, false, (int)(short)10, true, true);
    testWBS0.launch((int)(byte)(-1), false, false, (int)(byte)1, false, true, 100, false, true);
    testWBS0.launch((int)(short)10, false, true, (int)(short)0, false, false, 1, false, false);
    testWBS0.launch((int)(byte)100, false, true, (int)(byte)1, false, true, (int)(byte)(-1), false, false);

  }

  @Test
  public void test405() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test405"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)' ', false, true, (int)(byte)10, true, true, (-1), false, true);
    testWBS0.launch((int)(short)100, true, false, (int)'4', true, true, 0, false, false);
    testWBS0.launch(0, false, false, 0, false, false, (int)(byte)100, true, true);
    testWBS0.launch(0, true, true, 0, true, true, 0, false, true);
    testWBS0.launch((int)'4', true, true, (int)' ', false, true, (int)' ', true, true);
    testWBS0.launch(10, true, true, (int)(byte)0, true, false, (int)(short)100, false, false);
    testWBS0.launch(0, true, false, 10, true, true, (int)(short)10, false, false);
    testWBS0.launch(1, false, false, 1, false, true, (int)(short)10, false, true);

  }

  @Test
  public void test406() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test406"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)1, false, false, (int)(short)1, false, true, 0, true, true);
    testWBS0.launch((int)(short)100, false, false, (int)'4', true, true, (int)'#', false, false);
    testWBS0.launch(0, false, false, (int)(byte)1, true, true, (int)' ', true, false);
    testWBS0.launch((int)(byte)100, false, false, (int)'a', true, true, (int)(short)100, false, false);
    testWBS0.launch(0, true, true, (int)(short)0, false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(short)10, false, true, 1, false, false, (int)(byte)10, false, true);

  }

  @Test
  public void test407() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test407"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)1, false, false, (int)(short)0, true, false, 10, false, true);
    testWBS0.launch((int)(byte)100, true, false, (int)(short)10, true, false, 0, true, true);
    testWBS0.launch((int)(byte)(-1), true, false, (int)(short)10, true, true, (int)(short)1, true, false);
    testWBS0.launch((int)' ', false, true, (int)(short)(-1), true, false, (int)(byte)0, false, false);
    testWBS0.launch(0, false, false, (int)'a', false, true, (int)(short)0, false, false);
    testWBS0.launch(10, false, false, (int)(short)10, false, false, 0, true, true);
    testWBS0.launch((int)'4', true, true, (int)(byte)1, true, false, (int)'#', false, true);

  }

  @Test
  public void test408() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test408"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((-1), false, true, 10, false, false, 1, true, true);
    testWBS0.launch(1, false, false, (int)'a', false, false, (int)(byte)10, false, true);
    testWBS0.launch((-1), true, true, (int)(short)(-1), false, false, 0, true, false);
    testWBS0.launch((int)(short)1, false, true, (int)(byte)10, false, false, 100, false, true);
    testWBS0.launch(1, true, false, (-1), true, true, (int)(short)10, false, true);
    testWBS0.launch((int)(short)1, true, false, (-1), false, false, 1, true, false);

  }

  @Test
  public void test409() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test409"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((-1), false, true, 10, false, false, 1, true, true);
    testWBS0.launch((int)(byte)0, true, false, 0, false, false, (int)(short)(-1), false, false);
    testWBS0.launch(1, false, true, (int)(byte)0, false, true, (int)' ', true, false);
    testWBS0.launch((int)(short)10, true, false, (int)'#', false, false, (int)(short)(-1), true, true);
    testWBS0.launch((int)(short)100, true, true, 0, false, false, 10, true, true);
    testWBS0.launch((int)'#', true, false, (int)(short)100, false, false, (int)(short)1, true, false);
    testWBS0.launch((int)(short)(-1), true, false, (int)(byte)10, true, false, (int)'a', false, true);
    testWBS0.launch((int)(byte)0, true, false, (-1), false, false, 0, false, true);

  }

  @Test
  public void test410() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test410"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((-1), false, true, 10, false, false, 1, true, true);
    testWBS0.launch((int)(byte)0, true, false, 0, false, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(short)10, false, true, (int)'4', true, false, (int)(byte)100, false, true);
    testWBS0.launch(0, true, true, (int)'a', true, false, 0, false, false);

  }

  @Test
  public void test411() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test411"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch(0, false, true, (int)(byte)10, false, false, 1, false, false);
    testWBS0.launch(0, true, false, (int)'#', true, true, (int)(byte)10, false, false);
    testWBS0.launch(0, true, false, (int)(byte)1, true, false, (int)(byte)0, false, false);
    testWBS0.launch((int)(short)1, false, false, (int)(short)(-1), true, false, (int)(byte)(-1), false, false);
    testWBS0.launch((int)(byte)(-1), true, false, (int)(short)100, false, false, 10, false, true);
    testWBS0.launch((int)'a', true, true, (int)(short)10, false, false, (int)(byte)100, true, false);

  }

  @Test
  public void test412() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test412"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)'a', true, false, (int)(short)1, false, false, (int)(byte)10, true, true);
    testWBS0.launch((int)(short)10, true, true, (int)(byte)100, false, false, 10, false, true);
    testWBS0.launch((int)'#', false, true, 1, false, true, (int)(byte)(-1), false, false);
    testWBS0.launch((int)(byte)(-1), true, true, (int)(byte)0, false, false, 100, false, true);
    testWBS0.launch((int)(byte)1, true, false, (int)(byte)0, true, false, (int)(byte)0, false, false);
    testWBS0.launch(100, true, true, (int)(short)10, true, true, (int)(byte)100, false, false);

  }

  @Test
  public void test413() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test413"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)'a', true, false, (int)(short)1, false, false, (int)(byte)10, true, true);
    testWBS0.launch((int)(short)10, true, true, (int)(byte)100, false, false, 10, false, true);
    testWBS0.launch((int)'#', true, false, (int)(byte)(-1), true, false, (int)' ', true, false);
    testWBS0.launch(1, true, true, 1, false, true, (int)'4', true, true);
    testWBS0.launch((int)(short)1, false, true, (int)'a', false, false, (int)'#', true, false);
    testWBS0.launch(100, true, true, (int)' ', true, true, (int)' ', true, false);
    testWBS0.launch(1, true, false, (int)(byte)100, false, false, 100, false, true);

  }

  @Test
  public void test414() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test414"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)10, false, false, 100, false, true, 0, true, true);
    testWBS0.launch((int)'4', true, false, (int)(byte)(-1), false, false, (int)(byte)(-1), true, true);
    testWBS0.launch(1, true, true, (int)(byte)(-1), true, true, (int)(short)100, false, false);
    testWBS0.launch((-1), false, false, (int)'a', true, false, (int)'#', true, true);
    testWBS0.launch(100, true, false, (int)' ', false, false, (int)'a', false, false);

  }

  @Test
  public void test415() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test415"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch(0, false, true, (int)(byte)100, true, true, (int)(short)10, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(short)1, true, false, (int)'#', true, true);
    testWBS0.launch((int)(byte)(-1), false, false, (int)(byte)0, true, true, (int)(short)1, true, false);
    testWBS0.launch((-1), true, false, (int)'a', false, false, (int)(short)0, false, true);
    testWBS0.launch((int)(short)0, true, true, (int)' ', true, false, (int)'#', false, false);

  }

  @Test
  public void test416() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test416"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(byte)10, true, false, (int)'4', false, false);
    testWBS0.launch(10, false, true, (int)(short)0, false, false, (int)(byte)10, true, false);
    testWBS0.launch((int)(short)10, false, false, 1, true, true, (int)(byte)(-1), true, true);
    testWBS0.launch((-1), true, false, (int)'#', false, false, (int)(short)10, false, false);
    testWBS0.launch((int)(short)100, false, true, (int)' ', false, false, (int)(short)1, false, true);
    testWBS0.launch((int)(byte)(-1), false, false, (int)(short)(-1), true, true, (int)'4', true, false);
    testWBS0.launch((int)'#', false, true, 10, false, true, 0, false, true);

  }

  @Test
  public void test417() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test417"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch(10, false, false, 1, false, false, (int)'a', false, false);
    testWBS0.launch((int)(short)(-1), false, false, (int)'#', false, true, 10, true, false);
    testWBS0.launch((int)(byte)10, false, false, (int)(short)10, true, true, (int)'a', true, true);
    testWBS0.launch((int)(short)10, false, false, 10, false, false, (int)' ', true, false);
    testWBS0.launch((int)(byte)100, true, false, (int)(short)100, false, true, 10, true, true);
    testWBS0.launch(1, false, false, 100, false, true, (int)(short)(-1), true, false);
    testWBS0.launch((int)(byte)1, true, true, (int)(byte)1, false, false, 10, true, true);

  }

  @Test
  public void test418() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test418"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(byte)10, true, false, (int)(byte)10, true, false, (int)'4', false, false);
    testWBS0.launch(10, false, true, (int)(short)0, false, false, (int)(byte)10, true, false);
    testWBS0.launch(1, true, false, (int)'4', true, true, (int)(short)10, true, true);
    testWBS0.launch((int)(short)0, false, false, 100, false, true, (int)(short)100, false, true);
    testWBS0.launch((int)(byte)10, false, false, (int)(short)100, false, true, 0, true, true);
    testWBS0.launch((int)(byte)100, true, true, (int)(byte)100, false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(byte)(-1), false, false, (int)(short)100, false, true, (int)(byte)(-1), false, true);

  }

  @Test
  public void test419() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test419"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)' ', false, true, (int)(byte)10, true, true, (-1), false, true);
    testWBS0.launch((int)(byte)10, true, false, (int)(byte)0, false, true, (int)(byte)10, true, true);
    testWBS0.launch((int)'4', true, true, 0, false, false, (int)(short)(-1), false, false);
    testWBS0.launch((int)(byte)10, false, true, (int)(short)1, true, true, (int)(byte)100, false, false);

  }

  @Test
  public void test420() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test420"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)100, true, false, (int)(short)100, true, true, (int)(short)0, true, false);
    testWBS0.launch(1, true, true, (-1), true, false, 10, true, true);
    testWBS0.launch((int)(byte)1, true, false, (int)(short)1, true, true, (int)'4', true, false);
    testWBS0.launch((int)(short)(-1), true, false, (int)(byte)0, false, true, (int)(byte)0, false, false);

  }

  @Test
  public void test421() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test421"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)' ', true, true, (int)(byte)0, false, false, (int)(byte)0, true, false);
    testWBS0.launch((int)(byte)(-1), false, true, (int)(byte)1, true, false, (int)(byte)100, false, false);
    testWBS0.launch((int)(short)0, false, true, (int)'4', true, true, (int)'4', false, false);
    testWBS0.launch((int)'a', false, false, (int)(short)(-1), true, true, 10, true, true);
    testWBS0.launch((int)'#', true, false, (int)'#', false, false, 10, true, false);
    testWBS0.launch(0, true, false, (int)'a', true, false, 0, false, false);
    testWBS0.launch(1, false, false, (int)'4', true, true, (int)(short)10, false, true);

  }

  @Test
  public void test422() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test422"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch((int)(byte)0, false, false, (int)(byte)1, false, false, (int)(byte)1, true, true);
    testWBS0.launch((int)(short)1, false, false, (int)(byte)0, false, false, (-1), false, false);
    testWBS0.launch(0, false, true, (int)(byte)100, true, true, (int)(short)10, true, false);
    testWBS0.launch((int)(short)(-1), false, true, (int)(short)1, true, false, (int)'#', true, true);
    testWBS0.launch((int)(byte)(-1), false, true, (int)(short)10, true, true, (-1), false, true);
    testWBS0.launch((int)(short)0, false, true, (int)(short)(-1), false, false, (int)(byte)1, true, true);
    testWBS0.launch(0, true, true, (int)(byte)10, true, true, (int)(short)10, false, true);
    testWBS0.launch((int)(byte)10, false, true, 10, false, true, (int)(short)100, false, false);

  }

  @Test
  public void test423() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test423"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(10, true, true, (int)(byte)0, true, false, (int)'a', false, true);
    testWBS0.launch((int)(short)10, false, false, (int)(byte)0, true, false, (int)(short)(-1), true, true);
    testWBS0.launch((int)(byte)(-1), true, true, (-1), false, true, 100, true, true);
    testWBS0.launch((int)(byte)1, false, true, 100, false, true, (-1), true, false);

  }

  @Test
  public void test424() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test424"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch((int)(short)(-1), true, false, (int)'a', true, true, (int)(short)100, true, false);
    testWBS0.launch(0, false, true, (int)'a', false, true, (int)(short)0, true, false);
    testWBS0.launch((int)(short)100, false, false, (int)'#', false, true, (int)'a', false, false);
    testWBS0.launch(0, false, false, 100, true, false, (int)' ', true, false);
    testWBS0.launch((int)(short)0, true, true, 1, true, false, (int)(byte)0, true, false);
    testWBS0.launch(0, true, false, (int)(short)10, false, false, 100, false, false);
    testWBS0.launch((int)(byte)1, false, true, (int)'4', true, false, 10, true, true);

  }

  @Test
  public void test425() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test425"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(10, false, false, (int)(byte)10, false, false, (int)'4', true, true);
    testWBS0.launch((int)'#', false, true, (int)(byte)1, false, true, (int)(byte)10, false, true);
    testWBS0.launch((int)(short)(-1), true, false, (int)(byte)0, false, true, (int)(byte)10, true, true);
    testWBS0.launch((int)(short)10, false, true, (int)(byte)1, false, false, 10, false, false);
    testWBS0.launch((int)(short)1, false, true, (int)(short)100, false, false, (int)'#', true, true);

  }

  @Test
  public void test426() throws Throwable {

    if (debug) { System.out.format("%n%s%n","RegressionTest11.test426"); }


    etg.TestWBS testWBS0 = new etg.TestWBS();
    testWBS0.launch(100, false, true, 100, false, true, (int)' ', false, false);
    testWBS0.launch((int)' ', true, false, (int)(short)(-1), false, false, (int)(short)1, false, false);
    testWBS0.launch((int)(short)100, false, true, (int)'#', true, false, (int)(byte)1, true, true);
    testWBS0.launch(0, false, true, (int)'4', true, false, (int)(short)10, true, true);
    testWBS0.launch((int)'4', false, false, (int)(byte)10, false, false, (int)(byte)10, true, false);
    testWBS0.launch((int)' ', true, false, (int)(byte)1, true, true, (int)(byte)(-1), false, false);
    testWBS0.launch((int)(byte)(-1), true, true, (int)(short)(-1), true, false, (int)(byte)100, true, false);
    testWBS0.launch((int)'a', false, false, (int)(short)0, false, true, (int)(byte)(-1), true, false);

  }

}
