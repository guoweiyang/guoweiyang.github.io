package coverage;
import org.junit.Test;
public class TCAS_modifiedTest0 {
	tcas.TCAS_modified o = new tcas.TCAS_modified();
	@Test
	public void test0() {
		o.run(601, true, true, -1000000, -1000000, -999999, 0, -1000000, -1000000, 0, 1, true);
	}
	@Test
	public void test1() {
		o.run(601, true, true, -1000000, -1000000, -999999, 0, 301, 400, 0, 1, true);
	}
	@Test
	public void test2() {
		o.run(601, true, true, -1000000, -1000000, -1000000, 0, -1000000, -1000000, 0, 1, true);
	}
	@Test
	public void test3() {
		o.run(601, true, true, -999999, -1000000, -1000000, 0, 400, 500, 0, 1, true);
	}
	@Test
	public void test4() {
		o.run(601, true, true, -999999, -1000000, -1000000, 0, -1000000, -999900, 0, 1, true);
	}
	@Test
	public void test5() {
		o.run(601, true, true, -1000000, -1000000, -1000000, 0, -1000000, -999900, 0, 1, true);
	}
	@Test
	public void test6() {
		o.run(601, true, true, -1000000, -1000000, -999999, 0, -999999, -1000000, 0, 1, false);
	}
	@Test
	public void test7() {
		o.run(601, true, true, -1000000, -1000000, -999999, 0, 401, 400, 0, 1, false);
	}
	@Test
	public void test8() {
		o.run(601, true, true, -1000000, -1000000, -1000000, 0, -999999, -1000000, 0, 1, false);
	}
	@Test
	public void test9() {
		o.run(601, true, true, -999999, -1000000, -1000000, 0, 400, 400, 0, 1, false);
	}
	@Test
	public void test10() {
		o.run(601, true, true, -999999, -1000000, -1000000, 0, -1000000, -1000000, 0, 1, false);
	}
	@Test
	public void test11() {
		o.run(601, true, true, -1000000, -1000000, -1000000, 0, -1000000, -1000000, 0, 1, false);
	}
	@Test
	public void test12() {
		o.run(601, true, true, 0, -1000000, 0, 0, 0, 0, -1000000, 1, true);
	}
	@Test
	public void test13() {
		o.run(601, true, false, 0, -1000000, 0, 0, 0, 0, 0, 1, true);
	}
	@Test
	public void test14() {
		o.run(601, true, true, -1000000, -1000000, -999999, 0, -1000000, -1000000, 0, 2, true);
	}
	@Test
	public void test15() {
		o.run(601, true, true, -1000000, -1000000, -999999, 0, 301, 400, 0, 2, true);
	}
	@Test
	public void test16() {
		o.run(601, true, true, -1000000, -1000000, -1000000, 0, -1000000, -1000000, 0, 2, true);
	}
	@Test
	public void test17() {
		o.run(601, true, true, -999999, -1000000, -1000000, 0, 400, 500, 0, 2, true);
	}
	@Test
	public void test18() {
		o.run(601, true, true, -999999, -1000000, -1000000, 0, -1000000, -999900, 0, 2, true);
	}
	@Test
	public void test19() {
		o.run(601, true, true, -1000000, -1000000, -1000000, 0, -1000000, -999900, 0, 2, true);
	}
	@Test
	public void test20() {
		o.run(601, true, true, -1000000, -1000000, -999999, 0, -999999, -1000000, 0, 2, false);
	}
	@Test
	public void test21() {
		o.run(601, true, true, -1000000, -1000000, -999999, 0, 401, 400, 0, 2, false);
	}
	@Test
	public void test22() {
		o.run(601, true, true, -1000000, -1000000, -1000000, 0, -999999, -1000000, 0, 2, false);
	}
	@Test
	public void test23() {
		o.run(601, true, true, -999999, -1000000, -1000000, 0, 400, 400, 0, 2, false);
	}
	@Test
	public void test24() {
		o.run(601, true, true, -999999, -1000000, -1000000, 0, -1000000, -1000000, 0, 2, false);
	}
	@Test
	public void test25() {
		o.run(601, true, true, -1000000, -1000000, -1000000, 0, -1000000, -1000000, 0, 2, false);
	}
	@Test
	public void test26() {
		o.run(601, true, true, -1000000, -1000000, -999999, 0, -1000000, -1000000, -1000000, 2, true);
	}
	@Test
	public void test27() {
		o.run(601, true, true, -1000000, -1000000, -999999, 0, 301, 400, -1000000, 2, true);
	}
	@Test
	public void test28() {
		o.run(601, true, true, -1000000, -1000000, -1000000, 0, -1000000, -1000000, -1000000, 2, true);
	}
	@Test
	public void test29() {
		o.run(601, true, true, -999999, -1000000, -1000000, 0, 400, 500, -1000000, 2, true);
	}
	@Test
	public void test30() {
		o.run(601, true, true, -999999, -1000000, -1000000, 0, -1000000, -999900, -1000000, 2, true);
	}
	@Test
	public void test31() {
		o.run(601, true, true, -1000000, -1000000, -1000000, 0, -1000000, -999900, -1000000, 2, true);
	}
	@Test
	public void test32() {
		o.run(601, true, true, -1000000, -1000000, -999999, 0, -999999, -1000000, -1000000, 2, false);
	}
	@Test
	public void test33() {
		o.run(601, true, true, -1000000, -1000000, -999999, 0, 401, 400, -1000000, 2, false);
	}
	@Test
	public void test34() {
		o.run(601, true, true, -1000000, -1000000, -1000000, 0, -999999, -1000000, -1000000, 2, false);
	}
	@Test
	public void test35() {
		o.run(601, true, true, -999999, -1000000, -1000000, 0, 400, 400, -1000000, 2, false);
	}
	@Test
	public void test36() {
		o.run(601, true, true, -999999, -1000000, -1000000, 0, -1000000, -1000000, -1000000, 2, false);
	}
	@Test
	public void test37() {
		o.run(601, true, true, -1000000, -1000000, -1000000, 0, -1000000, -1000000, -1000000, 2, false);
	}
	@Test
	public void test38() {
		o.run(601, true, false, -1000000, -1000000, -999999, 0, -1000000, -1000000, 0, 2, true);
	}
	@Test
	public void test39() {
		o.run(601, true, false, -1000000, -1000000, -999999, 0, 301, 400, 0, 2, true);
	}
	@Test
	public void test40() {
		o.run(601, true, false, -1000000, -1000000, -1000000, 0, -1000000, -1000000, 0, 2, true);
	}
	@Test
	public void test41() {
		o.run(601, true, false, -999999, -1000000, -1000000, 0, 400, 500, 0, 2, true);
	}
	@Test
	public void test42() {
		o.run(601, true, false, -999999, -1000000, -1000000, 0, -1000000, -999900, 0, 2, true);
	}
	@Test
	public void test43() {
		o.run(601, true, false, -1000000, -1000000, -1000000, 0, -1000000, -999900, 0, 2, true);
	}
	@Test
	public void test44() {
		o.run(601, true, false, -1000000, -1000000, -999999, 0, -999999, -1000000, 0, 2, false);
	}
	@Test
	public void test45() {
		o.run(601, true, false, -1000000, -1000000, -999999, 0, 401, 400, 0, 2, false);
	}
	@Test
	public void test46() {
		o.run(601, true, false, -1000000, -1000000, -1000000, 0, -999999, -1000000, 0, 2, false);
	}
	@Test
	public void test47() {
		o.run(601, true, false, -999999, -1000000, -1000000, 0, 400, 400, 0, 2, false);
	}
	@Test
	public void test48() {
		o.run(601, true, false, -999999, -1000000, -1000000, 0, -1000000, -1000000, 0, 2, false);
	}
	@Test
	public void test49() {
		o.run(601, true, false, -1000000, -1000000, -1000000, 0, -1000000, -1000000, 0, 2, false);
	}
	@Test
	public void test50() {
		o.run(-1, true, true, 100, 1, 10, 0, -1, -1, 0, 1, true);
	}
	@Test
	public void test51() {
		o.run(0, true, true, 0, -1, -1, 10, 10, -1, 10, 1, false);
	}
	@Test
	public void test52() {
		o.run(100, true, false, 1, 0, 0, -1, 1, 100, 100, 1, true);
	}
	@Test
	public void test53() {
		o.run(10, true, true, 0, -1, -1, 0, 1, 10, 0, -1, true);
	}
	@Test
	public void test54() {
		o.run(0, true, true, 10, 0, 0, 10, 100, -1, 10, 0, true);
	}
	@Test
	public void test55() {
		o.run(10, true, false, -1, 10, 0, 0, 10, 0, 4, 0, true);
	}
	@Test
	public void test56() {
		o.run(0, true, true, 0, 601, 0, 0, 0, 0, 0, 1, true);
	}
	@Test
	public void test57() {
		o.run(0, true, true, 0, 601, 0, 0, 0, 0, -1000000, 1, true);
	}
	@Test
	public void test58() {
		o.run(0, true, false, 0, 601, 0, 0, 0, 0, 0, 1, true);
	}
	@Test
	public void test59() {
		o.run(0, true, true, 0, 601, 0, 0, 0, 0, 0, 2, true);
	}
	@Test
	public void test60() {
		o.run(0, true, true, 0, 601, 0, 0, 0, 0, -1000000, 2, true);
	}
	@Test
	public void test61() {
		o.run(0, true, false, 0, 601, 0, 0, 0, 0, 0, 2, true);
	}
	@Test
	public void test62() {
		o.run(1, false, true, 100, 10, 10, 10, 10, 10, 0, 1, true);
	}
	@Test
	public void test63() {
		o.run(-1, false, true, 100, 100, -1, 10, 10, -1, 10, 1, true);
	}
	@Test
	public void test64() {
		o.run(0, false, false, 10, 0, 0, -1, 0, 10, 10, 1, false);
	}
	@Test
	public void test65() {
		o.run(1, false, true, 10, 4, -1, -1, 1, 0, 0, 10, true);
	}
	@Test
	public void test66() {
		o.run(1, false, true, 0, -1, -1, 0, -1, 100, -1, -1, true);
	}
	@Test
	public void test67() {
		o.run(1, false, false, 10, 0, 1, -1, 1, 100, 10, 10, false);
	}

}