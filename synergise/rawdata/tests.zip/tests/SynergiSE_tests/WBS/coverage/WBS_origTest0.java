package coverage;
import org.junit.Test;
public class WBS_origTest0 {
	etg.WBS_orig o = new etg.WBS_orig();
	@Test
	public void test0() {
		o.launch(0, true, true, 0, true, true, 0, true, true);
	}
	@Test
	public void test1() {
		o.launch(0, true, true, 0, true, true, 0, true, false);
	}
	@Test
	public void test2() {
		o.launch(0, true, true, 0, true, true, 0, false, true);
	}
	@Test
	public void test3() {
		o.launch(0, true, true, 0, true, true, 0, false, false);
	}
	@Test
	public void test4() {
		o.launch(0, true, true, 0, true, true, 1, true, true);
	}
	@Test
	public void test5() {
		o.launch(0, true, true, 0, true, true, 1, true, false);
	}
	@Test
	public void test6() {
		o.launch(0, true, true, 0, true, true, 1, false, true);
	}
	@Test
	public void test7() {
		o.launch(0, true, true, 0, true, true, 1, false, false);
	}
	@Test
	public void test8() {
		o.launch(0, true, true, 0, true, true, 2, true, true);
	}
	@Test
	public void test9() {
		o.launch(0, true, true, 0, true, true, 2, true, false);
	}
	@Test
	public void test10() {
		o.launch(0, true, true, 0, true, true, 2, false, true);
	}
	@Test
	public void test11() {
		o.launch(0, true, true, 0, true, true, 2, false, false);
	}
	@Test
	public void test12() {
		o.launch(0, true, true, 0, true, true, 3, true, true);
	}
	@Test
	public void test13() {
		o.launch(0, true, true, 0, true, true, 3, true, false);
	}
	@Test
	public void test14() {
		o.launch(0, true, true, 0, true, true, 3, false, true);
	}
	@Test
	public void test15() {
		o.launch(0, true, true, 0, true, true, 3, false, false);
	}
	@Test
	public void test16() {
		o.launch(0, true, true, 0, true, true, 4, true, true);
	}
	@Test
	public void test17() {
		o.launch(0, true, true, 0, true, true, 4, true, false);
	}
	@Test
	public void test18() {
		o.launch(0, true, true, 0, true, true, 4, false, true);
	}
	@Test
	public void test19() {
		o.launch(0, true, true, 0, true, true, 4, false, false);
	}
	@Test
	public void test20() {
		o.launch(0, true, true, 0, true, true, -1, true, true);
	}
	@Test
	public void test21() {
		o.launch(0, true, true, 0, true, true, 100, true, false);
	}
	@Test
	public void test22() {
		o.launch(0, true, true, 0, true, true, -1, false, true);
	}
	@Test
	public void test23() {
		o.launch(0, true, true, 0, true, true, 5, false, false);
	}
	@Test
	public void test24() {
		o.launch(0, true, true, 0, true, false, 0, true, true);
	}
	@Test
	public void test25() {
		o.launch(0, true, true, 0, true, false, 0, true, false);
	}
	@Test
	public void test26() {
		o.launch(0, true, true, 0, true, false, 0, false, true);
	}
	@Test
	public void test27() {
		o.launch(0, true, true, 0, true, false, 0, false, false);
	}
	@Test
	public void test28() {
		o.launch(0, true, true, 0, true, false, 1, true, true);
	}
	@Test
	public void test29() {
		o.launch(0, true, true, 0, true, false, 1, true, false);
	}
	@Test
	public void test30() {
		o.launch(0, true, true, 0, true, false, 1, false, true);
	}
	@Test
	public void test31() {
		o.launch(0, true, true, 0, true, false, 1, false, false);
	}
	@Test
	public void test32() {
		o.launch(0, true, true, 0, true, false, 2, true, true);
	}
	@Test
	public void test33() {
		o.launch(0, true, true, 0, true, false, 2, true, false);
	}
	@Test
	public void test34() {
		o.launch(0, true, true, 0, true, false, 2, false, true);
	}
	@Test
	public void test35() {
		o.launch(0, true, true, 0, true, false, 2, false, false);
	}
	@Test
	public void test36() {
		o.launch(0, true, true, 0, true, false, 3, true, true);
	}
	@Test
	public void test37() {
		o.launch(0, true, true, 0, true, false, 3, true, false);
	}
	@Test
	public void test38() {
		o.launch(0, true, true, 0, true, false, 3, false, true);
	}
	@Test
	public void test39() {
		o.launch(0, true, true, 0, true, false, 3, false, false);
	}
	@Test
	public void test40() {
		o.launch(0, true, true, 0, true, false, 4, true, true);
	}
	@Test
	public void test41() {
		o.launch(0, true, true, 0, true, false, 4, true, false);
	}
	@Test
	public void test42() {
		o.launch(0, true, true, 0, true, false, 4, false, true);
	}
	@Test
	public void test43() {
		o.launch(0, true, true, 0, true, false, 4, false, false);
	}
	@Test
	public void test44() {
		o.launch(0, true, true, 0, true, false, 10, true, true);
	}
	@Test
	public void test45() {
		o.launch(0, true, true, 0, true, false, 10, true, false);
	}
	@Test
	public void test46() {
		o.launch(0, true, true, 0, true, false, 100, false, true);
	}
	@Test
	public void test47() {
		o.launch(0, true, true, 0, true, false, 10, false, false);
	}
	@Test
	public void test48() {
		o.launch(0, true, true, 0, false, true, 0, true, true);
	}
	@Test
	public void test49() {
		o.launch(0, true, true, 0, false, true, 0, true, false);
	}
	@Test
	public void test50() {
		o.launch(0, true, true, 0, false, true, 0, false, true);
	}
	@Test
	public void test51() {
		o.launch(0, true, true, 0, false, true, 0, false, false);
	}
	@Test
	public void test52() {
		o.launch(0, true, true, 0, false, true, 1, true, true);
	}
	@Test
	public void test53() {
		o.launch(0, true, true, 0, false, true, 1, true, false);
	}
	@Test
	public void test54() {
		o.launch(0, true, true, 0, false, true, 1, false, true);
	}
	@Test
	public void test55() {
		o.launch(0, true, true, 0, false, true, 1, false, false);
	}
	@Test
	public void test56() {
		o.launch(0, true, true, 0, false, true, 2, true, true);
	}
	@Test
	public void test57() {
		o.launch(0, true, true, 0, false, true, 2, true, false);
	}
	@Test
	public void test58() {
		o.launch(0, true, true, 0, false, true, 2, false, true);
	}
	@Test
	public void test59() {
		o.launch(0, true, true, 0, false, true, 2, false, false);
	}
	@Test
	public void test60() {
		o.launch(0, true, true, 0, false, true, 3, true, true);
	}
	@Test
	public void test61() {
		o.launch(0, true, true, 0, false, true, 3, true, false);
	}
	@Test
	public void test62() {
		o.launch(0, true, true, 0, false, true, 3, false, true);
	}
	@Test
	public void test63() {
		o.launch(0, true, true, 0, false, true, 3, false, false);
	}
	@Test
	public void test64() {
		o.launch(0, true, true, 0, false, true, 4, true, true);
	}
	@Test
	public void test65() {
		o.launch(0, true, true, 0, false, true, 4, true, false);
	}
	@Test
	public void test66() {
		o.launch(0, true, true, 0, false, true, 4, false, true);
	}
	@Test
	public void test67() {
		o.launch(0, true, true, 0, false, true, 4, false, false);
	}
	@Test
	public void test68() {
		o.launch(0, true, true, 0, false, true, -1, true, true);
	}
	@Test
	public void test69() {
		o.launch(0, true, true, 0, false, true, -1, true, false);
	}
	@Test
	public void test70() {
		o.launch(0, true, true, 0, false, true, -1, false, true);
	}
	@Test
	public void test71() {
		o.launch(0, true, true, 0, false, true, 5, false, false);
	}
	@Test
	public void test72() {
		o.launch(0, true, true, 0, false, false, 0, true, true);
	}
	@Test
	public void test73() {
		o.launch(0, true, true, 0, false, false, 0, true, false);
	}
	@Test
	public void test74() {
		o.launch(0, true, true, 0, false, false, 0, false, true);
	}
	@Test
	public void test75() {
		o.launch(0, true, true, 0, false, false, 0, false, false);
	}
	@Test
	public void test76() {
		o.launch(0, true, true, 0, false, false, 1, true, true);
	}
	@Test
	public void test77() {
		o.launch(0, true, true, 0, false, false, 1, true, false);
	}
	@Test
	public void test78() {
		o.launch(0, true, true, 0, false, false, 1, false, true);
	}
	@Test
	public void test79() {
		o.launch(0, true, true, 0, false, false, 1, false, false);
	}
	@Test
	public void test80() {
		o.launch(0, true, true, 0, false, false, 2, true, true);
	}
	@Test
	public void test81() {
		o.launch(0, true, true, 0, false, false, 2, true, false);
	}
	@Test
	public void test82() {
		o.launch(0, true, true, 0, false, false, 2, false, true);
	}
	@Test
	public void test83() {
		o.launch(0, true, true, 0, false, false, 2, false, false);
	}
	@Test
	public void test84() {
		o.launch(0, true, true, 0, false, false, 3, true, true);
	}
	@Test
	public void test85() {
		o.launch(0, true, true, 0, false, false, 3, true, false);
	}
	@Test
	public void test86() {
		o.launch(0, true, true, 0, false, false, 3, false, true);
	}
	@Test
	public void test87() {
		o.launch(0, true, true, 0, false, false, 3, false, false);
	}
	@Test
	public void test88() {
		o.launch(0, true, true, 0, false, false, 4, true, true);
	}
	@Test
	public void test89() {
		o.launch(0, true, true, 0, false, false, 4, true, false);
	}
	@Test
	public void test90() {
		o.launch(0, true, true, 0, false, false, 4, false, true);
	}
	@Test
	public void test91() {
		o.launch(0, true, true, 0, false, false, 4, false, false);
	}
	@Test
	public void test92() {
		o.launch(0, true, true, 0, false, false, 100, true, true);
	}
	@Test
	public void test93() {
		o.launch(0, true, true, 0, false, false, 100, true, false);
	}
	@Test
	public void test94() {
		o.launch(0, true, true, 0, false, false, 100, false, true);
	}
	@Test
	public void test95() {
		o.launch(0, true, true, 0, false, false, 100, false, false);
	}
	@Test
	public void test96() {
		o.launch(0, true, true, 1, true, true, 0, true, true);
	}
	@Test
	public void test97() {
		o.launch(0, true, true, 1, true, true, 0, true, false);
	}
	@Test
	public void test98() {
		o.launch(0, true, true, 1, true, true, 0, false, true);
	}
	@Test
	public void test99() {
		o.launch(0, true, true, 1, true, true, 0, false, false);
	}
	@Test
	public void test100() {
		o.launch(0, true, true, 1, true, true, 1, true, true);
	}
	@Test
	public void test101() {
		o.launch(0, true, true, 1, true, true, 1, true, false);
	}
	@Test
	public void test102() {
		o.launch(0, true, true, 1, true, true, 1, false, true);
	}
	@Test
	public void test103() {
		o.launch(0, true, true, 1, true, true, 1, false, false);
	}
	@Test
	public void test104() {
		o.launch(0, true, true, 1, true, true, 2, true, true);
	}
	@Test
	public void test105() {
		o.launch(0, true, true, 1, true, true, 2, true, false);
	}
	@Test
	public void test106() {
		o.launch(0, true, true, 1, true, true, 2, false, true);
	}
	@Test
	public void test107() {
		o.launch(0, true, true, 1, true, true, 2, false, false);
	}
	@Test
	public void test108() {
		o.launch(0, true, true, 1, true, true, 3, true, true);
	}
	@Test
	public void test109() {
		o.launch(0, true, true, 1, true, true, 3, true, false);
	}
	@Test
	public void test110() {
		o.launch(0, true, true, 1, true, true, 3, false, true);
	}
	@Test
	public void test111() {
		o.launch(0, true, true, 1, true, true, 3, false, false);
	}
	@Test
	public void test112() {
		o.launch(0, true, true, 1, true, true, 4, true, true);
	}
	@Test
	public void test113() {
		o.launch(0, true, true, 1, true, true, 4, true, false);
	}
	@Test
	public void test114() {
		o.launch(0, true, true, 1, true, true, 4, false, true);
	}
	@Test
	public void test115() {
		o.launch(0, true, true, 1, true, true, 4, false, false);
	}
	@Test
	public void test116() {
		o.launch(0, true, true, 1, true, true, -1, true, true);
	}
	@Test
	public void test117() {
		o.launch(0, true, true, 1, true, true, -1, true, false);
	}
	@Test
	public void test118() {
		o.launch(0, true, true, 1, true, true, -1, false, true);
	}
	@Test
	public void test119() {
		o.launch(0, true, true, 1, true, true, 10, false, false);
	}
	@Test
	public void test120() {
		o.launch(0, true, true, 1, true, false, 0, true, true);
	}
	@Test
	public void test121() {
		o.launch(0, true, true, 1, true, false, 0, true, false);
	}
	@Test
	public void test122() {
		o.launch(0, true, true, 1, true, false, 0, false, true);
	}
	@Test
	public void test123() {
		o.launch(0, true, true, 1, true, false, 0, false, false);
	}
	@Test
	public void test124() {
		o.launch(0, true, true, 1, true, false, 1, true, true);
	}
	@Test
	public void test125() {
		o.launch(0, true, true, 1, true, false, 1, true, false);
	}
	@Test
	public void test126() {
		o.launch(0, true, true, 1, true, false, 1, false, true);
	}
	@Test
	public void test127() {
		o.launch(0, true, true, 1, true, false, 1, false, false);
	}
	@Test
	public void test128() {
		o.launch(0, true, true, 1, true, false, 2, true, true);
	}
	@Test
	public void test129() {
		o.launch(0, true, true, 1, true, false, 2, true, false);
	}
	@Test
	public void test130() {
		o.launch(0, true, true, 1, true, false, 2, false, true);
	}
	@Test
	public void test131() {
		o.launch(0, true, true, 1, true, false, 2, false, false);
	}
	@Test
	public void test132() {
		o.launch(0, true, true, 1, true, false, 3, true, true);
	}
	@Test
	public void test133() {
		o.launch(0, true, true, 1, true, false, 3, true, false);
	}
	@Test
	public void test134() {
		o.launch(0, true, true, 1, true, false, 3, false, true);
	}
	@Test
	public void test135() {
		o.launch(0, true, true, 1, true, false, 3, false, false);
	}
	@Test
	public void test136() {
		o.launch(0, true, true, 1, true, false, 4, true, true);
	}
	@Test
	public void test137() {
		o.launch(0, true, true, 1, true, false, 4, true, false);
	}
	@Test
	public void test138() {
		o.launch(0, true, true, 1, true, false, 4, false, true);
	}
	@Test
	public void test139() {
		o.launch(0, true, true, 1, true, false, 4, false, false);
	}
	@Test
	public void test140() {
		o.launch(0, true, true, 1, true, false, 5, true, true);
	}
	@Test
	public void test141() {
		o.launch(0, true, true, 1, true, false, 10, true, false);
	}
	@Test
	public void test142() {
		o.launch(0, true, true, 1, true, false, 10, false, true);
	}
	@Test
	public void test143() {
		o.launch(0, true, true, 1, true, false, 100, false, false);
	}
	@Test
	public void test144() {
		o.launch(0, true, true, 1, false, true, 0, true, true);
	}
	@Test
	public void test145() {
		o.launch(0, true, true, 1, false, true, 0, true, false);
	}
	@Test
	public void test146() {
		o.launch(0, true, true, 1, false, true, 0, false, true);
	}
	@Test
	public void test147() {
		o.launch(0, true, true, 1, false, true, 0, false, false);
	}
	@Test
	public void test148() {
		o.launch(0, true, true, 1, false, true, 1, true, true);
	}
	@Test
	public void test149() {
		o.launch(0, true, true, 1, false, true, 1, true, false);
	}
	@Test
	public void test150() {
		o.launch(0, true, true, 1, false, true, 1, false, true);
	}
	@Test
	public void test151() {
		o.launch(0, true, true, 1, false, true, 1, false, false);
	}
	@Test
	public void test152() {
		o.launch(0, true, true, 1, false, true, 2, true, true);
	}
	@Test
	public void test153() {
		o.launch(0, true, true, 1, false, true, 2, true, false);
	}
	@Test
	public void test154() {
		o.launch(0, true, true, 1, false, true, 2, false, true);
	}
	@Test
	public void test155() {
		o.launch(0, true, true, 1, false, true, 2, false, false);
	}
	@Test
	public void test156() {
		o.launch(0, true, true, 1, false, true, 3, true, true);
	}
	@Test
	public void test157() {
		o.launch(0, true, true, 1, false, true, 3, true, false);
	}
	@Test
	public void test158() {
		o.launch(0, true, true, 1, false, true, 3, false, true);
	}
	@Test
	public void test159() {
		o.launch(0, true, true, 1, false, true, 3, false, false);
	}
	@Test
	public void test160() {
		o.launch(0, true, true, 1, false, true, 4, true, true);
	}
	@Test
	public void test161() {
		o.launch(0, true, true, 1, false, true, 4, true, false);
	}
	@Test
	public void test162() {
		o.launch(0, true, true, 1, false, true, 4, false, true);
	}
	@Test
	public void test163() {
		o.launch(0, true, true, 1, false, true, 4, false, false);
	}
	@Test
	public void test164() {
		o.launch(0, true, true, 1, false, true, 5, true, true);
	}
	@Test
	public void test165() {
		o.launch(0, true, true, 1, false, true, -1, true, false);
	}
	@Test
	public void test166() {
		o.launch(0, true, true, 1, false, true, 5, false, true);
	}
	@Test
	public void test167() {
		o.launch(0, true, true, 1, false, true, 100, false, false);
	}
	@Test
	public void test168() {
		o.launch(0, true, true, 1, false, false, 0, true, true);
	}
	@Test
	public void test169() {
		o.launch(0, true, true, 1, false, false, 0, true, false);
	}
	@Test
	public void test170() {
		o.launch(0, true, true, 1, false, false, 0, false, true);
	}
	@Test
	public void test171() {
		o.launch(0, true, true, 1, false, false, 0, false, false);
	}
	@Test
	public void test172() {
		o.launch(0, true, true, 1, false, false, 1, true, true);
	}
	@Test
	public void test173() {
		o.launch(0, true, true, 1, false, false, 1, true, false);
	}
	@Test
	public void test174() {
		o.launch(0, true, true, 1, false, false, 1, false, true);
	}
	@Test
	public void test175() {
		o.launch(0, true, true, 1, false, false, 1, false, false);
	}
	@Test
	public void test176() {
		o.launch(0, true, true, 1, false, false, 2, true, true);
	}
	@Test
	public void test177() {
		o.launch(0, true, true, 1, false, false, 2, true, false);
	}
	@Test
	public void test178() {
		o.launch(0, true, true, 1, false, false, 2, false, true);
	}
	@Test
	public void test179() {
		o.launch(0, true, true, 1, false, false, 2, false, false);
	}
	@Test
	public void test180() {
		o.launch(0, true, true, 1, false, false, 3, true, true);
	}
	@Test
	public void test181() {
		o.launch(0, true, true, 1, false, false, 3, true, false);
	}
	@Test
	public void test182() {
		o.launch(0, true, true, 1, false, false, 3, false, true);
	}
	@Test
	public void test183() {
		o.launch(0, true, true, 1, false, false, 3, false, false);
	}
	@Test
	public void test184() {
		o.launch(0, true, true, 1, false, false, 4, true, true);
	}
	@Test
	public void test185() {
		o.launch(0, true, true, 1, false, false, 4, true, false);
	}
	@Test
	public void test186() {
		o.launch(0, true, true, 1, false, false, 4, false, true);
	}
	@Test
	public void test187() {
		o.launch(0, true, true, 1, false, false, 4, false, false);
	}
	@Test
	public void test188() {
		o.launch(0, true, true, 1, false, false, 5, true, true);
	}
	@Test
	public void test189() {
		o.launch(0, true, true, 1, false, false, 5, true, false);
	}
	@Test
	public void test190() {
		o.launch(0, true, true, 1, false, false, 10, false, true);
	}
	@Test
	public void test191() {
		o.launch(0, true, true, 1, false, false, 10, false, false);
	}
	@Test
	public void test192() {
		o.launch(0, true, true, 2, true, true, 0, true, true);
	}
	@Test
	public void test193() {
		o.launch(0, true, true, 2, true, true, 0, true, false);
	}
	@Test
	public void test194() {
		o.launch(0, true, true, 2, true, true, 0, false, true);
	}
	@Test
	public void test195() {
		o.launch(0, true, true, 2, true, true, 0, false, false);
	}
	@Test
	public void test196() {
		o.launch(0, true, true, 2, true, true, 1, true, true);
	}
	@Test
	public void test197() {
		o.launch(0, true, true, 2, true, true, 1, true, false);
	}
	@Test
	public void test198() {
		o.launch(0, true, true, 2, true, true, 1, false, true);
	}
	@Test
	public void test199() {
		o.launch(0, true, true, 2, true, true, 1, false, false);
	}
	@Test
	public void test200() {
		o.launch(0, true, true, 2, true, true, 2, true, true);
	}
	@Test
	public void test201() {
		o.launch(0, true, true, 2, true, true, 2, true, false);
	}
	@Test
	public void test202() {
		o.launch(0, true, true, 2, true, true, 2, false, true);
	}
	@Test
	public void test203() {
		o.launch(0, true, true, 2, true, true, 2, false, false);
	}
	@Test
	public void test204() {
		o.launch(0, true, true, 2, true, true, 3, true, true);
	}
	@Test
	public void test205() {
		o.launch(0, true, true, 2, true, true, 3, true, false);
	}
	@Test
	public void test206() {
		o.launch(0, true, true, 2, true, true, 3, false, true);
	}
	@Test
	public void test207() {
		o.launch(0, true, true, 2, true, true, 3, false, false);
	}
	@Test
	public void test208() {
		o.launch(0, true, true, 2, true, true, 4, true, true);
	}
	@Test
	public void test209() {
		o.launch(0, true, true, 2, true, true, 4, true, false);
	}
	@Test
	public void test210() {
		o.launch(0, true, true, 2, true, true, 4, false, true);
	}
	@Test
	public void test211() {
		o.launch(0, true, true, 2, true, true, 4, false, false);
	}
	@Test
	public void test212() {
		o.launch(0, true, true, 2, true, true, 5, true, true);
	}
	@Test
	public void test213() {
		o.launch(0, true, true, 2, true, true, 5, true, false);
	}
	@Test
	public void test214() {
		o.launch(0, true, true, 2, true, true, 5, false, true);
	}
	@Test
	public void test215() {
		o.launch(0, true, true, 2, true, true, 5, false, false);
	}
	@Test
	public void test216() {
		o.launch(0, true, true, 2, true, false, 0, true, true);
	}
	@Test
	public void test217() {
		o.launch(0, true, true, 2, true, false, 0, true, false);
	}
	@Test
	public void test218() {
		o.launch(0, true, true, 2, true, false, 0, false, true);
	}
	@Test
	public void test219() {
		o.launch(0, true, true, 2, true, false, 0, false, false);
	}
	@Test
	public void test220() {
		o.launch(0, true, true, 2, true, false, 1, true, true);
	}
	@Test
	public void test221() {
		o.launch(0, true, true, 2, true, false, 1, true, false);
	}
	@Test
	public void test222() {
		o.launch(0, true, true, 2, true, false, 1, false, true);
	}
	@Test
	public void test223() {
		o.launch(0, true, true, 2, true, false, 1, false, false);
	}
	@Test
	public void test224() {
		o.launch(0, true, true, 2, true, false, 2, true, true);
	}
	@Test
	public void test225() {
		o.launch(0, true, true, 2, true, false, 2, true, false);
	}
	@Test
	public void test226() {
		o.launch(0, true, true, 2, true, false, 2, false, true);
	}
	@Test
	public void test227() {
		o.launch(0, true, true, 2, true, false, 2, false, false);
	}
	@Test
	public void test228() {
		o.launch(0, true, true, 2, true, false, 3, true, true);
	}
	@Test
	public void test229() {
		o.launch(0, true, true, 2, true, false, 3, true, false);
	}
	@Test
	public void test230() {
		o.launch(0, true, true, 2, true, false, 3, false, true);
	}
	@Test
	public void test231() {
		o.launch(0, true, true, 2, true, false, 3, false, false);
	}
	@Test
	public void test232() {
		o.launch(0, true, true, 2, true, false, 4, true, true);
	}
	@Test
	public void test233() {
		o.launch(0, true, true, 2, true, false, 4, true, false);
	}
	@Test
	public void test234() {
		o.launch(0, true, true, 2, true, false, 4, false, true);
	}
	@Test
	public void test235() {
		o.launch(0, true, true, 2, true, false, 4, false, false);
	}
	@Test
	public void test236() {
		o.launch(0, true, true, 2, true, false, 5, true, true);
	}
	@Test
	public void test237() {
		o.launch(0, true, true, 2, true, false, 5, true, false);
	}
	@Test
	public void test238() {
		o.launch(0, true, true, 2, true, false, 5, false, true);
	}
	@Test
	public void test239() {
		o.launch(0, true, true, 2, true, false, 5, false, false);
	}
	@Test
	public void test240() {
		o.launch(0, true, true, 2, false, true, 0, true, true);
	}
	@Test
	public void test241() {
		o.launch(0, true, true, 2, false, true, 0, true, false);
	}
	@Test
	public void test242() {
		o.launch(0, true, true, 2, false, true, 0, false, true);
	}
	@Test
	public void test243() {
		o.launch(0, true, true, 2, false, true, 0, false, false);
	}
	@Test
	public void test244() {
		o.launch(0, true, true, 2, false, true, 1, true, true);
	}
	@Test
	public void test245() {
		o.launch(0, true, true, 2, false, true, 1, true, false);
	}
	@Test
	public void test246() {
		o.launch(0, true, true, 2, false, true, 1, false, true);
	}
	@Test
	public void test247() {
		o.launch(0, true, true, 2, false, true, 1, false, false);
	}
	@Test
	public void test248() {
		o.launch(0, true, true, 2, false, true, 2, true, true);
	}
	@Test
	public void test249() {
		o.launch(0, true, true, 2, false, true, 2, true, false);
	}
	@Test
	public void test250() {
		o.launch(0, true, true, 2, false, true, 2, false, true);
	}
	@Test
	public void test251() {
		o.launch(0, true, true, 2, false, true, 2, false, false);
	}
	@Test
	public void test252() {
		o.launch(0, true, true, 2, false, true, 3, true, true);
	}
	@Test
	public void test253() {
		o.launch(0, true, true, 2, false, true, 3, true, false);
	}
	@Test
	public void test254() {
		o.launch(0, true, true, 2, false, true, 3, false, true);
	}
	@Test
	public void test255() {
		o.launch(0, true, true, 2, false, true, 3, false, false);
	}
	@Test
	public void test256() {
		o.launch(0, true, true, 2, false, true, 4, true, true);
	}
	@Test
	public void test257() {
		o.launch(0, true, true, 2, false, true, 4, true, false);
	}
	@Test
	public void test258() {
		o.launch(0, true, true, 2, false, true, 4, false, true);
	}
	@Test
	public void test259() {
		o.launch(0, true, true, 2, false, true, 4, false, false);
	}
	@Test
	public void test260() {
		o.launch(0, true, true, 2, false, true, 5, true, true);
	}
	@Test
	public void test261() {
		o.launch(0, true, true, 2, false, true, 5, true, false);
	}
	@Test
	public void test262() {
		o.launch(0, true, true, 2, false, true, 5, false, true);
	}
	@Test
	public void test263() {
		o.launch(0, true, true, 2, false, true, 5, false, false);
	}
	@Test
	public void test264() {
		o.launch(0, true, true, 2, false, false, 0, true, true);
	}
	@Test
	public void test265() {
		o.launch(0, true, true, 2, false, false, 0, true, false);
	}
	@Test
	public void test266() {
		o.launch(0, true, true, 2, false, false, 0, false, true);
	}
	@Test
	public void test267() {
		o.launch(0, true, true, 2, false, false, 0, false, false);
	}
	@Test
	public void test268() {
		o.launch(0, true, true, 2, false, false, 1, true, true);
	}
	@Test
	public void test269() {
		o.launch(0, true, true, 2, false, false, 1, true, false);
	}
	@Test
	public void test270() {
		o.launch(0, true, true, 2, false, false, 1, false, true);
	}
	@Test
	public void test271() {
		o.launch(0, true, true, 2, false, false, 1, false, false);
	}
	@Test
	public void test272() {
		o.launch(0, true, true, 2, false, false, 2, true, true);
	}
	@Test
	public void test273() {
		o.launch(0, true, true, 2, false, false, 2, true, false);
	}
	@Test
	public void test274() {
		o.launch(0, true, true, 2, false, false, 2, false, true);
	}
	@Test
	public void test275() {
		o.launch(0, true, true, 2, false, false, 2, false, false);
	}
	@Test
	public void test276() {
		o.launch(0, true, true, 2, false, false, 3, true, true);
	}
	@Test
	public void test277() {
		o.launch(0, true, true, 2, false, false, 3, true, false);
	}
	@Test
	public void test278() {
		o.launch(0, true, true, 2, false, false, 3, false, true);
	}
	@Test
	public void test279() {
		o.launch(0, true, true, 2, false, false, 3, false, false);
	}
	@Test
	public void test280() {
		o.launch(0, true, true, 2, false, false, 4, true, true);
	}
	@Test
	public void test281() {
		o.launch(0, true, true, 2, false, false, 4, true, false);
	}
	@Test
	public void test282() {
		o.launch(0, true, true, 2, false, false, 4, false, true);
	}
	@Test
	public void test283() {
		o.launch(0, true, true, 2, false, false, 4, false, false);
	}
	@Test
	public void test284() {
		o.launch(0, true, true, 2, false, false, 5, true, true);
	}
	@Test
	public void test285() {
		o.launch(0, true, true, 2, false, false, 5, true, false);
	}
	@Test
	public void test286() {
		o.launch(0, true, true, 2, false, false, 5, false, true);
	}
	@Test
	public void test287() {
		o.launch(0, true, true, 2, false, false, 5, false, false);
	}
	@Test
	public void test288() {
		o.launch(0, true, true, 3, true, true, 0, true, true);
	}
	@Test
	public void test289() {
		o.launch(0, true, true, 3, true, true, 0, true, false);
	}
	@Test
	public void test290() {
		o.launch(0, true, true, 3, true, true, 0, false, true);
	}
	@Test
	public void test291() {
		o.launch(0, true, true, 3, true, true, 0, false, false);
	}
	@Test
	public void test292() {
		o.launch(0, true, true, 3, true, true, 1, true, true);
	}
	@Test
	public void test293() {
		o.launch(0, true, true, 3, true, true, 1, true, false);
	}
	@Test
	public void test294() {
		o.launch(0, true, true, 3, true, true, 1, false, true);
	}
	@Test
	public void test295() {
		o.launch(0, true, true, 3, true, true, 1, false, false);
	}
	@Test
	public void test296() {
		o.launch(0, true, true, 3, true, true, 2, true, true);
	}
	@Test
	public void test297() {
		o.launch(0, true, true, 3, true, true, 2, true, false);
	}
	@Test
	public void test298() {
		o.launch(0, true, true, 3, true, true, 2, false, true);
	}
	@Test
	public void test299() {
		o.launch(0, true, true, 3, true, true, 2, false, false);
	}
	@Test
	public void test300() {
		o.launch(0, true, true, 3, true, true, 3, true, true);
	}
	@Test
	public void test301() {
		o.launch(0, true, true, 3, true, true, 3, true, false);
	}
	@Test
	public void test302() {
		o.launch(0, true, true, 3, true, true, 3, false, true);
	}
	@Test
	public void test303() {
		o.launch(0, true, true, 3, true, true, 3, false, false);
	}
	@Test
	public void test304() {
		o.launch(0, true, true, 3, true, true, 4, true, true);
	}
	@Test
	public void test305() {
		o.launch(0, true, true, 3, true, true, 4, true, false);
	}
	@Test
	public void test306() {
		o.launch(0, true, true, 3, true, true, 4, false, true);
	}
	@Test
	public void test307() {
		o.launch(0, true, true, 3, true, true, 4, false, false);
	}
	@Test
	public void test308() {
		o.launch(0, true, true, 3, true, true, 5, true, true);
	}
	@Test
	public void test309() {
		o.launch(0, true, true, 3, true, true, 5, true, false);
	}
	@Test
	public void test310() {
		o.launch(0, true, true, 3, true, true, 5, false, true);
	}
	@Test
	public void test311() {
		o.launch(0, true, true, 3, true, true, 5, false, false);
	}
	@Test
	public void test312() {
		o.launch(0, true, true, 3, true, false, 0, true, true);
	}
	@Test
	public void test313() {
		o.launch(0, true, true, 3, true, false, 0, true, false);
	}
	@Test
	public void test314() {
		o.launch(0, true, true, 3, true, false, 0, false, true);
	}
	@Test
	public void test315() {
		o.launch(0, true, true, 3, true, false, 0, false, false);
	}
	@Test
	public void test316() {
		o.launch(0, true, true, 3, true, false, 1, true, true);
	}
	@Test
	public void test317() {
		o.launch(0, true, true, 3, true, false, 1, true, false);
	}
	@Test
	public void test318() {
		o.launch(0, true, true, 3, true, false, 1, false, true);
	}
	@Test
	public void test319() {
		o.launch(0, true, true, 3, true, false, 1, false, false);
	}
	@Test
	public void test320() {
		o.launch(0, true, true, 3, true, false, 2, true, true);
	}
	@Test
	public void test321() {
		o.launch(0, true, true, 3, true, false, 2, true, false);
	}
	@Test
	public void test322() {
		o.launch(0, true, true, 3, true, false, 2, false, true);
	}
	@Test
	public void test323() {
		o.launch(0, true, true, 3, true, false, 2, false, false);
	}
	@Test
	public void test324() {
		o.launch(0, true, true, 3, true, false, 3, true, true);
	}
	@Test
	public void test325() {
		o.launch(0, true, true, 3, true, false, 3, true, false);
	}
	@Test
	public void test326() {
		o.launch(0, true, true, 3, true, false, 3, false, true);
	}
	@Test
	public void test327() {
		o.launch(0, true, true, 3, true, false, 3, false, false);
	}
	@Test
	public void test328() {
		o.launch(0, true, true, 3, true, false, 4, true, true);
	}
	@Test
	public void test329() {
		o.launch(0, true, true, 3, true, false, 4, true, false);
	}
	@Test
	public void test330() {
		o.launch(0, true, true, 3, true, false, 4, false, true);
	}
	@Test
	public void test331() {
		o.launch(0, true, true, 3, true, false, 4, false, false);
	}
	@Test
	public void test332() {
		o.launch(0, true, true, 3, true, false, 5, true, true);
	}
	@Test
	public void test333() {
		o.launch(0, true, true, 3, true, false, 5, true, false);
	}
	@Test
	public void test334() {
		o.launch(0, true, true, 3, true, false, 5, false, true);
	}
	@Test
	public void test335() {
		o.launch(0, true, true, 3, true, false, 5, false, false);
	}
	@Test
	public void test336() {
		o.launch(0, true, true, 3, false, true, 0, true, true);
	}
	@Test
	public void test337() {
		o.launch(0, true, true, 3, false, true, 0, true, false);
	}
	@Test
	public void test338() {
		o.launch(0, true, true, 3, false, true, 0, false, true);
	}
	@Test
	public void test339() {
		o.launch(0, true, true, 3, false, true, 0, false, false);
	}
	@Test
	public void test340() {
		o.launch(0, true, true, 3, false, true, 1, true, true);
	}
	@Test
	public void test341() {
		o.launch(0, true, true, 3, false, true, 1, true, false);
	}
	@Test
	public void test342() {
		o.launch(0, true, true, 3, false, true, 1, false, true);
	}
	@Test
	public void test343() {
		o.launch(0, true, true, 3, false, true, 1, false, false);
	}
	@Test
	public void test344() {
		o.launch(0, true, true, 3, false, true, 2, true, true);
	}
	@Test
	public void test345() {
		o.launch(0, true, true, 3, false, true, 2, true, false);
	}
	@Test
	public void test346() {
		o.launch(0, true, true, 3, false, true, 2, false, true);
	}
	@Test
	public void test347() {
		o.launch(0, true, true, 3, false, true, 2, false, false);
	}
	@Test
	public void test348() {
		o.launch(0, true, true, 3, false, true, 3, true, true);
	}
	@Test
	public void test349() {
		o.launch(0, true, true, 3, false, true, 3, true, false);
	}
	@Test
	public void test350() {
		o.launch(0, true, true, 3, false, true, 3, false, true);
	}
	@Test
	public void test351() {
		o.launch(0, true, true, 3, false, true, 3, false, false);
	}
	@Test
	public void test352() {
		o.launch(0, true, true, 3, false, true, 4, true, true);
	}
	@Test
	public void test353() {
		o.launch(0, true, true, 3, false, true, 4, true, false);
	}
	@Test
	public void test354() {
		o.launch(0, true, true, 3, false, true, 4, false, true);
	}
	@Test
	public void test355() {
		o.launch(0, true, true, 3, false, true, 4, false, false);
	}
	@Test
	public void test356() {
		o.launch(0, true, true, 3, false, true, 5, true, true);
	}
	@Test
	public void test357() {
		o.launch(0, true, true, 3, false, true, 5, true, false);
	}
	@Test
	public void test358() {
		o.launch(0, true, true, 3, false, true, 5, false, true);
	}
	@Test
	public void test359() {
		o.launch(0, true, true, 3, false, true, 5, false, false);
	}
	@Test
	public void test360() {
		o.launch(0, true, true, 3, false, false, 0, true, true);
	}
	@Test
	public void test361() {
		o.launch(0, true, true, 3, false, false, 0, true, false);
	}
	@Test
	public void test362() {
		o.launch(0, true, true, 3, false, false, 0, false, true);
	}
	@Test
	public void test363() {
		o.launch(0, true, true, 3, false, false, 0, false, false);
	}
	@Test
	public void test364() {
		o.launch(0, true, true, 3, false, false, 1, true, true);
	}
	@Test
	public void test365() {
		o.launch(0, true, true, 3, false, false, 1, true, false);
	}
	@Test
	public void test366() {
		o.launch(0, true, true, 3, false, false, 1, false, true);
	}
	@Test
	public void test367() {
		o.launch(0, true, true, 3, false, false, 1, false, false);
	}
	@Test
	public void test368() {
		o.launch(0, true, true, 3, false, false, 2, true, true);
	}
	@Test
	public void test369() {
		o.launch(0, true, true, 3, false, false, 2, true, false);
	}
	@Test
	public void test370() {
		o.launch(0, true, true, 3, false, false, 2, false, true);
	}
	@Test
	public void test371() {
		o.launch(0, true, true, 3, false, false, 2, false, false);
	}
	@Test
	public void test372() {
		o.launch(0, true, true, 3, false, false, 3, true, true);
	}
	@Test
	public void test373() {
		o.launch(0, true, true, 3, false, false, 3, true, false);
	}
	@Test
	public void test374() {
		o.launch(0, true, true, 3, false, false, 3, false, true);
	}
	@Test
	public void test375() {
		o.launch(0, true, true, 3, false, false, 3, false, false);
	}
	@Test
	public void test376() {
		o.launch(0, true, true, 3, false, false, 4, true, true);
	}
	@Test
	public void test377() {
		o.launch(0, true, true, 3, false, false, 4, true, false);
	}
	@Test
	public void test378() {
		o.launch(0, true, true, 3, false, false, 4, false, true);
	}
	@Test
	public void test379() {
		o.launch(0, true, true, 3, false, false, 4, false, false);
	}
	@Test
	public void test380() {
		o.launch(0, true, true, 3, false, false, 5, true, true);
	}
	@Test
	public void test381() {
		o.launch(0, true, true, 3, false, false, 5, true, false);
	}
	@Test
	public void test382() {
		o.launch(0, true, true, 3, false, false, 5, false, true);
	}
	@Test
	public void test383() {
		o.launch(0, true, true, 3, false, false, 5, false, false);
	}
	@Test
	public void test384() {
		o.launch(0, true, true, 4, true, true, 0, true, true);
	}
	@Test
	public void test385() {
		o.launch(0, true, true, 4, true, true, 0, true, false);
	}
	@Test
	public void test386() {
		o.launch(0, true, true, 4, true, true, 0, false, true);
	}
	@Test
	public void test387() {
		o.launch(0, true, true, 4, true, true, 0, false, false);
	}
	@Test
	public void test388() {
		o.launch(0, true, true, 4, true, true, 1, true, true);
	}
	@Test
	public void test389() {
		o.launch(0, true, true, 4, true, true, 1, true, false);
	}
	@Test
	public void test390() {
		o.launch(0, true, true, 4, true, true, 1, false, true);
	}
	@Test
	public void test391() {
		o.launch(0, true, true, 4, true, true, 1, false, false);
	}
	@Test
	public void test392() {
		o.launch(0, true, true, 4, true, true, 2, true, true);
	}
	@Test
	public void test393() {
		o.launch(0, true, true, 4, true, true, 2, true, false);
	}
	@Test
	public void test394() {
		o.launch(0, true, true, 4, true, true, 2, false, true);
	}
	@Test
	public void test395() {
		o.launch(0, true, true, 4, true, true, 2, false, false);
	}
	@Test
	public void test396() {
		o.launch(0, true, true, 4, true, true, 3, true, true);
	}
	@Test
	public void test397() {
		o.launch(0, true, true, 4, true, true, 3, true, false);
	}
	@Test
	public void test398() {
		o.launch(0, true, true, 4, true, true, 3, false, true);
	}
	@Test
	public void test399() {
		o.launch(0, true, true, 4, true, true, 3, false, false);
	}
	@Test
	public void test400() {
		o.launch(0, true, true, 4, true, true, 4, true, true);
	}
	@Test
	public void test401() {
		o.launch(0, true, true, 4, true, true, 4, true, false);
	}
	@Test
	public void test402() {
		o.launch(0, true, true, 4, true, true, 4, false, true);
	}
	@Test
	public void test403() {
		o.launch(0, true, true, 4, true, true, 4, false, false);
	}
	@Test
	public void test404() {
		o.launch(0, true, true, 4, true, true, 5, true, true);
	}
	@Test
	public void test405() {
		o.launch(0, true, true, 4, true, true, 5, true, false);
	}
	@Test
	public void test406() {
		o.launch(0, true, true, 4, true, true, 100, false, true);
	}
	@Test
	public void test407() {
		o.launch(0, true, true, 4, true, true, 5, false, false);
	}
	@Test
	public void test408() {
		o.launch(0, true, true, 4, true, false, 0, true, true);
	}
	@Test
	public void test409() {
		o.launch(0, true, true, 4, true, false, 0, true, false);
	}
	@Test
	public void test410() {
		o.launch(0, true, true, 4, true, false, 0, false, true);
	}
	@Test
	public void test411() {
		o.launch(0, true, true, 4, true, false, 0, false, false);
	}
	@Test
	public void test412() {
		o.launch(0, true, true, 4, true, false, 1, true, true);
	}
	@Test
	public void test413() {
		o.launch(0, true, true, 4, true, false, 1, true, false);
	}
	@Test
	public void test414() {
		o.launch(0, true, true, 4, true, false, 1, false, true);
	}
	@Test
	public void test415() {
		o.launch(0, true, true, 4, true, false, 1, false, false);
	}
	@Test
	public void test416() {
		o.launch(0, true, true, 4, true, false, 2, true, true);
	}
	@Test
	public void test417() {
		o.launch(0, true, true, 4, true, false, 2, true, false);
	}
	@Test
	public void test418() {
		o.launch(0, true, true, 4, true, false, 2, false, true);
	}
	@Test
	public void test419() {
		o.launch(0, true, true, 4, true, false, 2, false, false);
	}
	@Test
	public void test420() {
		o.launch(0, true, true, 4, true, false, 3, true, true);
	}
	@Test
	public void test421() {
		o.launch(0, true, true, 4, true, false, 3, true, false);
	}
	@Test
	public void test422() {
		o.launch(0, true, true, 4, true, false, 3, false, true);
	}
	@Test
	public void test423() {
		o.launch(0, true, true, 4, true, false, 3, false, false);
	}
	@Test
	public void test424() {
		o.launch(0, true, true, 4, true, false, 4, true, true);
	}
	@Test
	public void test425() {
		o.launch(0, true, true, 4, true, false, 4, true, false);
	}
	@Test
	public void test426() {
		o.launch(0, true, true, 4, true, false, 4, false, true);
	}
	@Test
	public void test427() {
		o.launch(0, true, true, 4, true, false, 4, false, false);
	}
	@Test
	public void test428() {
		o.launch(0, true, true, 4, true, false, 10, true, true);
	}
	@Test
	public void test429() {
		o.launch(0, true, true, 4, true, false, 5, true, false);
	}
	@Test
	public void test430() {
		o.launch(0, true, true, 4, true, false, 10, false, true);
	}
	@Test
	public void test431() {
		o.launch(0, true, true, 4, true, false, 5, false, false);
	}
	@Test
	public void test432() {
		o.launch(0, true, true, 4, false, true, 0, true, true);
	}
	@Test
	public void test433() {
		o.launch(0, true, true, 4, false, true, 0, true, false);
	}
	@Test
	public void test434() {
		o.launch(0, true, true, 4, false, true, 0, false, true);
	}
	@Test
	public void test435() {
		o.launch(0, true, true, 4, false, true, 0, false, false);
	}
	@Test
	public void test436() {
		o.launch(0, true, true, 4, false, true, 1, true, true);
	}
	@Test
	public void test437() {
		o.launch(0, true, true, 4, false, true, 1, true, false);
	}
	@Test
	public void test438() {
		o.launch(0, true, true, 4, false, true, 1, false, true);
	}
	@Test
	public void test439() {
		o.launch(0, true, true, 4, false, true, 1, false, false);
	}
	@Test
	public void test440() {
		o.launch(0, true, true, 4, false, true, 2, true, true);
	}
	@Test
	public void test441() {
		o.launch(0, true, true, 4, false, true, 2, true, false);
	}
	@Test
	public void test442() {
		o.launch(0, true, true, 4, false, true, 2, false, true);
	}
	@Test
	public void test443() {
		o.launch(0, true, true, 4, false, true, 2, false, false);
	}
	@Test
	public void test444() {
		o.launch(0, true, true, 4, false, true, 3, true, true);
	}
	@Test
	public void test445() {
		o.launch(0, true, true, 4, false, true, 3, true, false);
	}
	@Test
	public void test446() {
		o.launch(0, true, true, 4, false, true, 3, false, true);
	}
	@Test
	public void test447() {
		o.launch(0, true, true, 4, false, true, 3, false, false);
	}
	@Test
	public void test448() {
		o.launch(0, true, true, 4, false, true, 4, true, true);
	}
	@Test
	public void test449() {
		o.launch(0, true, true, 4, false, true, 4, true, false);
	}
	@Test
	public void test450() {
		o.launch(0, true, true, 4, false, true, 4, false, true);
	}
	@Test
	public void test451() {
		o.launch(0, true, true, 4, false, true, 4, false, false);
	}
	@Test
	public void test452() {
		o.launch(0, true, true, 4, false, true, 100, true, true);
	}
	@Test
	public void test453() {
		o.launch(0, true, true, 4, false, true, 10, true, false);
	}
	@Test
	public void test454() {
		o.launch(0, true, true, 4, false, true, -1, false, true);
	}
	@Test
	public void test455() {
		o.launch(0, true, true, 4, false, true, 100, false, false);
	}
	@Test
	public void test456() {
		o.launch(0, true, true, 4, false, false, 0, true, true);
	}
	@Test
	public void test457() {
		o.launch(0, true, true, 4, false, false, 0, true, false);
	}
	@Test
	public void test458() {
		o.launch(0, true, true, 4, false, false, 0, false, true);
	}
	@Test
	public void test459() {
		o.launch(0, true, true, 4, false, false, 0, false, false);
	}
	@Test
	public void test460() {
		o.launch(0, true, true, 4, false, false, 1, true, true);
	}
	@Test
	public void test461() {
		o.launch(0, true, true, 4, false, false, 1, true, false);
	}
	@Test
	public void test462() {
		o.launch(0, true, true, 4, false, false, 1, false, true);
	}
	@Test
	public void test463() {
		o.launch(0, true, true, 4, false, false, 1, false, false);
	}
	@Test
	public void test464() {
		o.launch(0, true, true, 4, false, false, 2, true, true);
	}
	@Test
	public void test465() {
		o.launch(0, true, true, 4, false, false, 2, true, false);
	}
	@Test
	public void test466() {
		o.launch(0, true, true, 4, false, false, 2, false, true);
	}
	@Test
	public void test467() {
		o.launch(0, true, true, 4, false, false, 2, false, false);
	}
	@Test
	public void test468() {
		o.launch(0, true, true, 4, false, false, 3, true, true);
	}
	@Test
	public void test469() {
		o.launch(0, true, true, 4, false, false, 3, true, false);
	}
	@Test
	public void test470() {
		o.launch(0, true, true, 4, false, false, 3, false, true);
	}
	@Test
	public void test471() {
		o.launch(0, true, true, 4, false, false, 3, false, false);
	}
	@Test
	public void test472() {
		o.launch(0, true, true, 4, false, false, 4, true, true);
	}
	@Test
	public void test473() {
		o.launch(0, true, true, 4, false, false, 4, true, false);
	}
	@Test
	public void test474() {
		o.launch(0, true, true, 4, false, false, 4, false, true);
	}
	@Test
	public void test475() {
		o.launch(0, true, true, 4, false, false, 4, false, false);
	}
	@Test
	public void test476() {
		o.launch(0, true, true, 4, false, false, 100, true, true);
	}
	@Test
	public void test477() {
		o.launch(0, true, true, 4, false, false, -1, true, false);
	}
	@Test
	public void test478() {
		o.launch(0, true, true, 4, false, false, 5, false, true);
	}
	@Test
	public void test479() {
		o.launch(0, true, true, 4, false, false, 5, false, false);
	}
	@Test
	public void test480() {
		o.launch(0, true, true, -1, true, true, 0, true, true);
	}
	@Test
	public void test481() {
		o.launch(0, true, true, 10, true, true, 0, true, false);
	}
	@Test
	public void test482() {
		o.launch(0, true, true, 10, true, true, 0, false, true);
	}
	@Test
	public void test483() {
		o.launch(0, true, true, -1, true, true, 0, false, false);
	}
	@Test
	public void test484() {
		o.launch(0, true, true, 10, true, true, 1, true, true);
	}
	@Test
	public void test485() {
		o.launch(0, true, true, 5, true, true, 1, true, false);
	}
	@Test
	public void test486() {
		o.launch(0, true, true, 5, true, true, 1, false, true);
	}
	@Test
	public void test487() {
		o.launch(0, true, true, 10, true, true, 1, false, false);
	}
	@Test
	public void test488() {
		o.launch(0, true, true, 5, true, true, 2, true, true);
	}
	@Test
	public void test489() {
		o.launch(0, true, true, 5, true, true, 2, true, false);
	}
	@Test
	public void test490() {
		o.launch(0, true, true, 5, true, true, 2, false, true);
	}
	@Test
	public void test491() {
		o.launch(0, true, true, 5, true, true, 2, false, false);
	}
	@Test
	public void test492() {
		o.launch(0, true, true, 5, true, true, 3, true, true);
	}
	@Test
	public void test493() {
		o.launch(0, true, true, 5, true, true, 3, true, false);
	}
	@Test
	public void test494() {
		o.launch(0, true, true, 5, true, true, 3, false, true);
	}
	@Test
	public void test495() {
		o.launch(0, true, true, 5, true, true, 3, false, false);
	}
	@Test
	public void test496() {
		o.launch(0, true, true, -1, true, true, 4, true, true);
	}
	@Test
	public void test497() {
		o.launch(0, true, true, 5, true, true, 4, true, false);
	}
	@Test
	public void test498() {
		o.launch(0, true, true, 100, true, true, 4, false, true);
	}
	@Test
	public void test499() {
		o.launch(0, true, true, 10, true, true, 4, false, false);
	}
	@Test
	public void test500() {
		o.launch(0, true, true, 10, true, true, 10, true, true);
	}
	@Test
	public void test501() {
		o.launch(0, true, true, 100, true, true, 100, true, false);
	}
	@Test
	public void test502() {
		o.launch(0, true, true, 10, true, true, 10, false, true);
	}
	@Test
	public void test503() {
		o.launch(0, true, true, 100, true, true, -1, false, false);
	}
	@Test
	public void test504() {
		o.launch(0, true, true, -1, true, false, 0, true, true);
	}
	@Test
	public void test505() {
		o.launch(0, true, true, -1, true, false, 0, true, false);
	}
	@Test
	public void test506() {
		o.launch(0, true, true, -1, true, false, 0, false, true);
	}
	@Test
	public void test507() {
		o.launch(0, true, true, 10, true, false, 0, false, false);
	}
	@Test
	public void test508() {
		o.launch(0, true, true, 5, true, false, 1, true, true);
	}
	@Test
	public void test509() {
		o.launch(0, true, true, 100, true, false, 1, true, false);
	}
	@Test
	public void test510() {
		o.launch(0, true, true, -1, true, false, 1, false, true);
	}
	@Test
	public void test511() {
		o.launch(0, true, true, -1, true, false, 1, false, false);
	}
	@Test
	public void test512() {
		o.launch(0, true, true, 5, true, false, 2, true, true);
	}
	@Test
	public void test513() {
		o.launch(0, true, true, 5, true, false, 2, true, false);
	}
	@Test
	public void test514() {
		o.launch(0, true, true, 5, true, false, 2, false, true);
	}
	@Test
	public void test515() {
		o.launch(0, true, true, 5, true, false, 2, false, false);
	}
	@Test
	public void test516() {
		o.launch(0, true, true, 5, true, false, 3, true, true);
	}
	@Test
	public void test517() {
		o.launch(0, true, true, 5, true, false, 3, true, false);
	}
	@Test
	public void test518() {
		o.launch(0, true, true, 5, true, false, 3, false, true);
	}
	@Test
	public void test519() {
		o.launch(0, true, true, 5, true, false, 3, false, false);
	}
	@Test
	public void test520() {
		o.launch(0, true, true, 5, true, false, 4, true, true);
	}
	@Test
	public void test521() {
		o.launch(0, true, true, -1, true, false, 4, true, false);
	}
	@Test
	public void test522() {
		o.launch(0, true, true, 5, true, false, 4, false, true);
	}
	@Test
	public void test523() {
		o.launch(0, true, true, -1, true, false, 4, false, false);
	}
	@Test
	public void test524() {
		o.launch(0, true, true, 10, true, false, 100, true, true);
	}
	@Test
	public void test525() {
		o.launch(0, true, true, 10, true, false, 100, true, false);
	}
	@Test
	public void test526() {
		o.launch(0, true, true, -1, true, false, -1, false, true);
	}
	@Test
	public void test527() {
		o.launch(0, true, true, 10, true, false, 100, false, false);
	}
	@Test
	public void test528() {
		o.launch(0, true, true, 100, false, true, 0, true, true);
	}
	@Test
	public void test529() {
		o.launch(0, true, true, 100, false, true, 0, true, false);
	}
	@Test
	public void test530() {
		o.launch(0, true, true, 100, false, true, 0, false, true);
	}
	@Test
	public void test531() {
		o.launch(0, true, true, 100, false, true, 0, false, false);
	}
	@Test
	public void test532() {
		o.launch(0, true, true, 10, false, true, 1, true, true);
	}
	@Test
	public void test533() {
		o.launch(0, true, true, 100, false, true, 1, true, false);
	}
	@Test
	public void test534() {
		o.launch(0, true, true, 100, false, true, 1, false, true);
	}
	@Test
	public void test535() {
		o.launch(0, true, true, 100, false, true, 1, false, false);
	}
	@Test
	public void test536() {
		o.launch(0, true, true, 5, false, true, 2, true, true);
	}
	@Test
	public void test537() {
		o.launch(0, true, true, 5, false, true, 2, true, false);
	}
	@Test
	public void test538() {
		o.launch(0, true, true, 5, false, true, 2, false, true);
	}
	@Test
	public void test539() {
		o.launch(0, true, true, 5, false, true, 2, false, false);
	}
	@Test
	public void test540() {
		o.launch(0, true, true, 5, false, true, 3, true, true);
	}
	@Test
	public void test541() {
		o.launch(0, true, true, 5, false, true, 3, true, false);
	}
	@Test
	public void test542() {
		o.launch(0, true, true, 5, false, true, 3, false, true);
	}
	@Test
	public void test543() {
		o.launch(0, true, true, 5, false, true, 3, false, false);
	}
	@Test
	public void test544() {
		o.launch(0, true, true, 10, false, true, 4, true, true);
	}
	@Test
	public void test545() {
		o.launch(0, true, true, 5, false, true, 4, true, false);
	}
	@Test
	public void test546() {
		o.launch(0, true, true, 100, false, true, 4, false, true);
	}
	@Test
	public void test547() {
		o.launch(0, true, true, -1, false, true, 4, false, false);
	}
	@Test
	public void test548() {
		o.launch(0, true, true, -1, false, true, 10, true, true);
	}
	@Test
	public void test549() {
		o.launch(0, true, true, -1, false, true, 10, true, false);
	}
	@Test
	public void test550() {
		o.launch(0, true, true, 100, false, true, 100, false, true);
	}
	@Test
	public void test551() {
		o.launch(0, true, true, 100, false, true, 100, false, false);
	}
	@Test
	public void test552() {
		o.launch(0, true, true, 10, false, false, 0, true, true);
	}
	@Test
	public void test553() {
		o.launch(0, true, true, -1, false, false, 0, true, false);
	}
	@Test
	public void test554() {
		o.launch(0, true, true, -1, false, false, 0, false, true);
	}
	@Test
	public void test555() {
		o.launch(0, true, true, -1, false, false, 0, false, false);
	}
	@Test
	public void test556() {
		o.launch(0, true, true, -1, false, false, 1, true, true);
	}
	@Test
	public void test557() {
		o.launch(0, true, true, 100, false, false, 1, true, false);
	}
	@Test
	public void test558() {
		o.launch(0, true, true, 100, false, false, 1, false, true);
	}
	@Test
	public void test559() {
		o.launch(0, true, true, 100, false, false, 1, false, false);
	}
	@Test
	public void test560() {
		o.launch(0, true, true, 5, false, false, 2, true, true);
	}
	@Test
	public void test561() {
		o.launch(0, true, true, 5, false, false, 2, true, false);
	}
	@Test
	public void test562() {
		o.launch(0, true, true, 5, false, false, 2, false, true);
	}
	@Test
	public void test563() {
		o.launch(0, true, true, 5, false, false, 2, false, false);
	}
	@Test
	public void test564() {
		o.launch(0, true, true, 5, false, false, 3, true, true);
	}
	@Test
	public void test565() {
		o.launch(0, true, true, 5, false, false, 3, true, false);
	}
	@Test
	public void test566() {
		o.launch(0, true, true, 5, false, false, 3, false, true);
	}
	@Test
	public void test567() {
		o.launch(0, true, true, 5, false, false, 3, false, false);
	}
	@Test
	public void test568() {
		o.launch(0, true, true, 5, false, false, 4, true, true);
	}
	@Test
	public void test569() {
		o.launch(0, true, true, -1, false, false, 4, true, false);
	}
	@Test
	public void test570() {
		o.launch(0, true, true, 5, false, false, 4, false, true);
	}
	@Test
	public void test571() {
		o.launch(0, true, true, 10, false, false, 4, false, false);
	}
	@Test
	public void test572() {
		o.launch(0, true, true, -1, false, false, 100, true, true);
	}
	@Test
	public void test573() {
		o.launch(0, true, true, -1, false, false, 100, true, false);
	}
	@Test
	public void test574() {
		o.launch(0, true, true, -1, false, false, -1, false, true);
	}
	@Test
	public void test575() {
		o.launch(0, true, true, -1, false, false, 100, false, false);
	}
	@Test
	public void test576() {
		o.launch(0, true, false, 0, true, true, 0, true, true);
	}
	@Test
	public void test577() {
		o.launch(0, true, false, 0, true, true, 0, true, false);
	}
	@Test
	public void test578() {
		o.launch(0, true, false, 0, true, true, 0, false, true);
	}
	@Test
	public void test579() {
		o.launch(0, true, false, 0, true, true, 0, false, false);
	}
	@Test
	public void test580() {
		o.launch(0, true, false, 0, true, true, 1, true, true);
	}
	@Test
	public void test581() {
		o.launch(0, true, false, 0, true, true, 1, true, false);
	}
	@Test
	public void test582() {
		o.launch(0, true, false, 0, true, true, 1, false, true);
	}
	@Test
	public void test583() {
		o.launch(0, true, false, 0, true, true, 1, false, false);
	}
	@Test
	public void test584() {
		o.launch(0, true, false, 0, true, true, 2, true, true);
	}
	@Test
	public void test585() {
		o.launch(0, true, false, 0, true, true, 2, true, false);
	}
	@Test
	public void test586() {
		o.launch(0, true, false, 0, true, true, 2, false, true);
	}
	@Test
	public void test587() {
		o.launch(0, true, false, 0, true, true, 2, false, false);
	}
	@Test
	public void test588() {
		o.launch(0, true, false, 0, true, true, 3, true, true);
	}
	@Test
	public void test589() {
		o.launch(0, true, false, 0, true, true, 3, true, false);
	}
	@Test
	public void test590() {
		o.launch(0, true, false, 0, true, true, 3, false, true);
	}
	@Test
	public void test591() {
		o.launch(0, true, false, 0, true, true, 3, false, false);
	}
	@Test
	public void test592() {
		o.launch(0, true, false, 0, true, true, 4, true, true);
	}
	@Test
	public void test593() {
		o.launch(0, true, false, 0, true, true, 4, true, false);
	}
	@Test
	public void test594() {
		o.launch(0, true, false, 0, true, true, 4, false, true);
	}
	@Test
	public void test595() {
		o.launch(0, true, false, 0, true, true, 4, false, false);
	}
	@Test
	public void test596() {
		o.launch(0, true, false, 0, true, true, -1, true, true);
	}
	@Test
	public void test597() {
		o.launch(0, true, false, 0, true, true, -1, true, false);
	}
	@Test
	public void test598() {
		o.launch(0, true, false, 0, true, true, -1, false, true);
	}
	@Test
	public void test599() {
		o.launch(0, true, false, 0, true, true, -1, false, false);
	}
	@Test
	public void test600() {
		o.launch(0, true, false, 0, true, false, 0, true, true);
	}
	@Test
	public void test601() {
		o.launch(0, true, false, 0, true, false, 0, true, false);
	}
	@Test
	public void test602() {
		o.launch(0, true, false, 0, true, false, 0, false, true);
	}
	@Test
	public void test603() {
		o.launch(0, true, false, 0, true, false, 0, false, false);
	}
	@Test
	public void test604() {
		o.launch(0, true, false, 0, true, false, 1, true, true);
	}
	@Test
	public void test605() {
		o.launch(0, true, false, 0, true, false, 1, true, false);
	}
	@Test
	public void test606() {
		o.launch(0, true, false, 0, true, false, 1, false, true);
	}
	@Test
	public void test607() {
		o.launch(0, true, false, 0, true, false, 1, false, false);
	}
	@Test
	public void test608() {
		o.launch(0, true, false, 0, true, false, 2, true, true);
	}
	@Test
	public void test609() {
		o.launch(0, true, false, 0, true, false, 2, true, false);
	}
	@Test
	public void test610() {
		o.launch(0, true, false, 0, true, false, 2, false, true);
	}
	@Test
	public void test611() {
		o.launch(0, true, false, 0, true, false, 2, false, false);
	}
	@Test
	public void test612() {
		o.launch(0, true, false, 0, true, false, 3, true, true);
	}
	@Test
	public void test613() {
		o.launch(0, true, false, 0, true, false, 3, true, false);
	}
	@Test
	public void test614() {
		o.launch(0, true, false, 0, true, false, 3, false, true);
	}
	@Test
	public void test615() {
		o.launch(0, true, false, 0, true, false, 3, false, false);
	}
	@Test
	public void test616() {
		o.launch(0, true, false, 0, true, false, 4, true, true);
	}
	@Test
	public void test617() {
		o.launch(0, true, false, 0, true, false, 4, true, false);
	}
	@Test
	public void test618() {
		o.launch(0, true, false, 0, true, false, 4, false, true);
	}
	@Test
	public void test619() {
		o.launch(0, true, false, 0, true, false, 4, false, false);
	}
	@Test
	public void test620() {
		o.launch(0, true, false, 0, true, false, 10, true, true);
	}
	@Test
	public void test621() {
		o.launch(0, true, false, 0, true, false, 10, true, false);
	}
	@Test
	public void test622() {
		o.launch(0, true, false, 0, true, false, 10, false, true);
	}
	@Test
	public void test623() {
		o.launch(0, true, false, 0, true, false, 10, false, false);
	}
	@Test
	public void test624() {
		o.launch(0, true, false, 0, false, true, 0, true, true);
	}
	@Test
	public void test625() {
		o.launch(0, true, false, 0, false, true, 0, true, false);
	}
	@Test
	public void test626() {
		o.launch(0, true, false, 0, false, true, 0, false, true);
	}
	@Test
	public void test627() {
		o.launch(0, true, false, 0, false, true, 0, false, false);
	}
	@Test
	public void test628() {
		o.launch(0, true, false, 0, false, true, 1, true, true);
	}
	@Test
	public void test629() {
		o.launch(0, true, false, 0, false, true, 1, true, false);
	}
	@Test
	public void test630() {
		o.launch(0, true, false, 0, false, true, 1, false, true);
	}
	@Test
	public void test631() {
		o.launch(0, true, false, 0, false, true, 1, false, false);
	}
	@Test
	public void test632() {
		o.launch(0, true, false, 0, false, true, 2, true, true);
	}
	@Test
	public void test633() {
		o.launch(0, true, false, 0, false, true, 2, true, false);
	}
	@Test
	public void test634() {
		o.launch(0, true, false, 0, false, true, 2, false, true);
	}
	@Test
	public void test635() {
		o.launch(0, true, false, 0, false, true, 2, false, false);
	}
	@Test
	public void test636() {
		o.launch(0, true, false, 0, false, true, 3, true, true);
	}
	@Test
	public void test637() {
		o.launch(0, true, false, 0, false, true, 3, true, false);
	}
	@Test
	public void test638() {
		o.launch(0, true, false, 0, false, true, 3, false, true);
	}
	@Test
	public void test639() {
		o.launch(0, true, false, 0, false, true, 3, false, false);
	}
	@Test
	public void test640() {
		o.launch(0, true, false, 0, false, true, 4, true, true);
	}
	@Test
	public void test641() {
		o.launch(0, true, false, 0, false, true, 4, true, false);
	}
	@Test
	public void test642() {
		o.launch(0, true, false, 0, false, true, 4, false, true);
	}
	@Test
	public void test643() {
		o.launch(0, true, false, 0, false, true, 4, false, false);
	}
	@Test
	public void test644() {
		o.launch(0, true, false, 0, false, true, -1, true, true);
	}
	@Test
	public void test645() {
		o.launch(0, true, false, 0, false, true, -1, true, false);
	}
	@Test
	public void test646() {
		o.launch(0, true, false, 0, false, true, -1, false, true);
	}
	@Test
	public void test647() {
		o.launch(0, true, false, 0, false, true, -1, false, false);
	}
	@Test
	public void test648() {
		o.launch(0, true, false, 0, false, false, 0, true, true);
	}
	@Test
	public void test649() {
		o.launch(0, true, false, 0, false, false, 0, true, false);
	}
	@Test
	public void test650() {
		o.launch(0, true, false, 0, false, false, 0, false, true);
	}
	@Test
	public void test651() {
		o.launch(0, true, false, 0, false, false, 0, false, false);
	}
	@Test
	public void test652() {
		o.launch(0, true, false, 0, false, false, 1, true, true);
	}
	@Test
	public void test653() {
		o.launch(0, true, false, 0, false, false, 1, true, false);
	}
	@Test
	public void test654() {
		o.launch(0, true, false, 0, false, false, 1, false, true);
	}
	@Test
	public void test655() {
		o.launch(0, true, false, 0, false, false, 1, false, false);
	}
	@Test
	public void test656() {
		o.launch(0, true, false, 0, false, false, 2, true, true);
	}
	@Test
	public void test657() {
		o.launch(0, true, false, 0, false, false, 2, true, false);
	}
	@Test
	public void test658() {
		o.launch(0, true, false, 0, false, false, 2, false, true);
	}
	@Test
	public void test659() {
		o.launch(0, true, false, 0, false, false, 2, false, false);
	}
	@Test
	public void test660() {
		o.launch(0, true, false, 0, false, false, 3, true, true);
	}
	@Test
	public void test661() {
		o.launch(0, true, false, 0, false, false, 3, true, false);
	}
	@Test
	public void test662() {
		o.launch(0, true, false, 0, false, false, 3, false, true);
	}
	@Test
	public void test663() {
		o.launch(0, true, false, 0, false, false, 3, false, false);
	}
	@Test
	public void test664() {
		o.launch(0, true, false, 0, false, false, 4, true, true);
	}
	@Test
	public void test665() {
		o.launch(0, true, false, 0, false, false, 4, true, false);
	}
	@Test
	public void test666() {
		o.launch(0, true, false, 0, false, false, 4, false, true);
	}
	@Test
	public void test667() {
		o.launch(0, true, false, 0, false, false, 4, false, false);
	}
	@Test
	public void test668() {
		o.launch(0, true, false, 0, false, false, 10, true, true);
	}
	@Test
	public void test669() {
		o.launch(0, true, false, 0, false, false, 10, true, false);
	}
	@Test
	public void test670() {
		o.launch(0, true, false, 0, false, false, -1, false, true);
	}
	@Test
	public void test671() {
		o.launch(0, true, false, 0, false, false, -1, false, false);
	}
	@Test
	public void test672() {
		o.launch(0, true, false, 1, true, true, 0, true, true);
	}
	@Test
	public void test673() {
		o.launch(0, true, false, 1, true, true, 0, true, false);
	}
	@Test
	public void test674() {
		o.launch(0, true, false, 1, true, true, 0, false, true);
	}
	@Test
	public void test675() {
		o.launch(0, true, false, 1, true, true, 0, false, false);
	}
	@Test
	public void test676() {
		o.launch(0, true, false, 1, true, true, 1, true, true);
	}
	@Test
	public void test677() {
		o.launch(0, true, false, 1, true, true, 1, true, false);
	}
	@Test
	public void test678() {
		o.launch(0, true, false, 1, true, true, 1, false, true);
	}
	@Test
	public void test679() {
		o.launch(0, true, false, 1, true, true, 1, false, false);
	}
	@Test
	public void test680() {
		o.launch(0, true, false, 1, true, true, 2, true, true);
	}
	@Test
	public void test681() {
		o.launch(0, true, false, 1, true, true, 2, true, false);
	}
	@Test
	public void test682() {
		o.launch(0, true, false, 1, true, true, 2, false, true);
	}
	@Test
	public void test683() {
		o.launch(0, true, false, 1, true, true, 2, false, false);
	}
	@Test
	public void test684() {
		o.launch(0, true, false, 1, true, true, 3, true, true);
	}
	@Test
	public void test685() {
		o.launch(0, true, false, 1, true, true, 3, true, false);
	}
	@Test
	public void test686() {
		o.launch(0, true, false, 1, true, true, 3, false, true);
	}
	@Test
	public void test687() {
		o.launch(0, true, false, 1, true, true, 3, false, false);
	}
	@Test
	public void test688() {
		o.launch(0, true, false, 1, true, true, 4, true, true);
	}
	@Test
	public void test689() {
		o.launch(0, true, false, 1, true, true, 4, true, false);
	}
	@Test
	public void test690() {
		o.launch(0, true, false, 1, true, true, 4, false, true);
	}
	@Test
	public void test691() {
		o.launch(0, true, false, 1, true, true, 4, false, false);
	}
	@Test
	public void test692() {
		o.launch(0, true, false, 1, true, true, 10, true, true);
	}
	@Test
	public void test693() {
		o.launch(0, true, false, 1, true, true, 10, true, false);
	}
	@Test
	public void test694() {
		o.launch(0, true, false, 1, true, true, 5, false, true);
	}
	@Test
	public void test695() {
		o.launch(0, true, false, 1, true, true, -1, false, false);
	}
	@Test
	public void test696() {
		o.launch(0, true, false, 1, true, false, 0, true, true);
	}
	@Test
	public void test697() {
		o.launch(0, true, false, 1, true, false, 0, true, false);
	}
	@Test
	public void test698() {
		o.launch(0, true, false, 1, true, false, 0, false, true);
	}
	@Test
	public void test699() {
		o.launch(0, true, false, 1, true, false, 0, false, false);
	}
	@Test
	public void test700() {
		o.launch(0, true, false, 1, true, false, 1, true, true);
	}
	@Test
	public void test701() {
		o.launch(0, true, false, 1, true, false, 1, true, false);
	}
	@Test
	public void test702() {
		o.launch(0, true, false, 1, true, false, 1, false, true);
	}
	@Test
	public void test703() {
		o.launch(0, true, false, 1, true, false, 1, false, false);
	}
	@Test
	public void test704() {
		o.launch(0, true, false, 1, true, false, 2, true, true);
	}
	@Test
	public void test705() {
		o.launch(0, true, false, 1, true, false, 2, true, false);
	}
	@Test
	public void test706() {
		o.launch(0, true, false, 1, true, false, 2, false, true);
	}
	@Test
	public void test707() {
		o.launch(0, true, false, 1, true, false, 2, false, false);
	}
	@Test
	public void test708() {
		o.launch(0, true, false, 1, true, false, 3, true, true);
	}
	@Test
	public void test709() {
		o.launch(0, true, false, 1, true, false, 3, true, false);
	}
	@Test
	public void test710() {
		o.launch(0, true, false, 1, true, false, 3, false, true);
	}
	@Test
	public void test711() {
		o.launch(0, true, false, 1, true, false, 3, false, false);
	}
	@Test
	public void test712() {
		o.launch(0, true, false, 1, true, false, 4, true, true);
	}
	@Test
	public void test713() {
		o.launch(0, true, false, 1, true, false, 4, true, false);
	}
	@Test
	public void test714() {
		o.launch(0, true, false, 1, true, false, 4, false, true);
	}
	@Test
	public void test715() {
		o.launch(0, true, false, 1, true, false, 4, false, false);
	}
	@Test
	public void test716() {
		o.launch(0, true, false, 1, true, false, -1, true, true);
	}
	@Test
	public void test717() {
		o.launch(0, true, false, 1, true, false, -1, true, false);
	}
	@Test
	public void test718() {
		o.launch(0, true, false, 1, true, false, -1, false, true);
	}
	@Test
	public void test719() {
		o.launch(0, true, false, 1, true, false, -1, false, false);
	}
	@Test
	public void test720() {
		o.launch(0, true, false, 1, false, true, 0, true, true);
	}
	@Test
	public void test721() {
		o.launch(0, true, false, 1, false, true, 0, true, false);
	}
	@Test
	public void test722() {
		o.launch(0, true, false, 1, false, true, 0, false, true);
	}
	@Test
	public void test723() {
		o.launch(0, true, false, 1, false, true, 0, false, false);
	}
	@Test
	public void test724() {
		o.launch(0, true, false, 1, false, true, 1, true, true);
	}
	@Test
	public void test725() {
		o.launch(0, true, false, 1, false, true, 1, true, false);
	}
	@Test
	public void test726() {
		o.launch(0, true, false, 1, false, true, 1, false, true);
	}
	@Test
	public void test727() {
		o.launch(0, true, false, 1, false, true, 1, false, false);
	}
	@Test
	public void test728() {
		o.launch(0, true, false, 1, false, true, 2, true, true);
	}
	@Test
	public void test729() {
		o.launch(0, true, false, 1, false, true, 2, true, false);
	}
	@Test
	public void test730() {
		o.launch(0, true, false, 1, false, true, 2, false, true);
	}
	@Test
	public void test731() {
		o.launch(0, true, false, 1, false, true, 2, false, false);
	}
	@Test
	public void test732() {
		o.launch(0, true, false, 1, false, true, 3, true, true);
	}
	@Test
	public void test733() {
		o.launch(0, true, false, 1, false, true, 3, true, false);
	}
	@Test
	public void test734() {
		o.launch(0, true, false, 1, false, true, 3, false, true);
	}
	@Test
	public void test735() {
		o.launch(0, true, false, 1, false, true, 3, false, false);
	}
	@Test
	public void test736() {
		o.launch(0, true, false, 1, false, true, 4, true, true);
	}
	@Test
	public void test737() {
		o.launch(0, true, false, 1, false, true, 4, true, false);
	}
	@Test
	public void test738() {
		o.launch(0, true, false, 1, false, true, 4, false, true);
	}
	@Test
	public void test739() {
		o.launch(0, true, false, 1, false, true, 4, false, false);
	}
	@Test
	public void test740() {
		o.launch(0, true, false, 1, false, true, -1, true, true);
	}
	@Test
	public void test741() {
		o.launch(0, true, false, 1, false, true, -1, true, false);
	}
	@Test
	public void test742() {
		o.launch(0, true, false, 1, false, true, -1, false, true);
	}
	@Test
	public void test743() {
		o.launch(0, true, false, 1, false, true, 10, false, false);
	}
	@Test
	public void test744() {
		o.launch(0, true, false, 1, false, false, 0, true, true);
	}
	@Test
	public void test745() {
		o.launch(0, true, false, 1, false, false, 0, true, false);
	}
	@Test
	public void test746() {
		o.launch(0, true, false, 1, false, false, 0, false, true);
	}
	@Test
	public void test747() {
		o.launch(0, true, false, 1, false, false, 0, false, false);
	}
	@Test
	public void test748() {
		o.launch(0, true, false, 1, false, false, 1, true, true);
	}
	@Test
	public void test749() {
		o.launch(0, true, false, 1, false, false, 1, true, false);
	}
	@Test
	public void test750() {
		o.launch(0, true, false, 1, false, false, 1, false, true);
	}
	@Test
	public void test751() {
		o.launch(0, true, false, 1, false, false, 1, false, false);
	}
	@Test
	public void test752() {
		o.launch(0, true, false, 1, false, false, 2, true, true);
	}
	@Test
	public void test753() {
		o.launch(0, true, false, 1, false, false, 2, true, false);
	}
	@Test
	public void test754() {
		o.launch(0, true, false, 1, false, false, 2, false, true);
	}
	@Test
	public void test755() {
		o.launch(0, true, false, 1, false, false, 2, false, false);
	}
	@Test
	public void test756() {
		o.launch(0, true, false, 1, false, false, 3, true, true);
	}
	@Test
	public void test757() {
		o.launch(0, true, false, 1, false, false, 3, true, false);
	}
	@Test
	public void test758() {
		o.launch(0, true, false, 1, false, false, 3, false, true);
	}
	@Test
	public void test759() {
		o.launch(0, true, false, 1, false, false, 3, false, false);
	}
	@Test
	public void test760() {
		o.launch(0, true, false, 1, false, false, 4, true, true);
	}
	@Test
	public void test761() {
		o.launch(0, true, false, 1, false, false, 4, true, false);
	}
	@Test
	public void test762() {
		o.launch(0, true, false, 1, false, false, 4, false, true);
	}
	@Test
	public void test763() {
		o.launch(0, true, false, 1, false, false, 4, false, false);
	}
	@Test
	public void test764() {
		o.launch(0, true, false, 1, false, false, 100, true, true);
	}
	@Test
	public void test765() {
		o.launch(0, true, false, 1, false, false, 100, true, false);
	}
	@Test
	public void test766() {
		o.launch(0, true, false, 1, false, false, 5, false, true);
	}
	@Test
	public void test767() {
		o.launch(0, true, false, 1, false, false, 10, false, false);
	}
	@Test
	public void test768() {
		o.launch(0, true, false, 2, true, true, 0, true, true);
	}
	@Test
	public void test769() {
		o.launch(0, true, false, 2, true, true, 0, true, false);
	}
	@Test
	public void test770() {
		o.launch(0, true, false, 2, true, true, 0, false, true);
	}
	@Test
	public void test771() {
		o.launch(0, true, false, 2, true, true, 0, false, false);
	}
	@Test
	public void test772() {
		o.launch(0, true, false, 2, true, true, 1, true, true);
	}
	@Test
	public void test773() {
		o.launch(0, true, false, 2, true, true, 1, true, false);
	}
	@Test
	public void test774() {
		o.launch(0, true, false, 2, true, true, 1, false, true);
	}
	@Test
	public void test775() {
		o.launch(0, true, false, 2, true, true, 1, false, false);
	}
	@Test
	public void test776() {
		o.launch(0, true, false, 2, true, true, 2, true, true);
	}
	@Test
	public void test777() {
		o.launch(0, true, false, 2, true, true, 2, true, false);
	}
	@Test
	public void test778() {
		o.launch(0, true, false, 2, true, true, 2, false, true);
	}
	@Test
	public void test779() {
		o.launch(0, true, false, 2, true, true, 2, false, false);
	}
	@Test
	public void test780() {
		o.launch(0, true, false, 2, true, true, 3, true, true);
	}
	@Test
	public void test781() {
		o.launch(0, true, false, 2, true, true, 3, true, false);
	}
	@Test
	public void test782() {
		o.launch(0, true, false, 2, true, true, 3, false, true);
	}
	@Test
	public void test783() {
		o.launch(0, true, false, 2, true, true, 3, false, false);
	}
	@Test
	public void test784() {
		o.launch(0, true, false, 2, true, true, 4, true, true);
	}
	@Test
	public void test785() {
		o.launch(0, true, false, 2, true, true, 4, true, false);
	}
	@Test
	public void test786() {
		o.launch(0, true, false, 2, true, true, 4, false, true);
	}
	@Test
	public void test787() {
		o.launch(0, true, false, 2, true, true, 4, false, false);
	}
	@Test
	public void test788() {
		o.launch(0, true, false, 2, true, true, 5, true, true);
	}
	@Test
	public void test789() {
		o.launch(0, true, false, 2, true, true, 5, true, false);
	}
	@Test
	public void test790() {
		o.launch(0, true, false, 2, true, true, 5, false, true);
	}
	@Test
	public void test791() {
		o.launch(0, true, false, 2, true, true, 5, false, false);
	}
	@Test
	public void test792() {
		o.launch(0, true, false, 2, true, false, 0, true, true);
	}
	@Test
	public void test793() {
		o.launch(0, true, false, 2, true, false, 0, true, false);
	}
	@Test
	public void test794() {
		o.launch(0, true, false, 2, true, false, 0, false, true);
	}
	@Test
	public void test795() {
		o.launch(0, true, false, 2, true, false, 0, false, false);
	}
	@Test
	public void test796() {
		o.launch(0, true, false, 2, true, false, 1, true, true);
	}
	@Test
	public void test797() {
		o.launch(0, true, false, 2, true, false, 1, true, false);
	}
	@Test
	public void test798() {
		o.launch(0, true, false, 2, true, false, 1, false, true);
	}
	@Test
	public void test799() {
		o.launch(0, true, false, 2, true, false, 1, false, false);
	}
	@Test
	public void test800() {
		o.launch(0, true, false, 2, true, false, 2, true, true);
	}
	@Test
	public void test801() {
		o.launch(0, true, false, 2, true, false, 2, true, false);
	}
	@Test
	public void test802() {
		o.launch(0, true, false, 2, true, false, 2, false, true);
	}
	@Test
	public void test803() {
		o.launch(0, true, false, 2, true, false, 2, false, false);
	}
	@Test
	public void test804() {
		o.launch(0, true, false, 2, true, false, 3, true, true);
	}
	@Test
	public void test805() {
		o.launch(0, true, false, 2, true, false, 3, true, false);
	}
	@Test
	public void test806() {
		o.launch(0, true, false, 2, true, false, 3, false, true);
	}
	@Test
	public void test807() {
		o.launch(0, true, false, 2, true, false, 3, false, false);
	}
	@Test
	public void test808() {
		o.launch(0, true, false, 2, true, false, 4, true, true);
	}
	@Test
	public void test809() {
		o.launch(0, true, false, 2, true, false, 4, true, false);
	}
	@Test
	public void test810() {
		o.launch(0, true, false, 2, true, false, 4, false, true);
	}
	@Test
	public void test811() {
		o.launch(0, true, false, 2, true, false, 4, false, false);
	}
	@Test
	public void test812() {
		o.launch(0, true, false, 2, true, false, 5, true, true);
	}
	@Test
	public void test813() {
		o.launch(0, true, false, 2, true, false, 5, true, false);
	}
	@Test
	public void test814() {
		o.launch(0, true, false, 2, true, false, 5, false, true);
	}
	@Test
	public void test815() {
		o.launch(0, true, false, 2, true, false, 5, false, false);
	}
	@Test
	public void test816() {
		o.launch(0, true, false, 2, false, true, 0, true, true);
	}
	@Test
	public void test817() {
		o.launch(0, true, false, 2, false, true, 0, true, false);
	}
	@Test
	public void test818() {
		o.launch(0, true, false, 2, false, true, 0, false, true);
	}
	@Test
	public void test819() {
		o.launch(0, true, false, 2, false, true, 0, false, false);
	}
	@Test
	public void test820() {
		o.launch(0, true, false, 2, false, true, 1, true, true);
	}
	@Test
	public void test821() {
		o.launch(0, true, false, 2, false, true, 1, true, false);
	}
	@Test
	public void test822() {
		o.launch(0, true, false, 2, false, true, 1, false, true);
	}
	@Test
	public void test823() {
		o.launch(0, true, false, 2, false, true, 1, false, false);
	}
	@Test
	public void test824() {
		o.launch(0, true, false, 2, false, true, 2, true, true);
	}
	@Test
	public void test825() {
		o.launch(0, true, false, 2, false, true, 2, true, false);
	}
	@Test
	public void test826() {
		o.launch(0, true, false, 2, false, true, 2, false, true);
	}
	@Test
	public void test827() {
		o.launch(0, true, false, 2, false, true, 2, false, false);
	}
	@Test
	public void test828() {
		o.launch(0, true, false, 2, false, true, 3, true, true);
	}
	@Test
	public void test829() {
		o.launch(0, true, false, 2, false, true, 3, true, false);
	}
	@Test
	public void test830() {
		o.launch(0, true, false, 2, false, true, 3, false, true);
	}
	@Test
	public void test831() {
		o.launch(0, true, false, 2, false, true, 3, false, false);
	}
	@Test
	public void test832() {
		o.launch(0, true, false, 2, false, true, 4, true, true);
	}
	@Test
	public void test833() {
		o.launch(0, true, false, 2, false, true, 4, true, false);
	}
	@Test
	public void test834() {
		o.launch(0, true, false, 2, false, true, 4, false, true);
	}
	@Test
	public void test835() {
		o.launch(0, true, false, 2, false, true, 4, false, false);
	}
	@Test
	public void test836() {
		o.launch(0, true, false, 2, false, true, 5, true, true);
	}
	@Test
	public void test837() {
		o.launch(0, true, false, 2, false, true, 5, true, false);
	}
	@Test
	public void test838() {
		o.launch(0, true, false, 2, false, true, 5, false, true);
	}
	@Test
	public void test839() {
		o.launch(0, true, false, 2, false, true, 5, false, false);
	}
	@Test
	public void test840() {
		o.launch(0, true, false, 2, false, false, 0, true, true);
	}
	@Test
	public void test841() {
		o.launch(0, true, false, 2, false, false, 0, true, false);
	}
	@Test
	public void test842() {
		o.launch(0, true, false, 2, false, false, 0, false, true);
	}
	@Test
	public void test843() {
		o.launch(0, true, false, 2, false, false, 0, false, false);
	}
	@Test
	public void test844() {
		o.launch(0, true, false, 2, false, false, 1, true, true);
	}
	@Test
	public void test845() {
		o.launch(0, true, false, 2, false, false, 1, true, false);
	}
	@Test
	public void test846() {
		o.launch(0, true, false, 2, false, false, 1, false, true);
	}
	@Test
	public void test847() {
		o.launch(0, true, false, 2, false, false, 1, false, false);
	}
	@Test
	public void test848() {
		o.launch(0, true, false, 2, false, false, 2, true, true);
	}
	@Test
	public void test849() {
		o.launch(0, true, false, 2, false, false, 2, true, false);
	}
	@Test
	public void test850() {
		o.launch(0, true, false, 2, false, false, 2, false, true);
	}
	@Test
	public void test851() {
		o.launch(0, true, false, 2, false, false, 2, false, false);
	}
	@Test
	public void test852() {
		o.launch(0, true, false, 2, false, false, 3, true, true);
	}
	@Test
	public void test853() {
		o.launch(0, true, false, 2, false, false, 3, true, false);
	}
	@Test
	public void test854() {
		o.launch(0, true, false, 2, false, false, 3, false, true);
	}
	@Test
	public void test855() {
		o.launch(0, true, false, 2, false, false, 3, false, false);
	}
	@Test
	public void test856() {
		o.launch(0, true, false, 2, false, false, 4, true, true);
	}
	@Test
	public void test857() {
		o.launch(0, true, false, 2, false, false, 4, true, false);
	}
	@Test
	public void test858() {
		o.launch(0, true, false, 2, false, false, 4, false, true);
	}
	@Test
	public void test859() {
		o.launch(0, true, false, 2, false, false, 4, false, false);
	}
	@Test
	public void test860() {
		o.launch(0, true, false, 2, false, false, 5, true, true);
	}
	@Test
	public void test861() {
		o.launch(0, true, false, 2, false, false, 5, true, false);
	}
	@Test
	public void test862() {
		o.launch(0, true, false, 2, false, false, 5, false, true);
	}
	@Test
	public void test863() {
		o.launch(0, true, false, 2, false, false, 5, false, false);
	}
	@Test
	public void test864() {
		o.launch(0, true, false, 3, true, true, 0, true, true);
	}
	@Test
	public void test865() {
		o.launch(0, true, false, 3, true, true, 0, true, false);
	}
	@Test
	public void test866() {
		o.launch(0, true, false, 3, true, true, 0, false, true);
	}
	@Test
	public void test867() {
		o.launch(0, true, false, 3, true, true, 0, false, false);
	}
	@Test
	public void test868() {
		o.launch(0, true, false, 3, true, true, 1, true, true);
	}
	@Test
	public void test869() {
		o.launch(0, true, false, 3, true, true, 1, true, false);
	}
	@Test
	public void test870() {
		o.launch(0, true, false, 3, true, true, 1, false, true);
	}
	@Test
	public void test871() {
		o.launch(0, true, false, 3, true, true, 1, false, false);
	}
	@Test
	public void test872() {
		o.launch(0, true, false, 3, true, true, 2, true, true);
	}
	@Test
	public void test873() {
		o.launch(0, true, false, 3, true, true, 2, true, false);
	}
	@Test
	public void test874() {
		o.launch(0, true, false, 3, true, true, 2, false, true);
	}
	@Test
	public void test875() {
		o.launch(0, true, false, 3, true, true, 2, false, false);
	}
	@Test
	public void test876() {
		o.launch(0, true, false, 3, true, true, 3, true, true);
	}
	@Test
	public void test877() {
		o.launch(0, true, false, 3, true, true, 3, true, false);
	}
	@Test
	public void test878() {
		o.launch(0, true, false, 3, true, true, 3, false, true);
	}
	@Test
	public void test879() {
		o.launch(0, true, false, 3, true, true, 3, false, false);
	}
	@Test
	public void test880() {
		o.launch(0, true, false, 3, true, true, 4, true, true);
	}
	@Test
	public void test881() {
		o.launch(0, true, false, 3, true, true, 4, true, false);
	}
	@Test
	public void test882() {
		o.launch(0, true, false, 3, true, true, 4, false, true);
	}
	@Test
	public void test883() {
		o.launch(0, true, false, 3, true, true, 4, false, false);
	}
	@Test
	public void test884() {
		o.launch(0, true, false, 3, true, true, 5, true, true);
	}
	@Test
	public void test885() {
		o.launch(0, true, false, 3, true, true, 5, true, false);
	}
	@Test
	public void test886() {
		o.launch(0, true, false, 3, true, true, 5, false, true);
	}
	@Test
	public void test887() {
		o.launch(0, true, false, 3, true, true, 5, false, false);
	}
	@Test
	public void test888() {
		o.launch(0, true, false, 3, true, false, 0, true, true);
	}
	@Test
	public void test889() {
		o.launch(0, true, false, 3, true, false, 0, true, false);
	}
	@Test
	public void test890() {
		o.launch(0, true, false, 3, true, false, 0, false, true);
	}
	@Test
	public void test891() {
		o.launch(0, true, false, 3, true, false, 0, false, false);
	}
	@Test
	public void test892() {
		o.launch(0, true, false, 3, true, false, 1, true, true);
	}
	@Test
	public void test893() {
		o.launch(0, true, false, 3, true, false, 1, true, false);
	}
	@Test
	public void test894() {
		o.launch(0, true, false, 3, true, false, 1, false, true);
	}
	@Test
	public void test895() {
		o.launch(0, true, false, 3, true, false, 1, false, false);
	}
	@Test
	public void test896() {
		o.launch(0, true, false, 3, true, false, 2, true, true);
	}
	@Test
	public void test897() {
		o.launch(0, true, false, 3, true, false, 2, true, false);
	}
	@Test
	public void test898() {
		o.launch(0, true, false, 3, true, false, 2, false, true);
	}
	@Test
	public void test899() {
		o.launch(0, true, false, 3, true, false, 2, false, false);
	}
	@Test
	public void test900() {
		o.launch(0, true, false, 3, true, false, 3, true, true);
	}
	@Test
	public void test901() {
		o.launch(0, true, false, 3, true, false, 3, true, false);
	}
	@Test
	public void test902() {
		o.launch(0, true, false, 3, true, false, 3, false, true);
	}
	@Test
	public void test903() {
		o.launch(0, true, false, 3, true, false, 3, false, false);
	}
	@Test
	public void test904() {
		o.launch(0, true, false, 3, true, false, 4, true, true);
	}
	@Test
	public void test905() {
		o.launch(0, true, false, 3, true, false, 4, true, false);
	}
	@Test
	public void test906() {
		o.launch(0, true, false, 3, true, false, 4, false, true);
	}
	@Test
	public void test907() {
		o.launch(0, true, false, 3, true, false, 4, false, false);
	}
	@Test
	public void test908() {
		o.launch(0, true, false, 3, true, false, 5, true, true);
	}
	@Test
	public void test909() {
		o.launch(0, true, false, 3, true, false, 5, true, false);
	}
	@Test
	public void test910() {
		o.launch(0, true, false, 3, true, false, 5, false, true);
	}
	@Test
	public void test911() {
		o.launch(0, true, false, 3, true, false, 5, false, false);
	}
	@Test
	public void test912() {
		o.launch(0, true, false, 3, false, true, 0, true, true);
	}
	@Test
	public void test913() {
		o.launch(0, true, false, 3, false, true, 0, true, false);
	}
	@Test
	public void test914() {
		o.launch(0, true, false, 3, false, true, 0, false, true);
	}
	@Test
	public void test915() {
		o.launch(0, true, false, 3, false, true, 0, false, false);
	}
	@Test
	public void test916() {
		o.launch(0, true, false, 3, false, true, 1, true, true);
	}
	@Test
	public void test917() {
		o.launch(0, true, false, 3, false, true, 1, true, false);
	}
	@Test
	public void test918() {
		o.launch(0, true, false, 3, false, true, 1, false, true);
	}
	@Test
	public void test919() {
		o.launch(0, true, false, 3, false, true, 1, false, false);
	}
	@Test
	public void test920() {
		o.launch(0, true, false, 3, false, true, 2, true, true);
	}
	@Test
	public void test921() {
		o.launch(0, true, false, 3, false, true, 2, true, false);
	}
	@Test
	public void test922() {
		o.launch(0, true, false, 3, false, true, 2, false, true);
	}
	@Test
	public void test923() {
		o.launch(0, true, false, 3, false, true, 2, false, false);
	}
	@Test
	public void test924() {
		o.launch(0, true, false, 3, false, true, 3, true, true);
	}
	@Test
	public void test925() {
		o.launch(0, true, false, 3, false, true, 3, true, false);
	}
	@Test
	public void test926() {
		o.launch(0, true, false, 3, false, true, 3, false, true);
	}
	@Test
	public void test927() {
		o.launch(0, true, false, 3, false, true, 3, false, false);
	}
	@Test
	public void test928() {
		o.launch(0, true, false, 3, false, true, 4, true, true);
	}
	@Test
	public void test929() {
		o.launch(0, true, false, 3, false, true, 4, true, false);
	}
	@Test
	public void test930() {
		o.launch(0, true, false, 3, false, true, 4, false, true);
	}
	@Test
	public void test931() {
		o.launch(0, true, false, 3, false, true, 4, false, false);
	}
	@Test
	public void test932() {
		o.launch(0, true, false, 3, false, true, 5, true, true);
	}
	@Test
	public void test933() {
		o.launch(0, true, false, 3, false, true, 5, true, false);
	}
	@Test
	public void test934() {
		o.launch(0, true, false, 3, false, true, 5, false, true);
	}
	@Test
	public void test935() {
		o.launch(0, true, false, 3, false, true, 5, false, false);
	}
	@Test
	public void test936() {
		o.launch(0, true, false, 3, false, false, 0, true, true);
	}
	@Test
	public void test937() {
		o.launch(0, true, false, 3, false, false, 0, true, false);
	}
	@Test
	public void test938() {
		o.launch(0, true, false, 3, false, false, 0, false, true);
	}
	@Test
	public void test939() {
		o.launch(0, true, false, 3, false, false, 0, false, false);
	}
	@Test
	public void test940() {
		o.launch(0, true, false, 3, false, false, 1, true, true);
	}
	@Test
	public void test941() {
		o.launch(0, true, false, 3, false, false, 1, true, false);
	}
	@Test
	public void test942() {
		o.launch(0, true, false, 3, false, false, 1, false, true);
	}
	@Test
	public void test943() {
		o.launch(0, true, false, 3, false, false, 1, false, false);
	}
	@Test
	public void test944() {
		o.launch(0, true, false, 3, false, false, 2, true, true);
	}
	@Test
	public void test945() {
		o.launch(0, true, false, 3, false, false, 2, true, false);
	}
	@Test
	public void test946() {
		o.launch(0, true, false, 3, false, false, 2, false, true);
	}
	@Test
	public void test947() {
		o.launch(0, true, false, 3, false, false, 2, false, false);
	}
	@Test
	public void test948() {
		o.launch(0, true, false, 3, false, false, 3, true, true);
	}
	@Test
	public void test949() {
		o.launch(0, true, false, 3, false, false, 3, true, false);
	}
	@Test
	public void test950() {
		o.launch(0, true, false, 3, false, false, 3, false, true);
	}
	@Test
	public void test951() {
		o.launch(0, true, false, 3, false, false, 3, false, false);
	}
	@Test
	public void test952() {
		o.launch(0, true, false, 3, false, false, 4, true, true);
	}
	@Test
	public void test953() {
		o.launch(0, true, false, 3, false, false, 4, true, false);
	}
	@Test
	public void test954() {
		o.launch(0, true, false, 3, false, false, 4, false, true);
	}
	@Test
	public void test955() {
		o.launch(0, true, false, 3, false, false, 4, false, false);
	}
	@Test
	public void test956() {
		o.launch(0, true, false, 3, false, false, 5, true, true);
	}
	@Test
	public void test957() {
		o.launch(0, true, false, 3, false, false, 5, true, false);
	}
	@Test
	public void test958() {
		o.launch(0, true, false, 3, false, false, 5, false, true);
	}
	@Test
	public void test959() {
		o.launch(0, true, false, 3, false, false, 5, false, false);
	}
	@Test
	public void test960() {
		o.launch(0, true, false, 4, true, true, 0, true, true);
	}
	@Test
	public void test961() {
		o.launch(0, true, false, 4, true, true, 0, true, false);
	}
	@Test
	public void test962() {
		o.launch(0, true, false, 4, true, true, 0, false, true);
	}
	@Test
	public void test963() {
		o.launch(0, true, false, 4, true, true, 0, false, false);
	}
	@Test
	public void test964() {
		o.launch(0, true, false, 4, true, true, 1, true, true);
	}
	@Test
	public void test965() {
		o.launch(0, true, false, 4, true, true, 1, true, false);
	}
	@Test
	public void test966() {
		o.launch(0, true, false, 4, true, true, 1, false, true);
	}
	@Test
	public void test967() {
		o.launch(0, true, false, 4, true, true, 1, false, false);
	}
	@Test
	public void test968() {
		o.launch(0, true, false, 4, true, true, 2, true, true);
	}
	@Test
	public void test969() {
		o.launch(0, true, false, 4, true, true, 2, true, false);
	}
	@Test
	public void test970() {
		o.launch(0, true, false, 4, true, true, 2, false, true);
	}
	@Test
	public void test971() {
		o.launch(0, true, false, 4, true, true, 2, false, false);
	}
	@Test
	public void test972() {
		o.launch(0, true, false, 4, true, true, 3, true, true);
	}
	@Test
	public void test973() {
		o.launch(0, true, false, 4, true, true, 3, true, false);
	}
	@Test
	public void test974() {
		o.launch(0, true, false, 4, true, true, 3, false, true);
	}
	@Test
	public void test975() {
		o.launch(0, true, false, 4, true, true, 3, false, false);
	}
	@Test
	public void test976() {
		o.launch(0, true, false, 4, true, true, 4, true, true);
	}
	@Test
	public void test977() {
		o.launch(0, true, false, 4, true, true, 4, true, false);
	}
	@Test
	public void test978() {
		o.launch(0, true, false, 4, true, true, 4, false, true);
	}
	@Test
	public void test979() {
		o.launch(0, true, false, 4, true, true, 4, false, false);
	}
	@Test
	public void test980() {
		o.launch(0, true, false, 4, true, true, 5, true, true);
	}
	@Test
	public void test981() {
		o.launch(0, true, false, 4, true, true, 5, true, false);
	}
	@Test
	public void test982() {
		o.launch(0, true, false, 4, true, true, -1, false, true);
	}
	@Test
	public void test983() {
		o.launch(0, true, false, 4, true, true, 5, false, false);
	}
	@Test
	public void test984() {
		o.launch(0, true, false, 4, true, false, 0, true, true);
	}
	@Test
	public void test985() {
		o.launch(0, true, false, 4, true, false, 0, true, false);
	}
	@Test
	public void test986() {
		o.launch(0, true, false, 4, true, false, 0, false, true);
	}
	@Test
	public void test987() {
		o.launch(0, true, false, 4, true, false, 0, false, false);
	}
	@Test
	public void test988() {
		o.launch(0, true, false, 4, true, false, 1, true, true);
	}
	@Test
	public void test989() {
		o.launch(0, true, false, 4, true, false, 1, true, false);
	}
	@Test
	public void test990() {
		o.launch(0, true, false, 4, true, false, 1, false, true);
	}
	@Test
	public void test991() {
		o.launch(0, true, false, 4, true, false, 1, false, false);
	}
	@Test
	public void test992() {
		o.launch(0, true, false, 4, true, false, 2, true, true);
	}
	@Test
	public void test993() {
		o.launch(0, true, false, 4, true, false, 2, true, false);
	}
	@Test
	public void test994() {
		o.launch(0, true, false, 4, true, false, 2, false, true);
	}
	@Test
	public void test995() {
		o.launch(0, true, false, 4, true, false, 2, false, false);
	}
	@Test
	public void test996() {
		o.launch(0, true, false, 4, true, false, 3, true, true);
	}
	@Test
	public void test997() {
		o.launch(0, true, false, 4, true, false, 3, true, false);
	}
	@Test
	public void test998() {
		o.launch(0, true, false, 4, true, false, 3, false, true);
	}
	@Test
	public void test999() {
		o.launch(0, true, false, 4, true, false, 3, false, false);
	}
	@Test
	public void test1000() {
		o.launch(0, true, false, 4, true, false, 4, true, true);
	}
	@Test
	public void test1001() {
		o.launch(0, true, false, 4, true, false, 4, true, false);
	}
	@Test
	public void test1002() {
		o.launch(0, true, false, 4, true, false, 4, false, true);
	}
	@Test
	public void test1003() {
		o.launch(0, true, false, 4, true, false, 4, false, false);
	}
	@Test
	public void test1004() {
		o.launch(0, true, false, 4, true, false, 100, true, true);
	}
	@Test
	public void test1005() {
		o.launch(0, true, false, 4, true, false, 10, true, false);
	}
	@Test
	public void test1006() {
		o.launch(0, true, false, 4, true, false, 5, false, true);
	}
	@Test
	public void test1007() {
		o.launch(0, true, false, 4, true, false, 100, false, false);
	}
	@Test
	public void test1008() {
		o.launch(0, true, false, 4, false, true, 0, true, true);
	}
	@Test
	public void test1009() {
		o.launch(0, true, false, 4, false, true, 0, true, false);
	}
	@Test
	public void test1010() {
		o.launch(0, true, false, 4, false, true, 0, false, true);
	}
	@Test
	public void test1011() {
		o.launch(0, true, false, 4, false, true, 0, false, false);
	}
	@Test
	public void test1012() {
		o.launch(0, true, false, 4, false, true, 1, true, true);
	}
	@Test
	public void test1013() {
		o.launch(0, true, false, 4, false, true, 1, true, false);
	}
	@Test
	public void test1014() {
		o.launch(0, true, false, 4, false, true, 1, false, true);
	}
	@Test
	public void test1015() {
		o.launch(0, true, false, 4, false, true, 1, false, false);
	}
	@Test
	public void test1016() {
		o.launch(0, true, false, 4, false, true, 2, true, true);
	}
	@Test
	public void test1017() {
		o.launch(0, true, false, 4, false, true, 2, true, false);
	}
	@Test
	public void test1018() {
		o.launch(0, true, false, 4, false, true, 2, false, true);
	}
	@Test
	public void test1019() {
		o.launch(0, true, false, 4, false, true, 2, false, false);
	}
	@Test
	public void test1020() {
		o.launch(0, true, false, 4, false, true, 3, true, true);
	}
	@Test
	public void test1021() {
		o.launch(0, true, false, 4, false, true, 3, true, false);
	}
	@Test
	public void test1022() {
		o.launch(0, true, false, 4, false, true, 3, false, true);
	}
	@Test
	public void test1023() {
		o.launch(0, true, false, 4, false, true, 3, false, false);
	}
	@Test
	public void test1024() {
		o.launch(0, true, false, 4, false, true, 4, true, true);
	}
	@Test
	public void test1025() {
		o.launch(0, true, false, 4, false, true, 4, true, false);
	}
	@Test
	public void test1026() {
		o.launch(0, true, false, 4, false, true, 4, false, true);
	}
	@Test
	public void test1027() {
		o.launch(0, true, false, 4, false, true, 4, false, false);
	}
	@Test
	public void test1028() {
		o.launch(0, true, false, 4, false, true, 5, true, true);
	}
	@Test
	public void test1029() {
		o.launch(0, true, false, 4, false, true, 100, true, false);
	}
	@Test
	public void test1030() {
		o.launch(0, true, false, 4, false, true, 10, false, true);
	}
	@Test
	public void test1031() {
		o.launch(0, true, false, 4, false, true, 100, false, false);
	}
	@Test
	public void test1032() {
		o.launch(0, true, false, 4, false, false, 0, true, true);
	}
	@Test
	public void test1033() {
		o.launch(0, true, false, 4, false, false, 0, true, false);
	}
	@Test
	public void test1034() {
		o.launch(0, true, false, 4, false, false, 0, false, true);
	}
	@Test
	public void test1035() {
		o.launch(0, true, false, 4, false, false, 0, false, false);
	}
	@Test
	public void test1036() {
		o.launch(0, true, false, 4, false, false, 1, true, true);
	}
	@Test
	public void test1037() {
		o.launch(0, true, false, 4, false, false, 1, true, false);
	}
	@Test
	public void test1038() {
		o.launch(0, true, false, 4, false, false, 1, false, true);
	}
	@Test
	public void test1039() {
		o.launch(0, true, false, 4, false, false, 1, false, false);
	}
	@Test
	public void test1040() {
		o.launch(0, true, false, 4, false, false, 2, true, true);
	}
	@Test
	public void test1041() {
		o.launch(0, true, false, 4, false, false, 2, true, false);
	}
	@Test
	public void test1042() {
		o.launch(0, true, false, 4, false, false, 2, false, true);
	}
	@Test
	public void test1043() {
		o.launch(0, true, false, 4, false, false, 2, false, false);
	}
	@Test
	public void test1044() {
		o.launch(0, true, false, 4, false, false, 3, true, true);
	}
	@Test
	public void test1045() {
		o.launch(0, true, false, 4, false, false, 3, true, false);
	}
	@Test
	public void test1046() {
		o.launch(0, true, false, 4, false, false, 3, false, true);
	}
	@Test
	public void test1047() {
		o.launch(0, true, false, 4, false, false, 3, false, false);
	}
	@Test
	public void test1048() {
		o.launch(0, true, false, 4, false, false, 4, true, true);
	}
	@Test
	public void test1049() {
		o.launch(0, true, false, 4, false, false, 4, true, false);
	}
	@Test
	public void test1050() {
		o.launch(0, true, false, 4, false, false, 4, false, true);
	}
	@Test
	public void test1051() {
		o.launch(0, true, false, 4, false, false, 4, false, false);
	}
	@Test
	public void test1052() {
		o.launch(0, true, false, 4, false, false, 100, true, true);
	}
	@Test
	public void test1053() {
		o.launch(0, true, false, 4, false, false, 10, true, false);
	}
	@Test
	public void test1054() {
		o.launch(0, true, false, 4, false, false, -1, false, true);
	}
	@Test
	public void test1055() {
		o.launch(0, true, false, 4, false, false, 5, false, false);
	}
	@Test
	public void test1056() {
		o.launch(0, true, false, -1, true, true, 0, true, true);
	}
	@Test
	public void test1057() {
		o.launch(0, true, false, -1, true, true, 0, true, false);
	}
	@Test
	public void test1058() {
		o.launch(0, true, false, -1, true, true, 0, false, true);
	}
	@Test
	public void test1059() {
		o.launch(0, true, false, 100, true, true, 0, false, false);
	}
	@Test
	public void test1060() {
		o.launch(0, true, false, -1, true, true, 1, true, true);
	}
	@Test
	public void test1061() {
		o.launch(0, true, false, -1, true, true, 1, true, false);
	}
	@Test
	public void test1062() {
		o.launch(0, true, false, -1, true, true, 1, false, true);
	}
	@Test
	public void test1063() {
		o.launch(0, true, false, -1, true, true, 1, false, false);
	}
	@Test
	public void test1064() {
		o.launch(0, true, false, 5, true, true, 2, true, true);
	}
	@Test
	public void test1065() {
		o.launch(0, true, false, 5, true, true, 2, true, false);
	}
	@Test
	public void test1066() {
		o.launch(0, true, false, 5, true, true, 2, false, true);
	}
	@Test
	public void test1067() {
		o.launch(0, true, false, 5, true, true, 2, false, false);
	}
	@Test
	public void test1068() {
		o.launch(0, true, false, 5, true, true, 3, true, true);
	}
	@Test
	public void test1069() {
		o.launch(0, true, false, 5, true, true, 3, true, false);
	}
	@Test
	public void test1070() {
		o.launch(0, true, false, 5, true, true, 3, false, true);
	}
	@Test
	public void test1071() {
		o.launch(0, true, false, 5, true, true, 3, false, false);
	}
	@Test
	public void test1072() {
		o.launch(0, true, false, -1, true, true, 4, true, true);
	}
	@Test
	public void test1073() {
		o.launch(0, true, false, -1, true, true, 4, true, false);
	}
	@Test
	public void test1074() {
		o.launch(0, true, false, 5, true, true, 4, false, true);
	}
	@Test
	public void test1075() {
		o.launch(0, true, false, -1, true, true, 4, false, false);
	}
	@Test
	public void test1076() {
		o.launch(0, true, false, 10, true, true, 100, true, true);
	}
	@Test
	public void test1077() {
		o.launch(0, true, false, 10, true, true, 100, true, false);
	}
	@Test
	public void test1078() {
		o.launch(0, true, false, 100, true, true, -1, false, true);
	}
	@Test
	public void test1079() {
		o.launch(0, true, false, 10, true, true, 100, false, false);
	}
	@Test
	public void test1080() {
		o.launch(0, true, false, -1, true, false, 0, true, true);
	}
	@Test
	public void test1081() {
		o.launch(0, true, false, -1, true, false, 0, true, false);
	}
	@Test
	public void test1082() {
		o.launch(0, true, false, -1, true, false, 0, false, true);
	}
	@Test
	public void test1083() {
		o.launch(0, true, false, -1, true, false, 0, false, false);
	}
	@Test
	public void test1084() {
		o.launch(0, true, false, -1, true, false, 1, true, true);
	}
	@Test
	public void test1085() {
		o.launch(0, true, false, -1, true, false, 1, true, false);
	}
	@Test
	public void test1086() {
		o.launch(0, true, false, -1, true, false, 1, false, true);
	}
	@Test
	public void test1087() {
		o.launch(0, true, false, 10, true, false, 1, false, false);
	}
	@Test
	public void test1088() {
		o.launch(0, true, false, 5, true, false, 2, true, true);
	}
	@Test
	public void test1089() {
		o.launch(0, true, false, 5, true, false, 2, true, false);
	}
	@Test
	public void test1090() {
		o.launch(0, true, false, 5, true, false, 2, false, true);
	}
	@Test
	public void test1091() {
		o.launch(0, true, false, 5, true, false, 2, false, false);
	}
	@Test
	public void test1092() {
		o.launch(0, true, false, 5, true, false, 3, true, true);
	}
	@Test
	public void test1093() {
		o.launch(0, true, false, 5, true, false, 3, true, false);
	}
	@Test
	public void test1094() {
		o.launch(0, true, false, 5, true, false, 3, false, true);
	}
	@Test
	public void test1095() {
		o.launch(0, true, false, 5, true, false, 3, false, false);
	}
	@Test
	public void test1096() {
		o.launch(0, true, false, -1, true, false, 4, true, true);
	}
	@Test
	public void test1097() {
		o.launch(0, true, false, 100, true, false, 4, true, false);
	}
	@Test
	public void test1098() {
		o.launch(0, true, false, 10, true, false, 4, false, true);
	}
	@Test
	public void test1099() {
		o.launch(0, true, false, -1, true, false, 4, false, false);
	}
	@Test
	public void test1100() {
		o.launch(0, true, false, -1, true, false, -1, true, true);
	}
	@Test
	public void test1101() {
		o.launch(0, true, false, -1, true, false, -1, true, false);
	}
	@Test
	public void test1102() {
		o.launch(0, true, false, -1, true, false, -1, false, true);
	}
	@Test
	public void test1103() {
		o.launch(0, true, false, -1, true, false, -1, false, false);
	}
	@Test
	public void test1104() {
		o.launch(0, true, false, 100, false, true, 0, true, true);
	}
	@Test
	public void test1105() {
		o.launch(0, true, false, 100, false, true, 0, true, false);
	}
	@Test
	public void test1106() {
		o.launch(0, true, false, 100, false, true, 0, false, true);
	}
	@Test
	public void test1107() {
		o.launch(0, true, false, 100, false, true, 0, false, false);
	}
	@Test
	public void test1108() {
		o.launch(0, true, false, 100, false, true, 1, true, true);
	}
	@Test
	public void test1109() {
		o.launch(0, true, false, 100, false, true, 1, true, false);
	}
	@Test
	public void test1110() {
		o.launch(0, true, false, 100, false, true, 1, false, true);
	}
	@Test
	public void test1111() {
		o.launch(0, true, false, 100, false, true, 1, false, false);
	}
	@Test
	public void test1112() {
		o.launch(0, true, false, 5, false, true, 2, true, true);
	}
	@Test
	public void test1113() {
		o.launch(0, true, false, 5, false, true, 2, true, false);
	}
	@Test
	public void test1114() {
		o.launch(0, true, false, 5, false, true, 2, false, true);
	}
	@Test
	public void test1115() {
		o.launch(0, true, false, 5, false, true, 2, false, false);
	}
	@Test
	public void test1116() {
		o.launch(0, true, false, 5, false, true, 3, true, true);
	}
	@Test
	public void test1117() {
		o.launch(0, true, false, 5, false, true, 3, true, false);
	}
	@Test
	public void test1118() {
		o.launch(0, true, false, 5, false, true, 3, false, true);
	}
	@Test
	public void test1119() {
		o.launch(0, true, false, 5, false, true, 3, false, false);
	}
	@Test
	public void test1120() {
		o.launch(0, true, false, 5, false, true, 4, true, true);
	}
	@Test
	public void test1121() {
		o.launch(0, true, false, 5, false, true, 4, true, false);
	}
	@Test
	public void test1122() {
		o.launch(0, true, false, -1, false, true, 4, false, true);
	}
	@Test
	public void test1123() {
		o.launch(0, true, false, -1, false, true, 4, false, false);
	}
	@Test
	public void test1124() {
		o.launch(0, true, false, 100, false, true, -1, true, true);
	}
	@Test
	public void test1125() {
		o.launch(0, true, false, 100, false, true, 100, true, false);
	}
	@Test
	public void test1126() {
		o.launch(0, true, false, 10, false, true, 100, false, true);
	}
	@Test
	public void test1127() {
		o.launch(0, true, false, 10, false, true, 100, false, false);
	}
	@Test
	public void test1128() {
		o.launch(0, true, false, 100, false, false, 0, true, true);
	}
	@Test
	public void test1129() {
		o.launch(0, true, false, 100, false, false, 0, true, false);
	}
	@Test
	public void test1130() {
		o.launch(0, true, false, 10, false, false, 0, false, true);
	}
	@Test
	public void test1131() {
		o.launch(0, true, false, 10, false, false, 0, false, false);
	}
	@Test
	public void test1132() {
		o.launch(0, true, false, -1, false, false, 1, true, true);
	}
	@Test
	public void test1133() {
		o.launch(0, true, false, -1, false, false, 1, true, false);
	}
	@Test
	public void test1134() {
		o.launch(0, true, false, -1, false, false, 1, false, true);
	}
	@Test
	public void test1135() {
		o.launch(0, true, false, 10, false, false, 1, false, false);
	}
	@Test
	public void test1136() {
		o.launch(0, true, false, 5, false, false, 2, true, true);
	}
	@Test
	public void test1137() {
		o.launch(0, true, false, 5, false, false, 2, true, false);
	}
	@Test
	public void test1138() {
		o.launch(0, true, false, 5, false, false, 2, false, true);
	}
	@Test
	public void test1139() {
		o.launch(0, true, false, 5, false, false, 2, false, false);
	}
	@Test
	public void test1140() {
		o.launch(0, true, false, 5, false, false, 3, true, true);
	}
	@Test
	public void test1141() {
		o.launch(0, true, false, 5, false, false, 3, true, false);
	}
	@Test
	public void test1142() {
		o.launch(0, true, false, 5, false, false, 3, false, true);
	}
	@Test
	public void test1143() {
		o.launch(0, true, false, 5, false, false, 3, false, false);
	}
	@Test
	public void test1144() {
		o.launch(0, true, false, 10, false, false, 4, true, true);
	}
	@Test
	public void test1145() {
		o.launch(0, true, false, 5, false, false, 4, true, false);
	}
	@Test
	public void test1146() {
		o.launch(0, true, false, -1, false, false, 4, false, true);
	}
	@Test
	public void test1147() {
		o.launch(0, true, false, -1, false, false, 4, false, false);
	}
	@Test
	public void test1148() {
		o.launch(0, true, false, -1, false, false, -1, true, true);
	}
	@Test
	public void test1149() {
		o.launch(0, true, false, 100, false, false, -1, true, false);
	}
	@Test
	public void test1150() {
		o.launch(0, true, false, 100, false, false, -1, false, true);
	}
	@Test
	public void test1151() {
		o.launch(0, true, false, 100, false, false, -1, false, false);
	}
	@Test
	public void test1152() {
		o.launch(0, false, true, 0, true, true, 0, true, true);
	}
	@Test
	public void test1153() {
		o.launch(0, false, true, 0, true, true, 0, true, false);
	}
	@Test
	public void test1154() {
		o.launch(0, false, true, 0, true, true, 0, false, true);
	}
	@Test
	public void test1155() {
		o.launch(0, false, true, 0, true, true, 0, false, false);
	}
	@Test
	public void test1156() {
		o.launch(0, false, true, 0, true, true, 1, true, true);
	}
	@Test
	public void test1157() {
		o.launch(0, false, true, 0, true, true, 1, true, false);
	}
	@Test
	public void test1158() {
		o.launch(0, false, true, 0, true, true, 1, false, true);
	}
	@Test
	public void test1159() {
		o.launch(0, false, true, 0, true, true, 1, false, false);
	}
	@Test
	public void test1160() {
		o.launch(0, false, true, 0, true, true, 2, true, true);
	}
	@Test
	public void test1161() {
		o.launch(0, false, true, 0, true, true, 2, true, false);
	}
	@Test
	public void test1162() {
		o.launch(0, false, true, 0, true, true, 2, false, true);
	}
	@Test
	public void test1163() {
		o.launch(0, false, true, 0, true, true, 2, false, false);
	}
	@Test
	public void test1164() {
		o.launch(0, false, true, 0, true, true, 3, true, true);
	}
	@Test
	public void test1165() {
		o.launch(0, false, true, 0, true, true, 3, true, false);
	}
	@Test
	public void test1166() {
		o.launch(0, false, true, 0, true, true, 3, false, true);
	}
	@Test
	public void test1167() {
		o.launch(0, false, true, 0, true, true, 3, false, false);
	}
	@Test
	public void test1168() {
		o.launch(0, false, true, 0, true, true, 4, true, true);
	}
	@Test
	public void test1169() {
		o.launch(0, false, true, 0, true, true, 4, true, false);
	}
	@Test
	public void test1170() {
		o.launch(0, false, true, 0, true, true, 4, false, true);
	}
	@Test
	public void test1171() {
		o.launch(0, false, true, 0, true, true, 4, false, false);
	}
	@Test
	public void test1172() {
		o.launch(0, false, true, 0, true, true, 100, true, true);
	}
	@Test
	public void test1173() {
		o.launch(0, false, true, 0, true, true, -1, true, false);
	}
	@Test
	public void test1174() {
		o.launch(0, false, true, 0, true, true, 10, false, true);
	}
	@Test
	public void test1175() {
		o.launch(0, false, true, 0, true, true, -1, false, false);
	}
	@Test
	public void test1176() {
		o.launch(0, false, true, 0, true, false, 0, true, true);
	}
	@Test
	public void test1177() {
		o.launch(0, false, true, 0, true, false, 0, true, false);
	}
	@Test
	public void test1178() {
		o.launch(0, false, true, 0, true, false, 0, false, true);
	}
	@Test
	public void test1179() {
		o.launch(0, false, true, 0, true, false, 0, false, false);
	}
	@Test
	public void test1180() {
		o.launch(0, false, true, 0, true, false, 1, true, true);
	}
	@Test
	public void test1181() {
		o.launch(0, false, true, 0, true, false, 1, true, false);
	}
	@Test
	public void test1182() {
		o.launch(0, false, true, 0, true, false, 1, false, true);
	}
	@Test
	public void test1183() {
		o.launch(0, false, true, 0, true, false, 1, false, false);
	}
	@Test
	public void test1184() {
		o.launch(0, false, true, 0, true, false, 2, true, true);
	}
	@Test
	public void test1185() {
		o.launch(0, false, true, 0, true, false, 2, true, false);
	}
	@Test
	public void test1186() {
		o.launch(0, false, true, 0, true, false, 2, false, true);
	}
	@Test
	public void test1187() {
		o.launch(0, false, true, 0, true, false, 2, false, false);
	}
	@Test
	public void test1188() {
		o.launch(0, false, true, 0, true, false, 3, true, true);
	}
	@Test
	public void test1189() {
		o.launch(0, false, true, 0, true, false, 3, true, false);
	}
	@Test
	public void test1190() {
		o.launch(0, false, true, 0, true, false, 3, false, true);
	}
	@Test
	public void test1191() {
		o.launch(0, false, true, 0, true, false, 3, false, false);
	}
	@Test
	public void test1192() {
		o.launch(0, false, true, 0, true, false, 4, true, true);
	}
	@Test
	public void test1193() {
		o.launch(0, false, true, 0, true, false, 4, true, false);
	}
	@Test
	public void test1194() {
		o.launch(0, false, true, 0, true, false, 4, false, true);
	}
	@Test
	public void test1195() {
		o.launch(0, false, true, 0, true, false, 4, false, false);
	}
	@Test
	public void test1196() {
		o.launch(0, false, true, 0, true, false, -1, true, true);
	}
	@Test
	public void test1197() {
		o.launch(0, false, true, 0, true, false, -1, true, false);
	}
	@Test
	public void test1198() {
		o.launch(0, false, true, 0, true, false, -1, false, true);
	}
	@Test
	public void test1199() {
		o.launch(0, false, true, 0, true, false, -1, false, false);
	}
	@Test
	public void test1200() {
		o.launch(0, false, true, 0, false, true, 0, true, true);
	}
	@Test
	public void test1201() {
		o.launch(0, false, true, 0, false, true, 0, true, false);
	}
	@Test
	public void test1202() {
		o.launch(0, false, true, 0, false, true, 0, false, true);
	}
	@Test
	public void test1203() {
		o.launch(0, false, true, 0, false, true, 0, false, false);
	}
	@Test
	public void test1204() {
		o.launch(0, false, true, 0, false, true, 1, true, true);
	}
	@Test
	public void test1205() {
		o.launch(0, false, true, 0, false, true, 1, true, false);
	}
	@Test
	public void test1206() {
		o.launch(0, false, true, 0, false, true, 1, false, true);
	}
	@Test
	public void test1207() {
		o.launch(0, false, true, 0, false, true, 1, false, false);
	}
	@Test
	public void test1208() {
		o.launch(0, false, true, 0, false, true, 2, true, true);
	}
	@Test
	public void test1209() {
		o.launch(0, false, true, 0, false, true, 2, true, false);
	}
	@Test
	public void test1210() {
		o.launch(0, false, true, 0, false, true, 2, false, true);
	}
	@Test
	public void test1211() {
		o.launch(0, false, true, 0, false, true, 2, false, false);
	}
	@Test
	public void test1212() {
		o.launch(0, false, true, 0, false, true, 3, true, true);
	}
	@Test
	public void test1213() {
		o.launch(0, false, true, 0, false, true, 3, true, false);
	}
	@Test
	public void test1214() {
		o.launch(0, false, true, 0, false, true, 3, false, true);
	}
	@Test
	public void test1215() {
		o.launch(0, false, true, 0, false, true, 3, false, false);
	}
	@Test
	public void test1216() {
		o.launch(0, false, true, 0, false, true, 4, true, true);
	}
	@Test
	public void test1217() {
		o.launch(0, false, true, 0, false, true, 4, true, false);
	}
	@Test
	public void test1218() {
		o.launch(0, false, true, 0, false, true, 4, false, true);
	}
	@Test
	public void test1219() {
		o.launch(0, false, true, 0, false, true, 4, false, false);
	}
	@Test
	public void test1220() {
		o.launch(0, false, true, 0, false, true, 10, true, true);
	}
	@Test
	public void test1221() {
		o.launch(0, false, true, 0, false, true, 10, true, false);
	}
	@Test
	public void test1222() {
		o.launch(0, false, true, 0, false, true, -1, false, true);
	}
	@Test
	public void test1223() {
		o.launch(0, false, true, 0, false, true, 10, false, false);
	}
	@Test
	public void test1224() {
		o.launch(0, false, true, 0, false, false, 0, true, true);
	}
	@Test
	public void test1225() {
		o.launch(0, false, true, 0, false, false, 0, true, false);
	}
	@Test
	public void test1226() {
		o.launch(0, false, true, 0, false, false, 0, false, true);
	}
	@Test
	public void test1227() {
		o.launch(0, false, true, 0, false, false, 0, false, false);
	}
	@Test
	public void test1228() {
		o.launch(0, false, true, 0, false, false, 1, true, true);
	}
	@Test
	public void test1229() {
		o.launch(0, false, true, 0, false, false, 1, true, false);
	}
	@Test
	public void test1230() {
		o.launch(0, false, true, 0, false, false, 1, false, true);
	}
	@Test
	public void test1231() {
		o.launch(0, false, true, 0, false, false, 1, false, false);
	}
	@Test
	public void test1232() {
		o.launch(0, false, true, 0, false, false, 2, true, true);
	}
	@Test
	public void test1233() {
		o.launch(0, false, true, 0, false, false, 2, true, false);
	}
	@Test
	public void test1234() {
		o.launch(0, false, true, 0, false, false, 2, false, true);
	}
	@Test
	public void test1235() {
		o.launch(0, false, true, 0, false, false, 2, false, false);
	}
	@Test
	public void test1236() {
		o.launch(0, false, true, 0, false, false, 3, true, true);
	}
	@Test
	public void test1237() {
		o.launch(0, false, true, 0, false, false, 3, true, false);
	}
	@Test
	public void test1238() {
		o.launch(0, false, true, 0, false, false, 3, false, true);
	}
	@Test
	public void test1239() {
		o.launch(0, false, true, 0, false, false, 3, false, false);
	}
	@Test
	public void test1240() {
		o.launch(0, false, true, 0, false, false, 4, true, true);
	}
	@Test
	public void test1241() {
		o.launch(0, false, true, 0, false, false, 4, true, false);
	}
	@Test
	public void test1242() {
		o.launch(0, false, true, 0, false, false, 4, false, true);
	}
	@Test
	public void test1243() {
		o.launch(0, false, true, 0, false, false, 4, false, false);
	}
	@Test
	public void test1244() {
		o.launch(0, false, true, 0, false, false, -1, true, true);
	}
	@Test
	public void test1245() {
		o.launch(0, false, true, 0, false, false, -1, true, false);
	}
	@Test
	public void test1246() {
		o.launch(0, false, true, 0, false, false, -1, false, true);
	}
	@Test
	public void test1247() {
		o.launch(0, false, true, 0, false, false, -1, false, false);
	}
	@Test
	public void test1248() {
		o.launch(0, false, true, 1, true, true, 0, true, true);
	}
	@Test
	public void test1249() {
		o.launch(0, false, true, 1, true, true, 0, true, false);
	}
	@Test
	public void test1250() {
		o.launch(0, false, true, 1, true, true, 0, false, true);
	}
	@Test
	public void test1251() {
		o.launch(0, false, true, 1, true, true, 0, false, false);
	}
	@Test
	public void test1252() {
		o.launch(0, false, true, 1, true, true, 1, true, true);
	}
	@Test
	public void test1253() {
		o.launch(0, false, true, 1, true, true, 1, true, false);
	}
	@Test
	public void test1254() {
		o.launch(0, false, true, 1, true, true, 1, false, true);
	}
	@Test
	public void test1255() {
		o.launch(0, false, true, 1, true, true, 1, false, false);
	}
	@Test
	public void test1256() {
		o.launch(0, false, true, 1, true, true, 2, true, true);
	}
	@Test
	public void test1257() {
		o.launch(0, false, true, 1, true, true, 2, true, false);
	}
	@Test
	public void test1258() {
		o.launch(0, false, true, 1, true, true, 2, false, true);
	}
	@Test
	public void test1259() {
		o.launch(0, false, true, 1, true, true, 2, false, false);
	}
	@Test
	public void test1260() {
		o.launch(0, false, true, 1, true, true, 3, true, true);
	}
	@Test
	public void test1261() {
		o.launch(0, false, true, 1, true, true, 3, true, false);
	}
	@Test
	public void test1262() {
		o.launch(0, false, true, 1, true, true, 3, false, true);
	}
	@Test
	public void test1263() {
		o.launch(0, false, true, 1, true, true, 3, false, false);
	}
	@Test
	public void test1264() {
		o.launch(0, false, true, 1, true, true, 4, true, true);
	}
	@Test
	public void test1265() {
		o.launch(0, false, true, 1, true, true, 4, true, false);
	}
	@Test
	public void test1266() {
		o.launch(0, false, true, 1, true, true, 4, false, true);
	}
	@Test
	public void test1267() {
		o.launch(0, false, true, 1, true, true, 4, false, false);
	}
	@Test
	public void test1268() {
		o.launch(0, false, true, 1, true, true, -1, true, true);
	}
	@Test
	public void test1269() {
		o.launch(0, false, true, 1, true, true, -1, true, false);
	}
	@Test
	public void test1270() {
		o.launch(0, false, true, 1, true, true, -1, false, true);
	}
	@Test
	public void test1271() {
		o.launch(0, false, true, 1, true, true, -1, false, false);
	}
	@Test
	public void test1272() {
		o.launch(0, false, true, 1, true, false, 0, true, true);
	}
	@Test
	public void test1273() {
		o.launch(0, false, true, 1, true, false, 0, true, false);
	}
	@Test
	public void test1274() {
		o.launch(0, false, true, 1, true, false, 0, false, true);
	}
	@Test
	public void test1275() {
		o.launch(0, false, true, 1, true, false, 0, false, false);
	}
	@Test
	public void test1276() {
		o.launch(0, false, true, 1, true, false, 1, true, true);
	}
	@Test
	public void test1277() {
		o.launch(0, false, true, 1, true, false, 1, true, false);
	}
	@Test
	public void test1278() {
		o.launch(0, false, true, 1, true, false, 1, false, true);
	}
	@Test
	public void test1279() {
		o.launch(0, false, true, 1, true, false, 1, false, false);
	}
	@Test
	public void test1280() {
		o.launch(0, false, true, 1, true, false, 2, true, true);
	}
	@Test
	public void test1281() {
		o.launch(0, false, true, 1, true, false, 2, true, false);
	}
	@Test
	public void test1282() {
		o.launch(0, false, true, 1, true, false, 2, false, true);
	}
	@Test
	public void test1283() {
		o.launch(0, false, true, 1, true, false, 2, false, false);
	}
	@Test
	public void test1284() {
		o.launch(0, false, true, 1, true, false, 3, true, true);
	}
	@Test
	public void test1285() {
		o.launch(0, false, true, 1, true, false, 3, true, false);
	}
	@Test
	public void test1286() {
		o.launch(0, false, true, 1, true, false, 3, false, true);
	}
	@Test
	public void test1287() {
		o.launch(0, false, true, 1, true, false, 3, false, false);
	}
	@Test
	public void test1288() {
		o.launch(0, false, true, 1, true, false, 4, true, true);
	}
	@Test
	public void test1289() {
		o.launch(0, false, true, 1, true, false, 4, true, false);
	}
	@Test
	public void test1290() {
		o.launch(0, false, true, 1, true, false, 4, false, true);
	}
	@Test
	public void test1291() {
		o.launch(0, false, true, 1, true, false, 4, false, false);
	}
	@Test
	public void test1292() {
		o.launch(0, false, true, 1, true, false, 100, true, true);
	}
	@Test
	public void test1293() {
		o.launch(0, false, true, 1, true, false, 100, true, false);
	}
	@Test
	public void test1294() {
		o.launch(0, false, true, 1, true, false, 10, false, true);
	}
	@Test
	public void test1295() {
		o.launch(0, false, true, 1, true, false, 100, false, false);
	}
	@Test
	public void test1296() {
		o.launch(0, false, true, 1, false, true, 0, true, true);
	}
	@Test
	public void test1297() {
		o.launch(0, false, true, 1, false, true, 0, true, false);
	}
	@Test
	public void test1298() {
		o.launch(0, false, true, 1, false, true, 0, false, true);
	}
	@Test
	public void test1299() {
		o.launch(0, false, true, 1, false, true, 0, false, false);
	}
	@Test
	public void test1300() {
		o.launch(0, false, true, 1, false, true, 1, true, true);
	}
	@Test
	public void test1301() {
		o.launch(0, false, true, 1, false, true, 1, true, false);
	}
	@Test
	public void test1302() {
		o.launch(0, false, true, 1, false, true, 1, false, true);
	}
	@Test
	public void test1303() {
		o.launch(0, false, true, 1, false, true, 1, false, false);
	}
	@Test
	public void test1304() {
		o.launch(0, false, true, 1, false, true, 2, true, true);
	}
	@Test
	public void test1305() {
		o.launch(0, false, true, 1, false, true, 2, true, false);
	}
	@Test
	public void test1306() {
		o.launch(0, false, true, 1, false, true, 2, false, true);
	}
	@Test
	public void test1307() {
		o.launch(0, false, true, 1, false, true, 2, false, false);
	}
	@Test
	public void test1308() {
		o.launch(0, false, true, 1, false, true, 3, true, true);
	}
	@Test
	public void test1309() {
		o.launch(0, false, true, 1, false, true, 3, true, false);
	}
	@Test
	public void test1310() {
		o.launch(0, false, true, 1, false, true, 3, false, true);
	}
	@Test
	public void test1311() {
		o.launch(0, false, true, 1, false, true, 3, false, false);
	}
	@Test
	public void test1312() {
		o.launch(0, false, true, 1, false, true, 4, true, true);
	}
	@Test
	public void test1313() {
		o.launch(0, false, true, 1, false, true, 4, true, false);
	}
	@Test
	public void test1314() {
		o.launch(0, false, true, 1, false, true, 4, false, true);
	}
	@Test
	public void test1315() {
		o.launch(0, false, true, 1, false, true, 4, false, false);
	}
	@Test
	public void test1316() {
		o.launch(0, false, true, 1, false, true, -1, true, true);
	}
	@Test
	public void test1317() {
		o.launch(0, false, true, 1, false, true, -1, true, false);
	}
	@Test
	public void test1318() {
		o.launch(0, false, true, 1, false, true, -1, false, true);
	}
	@Test
	public void test1319() {
		o.launch(0, false, true, 1, false, true, -1, false, false);
	}
	@Test
	public void test1320() {
		o.launch(0, false, true, 1, false, false, 0, true, true);
	}
	@Test
	public void test1321() {
		o.launch(0, false, true, 1, false, false, 0, true, false);
	}
	@Test
	public void test1322() {
		o.launch(0, false, true, 1, false, false, 0, false, true);
	}
	@Test
	public void test1323() {
		o.launch(0, false, true, 1, false, false, 0, false, false);
	}
	@Test
	public void test1324() {
		o.launch(0, false, true, 1, false, false, 1, true, true);
	}
	@Test
	public void test1325() {
		o.launch(0, false, true, 1, false, false, 1, true, false);
	}
	@Test
	public void test1326() {
		o.launch(0, false, true, 1, false, false, 1, false, true);
	}
	@Test
	public void test1327() {
		o.launch(0, false, true, 1, false, false, 1, false, false);
	}
	@Test
	public void test1328() {
		o.launch(0, false, true, 1, false, false, 2, true, true);
	}
	@Test
	public void test1329() {
		o.launch(0, false, true, 1, false, false, 2, true, false);
	}
	@Test
	public void test1330() {
		o.launch(0, false, true, 1, false, false, 2, false, true);
	}
	@Test
	public void test1331() {
		o.launch(0, false, true, 1, false, false, 2, false, false);
	}
	@Test
	public void test1332() {
		o.launch(0, false, true, 1, false, false, 3, true, true);
	}
	@Test
	public void test1333() {
		o.launch(0, false, true, 1, false, false, 3, true, false);
	}
	@Test
	public void test1334() {
		o.launch(0, false, true, 1, false, false, 3, false, true);
	}
	@Test
	public void test1335() {
		o.launch(0, false, true, 1, false, false, 3, false, false);
	}
	@Test
	public void test1336() {
		o.launch(0, false, true, 1, false, false, 4, true, true);
	}
	@Test
	public void test1337() {
		o.launch(0, false, true, 1, false, false, 4, true, false);
	}
	@Test
	public void test1338() {
		o.launch(0, false, true, 1, false, false, 4, false, true);
	}
	@Test
	public void test1339() {
		o.launch(0, false, true, 1, false, false, 4, false, false);
	}
	@Test
	public void test1340() {
		o.launch(0, false, true, 1, false, false, 100, true, true);
	}
	@Test
	public void test1341() {
		o.launch(0, false, true, 1, false, false, 10, true, false);
	}
	@Test
	public void test1342() {
		o.launch(0, false, true, 1, false, false, -1, false, true);
	}
	@Test
	public void test1343() {
		o.launch(0, false, true, 1, false, false, 10, false, false);
	}
	@Test
	public void test1344() {
		o.launch(0, false, true, 2, true, true, 0, true, true);
	}
	@Test
	public void test1345() {
		o.launch(0, false, true, 2, true, true, 0, true, false);
	}
	@Test
	public void test1346() {
		o.launch(0, false, true, 2, true, true, 0, false, true);
	}
	@Test
	public void test1347() {
		o.launch(0, false, true, 2, true, true, 0, false, false);
	}
	@Test
	public void test1348() {
		o.launch(0, false, true, 2, true, true, 1, true, true);
	}
	@Test
	public void test1349() {
		o.launch(0, false, true, 2, true, true, 1, true, false);
	}
	@Test
	public void test1350() {
		o.launch(0, false, true, 2, true, true, 1, false, true);
	}
	@Test
	public void test1351() {
		o.launch(0, false, true, 2, true, true, 1, false, false);
	}
	@Test
	public void test1352() {
		o.launch(0, false, true, 2, true, true, 2, true, true);
	}
	@Test
	public void test1353() {
		o.launch(0, false, true, 2, true, true, 2, true, false);
	}
	@Test
	public void test1354() {
		o.launch(0, false, true, 2, true, true, 2, false, true);
	}
	@Test
	public void test1355() {
		o.launch(0, false, true, 2, true, true, 2, false, false);
	}
	@Test
	public void test1356() {
		o.launch(0, false, true, 2, true, true, 3, true, true);
	}
	@Test
	public void test1357() {
		o.launch(0, false, true, 2, true, true, 3, true, false);
	}
	@Test
	public void test1358() {
		o.launch(0, false, true, 2, true, true, 3, false, true);
	}
	@Test
	public void test1359() {
		o.launch(0, false, true, 2, true, true, 3, false, false);
	}
	@Test
	public void test1360() {
		o.launch(0, false, true, 2, true, true, 4, true, true);
	}
	@Test
	public void test1361() {
		o.launch(0, false, true, 2, true, true, 4, true, false);
	}
	@Test
	public void test1362() {
		o.launch(0, false, true, 2, true, true, 4, false, true);
	}
	@Test
	public void test1363() {
		o.launch(0, false, true, 2, true, true, 4, false, false);
	}
	@Test
	public void test1364() {
		o.launch(0, false, true, 2, true, true, 5, true, true);
	}
	@Test
	public void test1365() {
		o.launch(0, false, true, 2, true, true, 5, true, false);
	}
	@Test
	public void test1366() {
		o.launch(0, false, true, 2, true, true, 5, false, true);
	}
	@Test
	public void test1367() {
		o.launch(0, false, true, 2, true, true, 5, false, false);
	}
	@Test
	public void test1368() {
		o.launch(0, false, true, 2, true, false, 0, true, true);
	}
	@Test
	public void test1369() {
		o.launch(0, false, true, 2, true, false, 0, true, false);
	}
	@Test
	public void test1370() {
		o.launch(0, false, true, 2, true, false, 0, false, true);
	}
	@Test
	public void test1371() {
		o.launch(0, false, true, 2, true, false, 0, false, false);
	}
	@Test
	public void test1372() {
		o.launch(0, false, true, 2, true, false, 1, true, true);
	}
	@Test
	public void test1373() {
		o.launch(0, false, true, 2, true, false, 1, true, false);
	}
	@Test
	public void test1374() {
		o.launch(0, false, true, 2, true, false, 1, false, true);
	}
	@Test
	public void test1375() {
		o.launch(0, false, true, 2, true, false, 1, false, false);
	}
	@Test
	public void test1376() {
		o.launch(0, false, true, 2, true, false, 2, true, true);
	}
	@Test
	public void test1377() {
		o.launch(0, false, true, 2, true, false, 2, true, false);
	}
	@Test
	public void test1378() {
		o.launch(0, false, true, 2, true, false, 2, false, true);
	}
	@Test
	public void test1379() {
		o.launch(0, false, true, 2, true, false, 2, false, false);
	}
	@Test
	public void test1380() {
		o.launch(0, false, true, 2, true, false, 3, true, true);
	}
	@Test
	public void test1381() {
		o.launch(0, false, true, 2, true, false, 3, true, false);
	}
	@Test
	public void test1382() {
		o.launch(0, false, true, 2, true, false, 3, false, true);
	}
	@Test
	public void test1383() {
		o.launch(0, false, true, 2, true, false, 3, false, false);
	}
	@Test
	public void test1384() {
		o.launch(0, false, true, 2, true, false, 4, true, true);
	}
	@Test
	public void test1385() {
		o.launch(0, false, true, 2, true, false, 4, true, false);
	}
	@Test
	public void test1386() {
		o.launch(0, false, true, 2, true, false, 4, false, true);
	}
	@Test
	public void test1387() {
		o.launch(0, false, true, 2, true, false, 4, false, false);
	}
	@Test
	public void test1388() {
		o.launch(0, false, true, 2, true, false, 5, true, true);
	}
	@Test
	public void test1389() {
		o.launch(0, false, true, 2, true, false, 5, true, false);
	}
	@Test
	public void test1390() {
		o.launch(0, false, true, 2, true, false, 5, false, true);
	}
	@Test
	public void test1391() {
		o.launch(0, false, true, 2, true, false, 5, false, false);
	}
	@Test
	public void test1392() {
		o.launch(0, false, true, 2, false, true, 0, true, true);
	}
	@Test
	public void test1393() {
		o.launch(0, false, true, 2, false, true, 0, true, false);
	}
	@Test
	public void test1394() {
		o.launch(0, false, true, 2, false, true, 0, false, true);
	}
	@Test
	public void test1395() {
		o.launch(0, false, true, 2, false, true, 0, false, false);
	}
	@Test
	public void test1396() {
		o.launch(0, false, true, 2, false, true, 1, true, true);
	}
	@Test
	public void test1397() {
		o.launch(0, false, true, 2, false, true, 1, true, false);
	}
	@Test
	public void test1398() {
		o.launch(0, false, true, 2, false, true, 1, false, true);
	}
	@Test
	public void test1399() {
		o.launch(0, false, true, 2, false, true, 1, false, false);
	}
	@Test
	public void test1400() {
		o.launch(0, false, true, 2, false, true, 2, true, true);
	}
	@Test
	public void test1401() {
		o.launch(0, false, true, 2, false, true, 2, true, false);
	}
	@Test
	public void test1402() {
		o.launch(0, false, true, 2, false, true, 2, false, true);
	}
	@Test
	public void test1403() {
		o.launch(0, false, true, 2, false, true, 2, false, false);
	}
	@Test
	public void test1404() {
		o.launch(0, false, true, 2, false, true, 3, true, true);
	}
	@Test
	public void test1405() {
		o.launch(0, false, true, 2, false, true, 3, true, false);
	}
	@Test
	public void test1406() {
		o.launch(0, false, true, 2, false, true, 3, false, true);
	}
	@Test
	public void test1407() {
		o.launch(0, false, true, 2, false, true, 3, false, false);
	}
	@Test
	public void test1408() {
		o.launch(0, false, true, 2, false, true, 4, true, true);
	}
	@Test
	public void test1409() {
		o.launch(0, false, true, 2, false, true, 4, true, false);
	}
	@Test
	public void test1410() {
		o.launch(0, false, true, 2, false, true, 4, false, true);
	}
	@Test
	public void test1411() {
		o.launch(0, false, true, 2, false, true, 4, false, false);
	}
	@Test
	public void test1412() {
		o.launch(0, false, true, 2, false, true, 5, true, true);
	}
	@Test
	public void test1413() {
		o.launch(0, false, true, 2, false, true, 5, true, false);
	}
	@Test
	public void test1414() {
		o.launch(0, false, true, 2, false, true, 5, false, true);
	}
	@Test
	public void test1415() {
		o.launch(0, false, true, 2, false, true, 5, false, false);
	}
	@Test
	public void test1416() {
		o.launch(0, false, true, 2, false, false, 0, true, true);
	}
	@Test
	public void test1417() {
		o.launch(0, false, true, 2, false, false, 0, true, false);
	}
	@Test
	public void test1418() {
		o.launch(0, false, true, 2, false, false, 0, false, true);
	}
	@Test
	public void test1419() {
		o.launch(0, false, true, 2, false, false, 0, false, false);
	}
	@Test
	public void test1420() {
		o.launch(0, false, true, 2, false, false, 1, true, true);
	}
	@Test
	public void test1421() {
		o.launch(0, false, true, 2, false, false, 1, true, false);
	}
	@Test
	public void test1422() {
		o.launch(0, false, true, 2, false, false, 1, false, true);
	}
	@Test
	public void test1423() {
		o.launch(0, false, true, 2, false, false, 1, false, false);
	}
	@Test
	public void test1424() {
		o.launch(0, false, true, 2, false, false, 2, true, true);
	}
	@Test
	public void test1425() {
		o.launch(0, false, true, 2, false, false, 2, true, false);
	}
	@Test
	public void test1426() {
		o.launch(0, false, true, 2, false, false, 2, false, true);
	}
	@Test
	public void test1427() {
		o.launch(0, false, true, 2, false, false, 2, false, false);
	}
	@Test
	public void test1428() {
		o.launch(0, false, true, 2, false, false, 3, true, true);
	}
	@Test
	public void test1429() {
		o.launch(0, false, true, 2, false, false, 3, true, false);
	}
	@Test
	public void test1430() {
		o.launch(0, false, true, 2, false, false, 3, false, true);
	}
	@Test
	public void test1431() {
		o.launch(0, false, true, 2, false, false, 3, false, false);
	}
	@Test
	public void test1432() {
		o.launch(0, false, true, 2, false, false, 4, true, true);
	}
	@Test
	public void test1433() {
		o.launch(0, false, true, 2, false, false, 4, true, false);
	}
	@Test
	public void test1434() {
		o.launch(0, false, true, 2, false, false, 4, false, true);
	}
	@Test
	public void test1435() {
		o.launch(0, false, true, 2, false, false, 4, false, false);
	}
	@Test
	public void test1436() {
		o.launch(0, false, true, 2, false, false, 5, true, true);
	}
	@Test
	public void test1437() {
		o.launch(0, false, true, 2, false, false, 5, true, false);
	}
	@Test
	public void test1438() {
		o.launch(0, false, true, 2, false, false, 5, false, true);
	}
	@Test
	public void test1439() {
		o.launch(0, false, true, 2, false, false, 5, false, false);
	}
	@Test
	public void test1440() {
		o.launch(0, false, true, 3, true, true, 0, true, true);
	}
	@Test
	public void test1441() {
		o.launch(0, false, true, 3, true, true, 0, true, false);
	}
	@Test
	public void test1442() {
		o.launch(0, false, true, 3, true, true, 0, false, true);
	}
	@Test
	public void test1443() {
		o.launch(0, false, true, 3, true, true, 0, false, false);
	}
	@Test
	public void test1444() {
		o.launch(0, false, true, 3, true, true, 1, true, true);
	}
	@Test
	public void test1445() {
		o.launch(0, false, true, 3, true, true, 1, true, false);
	}
	@Test
	public void test1446() {
		o.launch(0, false, true, 3, true, true, 1, false, true);
	}
	@Test
	public void test1447() {
		o.launch(0, false, true, 3, true, true, 1, false, false);
	}
	@Test
	public void test1448() {
		o.launch(0, false, true, 3, true, true, 2, true, true);
	}
	@Test
	public void test1449() {
		o.launch(0, false, true, 3, true, true, 2, true, false);
	}
	@Test
	public void test1450() {
		o.launch(0, false, true, 3, true, true, 2, false, true);
	}
	@Test
	public void test1451() {
		o.launch(0, false, true, 3, true, true, 2, false, false);
	}
	@Test
	public void test1452() {
		o.launch(0, false, true, 3, true, true, 3, true, true);
	}
	@Test
	public void test1453() {
		o.launch(0, false, true, 3, true, true, 3, true, false);
	}
	@Test
	public void test1454() {
		o.launch(0, false, true, 3, true, true, 3, false, true);
	}
	@Test
	public void test1455() {
		o.launch(0, false, true, 3, true, true, 3, false, false);
	}
	@Test
	public void test1456() {
		o.launch(0, false, true, 3, true, true, 4, true, true);
	}
	@Test
	public void test1457() {
		o.launch(0, false, true, 3, true, true, 4, true, false);
	}
	@Test
	public void test1458() {
		o.launch(0, false, true, 3, true, true, 4, false, true);
	}
	@Test
	public void test1459() {
		o.launch(0, false, true, 3, true, true, 4, false, false);
	}
	@Test
	public void test1460() {
		o.launch(0, false, true, 3, true, true, 5, true, true);
	}
	@Test
	public void test1461() {
		o.launch(0, false, true, 3, true, true, 5, true, false);
	}
	@Test
	public void test1462() {
		o.launch(0, false, true, 3, true, true, 5, false, true);
	}
	@Test
	public void test1463() {
		o.launch(0, false, true, 3, true, true, 5, false, false);
	}
	@Test
	public void test1464() {
		o.launch(0, false, true, 3, true, false, 0, true, true);
	}
	@Test
	public void test1465() {
		o.launch(0, false, true, 3, true, false, 0, true, false);
	}
	@Test
	public void test1466() {
		o.launch(0, false, true, 3, true, false, 0, false, true);
	}
	@Test
	public void test1467() {
		o.launch(0, false, true, 3, true, false, 0, false, false);
	}
	@Test
	public void test1468() {
		o.launch(0, false, true, 3, true, false, 1, true, true);
	}
	@Test
	public void test1469() {
		o.launch(0, false, true, 3, true, false, 1, true, false);
	}
	@Test
	public void test1470() {
		o.launch(0, false, true, 3, true, false, 1, false, true);
	}
	@Test
	public void test1471() {
		o.launch(0, false, true, 3, true, false, 1, false, false);
	}
	@Test
	public void test1472() {
		o.launch(0, false, true, 3, true, false, 2, true, true);
	}
	@Test
	public void test1473() {
		o.launch(0, false, true, 3, true, false, 2, true, false);
	}
	@Test
	public void test1474() {
		o.launch(0, false, true, 3, true, false, 2, false, true);
	}
	@Test
	public void test1475() {
		o.launch(0, false, true, 3, true, false, 2, false, false);
	}
	@Test
	public void test1476() {
		o.launch(0, false, true, 3, true, false, 3, true, true);
	}
	@Test
	public void test1477() {
		o.launch(0, false, true, 3, true, false, 3, true, false);
	}
	@Test
	public void test1478() {
		o.launch(0, false, true, 3, true, false, 3, false, true);
	}
	@Test
	public void test1479() {
		o.launch(0, false, true, 3, true, false, 3, false, false);
	}
	@Test
	public void test1480() {
		o.launch(0, false, true, 3, true, false, 4, true, true);
	}
	@Test
	public void test1481() {
		o.launch(0, false, true, 3, true, false, 4, true, false);
	}
	@Test
	public void test1482() {
		o.launch(0, false, true, 3, true, false, 4, false, true);
	}
	@Test
	public void test1483() {
		o.launch(0, false, true, 3, true, false, 4, false, false);
	}
	@Test
	public void test1484() {
		o.launch(0, false, true, 3, true, false, 5, true, true);
	}
	@Test
	public void test1485() {
		o.launch(0, false, true, 3, true, false, 5, true, false);
	}
	@Test
	public void test1486() {
		o.launch(0, false, true, 3, true, false, 5, false, true);
	}
	@Test
	public void test1487() {
		o.launch(0, false, true, 3, true, false, 5, false, false);
	}
	@Test
	public void test1488() {
		o.launch(0, false, true, 3, false, true, 0, true, true);
	}
	@Test
	public void test1489() {
		o.launch(0, false, true, 3, false, true, 0, true, false);
	}
	@Test
	public void test1490() {
		o.launch(0, false, true, 3, false, true, 0, false, true);
	}
	@Test
	public void test1491() {
		o.launch(0, false, true, 3, false, true, 0, false, false);
	}
	@Test
	public void test1492() {
		o.launch(0, false, true, 3, false, true, 1, true, true);
	}
	@Test
	public void test1493() {
		o.launch(0, false, true, 3, false, true, 1, true, false);
	}
	@Test
	public void test1494() {
		o.launch(0, false, true, 3, false, true, 1, false, true);
	}
	@Test
	public void test1495() {
		o.launch(0, false, true, 3, false, true, 1, false, false);
	}
	@Test
	public void test1496() {
		o.launch(0, false, true, 3, false, true, 2, true, true);
	}
	@Test
	public void test1497() {
		o.launch(0, false, true, 3, false, true, 2, true, false);
	}
	@Test
	public void test1498() {
		o.launch(0, false, true, 3, false, true, 2, false, true);
	}
	@Test
	public void test1499() {
		o.launch(0, false, true, 3, false, true, 2, false, false);
	}
	@Test
	public void test1500() {
		o.launch(0, false, true, 3, false, true, 3, true, true);
	}
	@Test
	public void test1501() {
		o.launch(0, false, true, 3, false, true, 3, true, false);
	}
	@Test
	public void test1502() {
		o.launch(0, false, true, 3, false, true, 3, false, true);
	}
	@Test
	public void test1503() {
		o.launch(0, false, true, 3, false, true, 3, false, false);
	}
	@Test
	public void test1504() {
		o.launch(0, false, true, 3, false, true, 4, true, true);
	}
	@Test
	public void test1505() {
		o.launch(0, false, true, 3, false, true, 4, true, false);
	}
	@Test
	public void test1506() {
		o.launch(0, false, true, 3, false, true, 4, false, true);
	}
	@Test
	public void test1507() {
		o.launch(0, false, true, 3, false, true, 4, false, false);
	}
	@Test
	public void test1508() {
		o.launch(0, false, true, 3, false, true, 5, true, true);
	}
	@Test
	public void test1509() {
		o.launch(0, false, true, 3, false, true, 5, true, false);
	}
	@Test
	public void test1510() {
		o.launch(0, false, true, 3, false, true, 5, false, true);
	}
	@Test
	public void test1511() {
		o.launch(0, false, true, 3, false, true, 5, false, false);
	}
	@Test
	public void test1512() {
		o.launch(0, false, true, 3, false, false, 0, true, true);
	}
	@Test
	public void test1513() {
		o.launch(0, false, true, 3, false, false, 0, true, false);
	}
	@Test
	public void test1514() {
		o.launch(0, false, true, 3, false, false, 0, false, true);
	}
	@Test
	public void test1515() {
		o.launch(0, false, true, 3, false, false, 0, false, false);
	}
	@Test
	public void test1516() {
		o.launch(0, false, true, 3, false, false, 1, true, true);
	}
	@Test
	public void test1517() {
		o.launch(0, false, true, 3, false, false, 1, true, false);
	}
	@Test
	public void test1518() {
		o.launch(0, false, true, 3, false, false, 1, false, true);
	}
	@Test
	public void test1519() {
		o.launch(0, false, true, 3, false, false, 1, false, false);
	}
	@Test
	public void test1520() {
		o.launch(0, false, true, 3, false, false, 2, true, true);
	}
	@Test
	public void test1521() {
		o.launch(0, false, true, 3, false, false, 2, true, false);
	}
	@Test
	public void test1522() {
		o.launch(0, false, true, 3, false, false, 2, false, true);
	}
	@Test
	public void test1523() {
		o.launch(0, false, true, 3, false, false, 2, false, false);
	}
	@Test
	public void test1524() {
		o.launch(0, false, true, 3, false, false, 3, true, true);
	}
	@Test
	public void test1525() {
		o.launch(0, false, true, 3, false, false, 3, true, false);
	}
	@Test
	public void test1526() {
		o.launch(0, false, true, 3, false, false, 3, false, true);
	}
	@Test
	public void test1527() {
		o.launch(0, false, true, 3, false, false, 3, false, false);
	}
	@Test
	public void test1528() {
		o.launch(0, false, true, 3, false, false, 4, true, true);
	}
	@Test
	public void test1529() {
		o.launch(0, false, true, 3, false, false, 4, true, false);
	}
	@Test
	public void test1530() {
		o.launch(0, false, true, 3, false, false, 4, false, true);
	}
	@Test
	public void test1531() {
		o.launch(0, false, true, 3, false, false, 4, false, false);
	}
	@Test
	public void test1532() {
		o.launch(0, false, true, 3, false, false, 5, true, true);
	}
	@Test
	public void test1533() {
		o.launch(0, false, true, 3, false, false, 5, true, false);
	}
	@Test
	public void test1534() {
		o.launch(0, false, true, 3, false, false, 5, false, true);
	}
	@Test
	public void test1535() {
		o.launch(0, false, true, 3, false, false, 5, false, false);
	}
	@Test
	public void test1536() {
		o.launch(0, false, true, 4, true, true, 0, true, true);
	}
	@Test
	public void test1537() {
		o.launch(0, false, true, 4, true, true, 0, true, false);
	}
	@Test
	public void test1538() {
		o.launch(0, false, true, 4, true, true, 0, false, true);
	}
	@Test
	public void test1539() {
		o.launch(0, false, true, 4, true, true, 0, false, false);
	}
	@Test
	public void test1540() {
		o.launch(0, false, true, 4, true, true, 1, true, true);
	}
	@Test
	public void test1541() {
		o.launch(0, false, true, 4, true, true, 1, true, false);
	}
	@Test
	public void test1542() {
		o.launch(0, false, true, 4, true, true, 1, false, true);
	}
	@Test
	public void test1543() {
		o.launch(0, false, true, 4, true, true, 1, false, false);
	}
	@Test
	public void test1544() {
		o.launch(0, false, true, 4, true, true, 2, true, true);
	}
	@Test
	public void test1545() {
		o.launch(0, false, true, 4, true, true, 2, true, false);
	}
	@Test
	public void test1546() {
		o.launch(0, false, true, 4, true, true, 2, false, true);
	}
	@Test
	public void test1547() {
		o.launch(0, false, true, 4, true, true, 2, false, false);
	}
	@Test
	public void test1548() {
		o.launch(0, false, true, 4, true, true, 3, true, true);
	}
	@Test
	public void test1549() {
		o.launch(0, false, true, 4, true, true, 3, true, false);
	}
	@Test
	public void test1550() {
		o.launch(0, false, true, 4, true, true, 3, false, true);
	}
	@Test
	public void test1551() {
		o.launch(0, false, true, 4, true, true, 3, false, false);
	}
	@Test
	public void test1552() {
		o.launch(0, false, true, 4, true, true, 4, true, true);
	}
	@Test
	public void test1553() {
		o.launch(0, false, true, 4, true, true, 4, true, false);
	}
	@Test
	public void test1554() {
		o.launch(0, false, true, 4, true, true, 4, false, true);
	}
	@Test
	public void test1555() {
		o.launch(0, false, true, 4, true, true, 4, false, false);
	}
	@Test
	public void test1556() {
		o.launch(0, false, true, 4, true, true, 5, true, true);
	}
	@Test
	public void test1557() {
		o.launch(0, false, true, 4, true, true, 100, true, false);
	}
	@Test
	public void test1558() {
		o.launch(0, false, true, 4, true, true, 5, false, true);
	}
	@Test
	public void test1559() {
		o.launch(0, false, true, 4, true, true, -1, false, false);
	}
	@Test
	public void test1560() {
		o.launch(0, false, true, 4, true, false, 0, true, true);
	}
	@Test
	public void test1561() {
		o.launch(0, false, true, 4, true, false, 0, true, false);
	}
	@Test
	public void test1562() {
		o.launch(0, false, true, 4, true, false, 0, false, true);
	}
	@Test
	public void test1563() {
		o.launch(0, false, true, 4, true, false, 0, false, false);
	}
	@Test
	public void test1564() {
		o.launch(0, false, true, 4, true, false, 1, true, true);
	}
	@Test
	public void test1565() {
		o.launch(0, false, true, 4, true, false, 1, true, false);
	}
	@Test
	public void test1566() {
		o.launch(0, false, true, 4, true, false, 1, false, true);
	}
	@Test
	public void test1567() {
		o.launch(0, false, true, 4, true, false, 1, false, false);
	}
	@Test
	public void test1568() {
		o.launch(0, false, true, 4, true, false, 2, true, true);
	}
	@Test
	public void test1569() {
		o.launch(0, false, true, 4, true, false, 2, true, false);
	}
	@Test
	public void test1570() {
		o.launch(0, false, true, 4, true, false, 2, false, true);
	}
	@Test
	public void test1571() {
		o.launch(0, false, true, 4, true, false, 2, false, false);
	}
	@Test
	public void test1572() {
		o.launch(0, false, true, 4, true, false, 3, true, true);
	}
	@Test
	public void test1573() {
		o.launch(0, false, true, 4, true, false, 3, true, false);
	}
	@Test
	public void test1574() {
		o.launch(0, false, true, 4, true, false, 3, false, true);
	}
	@Test
	public void test1575() {
		o.launch(0, false, true, 4, true, false, 3, false, false);
	}
	@Test
	public void test1576() {
		o.launch(0, false, true, 4, true, false, 4, true, true);
	}
	@Test
	public void test1577() {
		o.launch(0, false, true, 4, true, false, 4, true, false);
	}
	@Test
	public void test1578() {
		o.launch(0, false, true, 4, true, false, 4, false, true);
	}
	@Test
	public void test1579() {
		o.launch(0, false, true, 4, true, false, 4, false, false);
	}
	@Test
	public void test1580() {
		o.launch(0, false, true, 4, true, false, 10, true, true);
	}
	@Test
	public void test1581() {
		o.launch(0, false, true, 4, true, false, -1, true, false);
	}
	@Test
	public void test1582() {
		o.launch(0, false, true, 4, true, false, 5, false, true);
	}
	@Test
	public void test1583() {
		o.launch(0, false, true, 4, true, false, 5, false, false);
	}
	@Test
	public void test1584() {
		o.launch(0, false, true, 4, false, true, 0, true, true);
	}
	@Test
	public void test1585() {
		o.launch(0, false, true, 4, false, true, 0, true, false);
	}
	@Test
	public void test1586() {
		o.launch(0, false, true, 4, false, true, 0, false, true);
	}
	@Test
	public void test1587() {
		o.launch(0, false, true, 4, false, true, 0, false, false);
	}
	@Test
	public void test1588() {
		o.launch(0, false, true, 4, false, true, 1, true, true);
	}
	@Test
	public void test1589() {
		o.launch(0, false, true, 4, false, true, 1, true, false);
	}
	@Test
	public void test1590() {
		o.launch(0, false, true, 4, false, true, 1, false, true);
	}
	@Test
	public void test1591() {
		o.launch(0, false, true, 4, false, true, 1, false, false);
	}
	@Test
	public void test1592() {
		o.launch(0, false, true, 4, false, true, 2, true, true);
	}
	@Test
	public void test1593() {
		o.launch(0, false, true, 4, false, true, 2, true, false);
	}
	@Test
	public void test1594() {
		o.launch(0, false, true, 4, false, true, 2, false, true);
	}
	@Test
	public void test1595() {
		o.launch(0, false, true, 4, false, true, 2, false, false);
	}
	@Test
	public void test1596() {
		o.launch(0, false, true, 4, false, true, 3, true, true);
	}
	@Test
	public void test1597() {
		o.launch(0, false, true, 4, false, true, 3, true, false);
	}
	@Test
	public void test1598() {
		o.launch(0, false, true, 4, false, true, 3, false, true);
	}
	@Test
	public void test1599() {
		o.launch(0, false, true, 4, false, true, 3, false, false);
	}
	@Test
	public void test1600() {
		o.launch(0, false, true, 4, false, true, 4, true, true);
	}
	@Test
	public void test1601() {
		o.launch(0, false, true, 4, false, true, 4, true, false);
	}
	@Test
	public void test1602() {
		o.launch(0, false, true, 4, false, true, 4, false, true);
	}
	@Test
	public void test1603() {
		o.launch(0, false, true, 4, false, true, 4, false, false);
	}
	@Test
	public void test1604() {
		o.launch(0, false, true, 4, false, true, 100, true, true);
	}
	@Test
	public void test1605() {
		o.launch(0, false, true, 4, false, true, 10, true, false);
	}
	@Test
	public void test1606() {
		o.launch(0, false, true, 4, false, true, 5, false, true);
	}
	@Test
	public void test1607() {
		o.launch(0, false, true, 4, false, true, 10, false, false);
	}
	@Test
	public void test1608() {
		o.launch(0, false, true, 4, false, false, 0, true, true);
	}
	@Test
	public void test1609() {
		o.launch(0, false, true, 4, false, false, 0, true, false);
	}
	@Test
	public void test1610() {
		o.launch(0, false, true, 4, false, false, 0, false, true);
	}
	@Test
	public void test1611() {
		o.launch(0, false, true, 4, false, false, 0, false, false);
	}
	@Test
	public void test1612() {
		o.launch(0, false, true, 4, false, false, 1, true, true);
	}
	@Test
	public void test1613() {
		o.launch(0, false, true, 4, false, false, 1, true, false);
	}
	@Test
	public void test1614() {
		o.launch(0, false, true, 4, false, false, 1, false, true);
	}
	@Test
	public void test1615() {
		o.launch(0, false, true, 4, false, false, 1, false, false);
	}
	@Test
	public void test1616() {
		o.launch(0, false, true, 4, false, false, 2, true, true);
	}
	@Test
	public void test1617() {
		o.launch(0, false, true, 4, false, false, 2, true, false);
	}
	@Test
	public void test1618() {
		o.launch(0, false, true, 4, false, false, 2, false, true);
	}
	@Test
	public void test1619() {
		o.launch(0, false, true, 4, false, false, 2, false, false);
	}
	@Test
	public void test1620() {
		o.launch(0, false, true, 4, false, false, 3, true, true);
	}
	@Test
	public void test1621() {
		o.launch(0, false, true, 4, false, false, 3, true, false);
	}
	@Test
	public void test1622() {
		o.launch(0, false, true, 4, false, false, 3, false, true);
	}
	@Test
	public void test1623() {
		o.launch(0, false, true, 4, false, false, 3, false, false);
	}
	@Test
	public void test1624() {
		o.launch(0, false, true, 4, false, false, 4, true, true);
	}
	@Test
	public void test1625() {
		o.launch(0, false, true, 4, false, false, 4, true, false);
	}
	@Test
	public void test1626() {
		o.launch(0, false, true, 4, false, false, 4, false, true);
	}
	@Test
	public void test1627() {
		o.launch(0, false, true, 4, false, false, 4, false, false);
	}
	@Test
	public void test1628() {
		o.launch(0, false, true, 4, false, false, 5, true, true);
	}
	@Test
	public void test1629() {
		o.launch(0, false, true, 4, false, false, 5, true, false);
	}
	@Test
	public void test1630() {
		o.launch(0, false, true, 4, false, false, 5, false, true);
	}
	@Test
	public void test1631() {
		o.launch(0, false, true, 4, false, false, -1, false, false);
	}
	@Test
	public void test1632() {
		o.launch(0, false, true, -1, true, true, 0, true, true);
	}
	@Test
	public void test1633() {
		o.launch(0, false, true, -1, true, true, 0, true, false);
	}
	@Test
	public void test1634() {
		o.launch(0, false, true, -1, true, true, 0, false, true);
	}
	@Test
	public void test1635() {
		o.launch(0, false, true, -1, true, true, 0, false, false);
	}
	@Test
	public void test1636() {
		o.launch(0, false, true, 5, true, true, 1, true, true);
	}
	@Test
	public void test1637() {
		o.launch(0, false, true, 10, true, true, 1, true, false);
	}
	@Test
	public void test1638() {
		o.launch(0, false, true, 10, true, true, 1, false, true);
	}
	@Test
	public void test1639() {
		o.launch(0, false, true, 100, true, true, 1, false, false);
	}
	@Test
	public void test1640() {
		o.launch(0, false, true, 5, true, true, 2, true, true);
	}
	@Test
	public void test1641() {
		o.launch(0, false, true, 5, true, true, 2, true, false);
	}
	@Test
	public void test1642() {
		o.launch(0, false, true, 5, true, true, 2, false, true);
	}
	@Test
	public void test1643() {
		o.launch(0, false, true, 5, true, true, 2, false, false);
	}
	@Test
	public void test1644() {
		o.launch(0, false, true, 5, true, true, 3, true, true);
	}
	@Test
	public void test1645() {
		o.launch(0, false, true, 5, true, true, 3, true, false);
	}
	@Test
	public void test1646() {
		o.launch(0, false, true, 5, true, true, 3, false, true);
	}
	@Test
	public void test1647() {
		o.launch(0, false, true, 5, true, true, 3, false, false);
	}
	@Test
	public void test1648() {
		o.launch(0, false, true, 100, true, true, 4, true, true);
	}
	@Test
	public void test1649() {
		o.launch(0, false, true, 100, true, true, 4, true, false);
	}
	@Test
	public void test1650() {
		o.launch(0, false, true, 10, true, true, 4, false, true);
	}
	@Test
	public void test1651() {
		o.launch(0, false, true, 5, true, true, 4, false, false);
	}
	@Test
	public void test1652() {
		o.launch(0, false, true, 100, true, true, 100, true, true);
	}
	@Test
	public void test1653() {
		o.launch(0, false, true, 100, true, true, 100, true, false);
	}
	@Test
	public void test1654() {
		o.launch(0, false, true, 100, true, true, 10, false, true);
	}
	@Test
	public void test1655() {
		o.launch(0, false, true, 100, true, true, 100, false, false);
	}
	@Test
	public void test1656() {
		o.launch(0, false, true, -1, true, false, 0, true, true);
	}
	@Test
	public void test1657() {
		o.launch(0, false, true, -1, true, false, 0, true, false);
	}
	@Test
	public void test1658() {
		o.launch(0, false, true, -1, true, false, 0, false, true);
	}
	@Test
	public void test1659() {
		o.launch(0, false, true, -1, true, false, 0, false, false);
	}
	@Test
	public void test1660() {
		o.launch(0, false, true, -1, true, false, 1, true, true);
	}
	@Test
	public void test1661() {
		o.launch(0, false, true, -1, true, false, 1, true, false);
	}
	@Test
	public void test1662() {
		o.launch(0, false, true, -1, true, false, 1, false, true);
	}
	@Test
	public void test1663() {
		o.launch(0, false, true, -1, true, false, 1, false, false);
	}
	@Test
	public void test1664() {
		o.launch(0, false, true, 5, true, false, 2, true, true);
	}
	@Test
	public void test1665() {
		o.launch(0, false, true, 5, true, false, 2, true, false);
	}
	@Test
	public void test1666() {
		o.launch(0, false, true, 5, true, false, 2, false, true);
	}
	@Test
	public void test1667() {
		o.launch(0, false, true, 5, true, false, 2, false, false);
	}
	@Test
	public void test1668() {
		o.launch(0, false, true, 5, true, false, 3, true, true);
	}
	@Test
	public void test1669() {
		o.launch(0, false, true, 5, true, false, 3, true, false);
	}
	@Test
	public void test1670() {
		o.launch(0, false, true, 5, true, false, 3, false, true);
	}
	@Test
	public void test1671() {
		o.launch(0, false, true, 5, true, false, 3, false, false);
	}
	@Test
	public void test1672() {
		o.launch(0, false, true, 100, true, false, 4, true, true);
	}
	@Test
	public void test1673() {
		o.launch(0, false, true, 100, true, false, 4, true, false);
	}
	@Test
	public void test1674() {
		o.launch(0, false, true, 5, true, false, 4, false, true);
	}
	@Test
	public void test1675() {
		o.launch(0, false, true, 5, true, false, 4, false, false);
	}
	@Test
	public void test1676() {
		o.launch(0, false, true, 10, true, false, 10, true, true);
	}
	@Test
	public void test1677() {
		o.launch(0, false, true, 10, true, false, 10, true, false);
	}
	@Test
	public void test1678() {
		o.launch(0, false, true, 10, true, false, 100, false, true);
	}
	@Test
	public void test1679() {
		o.launch(0, false, true, 10, true, false, 10, false, false);
	}
	@Test
	public void test1680() {
		o.launch(0, false, true, 100, false, true, 0, true, true);
	}
	@Test
	public void test1681() {
		o.launch(0, false, true, 100, false, true, 0, true, false);
	}
	@Test
	public void test1682() {
		o.launch(0, false, true, 100, false, true, 0, false, true);
	}
	@Test
	public void test1683() {
		o.launch(0, false, true, 100, false, true, 0, false, false);
	}
	@Test
	public void test1684() {
		o.launch(0, false, true, 10, false, true, 1, true, true);
	}
	@Test
	public void test1685() {
		o.launch(0, false, true, 10, false, true, 1, true, false);
	}
	@Test
	public void test1686() {
		o.launch(0, false, true, 100, false, true, 1, false, true);
	}
	@Test
	public void test1687() {
		o.launch(0, false, true, 5, false, true, 1, false, false);
	}
	@Test
	public void test1688() {
		o.launch(0, false, true, 5, false, true, 2, true, true);
	}
	@Test
	public void test1689() {
		o.launch(0, false, true, 5, false, true, 2, true, false);
	}
	@Test
	public void test1690() {
		o.launch(0, false, true, 5, false, true, 2, false, true);
	}
	@Test
	public void test1691() {
		o.launch(0, false, true, 5, false, true, 2, false, false);
	}
	@Test
	public void test1692() {
		o.launch(0, false, true, 5, false, true, 3, true, true);
	}
	@Test
	public void test1693() {
		o.launch(0, false, true, 5, false, true, 3, true, false);
	}
	@Test
	public void test1694() {
		o.launch(0, false, true, 5, false, true, 3, false, true);
	}
	@Test
	public void test1695() {
		o.launch(0, false, true, 5, false, true, 3, false, false);
	}
	@Test
	public void test1696() {
		o.launch(0, false, true, 5, false, true, 4, true, true);
	}
	@Test
	public void test1697() {
		o.launch(0, false, true, 5, false, true, 4, true, false);
	}
	@Test
	public void test1698() {
		o.launch(0, false, true, 5, false, true, 4, false, true);
	}
	@Test
	public void test1699() {
		o.launch(0, false, true, 5, false, true, 4, false, false);
	}
	@Test
	public void test1700() {
		o.launch(0, false, true, -1, false, true, 10, true, true);
	}
	@Test
	public void test1701() {
		o.launch(0, false, true, 100, false, true, -1, true, false);
	}
	@Test
	public void test1702() {
		o.launch(0, false, true, -1, false, true, 10, false, true);
	}
	@Test
	public void test1703() {
		o.launch(0, false, true, -1, false, true, 10, false, false);
	}
	@Test
	public void test1704() {
		o.launch(0, false, true, -1, false, false, 0, true, true);
	}
	@Test
	public void test1705() {
		o.launch(0, false, true, -1, false, false, 0, true, false);
	}
	@Test
	public void test1706() {
		o.launch(0, false, true, -1, false, false, 0, false, true);
	}
	@Test
	public void test1707() {
		o.launch(0, false, true, -1, false, false, 0, false, false);
	}
	@Test
	public void test1708() {
		o.launch(0, false, true, -1, false, false, 1, true, true);
	}
	@Test
	public void test1709() {
		o.launch(0, false, true, -1, false, false, 1, true, false);
	}
	@Test
	public void test1710() {
		o.launch(0, false, true, -1, false, false, 1, false, true);
	}
	@Test
	public void test1711() {
		o.launch(0, false, true, -1, false, false, 1, false, false);
	}
	@Test
	public void test1712() {
		o.launch(0, false, true, 5, false, false, 2, true, true);
	}
	@Test
	public void test1713() {
		o.launch(0, false, true, 5, false, false, 2, true, false);
	}
	@Test
	public void test1714() {
		o.launch(0, false, true, 5, false, false, 2, false, true);
	}
	@Test
	public void test1715() {
		o.launch(0, false, true, 5, false, false, 2, false, false);
	}
	@Test
	public void test1716() {
		o.launch(0, false, true, 5, false, false, 3, true, true);
	}
	@Test
	public void test1717() {
		o.launch(0, false, true, 5, false, false, 3, true, false);
	}
	@Test
	public void test1718() {
		o.launch(0, false, true, 5, false, false, 3, false, true);
	}
	@Test
	public void test1719() {
		o.launch(0, false, true, 5, false, false, 3, false, false);
	}
	@Test
	public void test1720() {
		o.launch(0, false, true, 5, false, false, 4, true, true);
	}
	@Test
	public void test1721() {
		o.launch(0, false, true, 10, false, false, 4, true, false);
	}
	@Test
	public void test1722() {
		o.launch(0, false, true, 5, false, false, 4, false, true);
	}
	@Test
	public void test1723() {
		o.launch(0, false, true, 5, false, false, 4, false, false);
	}
	@Test
	public void test1724() {
		o.launch(0, false, true, 10, false, false, -1, true, true);
	}
	@Test
	public void test1725() {
		o.launch(0, false, true, -1, false, false, -1, true, false);
	}
	@Test
	public void test1726() {
		o.launch(0, false, true, 100, false, false, 10, false, true);
	}
	@Test
	public void test1727() {
		o.launch(0, false, true, 100, false, false, 10, false, false);
	}
	@Test
	public void test1728() {
		o.launch(0, false, false, 0, true, true, 0, true, true);
	}
	@Test
	public void test1729() {
		o.launch(0, false, false, 0, true, true, 0, true, false);
	}
	@Test
	public void test1730() {
		o.launch(0, false, false, 0, true, true, 0, false, true);
	}
	@Test
	public void test1731() {
		o.launch(0, false, false, 0, true, true, 0, false, false);
	}
	@Test
	public void test1732() {
		o.launch(0, false, false, 0, true, true, 1, true, true);
	}
	@Test
	public void test1733() {
		o.launch(0, false, false, 0, true, true, 1, true, false);
	}
	@Test
	public void test1734() {
		o.launch(0, false, false, 0, true, true, 1, false, true);
	}
	@Test
	public void test1735() {
		o.launch(0, false, false, 0, true, true, 1, false, false);
	}
	@Test
	public void test1736() {
		o.launch(0, false, false, 0, true, true, 2, true, true);
	}
	@Test
	public void test1737() {
		o.launch(0, false, false, 0, true, true, 2, true, false);
	}
	@Test
	public void test1738() {
		o.launch(0, false, false, 0, true, true, 2, false, true);
	}
	@Test
	public void test1739() {
		o.launch(0, false, false, 0, true, true, 2, false, false);
	}
	@Test
	public void test1740() {
		o.launch(0, false, false, 0, true, true, 3, true, true);
	}
	@Test
	public void test1741() {
		o.launch(0, false, false, 0, true, true, 3, true, false);
	}
	@Test
	public void test1742() {
		o.launch(0, false, false, 0, true, true, 3, false, true);
	}
	@Test
	public void test1743() {
		o.launch(0, false, false, 0, true, true, 3, false, false);
	}
	@Test
	public void test1744() {
		o.launch(0, false, false, 0, true, true, 4, true, true);
	}
	@Test
	public void test1745() {
		o.launch(0, false, false, 0, true, true, 4, true, false);
	}
	@Test
	public void test1746() {
		o.launch(0, false, false, 0, true, true, 4, false, true);
	}
	@Test
	public void test1747() {
		o.launch(0, false, false, 0, true, true, 4, false, false);
	}
	@Test
	public void test1748() {
		o.launch(0, false, false, 0, true, true, 10, true, true);
	}
	@Test
	public void test1749() {
		o.launch(0, false, false, 0, true, true, 10, true, false);
	}
	@Test
	public void test1750() {
		o.launch(0, false, false, 0, true, true, 10, false, true);
	}
	@Test
	public void test1751() {
		o.launch(0, false, false, 0, true, true, 10, false, false);
	}
	@Test
	public void test1752() {
		o.launch(0, false, false, 0, true, false, 0, true, true);
	}
	@Test
	public void test1753() {
		o.launch(0, false, false, 0, true, false, 0, true, false);
	}
	@Test
	public void test1754() {
		o.launch(0, false, false, 0, true, false, 0, false, true);
	}
	@Test
	public void test1755() {
		o.launch(0, false, false, 0, true, false, 0, false, false);
	}
	@Test
	public void test1756() {
		o.launch(0, false, false, 0, true, false, 1, true, true);
	}
	@Test
	public void test1757() {
		o.launch(0, false, false, 0, true, false, 1, true, false);
	}
	@Test
	public void test1758() {
		o.launch(0, false, false, 0, true, false, 1, false, true);
	}
	@Test
	public void test1759() {
		o.launch(0, false, false, 0, true, false, 1, false, false);
	}
	@Test
	public void test1760() {
		o.launch(0, false, false, 0, true, false, 2, true, true);
	}
	@Test
	public void test1761() {
		o.launch(0, false, false, 0, true, false, 2, true, false);
	}
	@Test
	public void test1762() {
		o.launch(0, false, false, 0, true, false, 2, false, true);
	}
	@Test
	public void test1763() {
		o.launch(0, false, false, 0, true, false, 2, false, false);
	}
	@Test
	public void test1764() {
		o.launch(0, false, false, 0, true, false, 3, true, true);
	}
	@Test
	public void test1765() {
		o.launch(0, false, false, 0, true, false, 3, true, false);
	}
	@Test
	public void test1766() {
		o.launch(0, false, false, 0, true, false, 3, false, true);
	}
	@Test
	public void test1767() {
		o.launch(0, false, false, 0, true, false, 3, false, false);
	}
	@Test
	public void test1768() {
		o.launch(0, false, false, 0, true, false, 4, true, true);
	}
	@Test
	public void test1769() {
		o.launch(0, false, false, 0, true, false, 4, true, false);
	}
	@Test
	public void test1770() {
		o.launch(0, false, false, 0, true, false, 4, false, true);
	}
	@Test
	public void test1771() {
		o.launch(0, false, false, 0, true, false, 4, false, false);
	}
	@Test
	public void test1772() {
		o.launch(0, false, false, 0, true, false, 100, true, true);
	}
	@Test
	public void test1773() {
		o.launch(0, false, false, 0, true, false, 100, true, false);
	}
	@Test
	public void test1774() {
		o.launch(0, false, false, 0, true, false, 10, false, true);
	}
	@Test
	public void test1775() {
		o.launch(0, false, false, 0, true, false, 100, false, false);
	}
	@Test
	public void test1776() {
		o.launch(0, false, false, 0, false, true, 0, true, true);
	}
	@Test
	public void test1777() {
		o.launch(0, false, false, 0, false, true, 0, true, false);
	}
	@Test
	public void test1778() {
		o.launch(0, false, false, 0, false, true, 0, false, true);
	}
	@Test
	public void test1779() {
		o.launch(0, false, false, 0, false, true, 0, false, false);
	}
	@Test
	public void test1780() {
		o.launch(0, false, false, 0, false, true, 1, true, true);
	}
	@Test
	public void test1781() {
		o.launch(0, false, false, 0, false, true, 1, true, false);
	}
	@Test
	public void test1782() {
		o.launch(0, false, false, 0, false, true, 1, false, true);
	}
	@Test
	public void test1783() {
		o.launch(0, false, false, 0, false, true, 1, false, false);
	}
	@Test
	public void test1784() {
		o.launch(0, false, false, 0, false, true, 2, true, true);
	}
	@Test
	public void test1785() {
		o.launch(0, false, false, 0, false, true, 2, true, false);
	}
	@Test
	public void test1786() {
		o.launch(0, false, false, 0, false, true, 2, false, true);
	}
	@Test
	public void test1787() {
		o.launch(0, false, false, 0, false, true, 2, false, false);
	}
	@Test
	public void test1788() {
		o.launch(0, false, false, 0, false, true, 3, true, true);
	}
	@Test
	public void test1789() {
		o.launch(0, false, false, 0, false, true, 3, true, false);
	}
	@Test
	public void test1790() {
		o.launch(0, false, false, 0, false, true, 3, false, true);
	}
	@Test
	public void test1791() {
		o.launch(0, false, false, 0, false, true, 3, false, false);
	}
	@Test
	public void test1792() {
		o.launch(0, false, false, 0, false, true, 4, true, true);
	}
	@Test
	public void test1793() {
		o.launch(0, false, false, 0, false, true, 4, true, false);
	}
	@Test
	public void test1794() {
		o.launch(0, false, false, 0, false, true, 4, false, true);
	}
	@Test
	public void test1795() {
		o.launch(0, false, false, 0, false, true, 4, false, false);
	}
	@Test
	public void test1796() {
		o.launch(0, false, false, 0, false, true, 10, true, true);
	}
	@Test
	public void test1797() {
		o.launch(0, false, false, 0, false, true, 10, true, false);
	}
	@Test
	public void test1798() {
		o.launch(0, false, false, 0, false, true, 10, false, true);
	}
	@Test
	public void test1799() {
		o.launch(0, false, false, 0, false, true, 10, false, false);
	}
	@Test
	public void test1800() {
		o.launch(0, false, false, 0, false, false, 0, true, true);
	}
	@Test
	public void test1801() {
		o.launch(0, false, false, 0, false, false, 0, true, false);
	}
	@Test
	public void test1802() {
		o.launch(0, false, false, 0, false, false, 0, false, true);
	}
	@Test
	public void test1803() {
		o.launch(0, false, false, 0, false, false, 0, false, false);
	}
	@Test
	public void test1804() {
		o.launch(0, false, false, 0, false, false, 1, true, true);
	}
	@Test
	public void test1805() {
		o.launch(0, false, false, 0, false, false, 1, true, false);
	}
	@Test
	public void test1806() {
		o.launch(0, false, false, 0, false, false, 1, false, true);
	}
	@Test
	public void test1807() {
		o.launch(0, false, false, 0, false, false, 1, false, false);
	}
	@Test
	public void test1808() {
		o.launch(0, false, false, 0, false, false, 2, true, true);
	}
	@Test
	public void test1809() {
		o.launch(0, false, false, 0, false, false, 2, true, false);
	}
	@Test
	public void test1810() {
		o.launch(0, false, false, 0, false, false, 2, false, true);
	}
	@Test
	public void test1811() {
		o.launch(0, false, false, 0, false, false, 2, false, false);
	}
	@Test
	public void test1812() {
		o.launch(0, false, false, 0, false, false, 3, true, true);
	}
	@Test
	public void test1813() {
		o.launch(0, false, false, 0, false, false, 3, true, false);
	}
	@Test
	public void test1814() {
		o.launch(0, false, false, 0, false, false, 3, false, true);
	}
	@Test
	public void test1815() {
		o.launch(0, false, false, 0, false, false, 3, false, false);
	}
	@Test
	public void test1816() {
		o.launch(0, false, false, 0, false, false, 4, true, true);
	}
	@Test
	public void test1817() {
		o.launch(0, false, false, 0, false, false, 4, true, false);
	}
	@Test
	public void test1818() {
		o.launch(0, false, false, 0, false, false, 4, false, true);
	}
	@Test
	public void test1819() {
		o.launch(0, false, false, 0, false, false, 4, false, false);
	}
	@Test
	public void test1820() {
		o.launch(0, false, false, 0, false, false, 10, true, true);
	}
	@Test
	public void test1821() {
		o.launch(0, false, false, 0, false, false, 10, true, false);
	}
	@Test
	public void test1822() {
		o.launch(0, false, false, 0, false, false, 10, false, true);
	}
	@Test
	public void test1823() {
		o.launch(0, false, false, 0, false, false, 10, false, false);
	}
	@Test
	public void test1824() {
		o.launch(0, false, false, 1, true, true, 0, true, true);
	}
	@Test
	public void test1825() {
		o.launch(0, false, false, 1, true, true, 0, true, false);
	}
	@Test
	public void test1826() {
		o.launch(0, false, false, 1, true, true, 0, false, true);
	}
	@Test
	public void test1827() {
		o.launch(0, false, false, 1, true, true, 0, false, false);
	}
	@Test
	public void test1828() {
		o.launch(0, false, false, 1, true, true, 1, true, true);
	}
	@Test
	public void test1829() {
		o.launch(0, false, false, 1, true, true, 1, true, false);
	}
	@Test
	public void test1830() {
		o.launch(0, false, false, 1, true, true, 1, false, true);
	}
	@Test
	public void test1831() {
		o.launch(0, false, false, 1, true, true, 1, false, false);
	}
	@Test
	public void test1832() {
		o.launch(0, false, false, 1, true, true, 2, true, true);
	}
	@Test
	public void test1833() {
		o.launch(0, false, false, 1, true, true, 2, true, false);
	}
	@Test
	public void test1834() {
		o.launch(0, false, false, 1, true, true, 2, false, true);
	}
	@Test
	public void test1835() {
		o.launch(0, false, false, 1, true, true, 2, false, false);
	}
	@Test
	public void test1836() {
		o.launch(0, false, false, 1, true, true, 3, true, true);
	}
	@Test
	public void test1837() {
		o.launch(0, false, false, 1, true, true, 3, true, false);
	}
	@Test
	public void test1838() {
		o.launch(0, false, false, 1, true, true, 3, false, true);
	}
	@Test
	public void test1839() {
		o.launch(0, false, false, 1, true, true, 3, false, false);
	}
	@Test
	public void test1840() {
		o.launch(0, false, false, 1, true, true, 4, true, true);
	}
	@Test
	public void test1841() {
		o.launch(0, false, false, 1, true, true, 4, true, false);
	}
	@Test
	public void test1842() {
		o.launch(0, false, false, 1, true, true, 4, false, true);
	}
	@Test
	public void test1843() {
		o.launch(0, false, false, 1, true, true, 4, false, false);
	}
	@Test
	public void test1844() {
		o.launch(0, false, false, 1, true, true, -1, true, true);
	}
	@Test
	public void test1845() {
		o.launch(0, false, false, 1, true, true, 10, true, false);
	}
	@Test
	public void test1846() {
		o.launch(0, false, false, 1, true, true, -1, false, true);
	}
	@Test
	public void test1847() {
		o.launch(0, false, false, 1, true, true, 10, false, false);
	}
	@Test
	public void test1848() {
		o.launch(0, false, false, 1, true, false, 0, true, true);
	}
	@Test
	public void test1849() {
		o.launch(0, false, false, 1, true, false, 0, true, false);
	}
	@Test
	public void test1850() {
		o.launch(0, false, false, 1, true, false, 0, false, true);
	}
	@Test
	public void test1851() {
		o.launch(0, false, false, 1, true, false, 0, false, false);
	}
	@Test
	public void test1852() {
		o.launch(0, false, false, 1, true, false, 1, true, true);
	}
	@Test
	public void test1853() {
		o.launch(0, false, false, 1, true, false, 1, true, false);
	}
	@Test
	public void test1854() {
		o.launch(0, false, false, 1, true, false, 1, false, true);
	}
	@Test
	public void test1855() {
		o.launch(0, false, false, 1, true, false, 1, false, false);
	}
	@Test
	public void test1856() {
		o.launch(0, false, false, 1, true, false, 2, true, true);
	}
	@Test
	public void test1857() {
		o.launch(0, false, false, 1, true, false, 2, true, false);
	}
	@Test
	public void test1858() {
		o.launch(0, false, false, 1, true, false, 2, false, true);
	}
	@Test
	public void test1859() {
		o.launch(0, false, false, 1, true, false, 2, false, false);
	}
	@Test
	public void test1860() {
		o.launch(0, false, false, 1, true, false, 3, true, true);
	}
	@Test
	public void test1861() {
		o.launch(0, false, false, 1, true, false, 3, true, false);
	}
	@Test
	public void test1862() {
		o.launch(0, false, false, 1, true, false, 3, false, true);
	}
	@Test
	public void test1863() {
		o.launch(0, false, false, 1, true, false, 3, false, false);
	}
	@Test
	public void test1864() {
		o.launch(0, false, false, 1, true, false, 4, true, true);
	}
	@Test
	public void test1865() {
		o.launch(0, false, false, 1, true, false, 4, true, false);
	}
	@Test
	public void test1866() {
		o.launch(0, false, false, 1, true, false, 4, false, true);
	}
	@Test
	public void test1867() {
		o.launch(0, false, false, 1, true, false, 4, false, false);
	}
	@Test
	public void test1868() {
		o.launch(0, false, false, 1, true, false, 100, true, true);
	}
	@Test
	public void test1869() {
		o.launch(0, false, false, 1, true, false, 10, true, false);
	}
	@Test
	public void test1870() {
		o.launch(0, false, false, 1, true, false, -1, false, true);
	}
	@Test
	public void test1871() {
		o.launch(0, false, false, 1, true, false, 10, false, false);
	}
	@Test
	public void test1872() {
		o.launch(0, false, false, 1, false, true, 0, true, true);
	}
	@Test
	public void test1873() {
		o.launch(0, false, false, 1, false, true, 0, true, false);
	}
	@Test
	public void test1874() {
		o.launch(0, false, false, 1, false, true, 0, false, true);
	}
	@Test
	public void test1875() {
		o.launch(0, false, false, 1, false, true, 0, false, false);
	}
	@Test
	public void test1876() {
		o.launch(0, false, false, 1, false, true, 1, true, true);
	}
	@Test
	public void test1877() {
		o.launch(0, false, false, 1, false, true, 1, true, false);
	}
	@Test
	public void test1878() {
		o.launch(0, false, false, 1, false, true, 1, false, true);
	}
	@Test
	public void test1879() {
		o.launch(0, false, false, 1, false, true, 1, false, false);
	}
	@Test
	public void test1880() {
		o.launch(0, false, false, 1, false, true, 2, true, true);
	}
	@Test
	public void test1881() {
		o.launch(0, false, false, 1, false, true, 2, true, false);
	}
	@Test
	public void test1882() {
		o.launch(0, false, false, 1, false, true, 2, false, true);
	}
	@Test
	public void test1883() {
		o.launch(0, false, false, 1, false, true, 2, false, false);
	}
	@Test
	public void test1884() {
		o.launch(0, false, false, 1, false, true, 3, true, true);
	}
	@Test
	public void test1885() {
		o.launch(0, false, false, 1, false, true, 3, true, false);
	}
	@Test
	public void test1886() {
		o.launch(0, false, false, 1, false, true, 3, false, true);
	}
	@Test
	public void test1887() {
		o.launch(0, false, false, 1, false, true, 3, false, false);
	}
	@Test
	public void test1888() {
		o.launch(0, false, false, 1, false, true, 4, true, true);
	}
	@Test
	public void test1889() {
		o.launch(0, false, false, 1, false, true, 4, true, false);
	}
	@Test
	public void test1890() {
		o.launch(0, false, false, 1, false, true, 4, false, true);
	}
	@Test
	public void test1891() {
		o.launch(0, false, false, 1, false, true, 4, false, false);
	}
	@Test
	public void test1892() {
		o.launch(0, false, false, 1, false, true, 10, true, true);
	}
	@Test
	public void test1893() {
		o.launch(0, false, false, 1, false, true, 10, true, false);
	}
	@Test
	public void test1894() {
		o.launch(0, false, false, 1, false, true, -1, false, true);
	}
	@Test
	public void test1895() {
		o.launch(0, false, false, 1, false, true, 10, false, false);
	}
	@Test
	public void test1896() {
		o.launch(0, false, false, 1, false, false, 0, true, true);
	}
	@Test
	public void test1897() {
		o.launch(0, false, false, 1, false, false, 0, true, false);
	}
	@Test
	public void test1898() {
		o.launch(0, false, false, 1, false, false, 0, false, true);
	}
	@Test
	public void test1899() {
		o.launch(0, false, false, 1, false, false, 0, false, false);
	}
	@Test
	public void test1900() {
		o.launch(0, false, false, 1, false, false, 1, true, true);
	}
	@Test
	public void test1901() {
		o.launch(0, false, false, 1, false, false, 1, true, false);
	}
	@Test
	public void test1902() {
		o.launch(0, false, false, 1, false, false, 1, false, true);
	}
	@Test
	public void test1903() {
		o.launch(0, false, false, 1, false, false, 1, false, false);
	}
	@Test
	public void test1904() {
		o.launch(0, false, false, 1, false, false, 2, true, true);
	}
	@Test
	public void test1905() {
		o.launch(0, false, false, 1, false, false, 2, true, false);
	}
	@Test
	public void test1906() {
		o.launch(0, false, false, 1, false, false, 2, false, true);
	}
	@Test
	public void test1907() {
		o.launch(0, false, false, 1, false, false, 2, false, false);
	}
	@Test
	public void test1908() {
		o.launch(0, false, false, 1, false, false, 3, true, true);
	}
	@Test
	public void test1909() {
		o.launch(0, false, false, 1, false, false, 3, true, false);
	}
	@Test
	public void test1910() {
		o.launch(0, false, false, 1, false, false, 3, false, true);
	}
	@Test
	public void test1911() {
		o.launch(0, false, false, 1, false, false, 3, false, false);
	}
	@Test
	public void test1912() {
		o.launch(0, false, false, 1, false, false, 4, true, true);
	}
	@Test
	public void test1913() {
		o.launch(0, false, false, 1, false, false, 4, true, false);
	}
	@Test
	public void test1914() {
		o.launch(0, false, false, 1, false, false, 4, false, true);
	}
	@Test
	public void test1915() {
		o.launch(0, false, false, 1, false, false, 4, false, false);
	}
	@Test
	public void test1916() {
		o.launch(0, false, false, 1, false, false, -1, true, true);
	}
	@Test
	public void test1917() {
		o.launch(0, false, false, 1, false, false, 100, true, false);
	}
	@Test
	public void test1918() {
		o.launch(0, false, false, 1, false, false, -1, false, true);
	}
	@Test
	public void test1919() {
		o.launch(0, false, false, 1, false, false, -1, false, false);
	}
	@Test
	public void test1920() {
		o.launch(0, false, false, 2, true, true, 0, true, true);
	}
	@Test
	public void test1921() {
		o.launch(0, false, false, 2, true, true, 0, true, false);
	}
	@Test
	public void test1922() {
		o.launch(0, false, false, 2, true, true, 0, false, true);
	}
	@Test
	public void test1923() {
		o.launch(0, false, false, 2, true, true, 0, false, false);
	}
	@Test
	public void test1924() {
		o.launch(0, false, false, 2, true, true, 1, true, true);
	}
	@Test
	public void test1925() {
		o.launch(0, false, false, 2, true, true, 1, true, false);
	}
	@Test
	public void test1926() {
		o.launch(0, false, false, 2, true, true, 1, false, true);
	}
	@Test
	public void test1927() {
		o.launch(0, false, false, 2, true, true, 1, false, false);
	}
	@Test
	public void test1928() {
		o.launch(0, false, false, 2, true, true, 2, true, true);
	}
	@Test
	public void test1929() {
		o.launch(0, false, false, 2, true, true, 2, true, false);
	}
	@Test
	public void test1930() {
		o.launch(0, false, false, 2, true, true, 2, false, true);
	}
	@Test
	public void test1931() {
		o.launch(0, false, false, 2, true, true, 2, false, false);
	}
	@Test
	public void test1932() {
		o.launch(0, false, false, 2, true, true, 3, true, true);
	}
	@Test
	public void test1933() {
		o.launch(0, false, false, 2, true, true, 3, true, false);
	}
	@Test
	public void test1934() {
		o.launch(0, false, false, 2, true, true, 3, false, true);
	}
	@Test
	public void test1935() {
		o.launch(0, false, false, 2, true, true, 3, false, false);
	}
	@Test
	public void test1936() {
		o.launch(0, false, false, 2, true, true, 4, true, true);
	}
	@Test
	public void test1937() {
		o.launch(0, false, false, 2, true, true, 4, true, false);
	}
	@Test
	public void test1938() {
		o.launch(0, false, false, 2, true, true, 4, false, true);
	}
	@Test
	public void test1939() {
		o.launch(0, false, false, 2, true, true, 4, false, false);
	}
	@Test
	public void test1940() {
		o.launch(0, false, false, 2, true, true, 5, true, true);
	}
	@Test
	public void test1941() {
		o.launch(0, false, false, 2, true, true, 5, true, false);
	}
	@Test
	public void test1942() {
		o.launch(0, false, false, 2, true, true, 5, false, true);
	}
	@Test
	public void test1943() {
		o.launch(0, false, false, 2, true, true, 5, false, false);
	}
	@Test
	public void test1944() {
		o.launch(0, false, false, 2, true, false, 0, true, true);
	}
	@Test
	public void test1945() {
		o.launch(0, false, false, 2, true, false, 0, true, false);
	}
	@Test
	public void test1946() {
		o.launch(0, false, false, 2, true, false, 0, false, true);
	}
	@Test
	public void test1947() {
		o.launch(0, false, false, 2, true, false, 0, false, false);
	}
	@Test
	public void test1948() {
		o.launch(0, false, false, 2, true, false, 1, true, true);
	}
	@Test
	public void test1949() {
		o.launch(0, false, false, 2, true, false, 1, true, false);
	}
	@Test
	public void test1950() {
		o.launch(0, false, false, 2, true, false, 1, false, true);
	}
	@Test
	public void test1951() {
		o.launch(0, false, false, 2, true, false, 1, false, false);
	}
	@Test
	public void test1952() {
		o.launch(0, false, false, 2, true, false, 2, true, true);
	}
	@Test
	public void test1953() {
		o.launch(0, false, false, 2, true, false, 2, true, false);
	}
	@Test
	public void test1954() {
		o.launch(0, false, false, 2, true, false, 2, false, true);
	}
	@Test
	public void test1955() {
		o.launch(0, false, false, 2, true, false, 2, false, false);
	}
	@Test
	public void test1956() {
		o.launch(0, false, false, 2, true, false, 3, true, true);
	}
	@Test
	public void test1957() {
		o.launch(0, false, false, 2, true, false, 3, true, false);
	}
	@Test
	public void test1958() {
		o.launch(0, false, false, 2, true, false, 3, false, true);
	}
	@Test
	public void test1959() {
		o.launch(0, false, false, 2, true, false, 3, false, false);
	}
	@Test
	public void test1960() {
		o.launch(0, false, false, 2, true, false, 4, true, true);
	}
	@Test
	public void test1961() {
		o.launch(0, false, false, 2, true, false, 4, true, false);
	}
	@Test
	public void test1962() {
		o.launch(0, false, false, 2, true, false, 4, false, true);
	}
	@Test
	public void test1963() {
		o.launch(0, false, false, 2, true, false, 4, false, false);
	}
	@Test
	public void test1964() {
		o.launch(0, false, false, 2, true, false, 5, true, true);
	}
	@Test
	public void test1965() {
		o.launch(0, false, false, 2, true, false, 5, true, false);
	}
	@Test
	public void test1966() {
		o.launch(0, false, false, 2, true, false, 5, false, true);
	}
	@Test
	public void test1967() {
		o.launch(0, false, false, 2, true, false, 5, false, false);
	}
	@Test
	public void test1968() {
		o.launch(0, false, false, 2, false, true, 0, true, true);
	}
	@Test
	public void test1969() {
		o.launch(0, false, false, 2, false, true, 0, true, false);
	}
	@Test
	public void test1970() {
		o.launch(0, false, false, 2, false, true, 0, false, true);
	}
	@Test
	public void test1971() {
		o.launch(0, false, false, 2, false, true, 0, false, false);
	}
	@Test
	public void test1972() {
		o.launch(0, false, false, 2, false, true, 1, true, true);
	}
	@Test
	public void test1973() {
		o.launch(0, false, false, 2, false, true, 1, true, false);
	}
	@Test
	public void test1974() {
		o.launch(0, false, false, 2, false, true, 1, false, true);
	}
	@Test
	public void test1975() {
		o.launch(0, false, false, 2, false, true, 1, false, false);
	}
	@Test
	public void test1976() {
		o.launch(0, false, false, 2, false, true, 2, true, true);
	}
	@Test
	public void test1977() {
		o.launch(0, false, false, 2, false, true, 2, true, false);
	}
	@Test
	public void test1978() {
		o.launch(0, false, false, 2, false, true, 2, false, true);
	}
	@Test
	public void test1979() {
		o.launch(0, false, false, 2, false, true, 2, false, false);
	}
	@Test
	public void test1980() {
		o.launch(0, false, false, 2, false, true, 3, true, true);
	}
	@Test
	public void test1981() {
		o.launch(0, false, false, 2, false, true, 3, true, false);
	}
	@Test
	public void test1982() {
		o.launch(0, false, false, 2, false, true, 3, false, true);
	}
	@Test
	public void test1983() {
		o.launch(0, false, false, 2, false, true, 3, false, false);
	}
	@Test
	public void test1984() {
		o.launch(0, false, false, 2, false, true, 4, true, true);
	}
	@Test
	public void test1985() {
		o.launch(0, false, false, 2, false, true, 4, true, false);
	}
	@Test
	public void test1986() {
		o.launch(0, false, false, 2, false, true, 4, false, true);
	}
	@Test
	public void test1987() {
		o.launch(0, false, false, 2, false, true, 4, false, false);
	}
	@Test
	public void test1988() {
		o.launch(0, false, false, 2, false, true, 5, true, true);
	}
	@Test
	public void test1989() {
		o.launch(0, false, false, 2, false, true, 5, true, false);
	}
	@Test
	public void test1990() {
		o.launch(0, false, false, 2, false, true, 5, false, true);
	}
	@Test
	public void test1991() {
		o.launch(0, false, false, 2, false, true, 5, false, false);
	}
	@Test
	public void test1992() {
		o.launch(0, false, false, 2, false, false, 0, true, true);
	}
	@Test
	public void test1993() {
		o.launch(0, false, false, 2, false, false, 0, true, false);
	}
	@Test
	public void test1994() {
		o.launch(0, false, false, 2, false, false, 0, false, true);
	}
	@Test
	public void test1995() {
		o.launch(0, false, false, 2, false, false, 0, false, false);
	}
	@Test
	public void test1996() {
		o.launch(0, false, false, 2, false, false, 1, true, true);
	}
	@Test
	public void test1997() {
		o.launch(0, false, false, 2, false, false, 1, true, false);
	}
	@Test
	public void test1998() {
		o.launch(0, false, false, 2, false, false, 1, false, true);
	}
	@Test
	public void test1999() {
		o.launch(0, false, false, 2, false, false, 1, false, false);
	}
	@Test
	public void test2000() {
		o.launch(0, false, false, 2, false, false, 2, true, true);
	}
	@Test
	public void test2001() {
		o.launch(0, false, false, 2, false, false, 2, true, false);
	}
	@Test
	public void test2002() {
		o.launch(0, false, false, 2, false, false, 2, false, true);
	}
	@Test
	public void test2003() {
		o.launch(0, false, false, 2, false, false, 2, false, false);
	}
	@Test
	public void test2004() {
		o.launch(0, false, false, 2, false, false, 3, true, true);
	}
	@Test
	public void test2005() {
		o.launch(0, false, false, 2, false, false, 3, true, false);
	}
	@Test
	public void test2006() {
		o.launch(0, false, false, 2, false, false, 3, false, true);
	}
	@Test
	public void test2007() {
		o.launch(0, false, false, 2, false, false, 3, false, false);
	}
	@Test
	public void test2008() {
		o.launch(0, false, false, 2, false, false, 4, true, true);
	}
	@Test
	public void test2009() {
		o.launch(0, false, false, 2, false, false, 4, true, false);
	}
	@Test
	public void test2010() {
		o.launch(0, false, false, 2, false, false, 4, false, true);
	}
	@Test
	public void test2011() {
		o.launch(0, false, false, 2, false, false, 4, false, false);
	}
	@Test
	public void test2012() {
		o.launch(0, false, false, 2, false, false, 5, true, true);
	}
	@Test
	public void test2013() {
		o.launch(0, false, false, 2, false, false, 5, true, false);
	}
	@Test
	public void test2014() {
		o.launch(0, false, false, 2, false, false, 5, false, true);
	}
	@Test
	public void test2015() {
		o.launch(0, false, false, 2, false, false, 5, false, false);
	}
	@Test
	public void test2016() {
		o.launch(0, false, false, 3, true, true, 0, true, true);
	}
	@Test
	public void test2017() {
		o.launch(0, false, false, 3, true, true, 0, true, false);
	}
	@Test
	public void test2018() {
		o.launch(0, false, false, 3, true, true, 0, false, true);
	}
	@Test
	public void test2019() {
		o.launch(0, false, false, 3, true, true, 0, false, false);
	}
	@Test
	public void test2020() {
		o.launch(0, false, false, 3, true, true, 1, true, true);
	}
	@Test
	public void test2021() {
		o.launch(0, false, false, 3, true, true, 1, true, false);
	}
	@Test
	public void test2022() {
		o.launch(0, false, false, 3, true, true, 1, false, true);
	}
	@Test
	public void test2023() {
		o.launch(0, false, false, 3, true, true, 1, false, false);
	}
	@Test
	public void test2024() {
		o.launch(0, false, false, 3, true, true, 2, true, true);
	}
	@Test
	public void test2025() {
		o.launch(0, false, false, 3, true, true, 2, true, false);
	}
	@Test
	public void test2026() {
		o.launch(0, false, false, 3, true, true, 2, false, true);
	}
	@Test
	public void test2027() {
		o.launch(0, false, false, 3, true, true, 2, false, false);
	}
	@Test
	public void test2028() {
		o.launch(0, false, false, 3, true, true, 3, true, true);
	}
	@Test
	public void test2029() {
		o.launch(0, false, false, 3, true, true, 3, true, false);
	}
	@Test
	public void test2030() {
		o.launch(0, false, false, 3, true, true, 3, false, true);
	}
	@Test
	public void test2031() {
		o.launch(0, false, false, 3, true, true, 3, false, false);
	}
	@Test
	public void test2032() {
		o.launch(0, false, false, 3, true, true, 4, true, true);
	}
	@Test
	public void test2033() {
		o.launch(0, false, false, 3, true, true, 4, true, false);
	}
	@Test
	public void test2034() {
		o.launch(0, false, false, 3, true, true, 4, false, true);
	}
	@Test
	public void test2035() {
		o.launch(0, false, false, 3, true, true, 4, false, false);
	}
	@Test
	public void test2036() {
		o.launch(0, false, false, 3, true, true, 5, true, true);
	}
	@Test
	public void test2037() {
		o.launch(0, false, false, 3, true, true, 5, true, false);
	}
	@Test
	public void test2038() {
		o.launch(0, false, false, 3, true, true, 5, false, true);
	}
	@Test
	public void test2039() {
		o.launch(0, false, false, 3, true, true, 5, false, false);
	}
	@Test
	public void test2040() {
		o.launch(0, false, false, 3, true, false, 0, true, true);
	}
	@Test
	public void test2041() {
		o.launch(0, false, false, 3, true, false, 0, true, false);
	}
	@Test
	public void test2042() {
		o.launch(0, false, false, 3, true, false, 0, false, true);
	}
	@Test
	public void test2043() {
		o.launch(0, false, false, 3, true, false, 0, false, false);
	}
	@Test
	public void test2044() {
		o.launch(0, false, false, 3, true, false, 1, true, true);
	}
	@Test
	public void test2045() {
		o.launch(0, false, false, 3, true, false, 1, true, false);
	}
	@Test
	public void test2046() {
		o.launch(0, false, false, 3, true, false, 1, false, true);
	}
	@Test
	public void test2047() {
		o.launch(0, false, false, 3, true, false, 1, false, false);
	}
	@Test
	public void test2048() {
		o.launch(0, false, false, 3, true, false, 2, true, true);
	}
	@Test
	public void test2049() {
		o.launch(0, false, false, 3, true, false, 2, true, false);
	}
	@Test
	public void test2050() {
		o.launch(0, false, false, 3, true, false, 2, false, true);
	}
	@Test
	public void test2051() {
		o.launch(0, false, false, 3, true, false, 2, false, false);
	}
	@Test
	public void test2052() {
		o.launch(0, false, false, 3, true, false, 3, true, true);
	}
	@Test
	public void test2053() {
		o.launch(0, false, false, 3, true, false, 3, true, false);
	}
	@Test
	public void test2054() {
		o.launch(0, false, false, 3, true, false, 3, false, true);
	}
	@Test
	public void test2055() {
		o.launch(0, false, false, 3, true, false, 3, false, false);
	}
	@Test
	public void test2056() {
		o.launch(0, false, false, 3, true, false, 4, true, true);
	}
	@Test
	public void test2057() {
		o.launch(0, false, false, 3, true, false, 4, true, false);
	}
	@Test
	public void test2058() {
		o.launch(0, false, false, 3, true, false, 4, false, true);
	}
	@Test
	public void test2059() {
		o.launch(0, false, false, 3, true, false, 4, false, false);
	}
	@Test
	public void test2060() {
		o.launch(0, false, false, 3, true, false, 5, true, true);
	}
	@Test
	public void test2061() {
		o.launch(0, false, false, 3, true, false, 5, true, false);
	}
	@Test
	public void test2062() {
		o.launch(0, false, false, 3, true, false, 5, false, true);
	}
	@Test
	public void test2063() {
		o.launch(0, false, false, 3, true, false, 5, false, false);
	}
	@Test
	public void test2064() {
		o.launch(0, false, false, 3, false, true, 0, true, true);
	}
	@Test
	public void test2065() {
		o.launch(0, false, false, 3, false, true, 0, true, false);
	}
	@Test
	public void test2066() {
		o.launch(0, false, false, 3, false, true, 0, false, true);
	}
	@Test
	public void test2067() {
		o.launch(0, false, false, 3, false, true, 0, false, false);
	}
	@Test
	public void test2068() {
		o.launch(0, false, false, 3, false, true, 1, true, true);
	}
	@Test
	public void test2069() {
		o.launch(0, false, false, 3, false, true, 1, true, false);
	}
	@Test
	public void test2070() {
		o.launch(0, false, false, 3, false, true, 1, false, true);
	}
	@Test
	public void test2071() {
		o.launch(0, false, false, 3, false, true, 1, false, false);
	}
	@Test
	public void test2072() {
		o.launch(0, false, false, 3, false, true, 2, true, true);
	}
	@Test
	public void test2073() {
		o.launch(0, false, false, 3, false, true, 2, true, false);
	}
	@Test
	public void test2074() {
		o.launch(0, false, false, 3, false, true, 2, false, true);
	}
	@Test
	public void test2075() {
		o.launch(0, false, false, 3, false, true, 2, false, false);
	}
	@Test
	public void test2076() {
		o.launch(0, false, false, 3, false, true, 3, true, true);
	}
	@Test
	public void test2077() {
		o.launch(0, false, false, 3, false, true, 3, true, false);
	}
	@Test
	public void test2078() {
		o.launch(0, false, false, 3, false, true, 3, false, true);
	}
	@Test
	public void test2079() {
		o.launch(0, false, false, 3, false, true, 3, false, false);
	}
	@Test
	public void test2080() {
		o.launch(0, false, false, 3, false, true, 4, true, true);
	}
	@Test
	public void test2081() {
		o.launch(0, false, false, 3, false, true, 4, true, false);
	}
	@Test
	public void test2082() {
		o.launch(0, false, false, 3, false, true, 4, false, true);
	}
	@Test
	public void test2083() {
		o.launch(0, false, false, 3, false, true, 4, false, false);
	}
	@Test
	public void test2084() {
		o.launch(0, false, false, 3, false, true, 5, true, true);
	}
	@Test
	public void test2085() {
		o.launch(0, false, false, 3, false, true, 5, true, false);
	}
	@Test
	public void test2086() {
		o.launch(0, false, false, 3, false, true, 5, false, true);
	}
	@Test
	public void test2087() {
		o.launch(0, false, false, 3, false, true, 5, false, false);
	}
	@Test
	public void test2088() {
		o.launch(0, false, false, 3, false, false, 0, true, true);
	}
	@Test
	public void test2089() {
		o.launch(0, false, false, 3, false, false, 0, true, false);
	}
	@Test
	public void test2090() {
		o.launch(0, false, false, 3, false, false, 0, false, true);
	}
	@Test
	public void test2091() {
		o.launch(0, false, false, 3, false, false, 0, false, false);
	}
	@Test
	public void test2092() {
		o.launch(0, false, false, 3, false, false, 1, true, true);
	}
	@Test
	public void test2093() {
		o.launch(0, false, false, 3, false, false, 1, true, false);
	}
	@Test
	public void test2094() {
		o.launch(0, false, false, 3, false, false, 1, false, true);
	}
	@Test
	public void test2095() {
		o.launch(0, false, false, 3, false, false, 1, false, false);
	}
	@Test
	public void test2096() {
		o.launch(0, false, false, 3, false, false, 2, true, true);
	}
	@Test
	public void test2097() {
		o.launch(0, false, false, 3, false, false, 2, true, false);
	}
	@Test
	public void test2098() {
		o.launch(0, false, false, 3, false, false, 2, false, true);
	}
	@Test
	public void test2099() {
		o.launch(0, false, false, 3, false, false, 2, false, false);
	}
	@Test
	public void test2100() {
		o.launch(0, false, false, 3, false, false, 3, true, true);
	}
	@Test
	public void test2101() {
		o.launch(0, false, false, 3, false, false, 3, true, false);
	}
	@Test
	public void test2102() {
		o.launch(0, false, false, 3, false, false, 3, false, true);
	}
	@Test
	public void test2103() {
		o.launch(0, false, false, 3, false, false, 3, false, false);
	}
	@Test
	public void test2104() {
		o.launch(0, false, false, 3, false, false, 4, true, true);
	}
	@Test
	public void test2105() {
		o.launch(0, false, false, 3, false, false, 4, true, false);
	}
	@Test
	public void test2106() {
		o.launch(0, false, false, 3, false, false, 4, false, true);
	}
	@Test
	public void test2107() {
		o.launch(0, false, false, 3, false, false, 4, false, false);
	}
	@Test
	public void test2108() {
		o.launch(0, false, false, 3, false, false, 5, true, true);
	}
	@Test
	public void test2109() {
		o.launch(0, false, false, 3, false, false, 5, true, false);
	}
	@Test
	public void test2110() {
		o.launch(0, false, false, 3, false, false, 5, false, true);
	}
	@Test
	public void test2111() {
		o.launch(0, false, false, 3, false, false, 5, false, false);
	}
	@Test
	public void test2112() {
		o.launch(0, false, false, 4, true, true, 0, true, true);
	}
	@Test
	public void test2113() {
		o.launch(0, false, false, 4, true, true, 0, true, false);
	}
	@Test
	public void test2114() {
		o.launch(0, false, false, 4, true, true, 0, false, true);
	}
	@Test
	public void test2115() {
		o.launch(0, false, false, 4, true, true, 0, false, false);
	}
	@Test
	public void test2116() {
		o.launch(0, false, false, 4, true, true, 1, true, true);
	}
	@Test
	public void test2117() {
		o.launch(0, false, false, 4, true, true, 1, true, false);
	}
	@Test
	public void test2118() {
		o.launch(0, false, false, 4, true, true, 1, false, true);
	}
	@Test
	public void test2119() {
		o.launch(0, false, false, 4, true, true, 1, false, false);
	}
	@Test
	public void test2120() {
		o.launch(0, false, false, 4, true, true, 2, true, true);
	}
	@Test
	public void test2121() {
		o.launch(0, false, false, 4, true, true, 2, true, false);
	}
	@Test
	public void test2122() {
		o.launch(0, false, false, 4, true, true, 2, false, true);
	}
	@Test
	public void test2123() {
		o.launch(0, false, false, 4, true, true, 2, false, false);
	}
	@Test
	public void test2124() {
		o.launch(0, false, false, 4, true, true, 3, true, true);
	}
	@Test
	public void test2125() {
		o.launch(0, false, false, 4, true, true, 3, true, false);
	}
	@Test
	public void test2126() {
		o.launch(0, false, false, 4, true, true, 3, false, true);
	}
	@Test
	public void test2127() {
		o.launch(0, false, false, 4, true, true, 3, false, false);
	}
	@Test
	public void test2128() {
		o.launch(0, false, false, 4, true, true, 4, true, true);
	}
	@Test
	public void test2129() {
		o.launch(0, false, false, 4, true, true, 4, true, false);
	}
	@Test
	public void test2130() {
		o.launch(0, false, false, 4, true, true, 4, false, true);
	}
	@Test
	public void test2131() {
		o.launch(0, false, false, 4, true, true, 4, false, false);
	}
	@Test
	public void test2132() {
		o.launch(0, false, false, 4, true, true, 10, true, true);
	}
	@Test
	public void test2133() {
		o.launch(0, false, false, 4, true, true, 5, true, false);
	}
	@Test
	public void test2134() {
		o.launch(0, false, false, 4, true, true, -1, false, true);
	}
	@Test
	public void test2135() {
		o.launch(0, false, false, 4, true, true, -1, false, false);
	}
	@Test
	public void test2136() {
		o.launch(0, false, false, 4, true, false, 0, true, true);
	}
	@Test
	public void test2137() {
		o.launch(0, false, false, 4, true, false, 0, true, false);
	}
	@Test
	public void test2138() {
		o.launch(0, false, false, 4, true, false, 0, false, true);
	}
	@Test
	public void test2139() {
		o.launch(0, false, false, 4, true, false, 0, false, false);
	}
	@Test
	public void test2140() {
		o.launch(0, false, false, 4, true, false, 1, true, true);
	}
	@Test
	public void test2141() {
		o.launch(0, false, false, 4, true, false, 1, true, false);
	}
	@Test
	public void test2142() {
		o.launch(0, false, false, 4, true, false, 1, false, true);
	}
	@Test
	public void test2143() {
		o.launch(0, false, false, 4, true, false, 1, false, false);
	}
	@Test
	public void test2144() {
		o.launch(0, false, false, 4, true, false, 2, true, true);
	}
	@Test
	public void test2145() {
		o.launch(0, false, false, 4, true, false, 2, true, false);
	}
	@Test
	public void test2146() {
		o.launch(0, false, false, 4, true, false, 2, false, true);
	}
	@Test
	public void test2147() {
		o.launch(0, false, false, 4, true, false, 2, false, false);
	}
	@Test
	public void test2148() {
		o.launch(0, false, false, 4, true, false, 3, true, true);
	}
	@Test
	public void test2149() {
		o.launch(0, false, false, 4, true, false, 3, true, false);
	}
	@Test
	public void test2150() {
		o.launch(0, false, false, 4, true, false, 3, false, true);
	}
	@Test
	public void test2151() {
		o.launch(0, false, false, 4, true, false, 3, false, false);
	}
	@Test
	public void test2152() {
		o.launch(0, false, false, 4, true, false, 4, true, true);
	}
	@Test
	public void test2153() {
		o.launch(0, false, false, 4, true, false, 4, true, false);
	}
	@Test
	public void test2154() {
		o.launch(0, false, false, 4, true, false, 4, false, true);
	}
	@Test
	public void test2155() {
		o.launch(0, false, false, 4, true, false, 4, false, false);
	}
	@Test
	public void test2156() {
		o.launch(0, false, false, 4, true, false, 100, true, true);
	}
	@Test
	public void test2157() {
		o.launch(0, false, false, 4, true, false, -1, true, false);
	}
	@Test
	public void test2158() {
		o.launch(0, false, false, 4, true, false, 100, false, true);
	}
	@Test
	public void test2159() {
		o.launch(0, false, false, 4, true, false, 100, false, false);
	}
	@Test
	public void test2160() {
		o.launch(0, false, false, 4, false, true, 0, true, true);
	}
	@Test
	public void test2161() {
		o.launch(0, false, false, 4, false, true, 0, true, false);
	}
	@Test
	public void test2162() {
		o.launch(0, false, false, 4, false, true, 0, false, true);
	}
	@Test
	public void test2163() {
		o.launch(0, false, false, 4, false, true, 0, false, false);
	}
	@Test
	public void test2164() {
		o.launch(0, false, false, 4, false, true, 1, true, true);
	}
	@Test
	public void test2165() {
		o.launch(0, false, false, 4, false, true, 1, true, false);
	}
	@Test
	public void test2166() {
		o.launch(0, false, false, 4, false, true, 1, false, true);
	}
	@Test
	public void test2167() {
		o.launch(0, false, false, 4, false, true, 1, false, false);
	}
	@Test
	public void test2168() {
		o.launch(0, false, false, 4, false, true, 2, true, true);
	}
	@Test
	public void test2169() {
		o.launch(0, false, false, 4, false, true, 2, true, false);
	}
	@Test
	public void test2170() {
		o.launch(0, false, false, 4, false, true, 2, false, true);
	}
	@Test
	public void test2171() {
		o.launch(0, false, false, 4, false, true, 2, false, false);
	}
	@Test
	public void test2172() {
		o.launch(0, false, false, 4, false, true, 3, true, true);
	}
	@Test
	public void test2173() {
		o.launch(0, false, false, 4, false, true, 3, true, false);
	}
	@Test
	public void test2174() {
		o.launch(0, false, false, 4, false, true, 3, false, true);
	}
	@Test
	public void test2175() {
		o.launch(0, false, false, 4, false, true, 3, false, false);
	}
	@Test
	public void test2176() {
		o.launch(0, false, false, 4, false, true, 4, true, true);
	}
	@Test
	public void test2177() {
		o.launch(0, false, false, 4, false, true, 4, true, false);
	}
	@Test
	public void test2178() {
		o.launch(0, false, false, 4, false, true, 4, false, true);
	}
	@Test
	public void test2179() {
		o.launch(0, false, false, 4, false, true, 4, false, false);
	}
	@Test
	public void test2180() {
		o.launch(0, false, false, 4, false, true, 5, true, true);
	}
	@Test
	public void test2181() {
		o.launch(0, false, false, 4, false, true, 5, true, false);
	}
	@Test
	public void test2182() {
		o.launch(0, false, false, 4, false, true, -1, false, true);
	}
	@Test
	public void test2183() {
		o.launch(0, false, false, 4, false, true, 5, false, false);
	}
	@Test
	public void test2184() {
		o.launch(0, false, false, 4, false, false, 0, true, true);
	}
	@Test
	public void test2185() {
		o.launch(0, false, false, 4, false, false, 0, true, false);
	}
	@Test
	public void test2186() {
		o.launch(0, false, false, 4, false, false, 0, false, true);
	}
	@Test
	public void test2187() {
		o.launch(0, false, false, 4, false, false, 0, false, false);
	}
	@Test
	public void test2188() {
		o.launch(0, false, false, 4, false, false, 1, true, true);
	}
	@Test
	public void test2189() {
		o.launch(0, false, false, 4, false, false, 1, true, false);
	}
	@Test
	public void test2190() {
		o.launch(0, false, false, 4, false, false, 1, false, true);
	}
	@Test
	public void test2191() {
		o.launch(0, false, false, 4, false, false, 1, false, false);
	}
	@Test
	public void test2192() {
		o.launch(0, false, false, 4, false, false, 2, true, true);
	}
	@Test
	public void test2193() {
		o.launch(0, false, false, 4, false, false, 2, true, false);
	}
	@Test
	public void test2194() {
		o.launch(0, false, false, 4, false, false, 2, false, true);
	}
	@Test
	public void test2195() {
		o.launch(0, false, false, 4, false, false, 2, false, false);
	}
	@Test
	public void test2196() {
		o.launch(0, false, false, 4, false, false, 3, true, true);
	}
	@Test
	public void test2197() {
		o.launch(0, false, false, 4, false, false, 3, true, false);
	}
	@Test
	public void test2198() {
		o.launch(0, false, false, 4, false, false, 3, false, true);
	}
	@Test
	public void test2199() {
		o.launch(0, false, false, 4, false, false, 3, false, false);
	}
	@Test
	public void test2200() {
		o.launch(0, false, false, 4, false, false, 4, true, true);
	}
	@Test
	public void test2201() {
		o.launch(0, false, false, 4, false, false, 4, true, false);
	}
	@Test
	public void test2202() {
		o.launch(0, false, false, 4, false, false, 4, false, true);
	}
	@Test
	public void test2203() {
		o.launch(0, false, false, 4, false, false, 4, false, false);
	}
	@Test
	public void test2204() {
		o.launch(0, false, false, 4, false, false, 5, true, true);
	}
	@Test
	public void test2205() {
		o.launch(0, false, false, 4, false, false, -1, true, false);
	}
	@Test
	public void test2206() {
		o.launch(0, false, false, 4, false, false, -1, false, true);
	}
	@Test
	public void test2207() {
		o.launch(0, false, false, 4, false, false, 5, false, false);
	}
	@Test
	public void test2208() {
		o.launch(0, false, false, 10, true, true, 0, true, true);
	}
	@Test
	public void test2209() {
		o.launch(0, false, false, -1, true, true, 0, true, false);
	}
	@Test
	public void test2210() {
		o.launch(0, false, false, 10, true, true, 0, false, true);
	}
	@Test
	public void test2211() {
		o.launch(0, false, false, 10, true, true, 0, false, false);
	}
	@Test
	public void test2212() {
		o.launch(0, false, false, 10, true, true, 1, true, true);
	}
	@Test
	public void test2213() {
		o.launch(0, false, false, -1, true, true, 1, true, false);
	}
	@Test
	public void test2214() {
		o.launch(0, false, false, -1, true, true, 1, false, true);
	}
	@Test
	public void test2215() {
		o.launch(0, false, false, -1, true, true, 1, false, false);
	}
	@Test
	public void test2216() {
		o.launch(0, false, false, 5, true, true, 2, true, true);
	}
	@Test
	public void test2217() {
		o.launch(0, false, false, 5, true, true, 2, true, false);
	}
	@Test
	public void test2218() {
		o.launch(0, false, false, 5, true, true, 2, false, true);
	}
	@Test
	public void test2219() {
		o.launch(0, false, false, 5, true, true, 2, false, false);
	}
	@Test
	public void test2220() {
		o.launch(0, false, false, 5, true, true, 3, true, true);
	}
	@Test
	public void test2221() {
		o.launch(0, false, false, 5, true, true, 3, true, false);
	}
	@Test
	public void test2222() {
		o.launch(0, false, false, 5, true, true, 3, false, true);
	}
	@Test
	public void test2223() {
		o.launch(0, false, false, 5, true, true, 3, false, false);
	}
	@Test
	public void test2224() {
		o.launch(0, false, false, -1, true, true, 4, true, true);
	}
	@Test
	public void test2225() {
		o.launch(0, false, false, 5, true, true, 4, true, false);
	}
	@Test
	public void test2226() {
		o.launch(0, false, false, -1, true, true, 4, false, true);
	}
	@Test
	public void test2227() {
		o.launch(0, false, false, 5, true, true, 4, false, false);
	}
	@Test
	public void test2228() {
		o.launch(0, false, false, 10, true, true, -1, true, true);
	}
	@Test
	public void test2229() {
		o.launch(0, false, false, -1, true, true, -1, true, false);
	}
	@Test
	public void test2230() {
		o.launch(0, false, false, -1, true, true, 10, false, true);
	}
	@Test
	public void test2231() {
		o.launch(0, false, false, -1, true, true, 10, false, false);
	}
	@Test
	public void test2232() {
		o.launch(0, false, false, -1, true, false, 0, true, true);
	}
	@Test
	public void test2233() {
		o.launch(0, false, false, -1, true, false, 0, true, false);
	}
	@Test
	public void test2234() {
		o.launch(0, false, false, -1, true, false, 0, false, true);
	}
	@Test
	public void test2235() {
		o.launch(0, false, false, -1, true, false, 0, false, false);
	}
	@Test
	public void test2236() {
		o.launch(0, false, false, -1, true, false, 1, true, true);
	}
	@Test
	public void test2237() {
		o.launch(0, false, false, -1, true, false, 1, true, false);
	}
	@Test
	public void test2238() {
		o.launch(0, false, false, -1, true, false, 1, false, true);
	}
	@Test
	public void test2239() {
		o.launch(0, false, false, 10, true, false, 1, false, false);
	}
	@Test
	public void test2240() {
		o.launch(0, false, false, 5, true, false, 2, true, true);
	}
	@Test
	public void test2241() {
		o.launch(0, false, false, 5, true, false, 2, true, false);
	}
	@Test
	public void test2242() {
		o.launch(0, false, false, 5, true, false, 2, false, true);
	}
	@Test
	public void test2243() {
		o.launch(0, false, false, 5, true, false, 2, false, false);
	}
	@Test
	public void test2244() {
		o.launch(0, false, false, 5, true, false, 3, true, true);
	}
	@Test
	public void test2245() {
		o.launch(0, false, false, 5, true, false, 3, true, false);
	}
	@Test
	public void test2246() {
		o.launch(0, false, false, 5, true, false, 3, false, true);
	}
	@Test
	public void test2247() {
		o.launch(0, false, false, 5, true, false, 3, false, false);
	}
	@Test
	public void test2248() {
		o.launch(0, false, false, -1, true, false, 4, true, true);
	}
	@Test
	public void test2249() {
		o.launch(0, false, false, 100, true, false, 4, true, false);
	}
	@Test
	public void test2250() {
		o.launch(0, false, false, -1, true, false, 4, false, true);
	}
	@Test
	public void test2251() {
		o.launch(0, false, false, -1, true, false, 4, false, false);
	}
	@Test
	public void test2252() {
		o.launch(0, false, false, -1, true, false, -1, true, true);
	}
	@Test
	public void test2253() {
		o.launch(0, false, false, 100, true, false, 10, true, false);
	}
	@Test
	public void test2254() {
		o.launch(0, false, false, 100, true, false, 10, false, true);
	}
	@Test
	public void test2255() {
		o.launch(0, false, false, 10, true, false, 100, false, false);
	}
	@Test
	public void test2256() {
		o.launch(0, false, false, 100, false, true, 0, true, true);
	}
	@Test
	public void test2257() {
		o.launch(0, false, false, 100, false, true, 0, true, false);
	}
	@Test
	public void test2258() {
		o.launch(0, false, false, 100, false, true, 0, false, true);
	}
	@Test
	public void test2259() {
		o.launch(0, false, false, 100, false, true, 0, false, false);
	}
	@Test
	public void test2260() {
		o.launch(0, false, false, 5, false, true, 1, true, true);
	}
	@Test
	public void test2261() {
		o.launch(0, false, false, -1, false, true, 1, true, false);
	}
	@Test
	public void test2262() {
		o.launch(0, false, false, 100, false, true, 1, false, true);
	}
	@Test
	public void test2263() {
		o.launch(0, false, false, 5, false, true, 1, false, false);
	}
	@Test
	public void test2264() {
		o.launch(0, false, false, 5, false, true, 2, true, true);
	}
	@Test
	public void test2265() {
		o.launch(0, false, false, 5, false, true, 2, true, false);
	}
	@Test
	public void test2266() {
		o.launch(0, false, false, 5, false, true, 2, false, true);
	}
	@Test
	public void test2267() {
		o.launch(0, false, false, 5, false, true, 2, false, false);
	}
	@Test
	public void test2268() {
		o.launch(0, false, false, 5, false, true, 3, true, true);
	}
	@Test
	public void test2269() {
		o.launch(0, false, false, 5, false, true, 3, true, false);
	}
	@Test
	public void test2270() {
		o.launch(0, false, false, 5, false, true, 3, false, true);
	}
	@Test
	public void test2271() {
		o.launch(0, false, false, 5, false, true, 3, false, false);
	}
	@Test
	public void test2272() {
		o.launch(0, false, false, 5, false, true, 4, true, true);
	}
	@Test
	public void test2273() {
		o.launch(0, false, false, 100, false, true, 4, true, false);
	}
	@Test
	public void test2274() {
		o.launch(0, false, false, 10, false, true, 4, false, true);
	}
	@Test
	public void test2275() {
		o.launch(0, false, false, -1, false, true, 4, false, false);
	}
	@Test
	public void test2276() {
		o.launch(0, false, false, -1, false, true, -1, true, true);
	}
	@Test
	public void test2277() {
		o.launch(0, false, false, -1, false, true, -1, true, false);
	}
	@Test
	public void test2278() {
		o.launch(0, false, false, -1, false, true, -1, false, true);
	}
	@Test
	public void test2279() {
		o.launch(0, false, false, -1, false, true, -1, false, false);
	}
	@Test
	public void test2280() {
		o.launch(0, false, false, 10, false, false, 0, true, true);
	}
	@Test
	public void test2281() {
		o.launch(0, false, false, 10, false, false, 0, true, false);
	}
	@Test
	public void test2282() {
		o.launch(0, false, false, 10, false, false, 0, false, true);
	}
	@Test
	public void test2283() {
		o.launch(0, false, false, 10, false, false, 0, false, false);
	}
	@Test
	public void test2284() {
		o.launch(0, false, false, 10, false, false, 1, true, true);
	}
	@Test
	public void test2285() {
		o.launch(0, false, false, -1, false, false, 1, true, false);
	}
	@Test
	public void test2286() {
		o.launch(0, false, false, 10, false, false, 1, false, true);
	}
	@Test
	public void test2287() {
		o.launch(0, false, false, 10, false, false, 1, false, false);
	}
	@Test
	public void test2288() {
		o.launch(0, false, false, 5, false, false, 2, true, true);
	}
	@Test
	public void test2289() {
		o.launch(0, false, false, 5, false, false, 2, true, false);
	}
	@Test
	public void test2290() {
		o.launch(0, false, false, 5, false, false, 2, false, true);
	}
	@Test
	public void test2291() {
		o.launch(0, false, false, 5, false, false, 2, false, false);
	}
	@Test
	public void test2292() {
		o.launch(0, false, false, 5, false, false, 3, true, true);
	}
	@Test
	public void test2293() {
		o.launch(0, false, false, 5, false, false, 3, true, false);
	}
	@Test
	public void test2294() {
		o.launch(0, false, false, 5, false, false, 3, false, true);
	}
	@Test
	public void test2295() {
		o.launch(0, false, false, 5, false, false, 3, false, false);
	}
	@Test
	public void test2296() {
		o.launch(0, false, false, -1, false, false, 4, true, true);
	}
	@Test
	public void test2297() {
		o.launch(0, false, false, 10, false, false, 4, true, false);
	}
	@Test
	public void test2298() {
		o.launch(0, false, false, -1, false, false, 4, false, true);
	}
	@Test
	public void test2299() {
		o.launch(0, false, false, 5, false, false, 4, false, false);
	}
	@Test
	public void test2300() {
		o.launch(0, false, false, -1, false, false, 100, true, true);
	}
	@Test
	public void test2301() {
		o.launch(0, false, false, -1, false, false, 10, true, false);
	}
	@Test
	public void test2302() {
		o.launch(0, false, false, -1, false, false, 10, false, true);
	}
	@Test
	public void test2303() {
		o.launch(0, false, false, -1, false, false, 10, false, false);
	}
	@Test
	public void test2304() {
		o.launch(1, true, true, 0, true, true, 0, true, true);
	}
	@Test
	public void test2305() {
		o.launch(1, true, true, 0, true, true, 0, true, false);
	}
	@Test
	public void test2306() {
		o.launch(1, true, true, 0, true, true, 0, false, true);
	}
	@Test
	public void test2307() {
		o.launch(1, true, true, 0, true, true, 0, false, false);
	}
	@Test
	public void test2308() {
		o.launch(1, true, true, 0, true, true, 1, true, true);
	}
	@Test
	public void test2309() {
		o.launch(1, true, true, 0, true, true, 1, true, false);
	}
	@Test
	public void test2310() {
		o.launch(1, true, true, 0, true, true, 1, false, true);
	}
	@Test
	public void test2311() {
		o.launch(1, true, true, 0, true, true, 1, false, false);
	}
	@Test
	public void test2312() {
		o.launch(1, true, true, 0, true, true, 2, true, true);
	}
	@Test
	public void test2313() {
		o.launch(1, true, true, 0, true, true, 2, true, false);
	}
	@Test
	public void test2314() {
		o.launch(1, true, true, 0, true, true, 2, false, true);
	}
	@Test
	public void test2315() {
		o.launch(1, true, true, 0, true, true, 2, false, false);
	}
	@Test
	public void test2316() {
		o.launch(1, true, true, 0, true, true, 3, true, true);
	}
	@Test
	public void test2317() {
		o.launch(1, true, true, 0, true, true, 3, true, false);
	}
	@Test
	public void test2318() {
		o.launch(1, true, true, 0, true, true, 3, false, true);
	}
	@Test
	public void test2319() {
		o.launch(1, true, true, 0, true, true, 3, false, false);
	}
	@Test
	public void test2320() {
		o.launch(1, true, true, 0, true, true, 4, true, true);
	}
	@Test
	public void test2321() {
		o.launch(1, true, true, 0, true, true, 4, true, false);
	}
	@Test
	public void test2322() {
		o.launch(1, true, true, 0, true, true, 4, false, true);
	}
	@Test
	public void test2323() {
		o.launch(1, true, true, 0, true, true, 4, false, false);
	}
	@Test
	public void test2324() {
		o.launch(1, true, true, 0, true, true, 100, true, true);
	}
	@Test
	public void test2325() {
		o.launch(1, true, true, 0, true, true, 100, true, false);
	}
	@Test
	public void test2326() {
		o.launch(1, true, true, 0, true, true, -1, false, true);
	}
	@Test
	public void test2327() {
		o.launch(1, true, true, 0, true, true, 100, false, false);
	}
	@Test
	public void test2328() {
		o.launch(1, true, true, 0, true, false, 0, true, true);
	}
	@Test
	public void test2329() {
		o.launch(1, true, true, 0, true, false, 0, true, false);
	}
	@Test
	public void test2330() {
		o.launch(1, true, true, 0, true, false, 0, false, true);
	}
	@Test
	public void test2331() {
		o.launch(1, true, true, 0, true, false, 0, false, false);
	}
	@Test
	public void test2332() {
		o.launch(1, true, true, 0, true, false, 1, true, true);
	}
	@Test
	public void test2333() {
		o.launch(1, true, true, 0, true, false, 1, true, false);
	}
	@Test
	public void test2334() {
		o.launch(1, true, true, 0, true, false, 1, false, true);
	}
	@Test
	public void test2335() {
		o.launch(1, true, true, 0, true, false, 1, false, false);
	}
	@Test
	public void test2336() {
		o.launch(1, true, true, 0, true, false, 2, true, true);
	}
	@Test
	public void test2337() {
		o.launch(1, true, true, 0, true, false, 2, true, false);
	}
	@Test
	public void test2338() {
		o.launch(1, true, true, 0, true, false, 2, false, true);
	}
	@Test
	public void test2339() {
		o.launch(1, true, true, 0, true, false, 2, false, false);
	}
	@Test
	public void test2340() {
		o.launch(1, true, true, 0, true, false, 3, true, true);
	}
	@Test
	public void test2341() {
		o.launch(1, true, true, 0, true, false, 3, true, false);
	}
	@Test
	public void test2342() {
		o.launch(1, true, true, 0, true, false, 3, false, true);
	}
	@Test
	public void test2343() {
		o.launch(1, true, true, 0, true, false, 3, false, false);
	}
	@Test
	public void test2344() {
		o.launch(1, true, true, 0, true, false, 4, true, true);
	}
	@Test
	public void test2345() {
		o.launch(1, true, true, 0, true, false, 4, true, false);
	}
	@Test
	public void test2346() {
		o.launch(1, true, true, 0, true, false, 4, false, true);
	}
	@Test
	public void test2347() {
		o.launch(1, true, true, 0, true, false, 4, false, false);
	}
	@Test
	public void test2348() {
		o.launch(1, true, true, 0, true, false, -1, true, true);
	}
	@Test
	public void test2349() {
		o.launch(1, true, true, 0, true, false, 10, true, false);
	}
	@Test
	public void test2350() {
		o.launch(1, true, true, 0, true, false, 10, false, true);
	}
	@Test
	public void test2351() {
		o.launch(1, true, true, 0, true, false, 100, false, false);
	}
	@Test
	public void test2352() {
		o.launch(1, true, true, 0, false, true, 0, true, true);
	}
	@Test
	public void test2353() {
		o.launch(1, true, true, 0, false, true, 0, true, false);
	}
	@Test
	public void test2354() {
		o.launch(1, true, true, 0, false, true, 0, false, true);
	}
	@Test
	public void test2355() {
		o.launch(1, true, true, 0, false, true, 0, false, false);
	}
	@Test
	public void test2356() {
		o.launch(1, true, true, 0, false, true, 1, true, true);
	}
	@Test
	public void test2357() {
		o.launch(1, true, true, 0, false, true, 1, true, false);
	}
	@Test
	public void test2358() {
		o.launch(1, true, true, 0, false, true, 1, false, true);
	}
	@Test
	public void test2359() {
		o.launch(1, true, true, 0, false, true, 1, false, false);
	}
	@Test
	public void test2360() {
		o.launch(1, true, true, 0, false, true, 2, true, true);
	}
	@Test
	public void test2361() {
		o.launch(1, true, true, 0, false, true, 2, true, false);
	}
	@Test
	public void test2362() {
		o.launch(1, true, true, 0, false, true, 2, false, true);
	}
	@Test
	public void test2363() {
		o.launch(1, true, true, 0, false, true, 2, false, false);
	}
	@Test
	public void test2364() {
		o.launch(1, true, true, 0, false, true, 3, true, true);
	}
	@Test
	public void test2365() {
		o.launch(1, true, true, 0, false, true, 3, true, false);
	}
	@Test
	public void test2366() {
		o.launch(1, true, true, 0, false, true, 3, false, true);
	}
	@Test
	public void test2367() {
		o.launch(1, true, true, 0, false, true, 3, false, false);
	}
	@Test
	public void test2368() {
		o.launch(1, true, true, 0, false, true, 4, true, true);
	}
	@Test
	public void test2369() {
		o.launch(1, true, true, 0, false, true, 4, true, false);
	}
	@Test
	public void test2370() {
		o.launch(1, true, true, 0, false, true, 4, false, true);
	}
	@Test
	public void test2371() {
		o.launch(1, true, true, 0, false, true, 4, false, false);
	}
	@Test
	public void test2372() {
		o.launch(1, true, true, 0, false, true, 100, true, true);
	}
	@Test
	public void test2373() {
		o.launch(1, true, true, 0, false, true, 100, true, false);
	}
	@Test
	public void test2374() {
		o.launch(1, true, true, 0, false, true, 10, false, true);
	}
	@Test
	public void test2375() {
		o.launch(1, true, true, 0, false, true, 100, false, false);
	}
	@Test
	public void test2376() {
		o.launch(1, true, true, 0, false, false, 0, true, true);
	}
	@Test
	public void test2377() {
		o.launch(1, true, true, 0, false, false, 0, true, false);
	}
	@Test
	public void test2378() {
		o.launch(1, true, true, 0, false, false, 0, false, true);
	}
	@Test
	public void test2379() {
		o.launch(1, true, true, 0, false, false, 0, false, false);
	}
	@Test
	public void test2380() {
		o.launch(1, true, true, 0, false, false, 1, true, true);
	}
	@Test
	public void test2381() {
		o.launch(1, true, true, 0, false, false, 1, true, false);
	}
	@Test
	public void test2382() {
		o.launch(1, true, true, 0, false, false, 1, false, true);
	}
	@Test
	public void test2383() {
		o.launch(1, true, true, 0, false, false, 1, false, false);
	}
	@Test
	public void test2384() {
		o.launch(1, true, true, 0, false, false, 2, true, true);
	}
	@Test
	public void test2385() {
		o.launch(1, true, true, 0, false, false, 2, true, false);
	}
	@Test
	public void test2386() {
		o.launch(1, true, true, 0, false, false, 2, false, true);
	}
	@Test
	public void test2387() {
		o.launch(1, true, true, 0, false, false, 2, false, false);
	}
	@Test
	public void test2388() {
		o.launch(1, true, true, 0, false, false, 3, true, true);
	}
	@Test
	public void test2389() {
		o.launch(1, true, true, 0, false, false, 3, true, false);
	}
	@Test
	public void test2390() {
		o.launch(1, true, true, 0, false, false, 3, false, true);
	}
	@Test
	public void test2391() {
		o.launch(1, true, true, 0, false, false, 3, false, false);
	}
	@Test
	public void test2392() {
		o.launch(1, true, true, 0, false, false, 4, true, true);
	}
	@Test
	public void test2393() {
		o.launch(1, true, true, 0, false, false, 4, true, false);
	}
	@Test
	public void test2394() {
		o.launch(1, true, true, 0, false, false, 4, false, true);
	}
	@Test
	public void test2395() {
		o.launch(1, true, true, 0, false, false, 4, false, false);
	}
	@Test
	public void test2396() {
		o.launch(1, true, true, 0, false, false, 10, true, true);
	}
	@Test
	public void test2397() {
		o.launch(1, true, true, 0, false, false, -1, true, false);
	}
	@Test
	public void test2398() {
		o.launch(1, true, true, 0, false, false, 10, false, true);
	}
	@Test
	public void test2399() {
		o.launch(1, true, true, 0, false, false, 10, false, false);
	}
	@Test
	public void test2400() {
		o.launch(1, true, true, 1, true, true, 0, true, true);
	}
	@Test
	public void test2401() {
		o.launch(1, true, true, 1, true, true, 0, true, false);
	}
	@Test
	public void test2402() {
		o.launch(1, true, true, 1, true, true, 0, false, true);
	}
	@Test
	public void test2403() {
		o.launch(1, true, true, 1, true, true, 0, false, false);
	}
	@Test
	public void test2404() {
		o.launch(1, true, true, 1, true, true, 1, true, true);
	}
	@Test
	public void test2405() {
		o.launch(1, true, true, 1, true, true, 1, true, false);
	}
	@Test
	public void test2406() {
		o.launch(1, true, true, 1, true, true, 1, false, true);
	}
	@Test
	public void test2407() {
		o.launch(1, true, true, 1, true, true, 1, false, false);
	}
	@Test
	public void test2408() {
		o.launch(1, true, true, 1, true, true, 2, true, true);
	}
	@Test
	public void test2409() {
		o.launch(1, true, true, 1, true, true, 2, true, false);
	}
	@Test
	public void test2410() {
		o.launch(1, true, true, 1, true, true, 2, false, true);
	}
	@Test
	public void test2411() {
		o.launch(1, true, true, 1, true, true, 2, false, false);
	}
	@Test
	public void test2412() {
		o.launch(1, true, true, 1, true, true, 3, true, true);
	}
	@Test
	public void test2413() {
		o.launch(1, true, true, 1, true, true, 3, true, false);
	}
	@Test
	public void test2414() {
		o.launch(1, true, true, 1, true, true, 3, false, true);
	}
	@Test
	public void test2415() {
		o.launch(1, true, true, 1, true, true, 3, false, false);
	}
	@Test
	public void test2416() {
		o.launch(1, true, true, 1, true, true, 4, true, true);
	}
	@Test
	public void test2417() {
		o.launch(1, true, true, 1, true, true, 4, true, false);
	}
	@Test
	public void test2418() {
		o.launch(1, true, true, 1, true, true, 4, false, true);
	}
	@Test
	public void test2419() {
		o.launch(1, true, true, 1, true, true, 4, false, false);
	}
	@Test
	public void test2420() {
		o.launch(1, true, true, 1, true, true, 10, true, true);
	}
	@Test
	public void test2421() {
		o.launch(1, true, true, 1, true, true, 100, true, false);
	}
	@Test
	public void test2422() {
		o.launch(1, true, true, 1, true, true, -1, false, true);
	}
	@Test
	public void test2423() {
		o.launch(1, true, true, 1, true, true, 5, false, false);
	}
	@Test
	public void test2424() {
		o.launch(1, true, true, 1, true, false, 0, true, true);
	}
	@Test
	public void test2425() {
		o.launch(1, true, true, 1, true, false, 0, true, false);
	}
	@Test
	public void test2426() {
		o.launch(1, true, true, 1, true, false, 0, false, true);
	}
	@Test
	public void test2427() {
		o.launch(1, true, true, 1, true, false, 0, false, false);
	}
	@Test
	public void test2428() {
		o.launch(1, true, true, 1, true, false, 1, true, true);
	}
	@Test
	public void test2429() {
		o.launch(1, true, true, 1, true, false, 1, true, false);
	}
	@Test
	public void test2430() {
		o.launch(1, true, true, 1, true, false, 1, false, true);
	}
	@Test
	public void test2431() {
		o.launch(1, true, true, 1, true, false, 1, false, false);
	}
	@Test
	public void test2432() {
		o.launch(1, true, true, 1, true, false, 2, true, true);
	}
	@Test
	public void test2433() {
		o.launch(1, true, true, 1, true, false, 2, true, false);
	}
	@Test
	public void test2434() {
		o.launch(1, true, true, 1, true, false, 2, false, true);
	}
	@Test
	public void test2435() {
		o.launch(1, true, true, 1, true, false, 2, false, false);
	}
	@Test
	public void test2436() {
		o.launch(1, true, true, 1, true, false, 3, true, true);
	}
	@Test
	public void test2437() {
		o.launch(1, true, true, 1, true, false, 3, true, false);
	}
	@Test
	public void test2438() {
		o.launch(1, true, true, 1, true, false, 3, false, true);
	}
	@Test
	public void test2439() {
		o.launch(1, true, true, 1, true, false, 3, false, false);
	}
	@Test
	public void test2440() {
		o.launch(1, true, true, 1, true, false, 4, true, true);
	}
	@Test
	public void test2441() {
		o.launch(1, true, true, 1, true, false, 4, true, false);
	}
	@Test
	public void test2442() {
		o.launch(1, true, true, 1, true, false, 4, false, true);
	}
	@Test
	public void test2443() {
		o.launch(1, true, true, 1, true, false, 4, false, false);
	}
	@Test
	public void test2444() {
		o.launch(1, true, true, 1, true, false, -1, true, true);
	}
	@Test
	public void test2445() {
		o.launch(1, true, true, 1, true, false, 100, true, false);
	}
	@Test
	public void test2446() {
		o.launch(1, true, true, 1, true, false, 10, false, true);
	}
	@Test
	public void test2447() {
		o.launch(1, true, true, 1, true, false, 10, false, false);
	}
	@Test
	public void test2448() {
		o.launch(1, true, true, 1, false, true, 0, true, true);
	}
	@Test
	public void test2449() {
		o.launch(1, true, true, 1, false, true, 0, true, false);
	}
	@Test
	public void test2450() {
		o.launch(1, true, true, 1, false, true, 0, false, true);
	}
	@Test
	public void test2451() {
		o.launch(1, true, true, 1, false, true, 0, false, false);
	}
	@Test
	public void test2452() {
		o.launch(1, true, true, 1, false, true, 1, true, true);
	}
	@Test
	public void test2453() {
		o.launch(1, true, true, 1, false, true, 1, true, false);
	}
	@Test
	public void test2454() {
		o.launch(1, true, true, 1, false, true, 1, false, true);
	}
	@Test
	public void test2455() {
		o.launch(1, true, true, 1, false, true, 1, false, false);
	}
	@Test
	public void test2456() {
		o.launch(1, true, true, 1, false, true, 2, true, true);
	}
	@Test
	public void test2457() {
		o.launch(1, true, true, 1, false, true, 2, true, false);
	}
	@Test
	public void test2458() {
		o.launch(1, true, true, 1, false, true, 2, false, true);
	}
	@Test
	public void test2459() {
		o.launch(1, true, true, 1, false, true, 2, false, false);
	}
	@Test
	public void test2460() {
		o.launch(1, true, true, 1, false, true, 3, true, true);
	}
	@Test
	public void test2461() {
		o.launch(1, true, true, 1, false, true, 3, true, false);
	}
	@Test
	public void test2462() {
		o.launch(1, true, true, 1, false, true, 3, false, true);
	}
	@Test
	public void test2463() {
		o.launch(1, true, true, 1, false, true, 3, false, false);
	}
	@Test
	public void test2464() {
		o.launch(1, true, true, 1, false, true, 4, true, true);
	}
	@Test
	public void test2465() {
		o.launch(1, true, true, 1, false, true, 4, true, false);
	}
	@Test
	public void test2466() {
		o.launch(1, true, true, 1, false, true, 4, false, true);
	}
	@Test
	public void test2467() {
		o.launch(1, true, true, 1, false, true, 4, false, false);
	}
	@Test
	public void test2468() {
		o.launch(1, true, true, 1, false, true, 5, true, true);
	}
	@Test
	public void test2469() {
		o.launch(1, true, true, 1, false, true, -1, true, false);
	}
	@Test
	public void test2470() {
		o.launch(1, true, true, 1, false, true, 10, false, true);
	}
	@Test
	public void test2471() {
		o.launch(1, true, true, 1, false, true, 10, false, false);
	}
	@Test
	public void test2472() {
		o.launch(1, true, true, 1, false, false, 0, true, true);
	}
	@Test
	public void test2473() {
		o.launch(1, true, true, 1, false, false, 0, true, false);
	}
	@Test
	public void test2474() {
		o.launch(1, true, true, 1, false, false, 0, false, true);
	}
	@Test
	public void test2475() {
		o.launch(1, true, true, 1, false, false, 0, false, false);
	}
	@Test
	public void test2476() {
		o.launch(1, true, true, 1, false, false, 1, true, true);
	}
	@Test
	public void test2477() {
		o.launch(1, true, true, 1, false, false, 1, true, false);
	}
	@Test
	public void test2478() {
		o.launch(1, true, true, 1, false, false, 1, false, true);
	}
	@Test
	public void test2479() {
		o.launch(1, true, true, 1, false, false, 1, false, false);
	}
	@Test
	public void test2480() {
		o.launch(1, true, true, 1, false, false, 2, true, true);
	}
	@Test
	public void test2481() {
		o.launch(1, true, true, 1, false, false, 2, true, false);
	}
	@Test
	public void test2482() {
		o.launch(1, true, true, 1, false, false, 2, false, true);
	}
	@Test
	public void test2483() {
		o.launch(1, true, true, 1, false, false, 2, false, false);
	}
	@Test
	public void test2484() {
		o.launch(1, true, true, 1, false, false, 3, true, true);
	}
	@Test
	public void test2485() {
		o.launch(1, true, true, 1, false, false, 3, true, false);
	}
	@Test
	public void test2486() {
		o.launch(1, true, true, 1, false, false, 3, false, true);
	}
	@Test
	public void test2487() {
		o.launch(1, true, true, 1, false, false, 3, false, false);
	}
	@Test
	public void test2488() {
		o.launch(1, true, true, 1, false, false, 4, true, true);
	}
	@Test
	public void test2489() {
		o.launch(1, true, true, 1, false, false, 4, true, false);
	}
	@Test
	public void test2490() {
		o.launch(1, true, true, 1, false, false, 4, false, true);
	}
	@Test
	public void test2491() {
		o.launch(1, true, true, 1, false, false, 4, false, false);
	}
	@Test
	public void test2492() {
		o.launch(1, true, true, 1, false, false, -1, true, true);
	}
	@Test
	public void test2493() {
		o.launch(1, true, true, 1, false, false, -1, true, false);
	}
	@Test
	public void test2494() {
		o.launch(1, true, true, 1, false, false, 100, false, true);
	}
	@Test
	public void test2495() {
		o.launch(1, true, true, 1, false, false, 100, false, false);
	}
	@Test
	public void test2496() {
		o.launch(1, true, true, 2, true, true, 0, true, true);
	}
	@Test
	public void test2497() {
		o.launch(1, true, true, 2, true, true, 0, true, false);
	}
	@Test
	public void test2498() {
		o.launch(1, true, true, 2, true, true, 0, false, true);
	}
	@Test
	public void test2499() {
		o.launch(1, true, true, 2, true, true, 0, false, false);
	}
	@Test
	public void test2500() {
		o.launch(1, true, true, 2, true, true, 1, true, true);
	}
	@Test
	public void test2501() {
		o.launch(1, true, true, 2, true, true, 1, true, false);
	}
	@Test
	public void test2502() {
		o.launch(1, true, true, 2, true, true, 1, false, true);
	}
	@Test
	public void test2503() {
		o.launch(1, true, true, 2, true, true, 1, false, false);
	}
	@Test
	public void test2504() {
		o.launch(1, true, true, 2, true, true, 2, true, true);
	}
	@Test
	public void test2505() {
		o.launch(1, true, true, 2, true, true, 2, true, false);
	}
	@Test
	public void test2506() {
		o.launch(1, true, true, 2, true, true, 2, false, true);
	}
	@Test
	public void test2507() {
		o.launch(1, true, true, 2, true, true, 2, false, false);
	}
	@Test
	public void test2508() {
		o.launch(1, true, true, 2, true, true, 3, true, true);
	}
	@Test
	public void test2509() {
		o.launch(1, true, true, 2, true, true, 3, true, false);
	}
	@Test
	public void test2510() {
		o.launch(1, true, true, 2, true, true, 3, false, true);
	}
	@Test
	public void test2511() {
		o.launch(1, true, true, 2, true, true, 3, false, false);
	}
	@Test
	public void test2512() {
		o.launch(1, true, true, 2, true, true, 4, true, true);
	}
	@Test
	public void test2513() {
		o.launch(1, true, true, 2, true, true, 4, true, false);
	}
	@Test
	public void test2514() {
		o.launch(1, true, true, 2, true, true, 4, false, true);
	}
	@Test
	public void test2515() {
		o.launch(1, true, true, 2, true, true, 4, false, false);
	}
	@Test
	public void test2516() {
		o.launch(1, true, true, 2, true, true, 5, true, true);
	}
	@Test
	public void test2517() {
		o.launch(1, true, true, 2, true, true, 5, true, false);
	}
	@Test
	public void test2518() {
		o.launch(1, true, true, 2, true, true, 5, false, true);
	}
	@Test
	public void test2519() {
		o.launch(1, true, true, 2, true, true, 5, false, false);
	}
	@Test
	public void test2520() {
		o.launch(1, true, true, 2, true, false, 0, true, true);
	}
	@Test
	public void test2521() {
		o.launch(1, true, true, 2, true, false, 0, true, false);
	}
	@Test
	public void test2522() {
		o.launch(1, true, true, 2, true, false, 0, false, true);
	}
	@Test
	public void test2523() {
		o.launch(1, true, true, 2, true, false, 0, false, false);
	}
	@Test
	public void test2524() {
		o.launch(1, true, true, 2, true, false, 1, true, true);
	}
	@Test
	public void test2525() {
		o.launch(1, true, true, 2, true, false, 1, true, false);
	}
	@Test
	public void test2526() {
		o.launch(1, true, true, 2, true, false, 1, false, true);
	}
	@Test
	public void test2527() {
		o.launch(1, true, true, 2, true, false, 1, false, false);
	}
	@Test
	public void test2528() {
		o.launch(1, true, true, 2, true, false, 2, true, true);
	}
	@Test
	public void test2529() {
		o.launch(1, true, true, 2, true, false, 2, true, false);
	}
	@Test
	public void test2530() {
		o.launch(1, true, true, 2, true, false, 2, false, true);
	}
	@Test
	public void test2531() {
		o.launch(1, true, true, 2, true, false, 2, false, false);
	}
	@Test
	public void test2532() {
		o.launch(1, true, true, 2, true, false, 3, true, true);
	}
	@Test
	public void test2533() {
		o.launch(1, true, true, 2, true, false, 3, true, false);
	}
	@Test
	public void test2534() {
		o.launch(1, true, true, 2, true, false, 3, false, true);
	}
	@Test
	public void test2535() {
		o.launch(1, true, true, 2, true, false, 3, false, false);
	}
	@Test
	public void test2536() {
		o.launch(1, true, true, 2, true, false, 4, true, true);
	}
	@Test
	public void test2537() {
		o.launch(1, true, true, 2, true, false, 4, true, false);
	}
	@Test
	public void test2538() {
		o.launch(1, true, true, 2, true, false, 4, false, true);
	}
	@Test
	public void test2539() {
		o.launch(1, true, true, 2, true, false, 4, false, false);
	}
	@Test
	public void test2540() {
		o.launch(1, true, true, 2, true, false, 5, true, true);
	}
	@Test
	public void test2541() {
		o.launch(1, true, true, 2, true, false, 5, true, false);
	}
	@Test
	public void test2542() {
		o.launch(1, true, true, 2, true, false, 5, false, true);
	}
	@Test
	public void test2543() {
		o.launch(1, true, true, 2, true, false, 5, false, false);
	}
	@Test
	public void test2544() {
		o.launch(1, true, true, 2, false, true, 0, true, true);
	}
	@Test
	public void test2545() {
		o.launch(1, true, true, 2, false, true, 0, true, false);
	}
	@Test
	public void test2546() {
		o.launch(1, true, true, 2, false, true, 0, false, true);
	}
	@Test
	public void test2547() {
		o.launch(1, true, true, 2, false, true, 0, false, false);
	}
	@Test
	public void test2548() {
		o.launch(1, true, true, 2, false, true, 1, true, true);
	}
	@Test
	public void test2549() {
		o.launch(1, true, true, 2, false, true, 1, true, false);
	}
	@Test
	public void test2550() {
		o.launch(1, true, true, 2, false, true, 1, false, true);
	}
	@Test
	public void test2551() {
		o.launch(1, true, true, 2, false, true, 1, false, false);
	}
	@Test
	public void test2552() {
		o.launch(1, true, true, 2, false, true, 2, true, true);
	}
	@Test
	public void test2553() {
		o.launch(1, true, true, 2, false, true, 2, true, false);
	}
	@Test
	public void test2554() {
		o.launch(1, true, true, 2, false, true, 2, false, true);
	}
	@Test
	public void test2555() {
		o.launch(1, true, true, 2, false, true, 2, false, false);
	}
	@Test
	public void test2556() {
		o.launch(1, true, true, 2, false, true, 3, true, true);
	}
	@Test
	public void test2557() {
		o.launch(1, true, true, 2, false, true, 3, true, false);
	}
	@Test
	public void test2558() {
		o.launch(1, true, true, 2, false, true, 3, false, true);
	}
	@Test
	public void test2559() {
		o.launch(1, true, true, 2, false, true, 3, false, false);
	}
	@Test
	public void test2560() {
		o.launch(1, true, true, 2, false, true, 4, true, true);
	}
	@Test
	public void test2561() {
		o.launch(1, true, true, 2, false, true, 4, true, false);
	}
	@Test
	public void test2562() {
		o.launch(1, true, true, 2, false, true, 4, false, true);
	}
	@Test
	public void test2563() {
		o.launch(1, true, true, 2, false, true, 4, false, false);
	}
	@Test
	public void test2564() {
		o.launch(1, true, true, 2, false, true, 5, true, true);
	}
	@Test
	public void test2565() {
		o.launch(1, true, true, 2, false, true, 5, true, false);
	}
	@Test
	public void test2566() {
		o.launch(1, true, true, 2, false, true, 5, false, true);
	}
	@Test
	public void test2567() {
		o.launch(1, true, true, 2, false, true, 5, false, false);
	}
	@Test
	public void test2568() {
		o.launch(1, true, true, 2, false, false, 0, true, true);
	}
	@Test
	public void test2569() {
		o.launch(1, true, true, 2, false, false, 0, true, false);
	}
	@Test
	public void test2570() {
		o.launch(1, true, true, 2, false, false, 0, false, true);
	}
	@Test
	public void test2571() {
		o.launch(1, true, true, 2, false, false, 0, false, false);
	}
	@Test
	public void test2572() {
		o.launch(1, true, true, 2, false, false, 1, true, true);
	}
	@Test
	public void test2573() {
		o.launch(1, true, true, 2, false, false, 1, true, false);
	}
	@Test
	public void test2574() {
		o.launch(1, true, true, 2, false, false, 1, false, true);
	}
	@Test
	public void test2575() {
		o.launch(1, true, true, 2, false, false, 1, false, false);
	}
	@Test
	public void test2576() {
		o.launch(1, true, true, 2, false, false, 2, true, true);
	}
	@Test
	public void test2577() {
		o.launch(1, true, true, 2, false, false, 2, true, false);
	}
	@Test
	public void test2578() {
		o.launch(1, true, true, 2, false, false, 2, false, true);
	}
	@Test
	public void test2579() {
		o.launch(1, true, true, 2, false, false, 2, false, false);
	}
	@Test
	public void test2580() {
		o.launch(1, true, true, 2, false, false, 3, true, true);
	}
	@Test
	public void test2581() {
		o.launch(1, true, true, 2, false, false, 3, true, false);
	}
	@Test
	public void test2582() {
		o.launch(1, true, true, 2, false, false, 3, false, true);
	}
	@Test
	public void test2583() {
		o.launch(1, true, true, 2, false, false, 3, false, false);
	}
	@Test
	public void test2584() {
		o.launch(1, true, true, 2, false, false, 4, true, true);
	}
	@Test
	public void test2585() {
		o.launch(1, true, true, 2, false, false, 4, true, false);
	}
	@Test
	public void test2586() {
		o.launch(1, true, true, 2, false, false, 4, false, true);
	}
	@Test
	public void test2587() {
		o.launch(1, true, true, 2, false, false, 4, false, false);
	}
	@Test
	public void test2588() {
		o.launch(1, true, true, 2, false, false, 5, true, true);
	}
	@Test
	public void test2589() {
		o.launch(1, true, true, 2, false, false, 5, true, false);
	}
	@Test
	public void test2590() {
		o.launch(1, true, true, 2, false, false, 5, false, true);
	}
	@Test
	public void test2591() {
		o.launch(1, true, true, 2, false, false, 5, false, false);
	}
	@Test
	public void test2592() {
		o.launch(1, true, true, 3, true, true, 0, true, true);
	}
	@Test
	public void test2593() {
		o.launch(1, true, true, 3, true, true, 0, true, false);
	}
	@Test
	public void test2594() {
		o.launch(1, true, true, 3, true, true, 0, false, true);
	}
	@Test
	public void test2595() {
		o.launch(1, true, true, 3, true, true, 0, false, false);
	}
	@Test
	public void test2596() {
		o.launch(1, true, true, 3, true, true, 1, true, true);
	}
	@Test
	public void test2597() {
		o.launch(1, true, true, 3, true, true, 1, true, false);
	}
	@Test
	public void test2598() {
		o.launch(1, true, true, 3, true, true, 1, false, true);
	}
	@Test
	public void test2599() {
		o.launch(1, true, true, 3, true, true, 1, false, false);
	}
	@Test
	public void test2600() {
		o.launch(1, true, true, 3, true, true, 2, true, true);
	}
	@Test
	public void test2601() {
		o.launch(1, true, true, 3, true, true, 2, true, false);
	}
	@Test
	public void test2602() {
		o.launch(1, true, true, 3, true, true, 2, false, true);
	}
	@Test
	public void test2603() {
		o.launch(1, true, true, 3, true, true, 2, false, false);
	}
	@Test
	public void test2604() {
		o.launch(1, true, true, 3, true, true, 3, true, true);
	}
	@Test
	public void test2605() {
		o.launch(1, true, true, 3, true, true, 3, true, false);
	}
	@Test
	public void test2606() {
		o.launch(1, true, true, 3, true, true, 3, false, true);
	}
	@Test
	public void test2607() {
		o.launch(1, true, true, 3, true, true, 3, false, false);
	}
	@Test
	public void test2608() {
		o.launch(1, true, true, 3, true, true, 4, true, true);
	}
	@Test
	public void test2609() {
		o.launch(1, true, true, 3, true, true, 4, true, false);
	}
	@Test
	public void test2610() {
		o.launch(1, true, true, 3, true, true, 4, false, true);
	}
	@Test
	public void test2611() {
		o.launch(1, true, true, 3, true, true, 4, false, false);
	}
	@Test
	public void test2612() {
		o.launch(1, true, true, 3, true, true, 5, true, true);
	}
	@Test
	public void test2613() {
		o.launch(1, true, true, 3, true, true, 5, true, false);
	}
	@Test
	public void test2614() {
		o.launch(1, true, true, 3, true, true, 5, false, true);
	}
	@Test
	public void test2615() {
		o.launch(1, true, true, 3, true, true, 5, false, false);
	}
	@Test
	public void test2616() {
		o.launch(1, true, true, 3, true, false, 0, true, true);
	}
	@Test
	public void test2617() {
		o.launch(1, true, true, 3, true, false, 0, true, false);
	}
	@Test
	public void test2618() {
		o.launch(1, true, true, 3, true, false, 0, false, true);
	}
	@Test
	public void test2619() {
		o.launch(1, true, true, 3, true, false, 0, false, false);
	}
	@Test
	public void test2620() {
		o.launch(1, true, true, 3, true, false, 1, true, true);
	}
	@Test
	public void test2621() {
		o.launch(1, true, true, 3, true, false, 1, true, false);
	}
	@Test
	public void test2622() {
		o.launch(1, true, true, 3, true, false, 1, false, true);
	}
	@Test
	public void test2623() {
		o.launch(1, true, true, 3, true, false, 1, false, false);
	}
	@Test
	public void test2624() {
		o.launch(1, true, true, 3, true, false, 2, true, true);
	}
	@Test
	public void test2625() {
		o.launch(1, true, true, 3, true, false, 2, true, false);
	}
	@Test
	public void test2626() {
		o.launch(1, true, true, 3, true, false, 2, false, true);
	}
	@Test
	public void test2627() {
		o.launch(1, true, true, 3, true, false, 2, false, false);
	}
	@Test
	public void test2628() {
		o.launch(1, true, true, 3, true, false, 3, true, true);
	}
	@Test
	public void test2629() {
		o.launch(1, true, true, 3, true, false, 3, true, false);
	}
	@Test
	public void test2630() {
		o.launch(1, true, true, 3, true, false, 3, false, true);
	}
	@Test
	public void test2631() {
		o.launch(1, true, true, 3, true, false, 3, false, false);
	}
	@Test
	public void test2632() {
		o.launch(1, true, true, 3, true, false, 4, true, true);
	}
	@Test
	public void test2633() {
		o.launch(1, true, true, 3, true, false, 4, true, false);
	}
	@Test
	public void test2634() {
		o.launch(1, true, true, 3, true, false, 4, false, true);
	}
	@Test
	public void test2635() {
		o.launch(1, true, true, 3, true, false, 4, false, false);
	}
	@Test
	public void test2636() {
		o.launch(1, true, true, 3, true, false, 5, true, true);
	}
	@Test
	public void test2637() {
		o.launch(1, true, true, 3, true, false, 5, true, false);
	}
	@Test
	public void test2638() {
		o.launch(1, true, true, 3, true, false, 5, false, true);
	}
	@Test
	public void test2639() {
		o.launch(1, true, true, 3, true, false, 5, false, false);
	}
	@Test
	public void test2640() {
		o.launch(1, true, true, 3, false, true, 0, true, true);
	}
	@Test
	public void test2641() {
		o.launch(1, true, true, 3, false, true, 0, true, false);
	}
	@Test
	public void test2642() {
		o.launch(1, true, true, 3, false, true, 0, false, true);
	}
	@Test
	public void test2643() {
		o.launch(1, true, true, 3, false, true, 0, false, false);
	}
	@Test
	public void test2644() {
		o.launch(1, true, true, 3, false, true, 1, true, true);
	}
	@Test
	public void test2645() {
		o.launch(1, true, true, 3, false, true, 1, true, false);
	}
	@Test
	public void test2646() {
		o.launch(1, true, true, 3, false, true, 1, false, true);
	}
	@Test
	public void test2647() {
		o.launch(1, true, true, 3, false, true, 1, false, false);
	}
	@Test
	public void test2648() {
		o.launch(1, true, true, 3, false, true, 2, true, true);
	}
	@Test
	public void test2649() {
		o.launch(1, true, true, 3, false, true, 2, true, false);
	}
	@Test
	public void test2650() {
		o.launch(1, true, true, 3, false, true, 2, false, true);
	}
	@Test
	public void test2651() {
		o.launch(1, true, true, 3, false, true, 2, false, false);
	}
	@Test
	public void test2652() {
		o.launch(1, true, true, 3, false, true, 3, true, true);
	}
	@Test
	public void test2653() {
		o.launch(1, true, true, 3, false, true, 3, true, false);
	}
	@Test
	public void test2654() {
		o.launch(1, true, true, 3, false, true, 3, false, true);
	}
	@Test
	public void test2655() {
		o.launch(1, true, true, 3, false, true, 3, false, false);
	}
	@Test
	public void test2656() {
		o.launch(1, true, true, 3, false, true, 4, true, true);
	}
	@Test
	public void test2657() {
		o.launch(1, true, true, 3, false, true, 4, true, false);
	}
	@Test
	public void test2658() {
		o.launch(1, true, true, 3, false, true, 4, false, true);
	}
	@Test
	public void test2659() {
		o.launch(1, true, true, 3, false, true, 4, false, false);
	}
	@Test
	public void test2660() {
		o.launch(1, true, true, 3, false, true, 5, true, true);
	}
	@Test
	public void test2661() {
		o.launch(1, true, true, 3, false, true, 5, true, false);
	}
	@Test
	public void test2662() {
		o.launch(1, true, true, 3, false, true, 5, false, true);
	}
	@Test
	public void test2663() {
		o.launch(1, true, true, 3, false, true, 5, false, false);
	}
	@Test
	public void test2664() {
		o.launch(1, true, true, 3, false, false, 0, true, true);
	}
	@Test
	public void test2665() {
		o.launch(1, true, true, 3, false, false, 0, true, false);
	}
	@Test
	public void test2666() {
		o.launch(1, true, true, 3, false, false, 0, false, true);
	}
	@Test
	public void test2667() {
		o.launch(1, true, true, 3, false, false, 0, false, false);
	}
	@Test
	public void test2668() {
		o.launch(1, true, true, 3, false, false, 1, true, true);
	}
	@Test
	public void test2669() {
		o.launch(1, true, true, 3, false, false, 1, true, false);
	}
	@Test
	public void test2670() {
		o.launch(1, true, true, 3, false, false, 1, false, true);
	}
	@Test
	public void test2671() {
		o.launch(1, true, true, 3, false, false, 1, false, false);
	}
	@Test
	public void test2672() {
		o.launch(1, true, true, 3, false, false, 2, true, true);
	}
	@Test
	public void test2673() {
		o.launch(1, true, true, 3, false, false, 2, true, false);
	}
	@Test
	public void test2674() {
		o.launch(1, true, true, 3, false, false, 2, false, true);
	}
	@Test
	public void test2675() {
		o.launch(1, true, true, 3, false, false, 2, false, false);
	}
	@Test
	public void test2676() {
		o.launch(1, true, true, 3, false, false, 3, true, true);
	}
	@Test
	public void test2677() {
		o.launch(1, true, true, 3, false, false, 3, true, false);
	}
	@Test
	public void test2678() {
		o.launch(1, true, true, 3, false, false, 3, false, true);
	}
	@Test
	public void test2679() {
		o.launch(1, true, true, 3, false, false, 3, false, false);
	}
	@Test
	public void test2680() {
		o.launch(1, true, true, 3, false, false, 4, true, true);
	}
	@Test
	public void test2681() {
		o.launch(1, true, true, 3, false, false, 4, true, false);
	}
	@Test
	public void test2682() {
		o.launch(1, true, true, 3, false, false, 4, false, true);
	}
	@Test
	public void test2683() {
		o.launch(1, true, true, 3, false, false, 4, false, false);
	}
	@Test
	public void test2684() {
		o.launch(1, true, true, 3, false, false, 5, true, true);
	}
	@Test
	public void test2685() {
		o.launch(1, true, true, 3, false, false, 5, true, false);
	}
	@Test
	public void test2686() {
		o.launch(1, true, true, 3, false, false, 5, false, true);
	}
	@Test
	public void test2687() {
		o.launch(1, true, true, 3, false, false, 5, false, false);
	}
	@Test
	public void test2688() {
		o.launch(1, true, true, 4, true, true, 0, true, true);
	}
	@Test
	public void test2689() {
		o.launch(1, true, true, 4, true, true, 0, true, false);
	}
	@Test
	public void test2690() {
		o.launch(1, true, true, 4, true, true, 0, false, true);
	}
	@Test
	public void test2691() {
		o.launch(1, true, true, 4, true, true, 0, false, false);
	}
	@Test
	public void test2692() {
		o.launch(1, true, true, 4, true, true, 1, true, true);
	}
	@Test
	public void test2693() {
		o.launch(1, true, true, 4, true, true, 1, true, false);
	}
	@Test
	public void test2694() {
		o.launch(1, true, true, 4, true, true, 1, false, true);
	}
	@Test
	public void test2695() {
		o.launch(1, true, true, 4, true, true, 1, false, false);
	}
	@Test
	public void test2696() {
		o.launch(1, true, true, 4, true, true, 2, true, true);
	}
	@Test
	public void test2697() {
		o.launch(1, true, true, 4, true, true, 2, true, false);
	}
	@Test
	public void test2698() {
		o.launch(1, true, true, 4, true, true, 2, false, true);
	}
	@Test
	public void test2699() {
		o.launch(1, true, true, 4, true, true, 2, false, false);
	}
	@Test
	public void test2700() {
		o.launch(1, true, true, 4, true, true, 3, true, true);
	}
	@Test
	public void test2701() {
		o.launch(1, true, true, 4, true, true, 3, true, false);
	}
	@Test
	public void test2702() {
		o.launch(1, true, true, 4, true, true, 3, false, true);
	}
	@Test
	public void test2703() {
		o.launch(1, true, true, 4, true, true, 3, false, false);
	}
	@Test
	public void test2704() {
		o.launch(1, true, true, 4, true, true, 4, true, true);
	}
	@Test
	public void test2705() {
		o.launch(1, true, true, 4, true, true, 4, true, false);
	}
	@Test
	public void test2706() {
		o.launch(1, true, true, 4, true, true, 4, false, true);
	}
	@Test
	public void test2707() {
		o.launch(1, true, true, 4, true, true, 4, false, false);
	}
	@Test
	public void test2708() {
		o.launch(1, true, true, 4, true, true, 10, true, true);
	}
	@Test
	public void test2709() {
		o.launch(1, true, true, 4, true, true, 5, true, false);
	}
	@Test
	public void test2710() {
		o.launch(1, true, true, 4, true, true, 5, false, true);
	}
	@Test
	public void test2711() {
		o.launch(1, true, true, 4, true, true, 5, false, false);
	}
	@Test
	public void test2712() {
		o.launch(1, true, true, 4, true, false, 0, true, true);
	}
	@Test
	public void test2713() {
		o.launch(1, true, true, 4, true, false, 0, true, false);
	}
	@Test
	public void test2714() {
		o.launch(1, true, true, 4, true, false, 0, false, true);
	}
	@Test
	public void test2715() {
		o.launch(1, true, true, 4, true, false, 0, false, false);
	}
	@Test
	public void test2716() {
		o.launch(1, true, true, 4, true, false, 1, true, true);
	}
	@Test
	public void test2717() {
		o.launch(1, true, true, 4, true, false, 1, true, false);
	}
	@Test
	public void test2718() {
		o.launch(1, true, true, 4, true, false, 1, false, true);
	}
	@Test
	public void test2719() {
		o.launch(1, true, true, 4, true, false, 1, false, false);
	}
	@Test
	public void test2720() {
		o.launch(1, true, true, 4, true, false, 2, true, true);
	}
	@Test
	public void test2721() {
		o.launch(1, true, true, 4, true, false, 2, true, false);
	}
	@Test
	public void test2722() {
		o.launch(1, true, true, 4, true, false, 2, false, true);
	}
	@Test
	public void test2723() {
		o.launch(1, true, true, 4, true, false, 2, false, false);
	}
	@Test
	public void test2724() {
		o.launch(1, true, true, 4, true, false, 3, true, true);
	}
	@Test
	public void test2725() {
		o.launch(1, true, true, 4, true, false, 3, true, false);
	}
	@Test
	public void test2726() {
		o.launch(1, true, true, 4, true, false, 3, false, true);
	}
	@Test
	public void test2727() {
		o.launch(1, true, true, 4, true, false, 3, false, false);
	}
	@Test
	public void test2728() {
		o.launch(1, true, true, 4, true, false, 4, true, true);
	}
	@Test
	public void test2729() {
		o.launch(1, true, true, 4, true, false, 4, true, false);
	}
	@Test
	public void test2730() {
		o.launch(1, true, true, 4, true, false, 4, false, true);
	}
	@Test
	public void test2731() {
		o.launch(1, true, true, 4, true, false, 4, false, false);
	}
	@Test
	public void test2732() {
		o.launch(1, true, true, 4, true, false, 100, true, true);
	}
	@Test
	public void test2733() {
		o.launch(1, true, true, 4, true, false, 10, true, false);
	}
	@Test
	public void test2734() {
		o.launch(1, true, true, 4, true, false, 10, false, true);
	}
	@Test
	public void test2735() {
		o.launch(1, true, true, 4, true, false, 100, false, false);
	}
	@Test
	public void test2736() {
		o.launch(1, true, true, 4, false, true, 0, true, true);
	}
	@Test
	public void test2737() {
		o.launch(1, true, true, 4, false, true, 0, true, false);
	}
	@Test
	public void test2738() {
		o.launch(1, true, true, 4, false, true, 0, false, true);
	}
	@Test
	public void test2739() {
		o.launch(1, true, true, 4, false, true, 0, false, false);
	}
	@Test
	public void test2740() {
		o.launch(1, true, true, 4, false, true, 1, true, true);
	}
	@Test
	public void test2741() {
		o.launch(1, true, true, 4, false, true, 1, true, false);
	}
	@Test
	public void test2742() {
		o.launch(1, true, true, 4, false, true, 1, false, true);
	}
	@Test
	public void test2743() {
		o.launch(1, true, true, 4, false, true, 1, false, false);
	}
	@Test
	public void test2744() {
		o.launch(1, true, true, 4, false, true, 2, true, true);
	}
	@Test
	public void test2745() {
		o.launch(1, true, true, 4, false, true, 2, true, false);
	}
	@Test
	public void test2746() {
		o.launch(1, true, true, 4, false, true, 2, false, true);
	}
	@Test
	public void test2747() {
		o.launch(1, true, true, 4, false, true, 2, false, false);
	}
	@Test
	public void test2748() {
		o.launch(1, true, true, 4, false, true, 3, true, true);
	}
	@Test
	public void test2749() {
		o.launch(1, true, true, 4, false, true, 3, true, false);
	}
	@Test
	public void test2750() {
		o.launch(1, true, true, 4, false, true, 3, false, true);
	}
	@Test
	public void test2751() {
		o.launch(1, true, true, 4, false, true, 3, false, false);
	}
	@Test
	public void test2752() {
		o.launch(1, true, true, 4, false, true, 4, true, true);
	}
	@Test
	public void test2753() {
		o.launch(1, true, true, 4, false, true, 4, true, false);
	}
	@Test
	public void test2754() {
		o.launch(1, true, true, 4, false, true, 4, false, true);
	}
	@Test
	public void test2755() {
		o.launch(1, true, true, 4, false, true, 4, false, false);
	}
	@Test
	public void test2756() {
		o.launch(1, true, true, 4, false, true, 5, true, true);
	}
	@Test
	public void test2757() {
		o.launch(1, true, true, 4, false, true, 5, true, false);
	}
	@Test
	public void test2758() {
		o.launch(1, true, true, 4, false, true, 100, false, true);
	}
	@Test
	public void test2759() {
		o.launch(1, true, true, 4, false, true, 5, false, false);
	}
	@Test
	public void test2760() {
		o.launch(1, true, true, 4, false, false, 0, true, true);
	}
	@Test
	public void test2761() {
		o.launch(1, true, true, 4, false, false, 0, true, false);
	}
	@Test
	public void test2762() {
		o.launch(1, true, true, 4, false, false, 0, false, true);
	}
	@Test
	public void test2763() {
		o.launch(1, true, true, 4, false, false, 0, false, false);
	}
	@Test
	public void test2764() {
		o.launch(1, true, true, 4, false, false, 1, true, true);
	}
	@Test
	public void test2765() {
		o.launch(1, true, true, 4, false, false, 1, true, false);
	}
	@Test
	public void test2766() {
		o.launch(1, true, true, 4, false, false, 1, false, true);
	}
	@Test
	public void test2767() {
		o.launch(1, true, true, 4, false, false, 1, false, false);
	}
	@Test
	public void test2768() {
		o.launch(1, true, true, 4, false, false, 2, true, true);
	}
	@Test
	public void test2769() {
		o.launch(1, true, true, 4, false, false, 2, true, false);
	}
	@Test
	public void test2770() {
		o.launch(1, true, true, 4, false, false, 2, false, true);
	}
	@Test
	public void test2771() {
		o.launch(1, true, true, 4, false, false, 2, false, false);
	}
	@Test
	public void test2772() {
		o.launch(1, true, true, 4, false, false, 3, true, true);
	}
	@Test
	public void test2773() {
		o.launch(1, true, true, 4, false, false, 3, true, false);
	}
	@Test
	public void test2774() {
		o.launch(1, true, true, 4, false, false, 3, false, true);
	}
	@Test
	public void test2775() {
		o.launch(1, true, true, 4, false, false, 3, false, false);
	}
	@Test
	public void test2776() {
		o.launch(1, true, true, 4, false, false, 4, true, true);
	}
	@Test
	public void test2777() {
		o.launch(1, true, true, 4, false, false, 4, true, false);
	}
	@Test
	public void test2778() {
		o.launch(1, true, true, 4, false, false, 4, false, true);
	}
	@Test
	public void test2779() {
		o.launch(1, true, true, 4, false, false, 4, false, false);
	}
	@Test
	public void test2780() {
		o.launch(1, true, true, 4, false, false, 10, true, true);
	}
	@Test
	public void test2781() {
		o.launch(1, true, true, 4, false, false, 5, true, false);
	}
	@Test
	public void test2782() {
		o.launch(1, true, true, 4, false, false, 5, false, true);
	}
	@Test
	public void test2783() {
		o.launch(1, true, true, 4, false, false, 10, false, false);
	}
	@Test
	public void test2784() {
		o.launch(1, true, true, 10, true, true, 0, true, true);
	}
	@Test
	public void test2785() {
		o.launch(1, true, true, 100, true, true, 0, true, false);
	}
	@Test
	public void test2786() {
		o.launch(1, true, true, 100, true, true, 0, false, true);
	}
	@Test
	public void test2787() {
		o.launch(1, true, true, 100, true, true, 0, false, false);
	}
	@Test
	public void test2788() {
		o.launch(1, true, true, 100, true, true, 1, true, true);
	}
	@Test
	public void test2789() {
		o.launch(1, true, true, 100, true, true, 1, true, false);
	}
	@Test
	public void test2790() {
		o.launch(1, true, true, 10, true, true, 1, false, true);
	}
	@Test
	public void test2791() {
		o.launch(1, true, true, 5, true, true, 1, false, false);
	}
	@Test
	public void test2792() {
		o.launch(1, true, true, 5, true, true, 2, true, true);
	}
	@Test
	public void test2793() {
		o.launch(1, true, true, 5, true, true, 2, true, false);
	}
	@Test
	public void test2794() {
		o.launch(1, true, true, 5, true, true, 2, false, true);
	}
	@Test
	public void test2795() {
		o.launch(1, true, true, 5, true, true, 2, false, false);
	}
	@Test
	public void test2796() {
		o.launch(1, true, true, 5, true, true, 3, true, true);
	}
	@Test
	public void test2797() {
		o.launch(1, true, true, 5, true, true, 3, true, false);
	}
	@Test
	public void test2798() {
		o.launch(1, true, true, 5, true, true, 3, false, true);
	}
	@Test
	public void test2799() {
		o.launch(1, true, true, 5, true, true, 3, false, false);
	}
	@Test
	public void test2800() {
		o.launch(1, true, true, -1, true, true, 4, true, true);
	}
	@Test
	public void test2801() {
		o.launch(1, true, true, 5, true, true, 4, true, false);
	}
	@Test
	public void test2802() {
		o.launch(1, true, true, -1, true, true, 4, false, true);
	}
	@Test
	public void test2803() {
		o.launch(1, true, true, 5, true, true, 4, false, false);
	}
	@Test
	public void test2804() {
		o.launch(1, true, true, 100, true, true, 10, true, true);
	}
	@Test
	public void test2805() {
		o.launch(1, true, true, 100, true, true, -1, true, false);
	}
	@Test
	public void test2806() {
		o.launch(1, true, true, 100, true, true, -1, false, true);
	}
	@Test
	public void test2807() {
		o.launch(1, true, true, 100, true, true, -1, false, false);
	}
	@Test
	public void test2808() {
		o.launch(1, true, true, -1, true, false, 0, true, true);
	}
	@Test
	public void test2809() {
		o.launch(1, true, true, 100, true, false, 0, true, false);
	}
	@Test
	public void test2810() {
		o.launch(1, true, true, -1, true, false, 0, false, true);
	}
	@Test
	public void test2811() {
		o.launch(1, true, true, 100, true, false, 0, false, false);
	}
	@Test
	public void test2812() {
		o.launch(1, true, true, 100, true, false, 1, true, true);
	}
	@Test
	public void test2813() {
		o.launch(1, true, true, -1, true, false, 1, true, false);
	}
	@Test
	public void test2814() {
		o.launch(1, true, true, 10, true, false, 1, false, true);
	}
	@Test
	public void test2815() {
		o.launch(1, true, true, 100, true, false, 1, false, false);
	}
	@Test
	public void test2816() {
		o.launch(1, true, true, 5, true, false, 2, true, true);
	}
	@Test
	public void test2817() {
		o.launch(1, true, true, 5, true, false, 2, true, false);
	}
	@Test
	public void test2818() {
		o.launch(1, true, true, 5, true, false, 2, false, true);
	}
	@Test
	public void test2819() {
		o.launch(1, true, true, 5, true, false, 2, false, false);
	}
	@Test
	public void test2820() {
		o.launch(1, true, true, 5, true, false, 3, true, true);
	}
	@Test
	public void test2821() {
		o.launch(1, true, true, 5, true, false, 3, true, false);
	}
	@Test
	public void test2822() {
		o.launch(1, true, true, 5, true, false, 3, false, true);
	}
	@Test
	public void test2823() {
		o.launch(1, true, true, 5, true, false, 3, false, false);
	}
	@Test
	public void test2824() {
		o.launch(1, true, true, 10, true, false, 4, true, true);
	}
	@Test
	public void test2825() {
		o.launch(1, true, true, 100, true, false, 4, true, false);
	}
	@Test
	public void test2826() {
		o.launch(1, true, true, -1, true, false, 4, false, true);
	}
	@Test
	public void test2827() {
		o.launch(1, true, true, 100, true, false, 4, false, false);
	}
	@Test
	public void test2828() {
		o.launch(1, true, true, -1, true, false, 10, true, true);
	}
	@Test
	public void test2829() {
		o.launch(1, true, true, -1, true, false, 10, true, false);
	}
	@Test
	public void test2830() {
		o.launch(1, true, true, 10, true, false, 100, false, true);
	}
	@Test
	public void test2831() {
		o.launch(1, true, true, 10, true, false, 100, false, false);
	}
	@Test
	public void test2832() {
		o.launch(1, true, true, 10, false, true, 0, true, true);
	}
	@Test
	public void test2833() {
		o.launch(1, true, true, 100, false, true, 0, true, false);
	}
	@Test
	public void test2834() {
		o.launch(1, true, true, 5, false, true, 0, false, true);
	}
	@Test
	public void test2835() {
		o.launch(1, true, true, 10, false, true, 0, false, false);
	}
	@Test
	public void test2836() {
		o.launch(1, true, true, -1, false, true, 1, true, true);
	}
	@Test
	public void test2837() {
		o.launch(1, true, true, -1, false, true, 1, true, false);
	}
	@Test
	public void test2838() {
		o.launch(1, true, true, 10, false, true, 1, false, true);
	}
	@Test
	public void test2839() {
		o.launch(1, true, true, -1, false, true, 1, false, false);
	}
	@Test
	public void test2840() {
		o.launch(1, true, true, 5, false, true, 2, true, true);
	}
	@Test
	public void test2841() {
		o.launch(1, true, true, 5, false, true, 2, true, false);
	}
	@Test
	public void test2842() {
		o.launch(1, true, true, 5, false, true, 2, false, true);
	}
	@Test
	public void test2843() {
		o.launch(1, true, true, 5, false, true, 2, false, false);
	}
	@Test
	public void test2844() {
		o.launch(1, true, true, 5, false, true, 3, true, true);
	}
	@Test
	public void test2845() {
		o.launch(1, true, true, 5, false, true, 3, true, false);
	}
	@Test
	public void test2846() {
		o.launch(1, true, true, 5, false, true, 3, false, true);
	}
	@Test
	public void test2847() {
		o.launch(1, true, true, 5, false, true, 3, false, false);
	}
	@Test
	public void test2848() {
		o.launch(1, true, true, 5, false, true, 4, true, true);
	}
	@Test
	public void test2849() {
		o.launch(1, true, true, 5, false, true, 4, true, false);
	}
	@Test
	public void test2850() {
		o.launch(1, true, true, 5, false, true, 4, false, true);
	}
	@Test
	public void test2851() {
		o.launch(1, true, true, -1, false, true, 4, false, false);
	}
	@Test
	public void test2852() {
		o.launch(1, true, true, -1, false, true, 10, true, true);
	}
	@Test
	public void test2853() {
		o.launch(1, true, true, 10, false, true, -1, true, false);
	}
	@Test
	public void test2854() {
		o.launch(1, true, true, 10, false, true, -1, false, true);
	}
	@Test
	public void test2855() {
		o.launch(1, true, true, 10, false, true, -1, false, false);
	}
	@Test
	public void test2856() {
		o.launch(1, true, true, -1, false, false, 0, true, true);
	}
	@Test
	public void test2857() {
		o.launch(1, true, true, -1, false, false, 0, true, false);
	}
	@Test
	public void test2858() {
		o.launch(1, true, true, -1, false, false, 0, false, true);
	}
	@Test
	public void test2859() {
		o.launch(1, true, true, -1, false, false, 0, false, false);
	}
	@Test
	public void test2860() {
		o.launch(1, true, true, -1, false, false, 1, true, true);
	}
	@Test
	public void test2861() {
		o.launch(1, true, true, 10, false, false, 1, true, false);
	}
	@Test
	public void test2862() {
		o.launch(1, true, true, -1, false, false, 1, false, true);
	}
	@Test
	public void test2863() {
		o.launch(1, true, true, 100, false, false, 1, false, false);
	}
	@Test
	public void test2864() {
		o.launch(1, true, true, 5, false, false, 2, true, true);
	}
	@Test
	public void test2865() {
		o.launch(1, true, true, 5, false, false, 2, true, false);
	}
	@Test
	public void test2866() {
		o.launch(1, true, true, 5, false, false, 2, false, true);
	}
	@Test
	public void test2867() {
		o.launch(1, true, true, 5, false, false, 2, false, false);
	}
	@Test
	public void test2868() {
		o.launch(1, true, true, 5, false, false, 3, true, true);
	}
	@Test
	public void test2869() {
		o.launch(1, true, true, 5, false, false, 3, true, false);
	}
	@Test
	public void test2870() {
		o.launch(1, true, true, 5, false, false, 3, false, true);
	}
	@Test
	public void test2871() {
		o.launch(1, true, true, 5, false, false, 3, false, false);
	}
	@Test
	public void test2872() {
		o.launch(1, true, true, 100, false, false, 4, true, true);
	}
	@Test
	public void test2873() {
		o.launch(1, true, true, 5, false, false, 4, true, false);
	}
	@Test
	public void test2874() {
		o.launch(1, true, true, 100, false, false, 4, false, true);
	}
	@Test
	public void test2875() {
		o.launch(1, true, true, 5, false, false, 4, false, false);
	}
	@Test
	public void test2876() {
		o.launch(1, true, true, -1, false, false, -1, true, true);
	}
	@Test
	public void test2877() {
		o.launch(1, true, true, -1, false, false, -1, true, false);
	}
	@Test
	public void test2878() {
		o.launch(1, true, true, -1, false, false, -1, false, true);
	}
	@Test
	public void test2879() {
		o.launch(1, true, true, -1, false, false, -1, false, false);
	}
	@Test
	public void test2880() {
		o.launch(1, true, false, 0, true, true, 0, true, true);
	}
	@Test
	public void test2881() {
		o.launch(1, true, false, 0, true, true, 0, true, false);
	}
	@Test
	public void test2882() {
		o.launch(1, true, false, 0, true, true, 0, false, true);
	}
	@Test
	public void test2883() {
		o.launch(1, true, false, 0, true, true, 0, false, false);
	}
	@Test
	public void test2884() {
		o.launch(1, true, false, 0, true, true, 1, true, true);
	}
	@Test
	public void test2885() {
		o.launch(1, true, false, 0, true, true, 1, true, false);
	}
	@Test
	public void test2886() {
		o.launch(1, true, false, 0, true, true, 1, false, true);
	}
	@Test
	public void test2887() {
		o.launch(1, true, false, 0, true, true, 1, false, false);
	}
	@Test
	public void test2888() {
		o.launch(1, true, false, 0, true, true, 2, true, true);
	}
	@Test
	public void test2889() {
		o.launch(1, true, false, 0, true, true, 2, true, false);
	}
	@Test
	public void test2890() {
		o.launch(1, true, false, 0, true, true, 2, false, true);
	}
	@Test
	public void test2891() {
		o.launch(1, true, false, 0, true, true, 2, false, false);
	}
	@Test
	public void test2892() {
		o.launch(1, true, false, 0, true, true, 3, true, true);
	}
	@Test
	public void test2893() {
		o.launch(1, true, false, 0, true, true, 3, true, false);
	}
	@Test
	public void test2894() {
		o.launch(1, true, false, 0, true, true, 3, false, true);
	}
	@Test
	public void test2895() {
		o.launch(1, true, false, 0, true, true, 3, false, false);
	}
	@Test
	public void test2896() {
		o.launch(1, true, false, 0, true, true, 4, true, true);
	}
	@Test
	public void test2897() {
		o.launch(1, true, false, 0, true, true, 4, true, false);
	}
	@Test
	public void test2898() {
		o.launch(1, true, false, 0, true, true, 4, false, true);
	}
	@Test
	public void test2899() {
		o.launch(1, true, false, 0, true, true, 4, false, false);
	}
	@Test
	public void test2900() {
		o.launch(1, true, false, 0, true, true, 10, true, true);
	}
	@Test
	public void test2901() {
		o.launch(1, true, false, 0, true, true, 10, true, false);
	}
	@Test
	public void test2902() {
		o.launch(1, true, false, 0, true, true, 100, false, true);
	}
	@Test
	public void test2903() {
		o.launch(1, true, false, 0, true, true, 10, false, false);
	}
	@Test
	public void test2904() {
		o.launch(1, true, false, 0, true, false, 0, true, true);
	}
	@Test
	public void test2905() {
		o.launch(1, true, false, 0, true, false, 0, true, false);
	}
	@Test
	public void test2906() {
		o.launch(1, true, false, 0, true, false, 0, false, true);
	}
	@Test
	public void test2907() {
		o.launch(1, true, false, 0, true, false, 0, false, false);
	}
	@Test
	public void test2908() {
		o.launch(1, true, false, 0, true, false, 1, true, true);
	}
	@Test
	public void test2909() {
		o.launch(1, true, false, 0, true, false, 1, true, false);
	}
	@Test
	public void test2910() {
		o.launch(1, true, false, 0, true, false, 1, false, true);
	}
	@Test
	public void test2911() {
		o.launch(1, true, false, 0, true, false, 1, false, false);
	}
	@Test
	public void test2912() {
		o.launch(1, true, false, 0, true, false, 2, true, true);
	}
	@Test
	public void test2913() {
		o.launch(1, true, false, 0, true, false, 2, true, false);
	}
	@Test
	public void test2914() {
		o.launch(1, true, false, 0, true, false, 2, false, true);
	}
	@Test
	public void test2915() {
		o.launch(1, true, false, 0, true, false, 2, false, false);
	}
	@Test
	public void test2916() {
		o.launch(1, true, false, 0, true, false, 3, true, true);
	}
	@Test
	public void test2917() {
		o.launch(1, true, false, 0, true, false, 3, true, false);
	}
	@Test
	public void test2918() {
		o.launch(1, true, false, 0, true, false, 3, false, true);
	}
	@Test
	public void test2919() {
		o.launch(1, true, false, 0, true, false, 3, false, false);
	}
	@Test
	public void test2920() {
		o.launch(1, true, false, 0, true, false, 4, true, true);
	}
	@Test
	public void test2921() {
		o.launch(1, true, false, 0, true, false, 4, true, false);
	}
	@Test
	public void test2922() {
		o.launch(1, true, false, 0, true, false, 4, false, true);
	}
	@Test
	public void test2923() {
		o.launch(1, true, false, 0, true, false, 4, false, false);
	}
	@Test
	public void test2924() {
		o.launch(1, true, false, 0, true, false, 100, true, true);
	}
	@Test
	public void test2925() {
		o.launch(1, true, false, 0, true, false, -1, true, false);
	}
	@Test
	public void test2926() {
		o.launch(1, true, false, 0, true, false, 5, false, true);
	}
	@Test
	public void test2927() {
		o.launch(1, true, false, 0, true, false, 100, false, false);
	}
	@Test
	public void test2928() {
		o.launch(1, true, false, 0, false, true, 0, true, true);
	}
	@Test
	public void test2929() {
		o.launch(1, true, false, 0, false, true, 0, true, false);
	}
	@Test
	public void test2930() {
		o.launch(1, true, false, 0, false, true, 0, false, true);
	}
	@Test
	public void test2931() {
		o.launch(1, true, false, 0, false, true, 0, false, false);
	}
	@Test
	public void test2932() {
		o.launch(1, true, false, 0, false, true, 1, true, true);
	}
	@Test
	public void test2933() {
		o.launch(1, true, false, 0, false, true, 1, true, false);
	}
	@Test
	public void test2934() {
		o.launch(1, true, false, 0, false, true, 1, false, true);
	}
	@Test
	public void test2935() {
		o.launch(1, true, false, 0, false, true, 1, false, false);
	}
	@Test
	public void test2936() {
		o.launch(1, true, false, 0, false, true, 2, true, true);
	}
	@Test
	public void test2937() {
		o.launch(1, true, false, 0, false, true, 2, true, false);
	}
	@Test
	public void test2938() {
		o.launch(1, true, false, 0, false, true, 2, false, true);
	}
	@Test
	public void test2939() {
		o.launch(1, true, false, 0, false, true, 2, false, false);
	}
	@Test
	public void test2940() {
		o.launch(1, true, false, 0, false, true, 3, true, true);
	}
	@Test
	public void test2941() {
		o.launch(1, true, false, 0, false, true, 3, true, false);
	}
	@Test
	public void test2942() {
		o.launch(1, true, false, 0, false, true, 3, false, true);
	}
	@Test
	public void test2943() {
		o.launch(1, true, false, 0, false, true, 3, false, false);
	}
	@Test
	public void test2944() {
		o.launch(1, true, false, 0, false, true, 4, true, true);
	}
	@Test
	public void test2945() {
		o.launch(1, true, false, 0, false, true, 4, true, false);
	}
	@Test
	public void test2946() {
		o.launch(1, true, false, 0, false, true, 4, false, true);
	}
	@Test
	public void test2947() {
		o.launch(1, true, false, 0, false, true, 4, false, false);
	}
	@Test
	public void test2948() {
		o.launch(1, true, false, 0, false, true, -1, true, true);
	}
	@Test
	public void test2949() {
		o.launch(1, true, false, 0, false, true, 5, true, false);
	}
	@Test
	public void test2950() {
		o.launch(1, true, false, 0, false, true, -1, false, true);
	}
	@Test
	public void test2951() {
		o.launch(1, true, false, 0, false, true, -1, false, false);
	}
	@Test
	public void test2952() {
		o.launch(1, true, false, 0, false, false, 0, true, true);
	}
	@Test
	public void test2953() {
		o.launch(1, true, false, 0, false, false, 0, true, false);
	}
	@Test
	public void test2954() {
		o.launch(1, true, false, 0, false, false, 0, false, true);
	}
	@Test
	public void test2955() {
		o.launch(1, true, false, 0, false, false, 0, false, false);
	}
	@Test
	public void test2956() {
		o.launch(1, true, false, 0, false, false, 1, true, true);
	}
	@Test
	public void test2957() {
		o.launch(1, true, false, 0, false, false, 1, true, false);
	}
	@Test
	public void test2958() {
		o.launch(1, true, false, 0, false, false, 1, false, true);
	}
	@Test
	public void test2959() {
		o.launch(1, true, false, 0, false, false, 1, false, false);
	}
	@Test
	public void test2960() {
		o.launch(1, true, false, 0, false, false, 2, true, true);
	}
	@Test
	public void test2961() {
		o.launch(1, true, false, 0, false, false, 2, true, false);
	}
	@Test
	public void test2962() {
		o.launch(1, true, false, 0, false, false, 2, false, true);
	}
	@Test
	public void test2963() {
		o.launch(1, true, false, 0, false, false, 2, false, false);
	}
	@Test
	public void test2964() {
		o.launch(1, true, false, 0, false, false, 3, true, true);
	}
	@Test
	public void test2965() {
		o.launch(1, true, false, 0, false, false, 3, true, false);
	}
	@Test
	public void test2966() {
		o.launch(1, true, false, 0, false, false, 3, false, true);
	}
	@Test
	public void test2967() {
		o.launch(1, true, false, 0, false, false, 3, false, false);
	}
	@Test
	public void test2968() {
		o.launch(1, true, false, 0, false, false, 4, true, true);
	}
	@Test
	public void test2969() {
		o.launch(1, true, false, 0, false, false, 4, true, false);
	}
	@Test
	public void test2970() {
		o.launch(1, true, false, 0, false, false, 4, false, true);
	}
	@Test
	public void test2971() {
		o.launch(1, true, false, 0, false, false, 4, false, false);
	}
	@Test
	public void test2972() {
		o.launch(1, true, false, 0, false, false, 10, true, true);
	}
	@Test
	public void test2973() {
		o.launch(1, true, false, 0, false, false, 10, true, false);
	}
	@Test
	public void test2974() {
		o.launch(1, true, false, 0, false, false, 10, false, true);
	}
	@Test
	public void test2975() {
		o.launch(1, true, false, 0, false, false, 100, false, false);
	}
	@Test
	public void test2976() {
		o.launch(1, true, false, 1, true, true, 0, true, true);
	}
	@Test
	public void test2977() {
		o.launch(1, true, false, 1, true, true, 0, true, false);
	}
	@Test
	public void test2978() {
		o.launch(1, true, false, 1, true, true, 0, false, true);
	}
	@Test
	public void test2979() {
		o.launch(1, true, false, 1, true, true, 0, false, false);
	}
	@Test
	public void test2980() {
		o.launch(1, true, false, 1, true, true, 1, true, true);
	}
	@Test
	public void test2981() {
		o.launch(1, true, false, 1, true, true, 1, true, false);
	}
	@Test
	public void test2982() {
		o.launch(1, true, false, 1, true, true, 1, false, true);
	}
	@Test
	public void test2983() {
		o.launch(1, true, false, 1, true, true, 1, false, false);
	}
	@Test
	public void test2984() {
		o.launch(1, true, false, 1, true, true, 2, true, true);
	}
	@Test
	public void test2985() {
		o.launch(1, true, false, 1, true, true, 2, true, false);
	}
	@Test
	public void test2986() {
		o.launch(1, true, false, 1, true, true, 2, false, true);
	}
	@Test
	public void test2987() {
		o.launch(1, true, false, 1, true, true, 2, false, false);
	}
	@Test
	public void test2988() {
		o.launch(1, true, false, 1, true, true, 3, true, true);
	}
	@Test
	public void test2989() {
		o.launch(1, true, false, 1, true, true, 3, true, false);
	}
	@Test
	public void test2990() {
		o.launch(1, true, false, 1, true, true, 3, false, true);
	}
	@Test
	public void test2991() {
		o.launch(1, true, false, 1, true, true, 3, false, false);
	}
	@Test
	public void test2992() {
		o.launch(1, true, false, 1, true, true, 4, true, true);
	}
	@Test
	public void test2993() {
		o.launch(1, true, false, 1, true, true, 4, true, false);
	}
	@Test
	public void test2994() {
		o.launch(1, true, false, 1, true, true, 4, false, true);
	}
	@Test
	public void test2995() {
		o.launch(1, true, false, 1, true, true, 4, false, false);
	}
	@Test
	public void test2996() {
		o.launch(1, true, false, 1, true, true, 5, true, true);
	}
	@Test
	public void test2997() {
		o.launch(1, true, false, 1, true, true, -1, true, false);
	}
	@Test
	public void test2998() {
		o.launch(1, true, false, 1, true, true, 5, false, true);
	}
	@Test
	public void test2999() {
		o.launch(1, true, false, 1, true, true, 100, false, false);
	}
	@Test
	public void test3000() {
		o.launch(1, true, false, 1, true, false, 0, true, true);
	}
	@Test
	public void test3001() {
		o.launch(1, true, false, 1, true, false, 0, true, false);
	}
	@Test
	public void test3002() {
		o.launch(1, true, false, 1, true, false, 0, false, true);
	}
	@Test
	public void test3003() {
		o.launch(1, true, false, 1, true, false, 0, false, false);
	}
	@Test
	public void test3004() {
		o.launch(1, true, false, 1, true, false, 1, true, true);
	}
	@Test
	public void test3005() {
		o.launch(1, true, false, 1, true, false, 1, true, false);
	}
	@Test
	public void test3006() {
		o.launch(1, true, false, 1, true, false, 1, false, true);
	}
	@Test
	public void test3007() {
		o.launch(1, true, false, 1, true, false, 1, false, false);
	}
	@Test
	public void test3008() {
		o.launch(1, true, false, 1, true, false, 2, true, true);
	}
	@Test
	public void test3009() {
		o.launch(1, true, false, 1, true, false, 2, true, false);
	}
	@Test
	public void test3010() {
		o.launch(1, true, false, 1, true, false, 2, false, true);
	}
	@Test
	public void test3011() {
		o.launch(1, true, false, 1, true, false, 2, false, false);
	}
	@Test
	public void test3012() {
		o.launch(1, true, false, 1, true, false, 3, true, true);
	}
	@Test
	public void test3013() {
		o.launch(1, true, false, 1, true, false, 3, true, false);
	}
	@Test
	public void test3014() {
		o.launch(1, true, false, 1, true, false, 3, false, true);
	}
	@Test
	public void test3015() {
		o.launch(1, true, false, 1, true, false, 3, false, false);
	}
	@Test
	public void test3016() {
		o.launch(1, true, false, 1, true, false, 4, true, true);
	}
	@Test
	public void test3017() {
		o.launch(1, true, false, 1, true, false, 4, true, false);
	}
	@Test
	public void test3018() {
		o.launch(1, true, false, 1, true, false, 4, false, true);
	}
	@Test
	public void test3019() {
		o.launch(1, true, false, 1, true, false, 4, false, false);
	}
	@Test
	public void test3020() {
		o.launch(1, true, false, 1, true, false, 10, true, true);
	}
	@Test
	public void test3021() {
		o.launch(1, true, false, 1, true, false, -1, true, false);
	}
	@Test
	public void test3022() {
		o.launch(1, true, false, 1, true, false, 10, false, true);
	}
	@Test
	public void test3023() {
		o.launch(1, true, false, 1, true, false, -1, false, false);
	}
	@Test
	public void test3024() {
		o.launch(1, true, false, 1, false, true, 0, true, true);
	}
	@Test
	public void test3025() {
		o.launch(1, true, false, 1, false, true, 0, true, false);
	}
	@Test
	public void test3026() {
		o.launch(1, true, false, 1, false, true, 0, false, true);
	}
	@Test
	public void test3027() {
		o.launch(1, true, false, 1, false, true, 0, false, false);
	}
	@Test
	public void test3028() {
		o.launch(1, true, false, 1, false, true, 1, true, true);
	}
	@Test
	public void test3029() {
		o.launch(1, true, false, 1, false, true, 1, true, false);
	}
	@Test
	public void test3030() {
		o.launch(1, true, false, 1, false, true, 1, false, true);
	}
	@Test
	public void test3031() {
		o.launch(1, true, false, 1, false, true, 1, false, false);
	}
	@Test
	public void test3032() {
		o.launch(1, true, false, 1, false, true, 2, true, true);
	}
	@Test
	public void test3033() {
		o.launch(1, true, false, 1, false, true, 2, true, false);
	}
	@Test
	public void test3034() {
		o.launch(1, true, false, 1, false, true, 2, false, true);
	}
	@Test
	public void test3035() {
		o.launch(1, true, false, 1, false, true, 2, false, false);
	}
	@Test
	public void test3036() {
		o.launch(1, true, false, 1, false, true, 3, true, true);
	}
	@Test
	public void test3037() {
		o.launch(1, true, false, 1, false, true, 3, true, false);
	}
	@Test
	public void test3038() {
		o.launch(1, true, false, 1, false, true, 3, false, true);
	}
	@Test
	public void test3039() {
		o.launch(1, true, false, 1, false, true, 3, false, false);
	}
	@Test
	public void test3040() {
		o.launch(1, true, false, 1, false, true, 4, true, true);
	}
	@Test
	public void test3041() {
		o.launch(1, true, false, 1, false, true, 4, true, false);
	}
	@Test
	public void test3042() {
		o.launch(1, true, false, 1, false, true, 4, false, true);
	}
	@Test
	public void test3043() {
		o.launch(1, true, false, 1, false, true, 4, false, false);
	}
	@Test
	public void test3044() {
		o.launch(1, true, false, 1, false, true, 10, true, true);
	}
	@Test
	public void test3045() {
		o.launch(1, true, false, 1, false, true, 10, true, false);
	}
	@Test
	public void test3046() {
		o.launch(1, true, false, 1, false, true, 10, false, true);
	}
	@Test
	public void test3047() {
		o.launch(1, true, false, 1, false, true, 10, false, false);
	}
	@Test
	public void test3048() {
		o.launch(1, true, false, 1, false, false, 0, true, true);
	}
	@Test
	public void test3049() {
		o.launch(1, true, false, 1, false, false, 0, true, false);
	}
	@Test
	public void test3050() {
		o.launch(1, true, false, 1, false, false, 0, false, true);
	}
	@Test
	public void test3051() {
		o.launch(1, true, false, 1, false, false, 0, false, false);
	}
	@Test
	public void test3052() {
		o.launch(1, true, false, 1, false, false, 1, true, true);
	}
	@Test
	public void test3053() {
		o.launch(1, true, false, 1, false, false, 1, true, false);
	}
	@Test
	public void test3054() {
		o.launch(1, true, false, 1, false, false, 1, false, true);
	}
	@Test
	public void test3055() {
		o.launch(1, true, false, 1, false, false, 1, false, false);
	}
	@Test
	public void test3056() {
		o.launch(1, true, false, 1, false, false, 2, true, true);
	}
	@Test
	public void test3057() {
		o.launch(1, true, false, 1, false, false, 2, true, false);
	}
	@Test
	public void test3058() {
		o.launch(1, true, false, 1, false, false, 2, false, true);
	}
	@Test
	public void test3059() {
		o.launch(1, true, false, 1, false, false, 2, false, false);
	}
	@Test
	public void test3060() {
		o.launch(1, true, false, 1, false, false, 3, true, true);
	}
	@Test
	public void test3061() {
		o.launch(1, true, false, 1, false, false, 3, true, false);
	}
	@Test
	public void test3062() {
		o.launch(1, true, false, 1, false, false, 3, false, true);
	}
	@Test
	public void test3063() {
		o.launch(1, true, false, 1, false, false, 3, false, false);
	}
	@Test
	public void test3064() {
		o.launch(1, true, false, 1, false, false, 4, true, true);
	}
	@Test
	public void test3065() {
		o.launch(1, true, false, 1, false, false, 4, true, false);
	}
	@Test
	public void test3066() {
		o.launch(1, true, false, 1, false, false, 4, false, true);
	}
	@Test
	public void test3067() {
		o.launch(1, true, false, 1, false, false, 4, false, false);
	}
	@Test
	public void test3068() {
		o.launch(1, true, false, 1, false, false, -1, true, true);
	}
	@Test
	public void test3069() {
		o.launch(1, true, false, 1, false, false, -1, true, false);
	}
	@Test
	public void test3070() {
		o.launch(1, true, false, 1, false, false, 10, false, true);
	}
	@Test
	public void test3071() {
		o.launch(1, true, false, 1, false, false, -1, false, false);
	}
	@Test
	public void test3072() {
		o.launch(1, true, false, 2, true, true, 0, true, true);
	}
	@Test
	public void test3073() {
		o.launch(1, true, false, 2, true, true, 0, true, false);
	}
	@Test
	public void test3074() {
		o.launch(1, true, false, 2, true, true, 0, false, true);
	}
	@Test
	public void test3075() {
		o.launch(1, true, false, 2, true, true, 0, false, false);
	}
	@Test
	public void test3076() {
		o.launch(1, true, false, 2, true, true, 1, true, true);
	}
	@Test
	public void test3077() {
		o.launch(1, true, false, 2, true, true, 1, true, false);
	}
	@Test
	public void test3078() {
		o.launch(1, true, false, 2, true, true, 1, false, true);
	}
	@Test
	public void test3079() {
		o.launch(1, true, false, 2, true, true, 1, false, false);
	}
	@Test
	public void test3080() {
		o.launch(1, true, false, 2, true, true, 2, true, true);
	}
	@Test
	public void test3081() {
		o.launch(1, true, false, 2, true, true, 2, true, false);
	}
	@Test
	public void test3082() {
		o.launch(1, true, false, 2, true, true, 2, false, true);
	}
	@Test
	public void test3083() {
		o.launch(1, true, false, 2, true, true, 2, false, false);
	}
	@Test
	public void test3084() {
		o.launch(1, true, false, 2, true, true, 3, true, true);
	}
	@Test
	public void test3085() {
		o.launch(1, true, false, 2, true, true, 3, true, false);
	}
	@Test
	public void test3086() {
		o.launch(1, true, false, 2, true, true, 3, false, true);
	}
	@Test
	public void test3087() {
		o.launch(1, true, false, 2, true, true, 3, false, false);
	}
	@Test
	public void test3088() {
		o.launch(1, true, false, 2, true, true, 4, true, true);
	}
	@Test
	public void test3089() {
		o.launch(1, true, false, 2, true, true, 4, true, false);
	}
	@Test
	public void test3090() {
		o.launch(1, true, false, 2, true, true, 4, false, true);
	}
	@Test
	public void test3091() {
		o.launch(1, true, false, 2, true, true, 4, false, false);
	}
	@Test
	public void test3092() {
		o.launch(1, true, false, 2, true, true, 5, true, true);
	}
	@Test
	public void test3093() {
		o.launch(1, true, false, 2, true, true, 5, true, false);
	}
	@Test
	public void test3094() {
		o.launch(1, true, false, 2, true, true, 5, false, true);
	}
	@Test
	public void test3095() {
		o.launch(1, true, false, 2, true, true, 5, false, false);
	}
	@Test
	public void test3096() {
		o.launch(1, true, false, 2, true, false, 0, true, true);
	}
	@Test
	public void test3097() {
		o.launch(1, true, false, 2, true, false, 0, true, false);
	}
	@Test
	public void test3098() {
		o.launch(1, true, false, 2, true, false, 0, false, true);
	}
	@Test
	public void test3099() {
		o.launch(1, true, false, 2, true, false, 0, false, false);
	}
	@Test
	public void test3100() {
		o.launch(1, true, false, 2, true, false, 1, true, true);
	}
	@Test
	public void test3101() {
		o.launch(1, true, false, 2, true, false, 1, true, false);
	}
	@Test
	public void test3102() {
		o.launch(1, true, false, 2, true, false, 1, false, true);
	}
	@Test
	public void test3103() {
		o.launch(1, true, false, 2, true, false, 1, false, false);
	}
	@Test
	public void test3104() {
		o.launch(1, true, false, 2, true, false, 2, true, true);
	}
	@Test
	public void test3105() {
		o.launch(1, true, false, 2, true, false, 2, true, false);
	}
	@Test
	public void test3106() {
		o.launch(1, true, false, 2, true, false, 2, false, true);
	}
	@Test
	public void test3107() {
		o.launch(1, true, false, 2, true, false, 2, false, false);
	}
	@Test
	public void test3108() {
		o.launch(1, true, false, 2, true, false, 3, true, true);
	}
	@Test
	public void test3109() {
		o.launch(1, true, false, 2, true, false, 3, true, false);
	}
	@Test
	public void test3110() {
		o.launch(1, true, false, 2, true, false, 3, false, true);
	}
	@Test
	public void test3111() {
		o.launch(1, true, false, 2, true, false, 3, false, false);
	}
	@Test
	public void test3112() {
		o.launch(1, true, false, 2, true, false, 4, true, true);
	}
	@Test
	public void test3113() {
		o.launch(1, true, false, 2, true, false, 4, true, false);
	}
	@Test
	public void test3114() {
		o.launch(1, true, false, 2, true, false, 4, false, true);
	}
	@Test
	public void test3115() {
		o.launch(1, true, false, 2, true, false, 4, false, false);
	}
	@Test
	public void test3116() {
		o.launch(1, true, false, 2, true, false, 5, true, true);
	}
	@Test
	public void test3117() {
		o.launch(1, true, false, 2, true, false, 5, true, false);
	}
	@Test
	public void test3118() {
		o.launch(1, true, false, 2, true, false, 5, false, true);
	}
	@Test
	public void test3119() {
		o.launch(1, true, false, 2, true, false, 5, false, false);
	}
	@Test
	public void test3120() {
		o.launch(1, true, false, 2, false, true, 0, true, true);
	}
	@Test
	public void test3121() {
		o.launch(1, true, false, 2, false, true, 0, true, false);
	}
	@Test
	public void test3122() {
		o.launch(1, true, false, 2, false, true, 0, false, true);
	}
	@Test
	public void test3123() {
		o.launch(1, true, false, 2, false, true, 0, false, false);
	}
	@Test
	public void test3124() {
		o.launch(1, true, false, 2, false, true, 1, true, true);
	}
	@Test
	public void test3125() {
		o.launch(1, true, false, 2, false, true, 1, true, false);
	}
	@Test
	public void test3126() {
		o.launch(1, true, false, 2, false, true, 1, false, true);
	}
	@Test
	public void test3127() {
		o.launch(1, true, false, 2, false, true, 1, false, false);
	}
	@Test
	public void test3128() {
		o.launch(1, true, false, 2, false, true, 2, true, true);
	}
	@Test
	public void test3129() {
		o.launch(1, true, false, 2, false, true, 2, true, false);
	}
	@Test
	public void test3130() {
		o.launch(1, true, false, 2, false, true, 2, false, true);
	}
	@Test
	public void test3131() {
		o.launch(1, true, false, 2, false, true, 2, false, false);
	}
	@Test
	public void test3132() {
		o.launch(1, true, false, 2, false, true, 3, true, true);
	}
	@Test
	public void test3133() {
		o.launch(1, true, false, 2, false, true, 3, true, false);
	}
	@Test
	public void test3134() {
		o.launch(1, true, false, 2, false, true, 3, false, true);
	}
	@Test
	public void test3135() {
		o.launch(1, true, false, 2, false, true, 3, false, false);
	}
	@Test
	public void test3136() {
		o.launch(1, true, false, 2, false, true, 4, true, true);
	}
	@Test
	public void test3137() {
		o.launch(1, true, false, 2, false, true, 4, true, false);
	}
	@Test
	public void test3138() {
		o.launch(1, true, false, 2, false, true, 4, false, true);
	}
	@Test
	public void test3139() {
		o.launch(1, true, false, 2, false, true, 4, false, false);
	}
	@Test
	public void test3140() {
		o.launch(1, true, false, 2, false, true, 5, true, true);
	}
	@Test
	public void test3141() {
		o.launch(1, true, false, 2, false, true, 5, true, false);
	}
	@Test
	public void test3142() {
		o.launch(1, true, false, 2, false, true, 5, false, true);
	}
	@Test
	public void test3143() {
		o.launch(1, true, false, 2, false, true, 5, false, false);
	}
	@Test
	public void test3144() {
		o.launch(1, true, false, 2, false, false, 0, true, true);
	}
	@Test
	public void test3145() {
		o.launch(1, true, false, 2, false, false, 0, true, false);
	}
	@Test
	public void test3146() {
		o.launch(1, true, false, 2, false, false, 0, false, true);
	}
	@Test
	public void test3147() {
		o.launch(1, true, false, 2, false, false, 0, false, false);
	}
	@Test
	public void test3148() {
		o.launch(1, true, false, 2, false, false, 1, true, true);
	}
	@Test
	public void test3149() {
		o.launch(1, true, false, 2, false, false, 1, true, false);
	}
	@Test
	public void test3150() {
		o.launch(1, true, false, 2, false, false, 1, false, true);
	}
	@Test
	public void test3151() {
		o.launch(1, true, false, 2, false, false, 1, false, false);
	}
	@Test
	public void test3152() {
		o.launch(1, true, false, 2, false, false, 2, true, true);
	}
	@Test
	public void test3153() {
		o.launch(1, true, false, 2, false, false, 2, true, false);
	}
	@Test
	public void test3154() {
		o.launch(1, true, false, 2, false, false, 2, false, true);
	}
	@Test
	public void test3155() {
		o.launch(1, true, false, 2, false, false, 2, false, false);
	}
	@Test
	public void test3156() {
		o.launch(1, true, false, 2, false, false, 3, true, true);
	}
	@Test
	public void test3157() {
		o.launch(1, true, false, 2, false, false, 3, true, false);
	}
	@Test
	public void test3158() {
		o.launch(1, true, false, 2, false, false, 3, false, true);
	}
	@Test
	public void test3159() {
		o.launch(1, true, false, 2, false, false, 3, false, false);
	}
	@Test
	public void test3160() {
		o.launch(1, true, false, 2, false, false, 4, true, true);
	}
	@Test
	public void test3161() {
		o.launch(1, true, false, 2, false, false, 4, true, false);
	}
	@Test
	public void test3162() {
		o.launch(1, true, false, 2, false, false, 4, false, true);
	}
	@Test
	public void test3163() {
		o.launch(1, true, false, 2, false, false, 4, false, false);
	}
	@Test
	public void test3164() {
		o.launch(1, true, false, 2, false, false, 5, true, true);
	}
	@Test
	public void test3165() {
		o.launch(1, true, false, 2, false, false, 5, true, false);
	}
	@Test
	public void test3166() {
		o.launch(1, true, false, 2, false, false, 5, false, true);
	}
	@Test
	public void test3167() {
		o.launch(1, true, false, 2, false, false, 5, false, false);
	}
	@Test
	public void test3168() {
		o.launch(1, true, false, 3, true, true, 0, true, true);
	}
	@Test
	public void test3169() {
		o.launch(1, true, false, 3, true, true, 0, true, false);
	}
	@Test
	public void test3170() {
		o.launch(1, true, false, 3, true, true, 0, false, true);
	}
	@Test
	public void test3171() {
		o.launch(1, true, false, 3, true, true, 0, false, false);
	}
	@Test
	public void test3172() {
		o.launch(1, true, false, 3, true, true, 1, true, true);
	}
	@Test
	public void test3173() {
		o.launch(1, true, false, 3, true, true, 1, true, false);
	}
	@Test
	public void test3174() {
		o.launch(1, true, false, 3, true, true, 1, false, true);
	}
	@Test
	public void test3175() {
		o.launch(1, true, false, 3, true, true, 1, false, false);
	}
	@Test
	public void test3176() {
		o.launch(1, true, false, 3, true, true, 2, true, true);
	}
	@Test
	public void test3177() {
		o.launch(1, true, false, 3, true, true, 2, true, false);
	}
	@Test
	public void test3178() {
		o.launch(1, true, false, 3, true, true, 2, false, true);
	}
	@Test
	public void test3179() {
		o.launch(1, true, false, 3, true, true, 2, false, false);
	}
	@Test
	public void test3180() {
		o.launch(1, true, false, 3, true, true, 3, true, true);
	}
	@Test
	public void test3181() {
		o.launch(1, true, false, 3, true, true, 3, true, false);
	}
	@Test
	public void test3182() {
		o.launch(1, true, false, 3, true, true, 3, false, true);
	}
	@Test
	public void test3183() {
		o.launch(1, true, false, 3, true, true, 3, false, false);
	}
	@Test
	public void test3184() {
		o.launch(1, true, false, 3, true, true, 4, true, true);
	}
	@Test
	public void test3185() {
		o.launch(1, true, false, 3, true, true, 4, true, false);
	}
	@Test
	public void test3186() {
		o.launch(1, true, false, 3, true, true, 4, false, true);
	}
	@Test
	public void test3187() {
		o.launch(1, true, false, 3, true, true, 4, false, false);
	}
	@Test
	public void test3188() {
		o.launch(1, true, false, 3, true, true, 5, true, true);
	}
	@Test
	public void test3189() {
		o.launch(1, true, false, 3, true, true, 5, true, false);
	}
	@Test
	public void test3190() {
		o.launch(1, true, false, 3, true, true, 5, false, true);
	}
	@Test
	public void test3191() {
		o.launch(1, true, false, 3, true, true, 5, false, false);
	}
	@Test
	public void test3192() {
		o.launch(1, true, false, 3, true, false, 0, true, true);
	}
	@Test
	public void test3193() {
		o.launch(1, true, false, 3, true, false, 0, true, false);
	}
	@Test
	public void test3194() {
		o.launch(1, true, false, 3, true, false, 0, false, true);
	}
	@Test
	public void test3195() {
		o.launch(1, true, false, 3, true, false, 0, false, false);
	}
	@Test
	public void test3196() {
		o.launch(1, true, false, 3, true, false, 1, true, true);
	}
	@Test
	public void test3197() {
		o.launch(1, true, false, 3, true, false, 1, true, false);
	}
	@Test
	public void test3198() {
		o.launch(1, true, false, 3, true, false, 1, false, true);
	}
	@Test
	public void test3199() {
		o.launch(1, true, false, 3, true, false, 1, false, false);
	}
	@Test
	public void test3200() {
		o.launch(1, true, false, 3, true, false, 2, true, true);
	}
	@Test
	public void test3201() {
		o.launch(1, true, false, 3, true, false, 2, true, false);
	}
	@Test
	public void test3202() {
		o.launch(1, true, false, 3, true, false, 2, false, true);
	}
	@Test
	public void test3203() {
		o.launch(1, true, false, 3, true, false, 2, false, false);
	}
	@Test
	public void test3204() {
		o.launch(1, true, false, 3, true, false, 3, true, true);
	}
	@Test
	public void test3205() {
		o.launch(1, true, false, 3, true, false, 3, true, false);
	}
	@Test
	public void test3206() {
		o.launch(1, true, false, 3, true, false, 3, false, true);
	}
	@Test
	public void test3207() {
		o.launch(1, true, false, 3, true, false, 3, false, false);
	}
	@Test
	public void test3208() {
		o.launch(1, true, false, 3, true, false, 4, true, true);
	}
	@Test
	public void test3209() {
		o.launch(1, true, false, 3, true, false, 4, true, false);
	}
	@Test
	public void test3210() {
		o.launch(1, true, false, 3, true, false, 4, false, true);
	}
	@Test
	public void test3211() {
		o.launch(1, true, false, 3, true, false, 4, false, false);
	}
	@Test
	public void test3212() {
		o.launch(1, true, false, 3, true, false, 5, true, true);
	}
	@Test
	public void test3213() {
		o.launch(1, true, false, 3, true, false, 5, true, false);
	}
	@Test
	public void test3214() {
		o.launch(1, true, false, 3, true, false, 5, false, true);
	}
	@Test
	public void test3215() {
		o.launch(1, true, false, 3, true, false, 5, false, false);
	}
	@Test
	public void test3216() {
		o.launch(1, true, false, 3, false, true, 0, true, true);
	}
	@Test
	public void test3217() {
		o.launch(1, true, false, 3, false, true, 0, true, false);
	}
	@Test
	public void test3218() {
		o.launch(1, true, false, 3, false, true, 0, false, true);
	}
	@Test
	public void test3219() {
		o.launch(1, true, false, 3, false, true, 0, false, false);
	}
	@Test
	public void test3220() {
		o.launch(1, true, false, 3, false, true, 1, true, true);
	}
	@Test
	public void test3221() {
		o.launch(1, true, false, 3, false, true, 1, true, false);
	}
	@Test
	public void test3222() {
		o.launch(1, true, false, 3, false, true, 1, false, true);
	}
	@Test
	public void test3223() {
		o.launch(1, true, false, 3, false, true, 1, false, false);
	}
	@Test
	public void test3224() {
		o.launch(1, true, false, 3, false, true, 2, true, true);
	}
	@Test
	public void test3225() {
		o.launch(1, true, false, 3, false, true, 2, true, false);
	}
	@Test
	public void test3226() {
		o.launch(1, true, false, 3, false, true, 2, false, true);
	}
	@Test
	public void test3227() {
		o.launch(1, true, false, 3, false, true, 2, false, false);
	}
	@Test
	public void test3228() {
		o.launch(1, true, false, 3, false, true, 3, true, true);
	}
	@Test
	public void test3229() {
		o.launch(1, true, false, 3, false, true, 3, true, false);
	}
	@Test
	public void test3230() {
		o.launch(1, true, false, 3, false, true, 3, false, true);
	}
	@Test
	public void test3231() {
		o.launch(1, true, false, 3, false, true, 3, false, false);
	}
	@Test
	public void test3232() {
		o.launch(1, true, false, 3, false, true, 4, true, true);
	}
	@Test
	public void test3233() {
		o.launch(1, true, false, 3, false, true, 4, true, false);
	}
	@Test
	public void test3234() {
		o.launch(1, true, false, 3, false, true, 4, false, true);
	}
	@Test
	public void test3235() {
		o.launch(1, true, false, 3, false, true, 4, false, false);
	}
	@Test
	public void test3236() {
		o.launch(1, true, false, 3, false, true, 5, true, true);
	}
	@Test
	public void test3237() {
		o.launch(1, true, false, 3, false, true, 5, true, false);
	}
	@Test
	public void test3238() {
		o.launch(1, true, false, 3, false, true, 5, false, true);
	}
	@Test
	public void test3239() {
		o.launch(1, true, false, 3, false, true, 5, false, false);
	}
	@Test
	public void test3240() {
		o.launch(1, true, false, 3, false, false, 0, true, true);
	}
	@Test
	public void test3241() {
		o.launch(1, true, false, 3, false, false, 0, true, false);
	}
	@Test
	public void test3242() {
		o.launch(1, true, false, 3, false, false, 0, false, true);
	}
	@Test
	public void test3243() {
		o.launch(1, true, false, 3, false, false, 0, false, false);
	}
	@Test
	public void test3244() {
		o.launch(1, true, false, 3, false, false, 1, true, true);
	}
	@Test
	public void test3245() {
		o.launch(1, true, false, 3, false, false, 1, true, false);
	}
	@Test
	public void test3246() {
		o.launch(1, true, false, 3, false, false, 1, false, true);
	}
	@Test
	public void test3247() {
		o.launch(1, true, false, 3, false, false, 1, false, false);
	}
	@Test
	public void test3248() {
		o.launch(1, true, false, 3, false, false, 2, true, true);
	}
	@Test
	public void test3249() {
		o.launch(1, true, false, 3, false, false, 2, true, false);
	}
	@Test
	public void test3250() {
		o.launch(1, true, false, 3, false, false, 2, false, true);
	}
	@Test
	public void test3251() {
		o.launch(1, true, false, 3, false, false, 2, false, false);
	}
	@Test
	public void test3252() {
		o.launch(1, true, false, 3, false, false, 3, true, true);
	}
	@Test
	public void test3253() {
		o.launch(1, true, false, 3, false, false, 3, true, false);
	}
	@Test
	public void test3254() {
		o.launch(1, true, false, 3, false, false, 3, false, true);
	}
	@Test
	public void test3255() {
		o.launch(1, true, false, 3, false, false, 3, false, false);
	}
	@Test
	public void test3256() {
		o.launch(1, true, false, 3, false, false, 4, true, true);
	}
	@Test
	public void test3257() {
		o.launch(1, true, false, 3, false, false, 4, true, false);
	}
	@Test
	public void test3258() {
		o.launch(1, true, false, 3, false, false, 4, false, true);
	}
	@Test
	public void test3259() {
		o.launch(1, true, false, 3, false, false, 4, false, false);
	}
	@Test
	public void test3260() {
		o.launch(1, true, false, 3, false, false, 5, true, true);
	}
	@Test
	public void test3261() {
		o.launch(1, true, false, 3, false, false, 5, true, false);
	}
	@Test
	public void test3262() {
		o.launch(1, true, false, 3, false, false, 5, false, true);
	}
	@Test
	public void test3263() {
		o.launch(1, true, false, 3, false, false, 5, false, false);
	}
	@Test
	public void test3264() {
		o.launch(1, true, false, 4, true, true, 0, true, true);
	}
	@Test
	public void test3265() {
		o.launch(1, true, false, 4, true, true, 0, true, false);
	}
	@Test
	public void test3266() {
		o.launch(1, true, false, 4, true, true, 0, false, true);
	}
	@Test
	public void test3267() {
		o.launch(1, true, false, 4, true, true, 0, false, false);
	}
	@Test
	public void test3268() {
		o.launch(1, true, false, 4, true, true, 1, true, true);
	}
	@Test
	public void test3269() {
		o.launch(1, true, false, 4, true, true, 1, true, false);
	}
	@Test
	public void test3270() {
		o.launch(1, true, false, 4, true, true, 1, false, true);
	}
	@Test
	public void test3271() {
		o.launch(1, true, false, 4, true, true, 1, false, false);
	}
	@Test
	public void test3272() {
		o.launch(1, true, false, 4, true, true, 2, true, true);
	}
	@Test
	public void test3273() {
		o.launch(1, true, false, 4, true, true, 2, true, false);
	}
	@Test
	public void test3274() {
		o.launch(1, true, false, 4, true, true, 2, false, true);
	}
	@Test
	public void test3275() {
		o.launch(1, true, false, 4, true, true, 2, false, false);
	}
	@Test
	public void test3276() {
		o.launch(1, true, false, 4, true, true, 3, true, true);
	}
	@Test
	public void test3277() {
		o.launch(1, true, false, 4, true, true, 3, true, false);
	}
	@Test
	public void test3278() {
		o.launch(1, true, false, 4, true, true, 3, false, true);
	}
	@Test
	public void test3279() {
		o.launch(1, true, false, 4, true, true, 3, false, false);
	}
	@Test
	public void test3280() {
		o.launch(1, true, false, 4, true, true, 4, true, true);
	}
	@Test
	public void test3281() {
		o.launch(1, true, false, 4, true, true, 4, true, false);
	}
	@Test
	public void test3282() {
		o.launch(1, true, false, 4, true, true, 4, false, true);
	}
	@Test
	public void test3283() {
		o.launch(1, true, false, 4, true, true, 4, false, false);
	}
	@Test
	public void test3284() {
		o.launch(1, true, false, 4, true, true, 10, true, true);
	}
	@Test
	public void test3285() {
		o.launch(1, true, false, 4, true, true, -1, true, false);
	}
	@Test
	public void test3286() {
		o.launch(1, true, false, 4, true, true, 5, false, true);
	}
	@Test
	public void test3287() {
		o.launch(1, true, false, 4, true, true, 5, false, false);
	}
	@Test
	public void test3288() {
		o.launch(1, true, false, 4, true, false, 0, true, true);
	}
	@Test
	public void test3289() {
		o.launch(1, true, false, 4, true, false, 0, true, false);
	}
	@Test
	public void test3290() {
		o.launch(1, true, false, 4, true, false, 0, false, true);
	}
	@Test
	public void test3291() {
		o.launch(1, true, false, 4, true, false, 0, false, false);
	}
	@Test
	public void test3292() {
		o.launch(1, true, false, 4, true, false, 1, true, true);
	}
	@Test
	public void test3293() {
		o.launch(1, true, false, 4, true, false, 1, true, false);
	}
	@Test
	public void test3294() {
		o.launch(1, true, false, 4, true, false, 1, false, true);
	}
	@Test
	public void test3295() {
		o.launch(1, true, false, 4, true, false, 1, false, false);
	}
	@Test
	public void test3296() {
		o.launch(1, true, false, 4, true, false, 2, true, true);
	}
	@Test
	public void test3297() {
		o.launch(1, true, false, 4, true, false, 2, true, false);
	}
	@Test
	public void test3298() {
		o.launch(1, true, false, 4, true, false, 2, false, true);
	}
	@Test
	public void test3299() {
		o.launch(1, true, false, 4, true, false, 2, false, false);
	}
	@Test
	public void test3300() {
		o.launch(1, true, false, 4, true, false, 3, true, true);
	}
	@Test
	public void test3301() {
		o.launch(1, true, false, 4, true, false, 3, true, false);
	}
	@Test
	public void test3302() {
		o.launch(1, true, false, 4, true, false, 3, false, true);
	}
	@Test
	public void test3303() {
		o.launch(1, true, false, 4, true, false, 3, false, false);
	}
	@Test
	public void test3304() {
		o.launch(1, true, false, 4, true, false, 4, true, true);
	}
	@Test
	public void test3305() {
		o.launch(1, true, false, 4, true, false, 4, true, false);
	}
	@Test
	public void test3306() {
		o.launch(1, true, false, 4, true, false, 4, false, true);
	}
	@Test
	public void test3307() {
		o.launch(1, true, false, 4, true, false, 4, false, false);
	}
	@Test
	public void test3308() {
		o.launch(1, true, false, 4, true, false, 10, true, true);
	}
	@Test
	public void test3309() {
		o.launch(1, true, false, 4, true, false, 100, true, false);
	}
	@Test
	public void test3310() {
		o.launch(1, true, false, 4, true, false, 5, false, true);
	}
	@Test
	public void test3311() {
		o.launch(1, true, false, 4, true, false, 5, false, false);
	}
	@Test
	public void test3312() {
		o.launch(1, true, false, 4, false, true, 0, true, true);
	}
	@Test
	public void test3313() {
		o.launch(1, true, false, 4, false, true, 0, true, false);
	}
	@Test
	public void test3314() {
		o.launch(1, true, false, 4, false, true, 0, false, true);
	}
	@Test
	public void test3315() {
		o.launch(1, true, false, 4, false, true, 0, false, false);
	}
	@Test
	public void test3316() {
		o.launch(1, true, false, 4, false, true, 1, true, true);
	}
	@Test
	public void test3317() {
		o.launch(1, true, false, 4, false, true, 1, true, false);
	}
	@Test
	public void test3318() {
		o.launch(1, true, false, 4, false, true, 1, false, true);
	}
	@Test
	public void test3319() {
		o.launch(1, true, false, 4, false, true, 1, false, false);
	}
	@Test
	public void test3320() {
		o.launch(1, true, false, 4, false, true, 2, true, true);
	}
	@Test
	public void test3321() {
		o.launch(1, true, false, 4, false, true, 2, true, false);
	}
	@Test
	public void test3322() {
		o.launch(1, true, false, 4, false, true, 2, false, true);
	}
	@Test
	public void test3323() {
		o.launch(1, true, false, 4, false, true, 2, false, false);
	}
	@Test
	public void test3324() {
		o.launch(1, true, false, 4, false, true, 3, true, true);
	}
	@Test
	public void test3325() {
		o.launch(1, true, false, 4, false, true, 3, true, false);
	}
	@Test
	public void test3326() {
		o.launch(1, true, false, 4, false, true, 3, false, true);
	}
	@Test
	public void test3327() {
		o.launch(1, true, false, 4, false, true, 3, false, false);
	}
	@Test
	public void test3328() {
		o.launch(1, true, false, 4, false, true, 4, true, true);
	}
	@Test
	public void test3329() {
		o.launch(1, true, false, 4, false, true, 4, true, false);
	}
	@Test
	public void test3330() {
		o.launch(1, true, false, 4, false, true, 4, false, true);
	}
	@Test
	public void test3331() {
		o.launch(1, true, false, 4, false, true, 4, false, false);
	}
	@Test
	public void test3332() {
		o.launch(1, true, false, 4, false, true, 5, true, true);
	}
	@Test
	public void test3333() {
		o.launch(1, true, false, 4, false, true, 10, true, false);
	}
	@Test
	public void test3334() {
		o.launch(1, true, false, 4, false, true, 5, false, true);
	}
	@Test
	public void test3335() {
		o.launch(1, true, false, 4, false, true, 5, false, false);
	}
	@Test
	public void test3336() {
		o.launch(1, true, false, 4, false, false, 0, true, true);
	}
	@Test
	public void test3337() {
		o.launch(1, true, false, 4, false, false, 0, true, false);
	}
	@Test
	public void test3338() {
		o.launch(1, true, false, 4, false, false, 0, false, true);
	}
	@Test
	public void test3339() {
		o.launch(1, true, false, 4, false, false, 0, false, false);
	}
	@Test
	public void test3340() {
		o.launch(1, true, false, 4, false, false, 1, true, true);
	}
	@Test
	public void test3341() {
		o.launch(1, true, false, 4, false, false, 1, true, false);
	}
	@Test
	public void test3342() {
		o.launch(1, true, false, 4, false, false, 1, false, true);
	}
	@Test
	public void test3343() {
		o.launch(1, true, false, 4, false, false, 1, false, false);
	}
	@Test
	public void test3344() {
		o.launch(1, true, false, 4, false, false, 2, true, true);
	}
	@Test
	public void test3345() {
		o.launch(1, true, false, 4, false, false, 2, true, false);
	}
	@Test
	public void test3346() {
		o.launch(1, true, false, 4, false, false, 2, false, true);
	}
	@Test
	public void test3347() {
		o.launch(1, true, false, 4, false, false, 2, false, false);
	}
	@Test
	public void test3348() {
		o.launch(1, true, false, 4, false, false, 3, true, true);
	}
	@Test
	public void test3349() {
		o.launch(1, true, false, 4, false, false, 3, true, false);
	}
	@Test
	public void test3350() {
		o.launch(1, true, false, 4, false, false, 3, false, true);
	}
	@Test
	public void test3351() {
		o.launch(1, true, false, 4, false, false, 3, false, false);
	}
	@Test
	public void test3352() {
		o.launch(1, true, false, 4, false, false, 4, true, true);
	}
	@Test
	public void test3353() {
		o.launch(1, true, false, 4, false, false, 4, true, false);
	}
	@Test
	public void test3354() {
		o.launch(1, true, false, 4, false, false, 4, false, true);
	}
	@Test
	public void test3355() {
		o.launch(1, true, false, 4, false, false, 4, false, false);
	}
	@Test
	public void test3356() {
		o.launch(1, true, false, 4, false, false, 100, true, true);
	}
	@Test
	public void test3357() {
		o.launch(1, true, false, 4, false, false, 10, true, false);
	}
	@Test
	public void test3358() {
		o.launch(1, true, false, 4, false, false, 5, false, true);
	}
	@Test
	public void test3359() {
		o.launch(1, true, false, 4, false, false, 10, false, false);
	}
	@Test
	public void test3360() {
		o.launch(1, true, false, 100, true, true, 0, true, true);
	}
	@Test
	public void test3361() {
		o.launch(1, true, false, 100, true, true, 0, true, false);
	}
	@Test
	public void test3362() {
		o.launch(1, true, false, 5, true, true, 0, false, true);
	}
	@Test
	public void test3363() {
		o.launch(1, true, false, 10, true, true, 0, false, false);
	}
	@Test
	public void test3364() {
		o.launch(1, true, false, 5, true, true, 1, true, true);
	}
	@Test
	public void test3365() {
		o.launch(1, true, false, -1, true, true, 1, true, false);
	}
	@Test
	public void test3366() {
		o.launch(1, true, false, 5, true, true, 1, false, true);
	}
	@Test
	public void test3367() {
		o.launch(1, true, false, -1, true, true, 1, false, false);
	}
	@Test
	public void test3368() {
		o.launch(1, true, false, 5, true, true, 2, true, true);
	}
	@Test
	public void test3369() {
		o.launch(1, true, false, 5, true, true, 2, true, false);
	}
	@Test
	public void test3370() {
		o.launch(1, true, false, 5, true, true, 2, false, true);
	}
	@Test
	public void test3371() {
		o.launch(1, true, false, 5, true, true, 2, false, false);
	}
	@Test
	public void test3372() {
		o.launch(1, true, false, 5, true, true, 3, true, true);
	}
	@Test
	public void test3373() {
		o.launch(1, true, false, 5, true, true, 3, true, false);
	}
	@Test
	public void test3374() {
		o.launch(1, true, false, 5, true, true, 3, false, true);
	}
	@Test
	public void test3375() {
		o.launch(1, true, false, 5, true, true, 3, false, false);
	}
	@Test
	public void test3376() {
		o.launch(1, true, false, 5, true, true, 4, true, true);
	}
	@Test
	public void test3377() {
		o.launch(1, true, false, 100, true, true, 4, true, false);
	}
	@Test
	public void test3378() {
		o.launch(1, true, false, 10, true, true, 4, false, true);
	}
	@Test
	public void test3379() {
		o.launch(1, true, false, 5, true, true, 4, false, false);
	}
	@Test
	public void test3380() {
		o.launch(1, true, false, 10, true, true, 100, true, true);
	}
	@Test
	public void test3381() {
		o.launch(1, true, false, 10, true, true, 100, true, false);
	}
	@Test
	public void test3382() {
		o.launch(1, true, false, 10, true, true, 100, false, true);
	}
	@Test
	public void test3383() {
		o.launch(1, true, false, 10, true, true, 100, false, false);
	}
	@Test
	public void test3384() {
		o.launch(1, true, false, 100, true, false, 0, true, true);
	}
	@Test
	public void test3385() {
		o.launch(1, true, false, -1, true, false, 0, true, false);
	}
	@Test
	public void test3386() {
		o.launch(1, true, false, 10, true, false, 0, false, true);
	}
	@Test
	public void test3387() {
		o.launch(1, true, false, 10, true, false, 0, false, false);
	}
	@Test
	public void test3388() {
		o.launch(1, true, false, 10, true, false, 1, true, true);
	}
	@Test
	public void test3389() {
		o.launch(1, true, false, -1, true, false, 1, true, false);
	}
	@Test
	public void test3390() {
		o.launch(1, true, false, 10, true, false, 1, false, true);
	}
	@Test
	public void test3391() {
		o.launch(1, true, false, 10, true, false, 1, false, false);
	}
	@Test
	public void test3392() {
		o.launch(1, true, false, 5, true, false, 2, true, true);
	}
	@Test
	public void test3393() {
		o.launch(1, true, false, 5, true, false, 2, true, false);
	}
	@Test
	public void test3394() {
		o.launch(1, true, false, 5, true, false, 2, false, true);
	}
	@Test
	public void test3395() {
		o.launch(1, true, false, 5, true, false, 2, false, false);
	}
	@Test
	public void test3396() {
		o.launch(1, true, false, 5, true, false, 3, true, true);
	}
	@Test
	public void test3397() {
		o.launch(1, true, false, 5, true, false, 3, true, false);
	}
	@Test
	public void test3398() {
		o.launch(1, true, false, 5, true, false, 3, false, true);
	}
	@Test
	public void test3399() {
		o.launch(1, true, false, 5, true, false, 3, false, false);
	}
	@Test
	public void test3400() {
		o.launch(1, true, false, 5, true, false, 4, true, true);
	}
	@Test
	public void test3401() {
		o.launch(1, true, false, 5, true, false, 4, true, false);
	}
	@Test
	public void test3402() {
		o.launch(1, true, false, -1, true, false, 4, false, true);
	}
	@Test
	public void test3403() {
		o.launch(1, true, false, 100, true, false, 4, false, false);
	}
	@Test
	public void test3404() {
		o.launch(1, true, false, -1, true, false, 10, true, true);
	}
	@Test
	public void test3405() {
		o.launch(1, true, false, -1, true, false, 10, true, false);
	}
	@Test
	public void test3406() {
		o.launch(1, true, false, 10, true, false, 10, false, true);
	}
	@Test
	public void test3407() {
		o.launch(1, true, false, 100, true, false, -1, false, false);
	}
	@Test
	public void test3408() {
		o.launch(1, true, false, -1, false, true, 0, true, true);
	}
	@Test
	public void test3409() {
		o.launch(1, true, false, -1, false, true, 0, true, false);
	}
	@Test
	public void test3410() {
		o.launch(1, true, false, 100, false, true, 0, false, true);
	}
	@Test
	public void test3411() {
		o.launch(1, true, false, -1, false, true, 0, false, false);
	}
	@Test
	public void test3412() {
		o.launch(1, true, false, -1, false, true, 1, true, true);
	}
	@Test
	public void test3413() {
		o.launch(1, true, false, 100, false, true, 1, true, false);
	}
	@Test
	public void test3414() {
		o.launch(1, true, false, 100, false, true, 1, false, true);
	}
	@Test
	public void test3415() {
		o.launch(1, true, false, 100, false, true, 1, false, false);
	}
	@Test
	public void test3416() {
		o.launch(1, true, false, 5, false, true, 2, true, true);
	}
	@Test
	public void test3417() {
		o.launch(1, true, false, 5, false, true, 2, true, false);
	}
	@Test
	public void test3418() {
		o.launch(1, true, false, 5, false, true, 2, false, true);
	}
	@Test
	public void test3419() {
		o.launch(1, true, false, 5, false, true, 2, false, false);
	}
	@Test
	public void test3420() {
		o.launch(1, true, false, 5, false, true, 3, true, true);
	}
	@Test
	public void test3421() {
		o.launch(1, true, false, 5, false, true, 3, true, false);
	}
	@Test
	public void test3422() {
		o.launch(1, true, false, 5, false, true, 3, false, true);
	}
	@Test
	public void test3423() {
		o.launch(1, true, false, 5, false, true, 3, false, false);
	}
	@Test
	public void test3424() {
		o.launch(1, true, false, -1, false, true, 4, true, true);
	}
	@Test
	public void test3425() {
		o.launch(1, true, false, 5, false, true, 4, true, false);
	}
	@Test
	public void test3426() {
		o.launch(1, true, false, 100, false, true, 4, false, true);
	}
	@Test
	public void test3427() {
		o.launch(1, true, false, 5, false, true, 4, false, false);
	}
	@Test
	public void test3428() {
		o.launch(1, true, false, -1, false, true, -1, true, true);
	}
	@Test
	public void test3429() {
		o.launch(1, true, false, 100, false, true, 100, true, false);
	}
	@Test
	public void test3430() {
		o.launch(1, true, false, 100, false, true, 100, false, true);
	}
	@Test
	public void test3431() {
		o.launch(1, true, false, 100, false, true, 100, false, false);
	}
	@Test
	public void test3432() {
		o.launch(1, true, false, 10, false, false, 0, true, true);
	}
	@Test
	public void test3433() {
		o.launch(1, true, false, 10, false, false, 0, true, false);
	}
	@Test
	public void test3434() {
		o.launch(1, true, false, 10, false, false, 0, false, true);
	}
	@Test
	public void test3435() {
		o.launch(1, true, false, 10, false, false, 0, false, false);
	}
	@Test
	public void test3436() {
		o.launch(1, true, false, -1, false, false, 1, true, true);
	}
	@Test
	public void test3437() {
		o.launch(1, true, false, 10, false, false, 1, true, false);
	}
	@Test
	public void test3438() {
		o.launch(1, true, false, 10, false, false, 1, false, true);
	}
	@Test
	public void test3439() {
		o.launch(1, true, false, 5, false, false, 1, false, false);
	}
	@Test
	public void test3440() {
		o.launch(1, true, false, 5, false, false, 2, true, true);
	}
	@Test
	public void test3441() {
		o.launch(1, true, false, 5, false, false, 2, true, false);
	}
	@Test
	public void test3442() {
		o.launch(1, true, false, 5, false, false, 2, false, true);
	}
	@Test
	public void test3443() {
		o.launch(1, true, false, 5, false, false, 2, false, false);
	}
	@Test
	public void test3444() {
		o.launch(1, true, false, 5, false, false, 3, true, true);
	}
	@Test
	public void test3445() {
		o.launch(1, true, false, 5, false, false, 3, true, false);
	}
	@Test
	public void test3446() {
		o.launch(1, true, false, 5, false, false, 3, false, true);
	}
	@Test
	public void test3447() {
		o.launch(1, true, false, 5, false, false, 3, false, false);
	}
	@Test
	public void test3448() {
		o.launch(1, true, false, 5, false, false, 4, true, true);
	}
	@Test
	public void test3449() {
		o.launch(1, true, false, 5, false, false, 4, true, false);
	}
	@Test
	public void test3450() {
		o.launch(1, true, false, 100, false, false, 4, false, true);
	}
	@Test
	public void test3451() {
		o.launch(1, true, false, 100, false, false, 4, false, false);
	}
	@Test
	public void test3452() {
		o.launch(1, true, false, 10, false, false, 100, true, true);
	}
	@Test
	public void test3453() {
		o.launch(1, true, false, 10, false, false, -1, true, false);
	}
	@Test
	public void test3454() {
		o.launch(1, true, false, 100, false, false, 100, false, true);
	}
	@Test
	public void test3455() {
		o.launch(1, true, false, 10, false, false, -1, false, false);
	}
	@Test
	public void test3456() {
		o.launch(1, false, true, 0, true, true, 0, true, true);
	}
	@Test
	public void test3457() {
		o.launch(1, false, true, 0, true, true, 0, true, false);
	}
	@Test
	public void test3458() {
		o.launch(1, false, true, 0, true, true, 0, false, true);
	}
	@Test
	public void test3459() {
		o.launch(1, false, true, 0, true, true, 0, false, false);
	}
	@Test
	public void test3460() {
		o.launch(1, false, true, 0, true, true, 1, true, true);
	}
	@Test
	public void test3461() {
		o.launch(1, false, true, 0, true, true, 1, true, false);
	}
	@Test
	public void test3462() {
		o.launch(1, false, true, 0, true, true, 1, false, true);
	}
	@Test
	public void test3463() {
		o.launch(1, false, true, 0, true, true, 1, false, false);
	}
	@Test
	public void test3464() {
		o.launch(1, false, true, 0, true, true, 2, true, true);
	}
	@Test
	public void test3465() {
		o.launch(1, false, true, 0, true, true, 2, true, false);
	}
	@Test
	public void test3466() {
		o.launch(1, false, true, 0, true, true, 2, false, true);
	}
	@Test
	public void test3467() {
		o.launch(1, false, true, 0, true, true, 2, false, false);
	}
	@Test
	public void test3468() {
		o.launch(1, false, true, 0, true, true, 3, true, true);
	}
	@Test
	public void test3469() {
		o.launch(1, false, true, 0, true, true, 3, true, false);
	}
	@Test
	public void test3470() {
		o.launch(1, false, true, 0, true, true, 3, false, true);
	}
	@Test
	public void test3471() {
		o.launch(1, false, true, 0, true, true, 3, false, false);
	}
	@Test
	public void test3472() {
		o.launch(1, false, true, 0, true, true, 4, true, true);
	}
	@Test
	public void test3473() {
		o.launch(1, false, true, 0, true, true, 4, true, false);
	}
	@Test
	public void test3474() {
		o.launch(1, false, true, 0, true, true, 4, false, true);
	}
	@Test
	public void test3475() {
		o.launch(1, false, true, 0, true, true, 4, false, false);
	}
	@Test
	public void test3476() {
		o.launch(1, false, true, 0, true, true, 100, true, true);
	}
	@Test
	public void test3477() {
		o.launch(1, false, true, 0, true, true, 100, true, false);
	}
	@Test
	public void test3478() {
		o.launch(1, false, true, 0, true, true, 10, false, true);
	}
	@Test
	public void test3479() {
		o.launch(1, false, true, 0, true, true, -1, false, false);
	}
	@Test
	public void test3480() {
		o.launch(1, false, true, 0, true, false, 0, true, true);
	}
	@Test
	public void test3481() {
		o.launch(1, false, true, 0, true, false, 0, true, false);
	}
	@Test
	public void test3482() {
		o.launch(1, false, true, 0, true, false, 0, false, true);
	}
	@Test
	public void test3483() {
		o.launch(1, false, true, 0, true, false, 0, false, false);
	}
	@Test
	public void test3484() {
		o.launch(1, false, true, 0, true, false, 1, true, true);
	}
	@Test
	public void test3485() {
		o.launch(1, false, true, 0, true, false, 1, true, false);
	}
	@Test
	public void test3486() {
		o.launch(1, false, true, 0, true, false, 1, false, true);
	}
	@Test
	public void test3487() {
		o.launch(1, false, true, 0, true, false, 1, false, false);
	}
	@Test
	public void test3488() {
		o.launch(1, false, true, 0, true, false, 2, true, true);
	}
	@Test
	public void test3489() {
		o.launch(1, false, true, 0, true, false, 2, true, false);
	}
	@Test
	public void test3490() {
		o.launch(1, false, true, 0, true, false, 2, false, true);
	}
	@Test
	public void test3491() {
		o.launch(1, false, true, 0, true, false, 2, false, false);
	}
	@Test
	public void test3492() {
		o.launch(1, false, true, 0, true, false, 3, true, true);
	}
	@Test
	public void test3493() {
		o.launch(1, false, true, 0, true, false, 3, true, false);
	}
	@Test
	public void test3494() {
		o.launch(1, false, true, 0, true, false, 3, false, true);
	}
	@Test
	public void test3495() {
		o.launch(1, false, true, 0, true, false, 3, false, false);
	}
	@Test
	public void test3496() {
		o.launch(1, false, true, 0, true, false, 4, true, true);
	}
	@Test
	public void test3497() {
		o.launch(1, false, true, 0, true, false, 4, true, false);
	}
	@Test
	public void test3498() {
		o.launch(1, false, true, 0, true, false, 4, false, true);
	}
	@Test
	public void test3499() {
		o.launch(1, false, true, 0, true, false, 4, false, false);
	}
	@Test
	public void test3500() {
		o.launch(1, false, true, 0, true, false, 10, true, true);
	}
	@Test
	public void test3501() {
		o.launch(1, false, true, 0, true, false, 100, true, false);
	}
	@Test
	public void test3502() {
		o.launch(1, false, true, 0, true, false, 10, false, true);
	}
	@Test
	public void test3503() {
		o.launch(1, false, true, 0, true, false, 10, false, false);
	}
	@Test
	public void test3504() {
		o.launch(1, false, true, 0, false, true, 0, true, true);
	}
	@Test
	public void test3505() {
		o.launch(1, false, true, 0, false, true, 0, true, false);
	}
	@Test
	public void test3506() {
		o.launch(1, false, true, 0, false, true, 0, false, true);
	}
	@Test
	public void test3507() {
		o.launch(1, false, true, 0, false, true, 0, false, false);
	}
	@Test
	public void test3508() {
		o.launch(1, false, true, 0, false, true, 1, true, true);
	}
	@Test
	public void test3509() {
		o.launch(1, false, true, 0, false, true, 1, true, false);
	}
	@Test
	public void test3510() {
		o.launch(1, false, true, 0, false, true, 1, false, true);
	}
	@Test
	public void test3511() {
		o.launch(1, false, true, 0, false, true, 1, false, false);
	}
	@Test
	public void test3512() {
		o.launch(1, false, true, 0, false, true, 2, true, true);
	}
	@Test
	public void test3513() {
		o.launch(1, false, true, 0, false, true, 2, true, false);
	}
	@Test
	public void test3514() {
		o.launch(1, false, true, 0, false, true, 2, false, true);
	}
	@Test
	public void test3515() {
		o.launch(1, false, true, 0, false, true, 2, false, false);
	}
	@Test
	public void test3516() {
		o.launch(1, false, true, 0, false, true, 3, true, true);
	}
	@Test
	public void test3517() {
		o.launch(1, false, true, 0, false, true, 3, true, false);
	}
	@Test
	public void test3518() {
		o.launch(1, false, true, 0, false, true, 3, false, true);
	}
	@Test
	public void test3519() {
		o.launch(1, false, true, 0, false, true, 3, false, false);
	}
	@Test
	public void test3520() {
		o.launch(1, false, true, 0, false, true, 4, true, true);
	}
	@Test
	public void test3521() {
		o.launch(1, false, true, 0, false, true, 4, true, false);
	}
	@Test
	public void test3522() {
		o.launch(1, false, true, 0, false, true, 4, false, true);
	}
	@Test
	public void test3523() {
		o.launch(1, false, true, 0, false, true, 4, false, false);
	}
	@Test
	public void test3524() {
		o.launch(1, false, true, 0, false, true, -1, true, true);
	}
	@Test
	public void test3525() {
		o.launch(1, false, true, 0, false, true, -1, true, false);
	}
	@Test
	public void test3526() {
		o.launch(1, false, true, 0, false, true, -1, false, true);
	}
	@Test
	public void test3527() {
		o.launch(1, false, true, 0, false, true, -1, false, false);
	}
	@Test
	public void test3528() {
		o.launch(1, false, true, 0, false, false, 0, true, true);
	}
	@Test
	public void test3529() {
		o.launch(1, false, true, 0, false, false, 0, true, false);
	}
	@Test
	public void test3530() {
		o.launch(1, false, true, 0, false, false, 0, false, true);
	}
	@Test
	public void test3531() {
		o.launch(1, false, true, 0, false, false, 0, false, false);
	}
	@Test
	public void test3532() {
		o.launch(1, false, true, 0, false, false, 1, true, true);
	}
	@Test
	public void test3533() {
		o.launch(1, false, true, 0, false, false, 1, true, false);
	}
	@Test
	public void test3534() {
		o.launch(1, false, true, 0, false, false, 1, false, true);
	}
	@Test
	public void test3535() {
		o.launch(1, false, true, 0, false, false, 1, false, false);
	}
	@Test
	public void test3536() {
		o.launch(1, false, true, 0, false, false, 2, true, true);
	}
	@Test
	public void test3537() {
		o.launch(1, false, true, 0, false, false, 2, true, false);
	}
	@Test
	public void test3538() {
		o.launch(1, false, true, 0, false, false, 2, false, true);
	}
	@Test
	public void test3539() {
		o.launch(1, false, true, 0, false, false, 2, false, false);
	}
	@Test
	public void test3540() {
		o.launch(1, false, true, 0, false, false, 3, true, true);
	}
	@Test
	public void test3541() {
		o.launch(1, false, true, 0, false, false, 3, true, false);
	}
	@Test
	public void test3542() {
		o.launch(1, false, true, 0, false, false, 3, false, true);
	}
	@Test
	public void test3543() {
		o.launch(1, false, true, 0, false, false, 3, false, false);
	}
	@Test
	public void test3544() {
		o.launch(1, false, true, 0, false, false, 4, true, true);
	}
	@Test
	public void test3545() {
		o.launch(1, false, true, 0, false, false, 4, true, false);
	}
	@Test
	public void test3546() {
		o.launch(1, false, true, 0, false, false, 4, false, true);
	}
	@Test
	public void test3547() {
		o.launch(1, false, true, 0, false, false, 4, false, false);
	}
	@Test
	public void test3548() {
		o.launch(1, false, true, 0, false, false, 10, true, true);
	}
	@Test
	public void test3549() {
		o.launch(1, false, true, 0, false, false, 10, true, false);
	}
	@Test
	public void test3550() {
		o.launch(1, false, true, 0, false, false, 10, false, true);
	}
	@Test
	public void test3551() {
		o.launch(1, false, true, 0, false, false, -1, false, false);
	}
	@Test
	public void test3552() {
		o.launch(1, false, true, 1, true, true, 0, true, true);
	}
	@Test
	public void test3553() {
		o.launch(1, false, true, 1, true, true, 0, true, false);
	}
	@Test
	public void test3554() {
		o.launch(1, false, true, 1, true, true, 0, false, true);
	}
	@Test
	public void test3555() {
		o.launch(1, false, true, 1, true, true, 0, false, false);
	}
	@Test
	public void test3556() {
		o.launch(1, false, true, 1, true, true, 1, true, true);
	}
	@Test
	public void test3557() {
		o.launch(1, false, true, 1, true, true, 1, true, false);
	}
	@Test
	public void test3558() {
		o.launch(1, false, true, 1, true, true, 1, false, true);
	}
	@Test
	public void test3559() {
		o.launch(1, false, true, 1, true, true, 1, false, false);
	}
	@Test
	public void test3560() {
		o.launch(1, false, true, 1, true, true, 2, true, true);
	}
	@Test
	public void test3561() {
		o.launch(1, false, true, 1, true, true, 2, true, false);
	}
	@Test
	public void test3562() {
		o.launch(1, false, true, 1, true, true, 2, false, true);
	}
	@Test
	public void test3563() {
		o.launch(1, false, true, 1, true, true, 2, false, false);
	}
	@Test
	public void test3564() {
		o.launch(1, false, true, 1, true, true, 3, true, true);
	}
	@Test
	public void test3565() {
		o.launch(1, false, true, 1, true, true, 3, true, false);
	}
	@Test
	public void test3566() {
		o.launch(1, false, true, 1, true, true, 3, false, true);
	}
	@Test
	public void test3567() {
		o.launch(1, false, true, 1, true, true, 3, false, false);
	}
	@Test
	public void test3568() {
		o.launch(1, false, true, 1, true, true, 4, true, true);
	}
	@Test
	public void test3569() {
		o.launch(1, false, true, 1, true, true, 4, true, false);
	}
	@Test
	public void test3570() {
		o.launch(1, false, true, 1, true, true, 4, false, true);
	}
	@Test
	public void test3571() {
		o.launch(1, false, true, 1, true, true, 4, false, false);
	}
	@Test
	public void test3572() {
		o.launch(1, false, true, 1, true, true, 100, true, true);
	}
	@Test
	public void test3573() {
		o.launch(1, false, true, 1, true, true, 10, true, false);
	}
	@Test
	public void test3574() {
		o.launch(1, false, true, 1, true, true, 10, false, true);
	}
	@Test
	public void test3575() {
		o.launch(1, false, true, 1, true, true, -1, false, false);
	}
	@Test
	public void test3576() {
		o.launch(1, false, true, 1, true, false, 0, true, true);
	}
	@Test
	public void test3577() {
		o.launch(1, false, true, 1, true, false, 0, true, false);
	}
	@Test
	public void test3578() {
		o.launch(1, false, true, 1, true, false, 0, false, true);
	}
	@Test
	public void test3579() {
		o.launch(1, false, true, 1, true, false, 0, false, false);
	}
	@Test
	public void test3580() {
		o.launch(1, false, true, 1, true, false, 1, true, true);
	}
	@Test
	public void test3581() {
		o.launch(1, false, true, 1, true, false, 1, true, false);
	}
	@Test
	public void test3582() {
		o.launch(1, false, true, 1, true, false, 1, false, true);
	}
	@Test
	public void test3583() {
		o.launch(1, false, true, 1, true, false, 1, false, false);
	}
	@Test
	public void test3584() {
		o.launch(1, false, true, 1, true, false, 2, true, true);
	}
	@Test
	public void test3585() {
		o.launch(1, false, true, 1, true, false, 2, true, false);
	}
	@Test
	public void test3586() {
		o.launch(1, false, true, 1, true, false, 2, false, true);
	}
	@Test
	public void test3587() {
		o.launch(1, false, true, 1, true, false, 2, false, false);
	}
	@Test
	public void test3588() {
		o.launch(1, false, true, 1, true, false, 3, true, true);
	}
	@Test
	public void test3589() {
		o.launch(1, false, true, 1, true, false, 3, true, false);
	}
	@Test
	public void test3590() {
		o.launch(1, false, true, 1, true, false, 3, false, true);
	}
	@Test
	public void test3591() {
		o.launch(1, false, true, 1, true, false, 3, false, false);
	}
	@Test
	public void test3592() {
		o.launch(1, false, true, 1, true, false, 4, true, true);
	}
	@Test
	public void test3593() {
		o.launch(1, false, true, 1, true, false, 4, true, false);
	}
	@Test
	public void test3594() {
		o.launch(1, false, true, 1, true, false, 4, false, true);
	}
	@Test
	public void test3595() {
		o.launch(1, false, true, 1, true, false, 4, false, false);
	}
	@Test
	public void test3596() {
		o.launch(1, false, true, 1, true, false, 100, true, true);
	}
	@Test
	public void test3597() {
		o.launch(1, false, true, 1, true, false, 100, true, false);
	}
	@Test
	public void test3598() {
		o.launch(1, false, true, 1, true, false, -1, false, true);
	}
	@Test
	public void test3599() {
		o.launch(1, false, true, 1, true, false, 10, false, false);
	}
	@Test
	public void test3600() {
		o.launch(1, false, true, 1, false, true, 0, true, true);
	}
	@Test
	public void test3601() {
		o.launch(1, false, true, 1, false, true, 0, true, false);
	}
	@Test
	public void test3602() {
		o.launch(1, false, true, 1, false, true, 0, false, true);
	}
	@Test
	public void test3603() {
		o.launch(1, false, true, 1, false, true, 0, false, false);
	}
	@Test
	public void test3604() {
		o.launch(1, false, true, 1, false, true, 1, true, true);
	}
	@Test
	public void test3605() {
		o.launch(1, false, true, 1, false, true, 1, true, false);
	}
	@Test
	public void test3606() {
		o.launch(1, false, true, 1, false, true, 1, false, true);
	}
	@Test
	public void test3607() {
		o.launch(1, false, true, 1, false, true, 1, false, false);
	}
	@Test
	public void test3608() {
		o.launch(1, false, true, 1, false, true, 2, true, true);
	}
	@Test
	public void test3609() {
		o.launch(1, false, true, 1, false, true, 2, true, false);
	}
	@Test
	public void test3610() {
		o.launch(1, false, true, 1, false, true, 2, false, true);
	}
	@Test
	public void test3611() {
		o.launch(1, false, true, 1, false, true, 2, false, false);
	}
	@Test
	public void test3612() {
		o.launch(1, false, true, 1, false, true, 3, true, true);
	}
	@Test
	public void test3613() {
		o.launch(1, false, true, 1, false, true, 3, true, false);
	}
	@Test
	public void test3614() {
		o.launch(1, false, true, 1, false, true, 3, false, true);
	}
	@Test
	public void test3615() {
		o.launch(1, false, true, 1, false, true, 3, false, false);
	}
	@Test
	public void test3616() {
		o.launch(1, false, true, 1, false, true, 4, true, true);
	}
	@Test
	public void test3617() {
		o.launch(1, false, true, 1, false, true, 4, true, false);
	}
	@Test
	public void test3618() {
		o.launch(1, false, true, 1, false, true, 4, false, true);
	}
	@Test
	public void test3619() {
		o.launch(1, false, true, 1, false, true, 4, false, false);
	}
	@Test
	public void test3620() {
		o.launch(1, false, true, 1, false, true, 100, true, true);
	}
	@Test
	public void test3621() {
		o.launch(1, false, true, 1, false, true, 10, true, false);
	}
	@Test
	public void test3622() {
		o.launch(1, false, true, 1, false, true, 100, false, true);
	}
	@Test
	public void test3623() {
		o.launch(1, false, true, 1, false, true, 100, false, false);
	}
	@Test
	public void test3624() {
		o.launch(1, false, true, 1, false, false, 0, true, true);
	}
	@Test
	public void test3625() {
		o.launch(1, false, true, 1, false, false, 0, true, false);
	}
	@Test
	public void test3626() {
		o.launch(1, false, true, 1, false, false, 0, false, true);
	}
	@Test
	public void test3627() {
		o.launch(1, false, true, 1, false, false, 0, false, false);
	}
	@Test
	public void test3628() {
		o.launch(1, false, true, 1, false, false, 1, true, true);
	}
	@Test
	public void test3629() {
		o.launch(1, false, true, 1, false, false, 1, true, false);
	}
	@Test
	public void test3630() {
		o.launch(1, false, true, 1, false, false, 1, false, true);
	}
	@Test
	public void test3631() {
		o.launch(1, false, true, 1, false, false, 1, false, false);
	}
	@Test
	public void test3632() {
		o.launch(1, false, true, 1, false, false, 2, true, true);
	}
	@Test
	public void test3633() {
		o.launch(1, false, true, 1, false, false, 2, true, false);
	}
	@Test
	public void test3634() {
		o.launch(1, false, true, 1, false, false, 2, false, true);
	}
	@Test
	public void test3635() {
		o.launch(1, false, true, 1, false, false, 2, false, false);
	}
	@Test
	public void test3636() {
		o.launch(1, false, true, 1, false, false, 3, true, true);
	}
	@Test
	public void test3637() {
		o.launch(1, false, true, 1, false, false, 3, true, false);
	}
	@Test
	public void test3638() {
		o.launch(1, false, true, 1, false, false, 3, false, true);
	}
	@Test
	public void test3639() {
		o.launch(1, false, true, 1, false, false, 3, false, false);
	}
	@Test
	public void test3640() {
		o.launch(1, false, true, 1, false, false, 4, true, true);
	}
	@Test
	public void test3641() {
		o.launch(1, false, true, 1, false, false, 4, true, false);
	}
	@Test
	public void test3642() {
		o.launch(1, false, true, 1, false, false, 4, false, true);
	}
	@Test
	public void test3643() {
		o.launch(1, false, true, 1, false, false, 4, false, false);
	}
	@Test
	public void test3644() {
		o.launch(1, false, true, 1, false, false, 10, true, true);
	}
	@Test
	public void test3645() {
		o.launch(1, false, true, 1, false, false, 10, true, false);
	}
	@Test
	public void test3646() {
		o.launch(1, false, true, 1, false, false, -1, false, true);
	}
	@Test
	public void test3647() {
		o.launch(1, false, true, 1, false, false, 100, false, false);
	}
	@Test
	public void test3648() {
		o.launch(1, false, true, 2, true, true, 0, true, true);
	}
	@Test
	public void test3649() {
		o.launch(1, false, true, 2, true, true, 0, true, false);
	}
	@Test
	public void test3650() {
		o.launch(1, false, true, 2, true, true, 0, false, true);
	}
	@Test
	public void test3651() {
		o.launch(1, false, true, 2, true, true, 0, false, false);
	}
	@Test
	public void test3652() {
		o.launch(1, false, true, 2, true, true, 1, true, true);
	}
	@Test
	public void test3653() {
		o.launch(1, false, true, 2, true, true, 1, true, false);
	}
	@Test
	public void test3654() {
		o.launch(1, false, true, 2, true, true, 1, false, true);
	}
	@Test
	public void test3655() {
		o.launch(1, false, true, 2, true, true, 1, false, false);
	}
	@Test
	public void test3656() {
		o.launch(1, false, true, 2, true, true, 2, true, true);
	}
	@Test
	public void test3657() {
		o.launch(1, false, true, 2, true, true, 2, true, false);
	}
	@Test
	public void test3658() {
		o.launch(1, false, true, 2, true, true, 2, false, true);
	}
	@Test
	public void test3659() {
		o.launch(1, false, true, 2, true, true, 2, false, false);
	}
	@Test
	public void test3660() {
		o.launch(1, false, true, 2, true, true, 3, true, true);
	}
	@Test
	public void test3661() {
		o.launch(1, false, true, 2, true, true, 3, true, false);
	}
	@Test
	public void test3662() {
		o.launch(1, false, true, 2, true, true, 3, false, true);
	}
	@Test
	public void test3663() {
		o.launch(1, false, true, 2, true, true, 3, false, false);
	}
	@Test
	public void test3664() {
		o.launch(1, false, true, 2, true, true, 4, true, true);
	}
	@Test
	public void test3665() {
		o.launch(1, false, true, 2, true, true, 4, true, false);
	}
	@Test
	public void test3666() {
		o.launch(1, false, true, 2, true, true, 4, false, true);
	}
	@Test
	public void test3667() {
		o.launch(1, false, true, 2, true, true, 4, false, false);
	}
	@Test
	public void test3668() {
		o.launch(1, false, true, 2, true, true, 5, true, true);
	}
	@Test
	public void test3669() {
		o.launch(1, false, true, 2, true, true, 5, true, false);
	}
	@Test
	public void test3670() {
		o.launch(1, false, true, 2, true, true, 5, false, true);
	}
	@Test
	public void test3671() {
		o.launch(1, false, true, 2, true, true, 5, false, false);
	}
	@Test
	public void test3672() {
		o.launch(1, false, true, 2, true, false, 0, true, true);
	}
	@Test
	public void test3673() {
		o.launch(1, false, true, 2, true, false, 0, true, false);
	}
	@Test
	public void test3674() {
		o.launch(1, false, true, 2, true, false, 0, false, true);
	}
	@Test
	public void test3675() {
		o.launch(1, false, true, 2, true, false, 0, false, false);
	}
	@Test
	public void test3676() {
		o.launch(1, false, true, 2, true, false, 1, true, true);
	}
	@Test
	public void test3677() {
		o.launch(1, false, true, 2, true, false, 1, true, false);
	}
	@Test
	public void test3678() {
		o.launch(1, false, true, 2, true, false, 1, false, true);
	}
	@Test
	public void test3679() {
		o.launch(1, false, true, 2, true, false, 1, false, false);
	}
	@Test
	public void test3680() {
		o.launch(1, false, true, 2, true, false, 2, true, true);
	}
	@Test
	public void test3681() {
		o.launch(1, false, true, 2, true, false, 2, true, false);
	}
	@Test
	public void test3682() {
		o.launch(1, false, true, 2, true, false, 2, false, true);
	}
	@Test
	public void test3683() {
		o.launch(1, false, true, 2, true, false, 2, false, false);
	}
	@Test
	public void test3684() {
		o.launch(1, false, true, 2, true, false, 3, true, true);
	}
	@Test
	public void test3685() {
		o.launch(1, false, true, 2, true, false, 3, true, false);
	}
	@Test
	public void test3686() {
		o.launch(1, false, true, 2, true, false, 3, false, true);
	}
	@Test
	public void test3687() {
		o.launch(1, false, true, 2, true, false, 3, false, false);
	}
	@Test
	public void test3688() {
		o.launch(1, false, true, 2, true, false, 4, true, true);
	}
	@Test
	public void test3689() {
		o.launch(1, false, true, 2, true, false, 4, true, false);
	}
	@Test
	public void test3690() {
		o.launch(1, false, true, 2, true, false, 4, false, true);
	}
	@Test
	public void test3691() {
		o.launch(1, false, true, 2, true, false, 4, false, false);
	}
	@Test
	public void test3692() {
		o.launch(1, false, true, 2, true, false, 5, true, true);
	}
	@Test
	public void test3693() {
		o.launch(1, false, true, 2, true, false, 5, true, false);
	}
	@Test
	public void test3694() {
		o.launch(1, false, true, 2, true, false, 5, false, true);
	}
	@Test
	public void test3695() {
		o.launch(1, false, true, 2, true, false, 5, false, false);
	}
	@Test
	public void test3696() {
		o.launch(1, false, true, 2, false, true, 0, true, true);
	}
	@Test
	public void test3697() {
		o.launch(1, false, true, 2, false, true, 0, true, false);
	}
	@Test
	public void test3698() {
		o.launch(1, false, true, 2, false, true, 0, false, true);
	}
	@Test
	public void test3699() {
		o.launch(1, false, true, 2, false, true, 0, false, false);
	}
	@Test
	public void test3700() {
		o.launch(1, false, true, 2, false, true, 1, true, true);
	}
	@Test
	public void test3701() {
		o.launch(1, false, true, 2, false, true, 1, true, false);
	}
	@Test
	public void test3702() {
		o.launch(1, false, true, 2, false, true, 1, false, true);
	}
	@Test
	public void test3703() {
		o.launch(1, false, true, 2, false, true, 1, false, false);
	}
	@Test
	public void test3704() {
		o.launch(1, false, true, 2, false, true, 2, true, true);
	}
	@Test
	public void test3705() {
		o.launch(1, false, true, 2, false, true, 2, true, false);
	}
	@Test
	public void test3706() {
		o.launch(1, false, true, 2, false, true, 2, false, true);
	}
	@Test
	public void test3707() {
		o.launch(1, false, true, 2, false, true, 2, false, false);
	}
	@Test
	public void test3708() {
		o.launch(1, false, true, 2, false, true, 3, true, true);
	}
	@Test
	public void test3709() {
		o.launch(1, false, true, 2, false, true, 3, true, false);
	}
	@Test
	public void test3710() {
		o.launch(1, false, true, 2, false, true, 3, false, true);
	}
	@Test
	public void test3711() {
		o.launch(1, false, true, 2, false, true, 3, false, false);
	}
	@Test
	public void test3712() {
		o.launch(1, false, true, 2, false, true, 4, true, true);
	}
	@Test
	public void test3713() {
		o.launch(1, false, true, 2, false, true, 4, true, false);
	}
	@Test
	public void test3714() {
		o.launch(1, false, true, 2, false, true, 4, false, true);
	}
	@Test
	public void test3715() {
		o.launch(1, false, true, 2, false, true, 4, false, false);
	}
	@Test
	public void test3716() {
		o.launch(1, false, true, 2, false, true, 5, true, true);
	}
	@Test
	public void test3717() {
		o.launch(1, false, true, 2, false, true, 5, true, false);
	}
	@Test
	public void test3718() {
		o.launch(1, false, true, 2, false, true, 5, false, true);
	}
	@Test
	public void test3719() {
		o.launch(1, false, true, 2, false, true, 5, false, false);
	}
	@Test
	public void test3720() {
		o.launch(1, false, true, 2, false, false, 0, true, true);
	}
	@Test
	public void test3721() {
		o.launch(1, false, true, 2, false, false, 0, true, false);
	}
	@Test
	public void test3722() {
		o.launch(1, false, true, 2, false, false, 0, false, true);
	}
	@Test
	public void test3723() {
		o.launch(1, false, true, 2, false, false, 0, false, false);
	}
	@Test
	public void test3724() {
		o.launch(1, false, true, 2, false, false, 1, true, true);
	}
	@Test
	public void test3725() {
		o.launch(1, false, true, 2, false, false, 1, true, false);
	}
	@Test
	public void test3726() {
		o.launch(1, false, true, 2, false, false, 1, false, true);
	}
	@Test
	public void test3727() {
		o.launch(1, false, true, 2, false, false, 1, false, false);
	}
	@Test
	public void test3728() {
		o.launch(1, false, true, 2, false, false, 2, true, true);
	}
	@Test
	public void test3729() {
		o.launch(1, false, true, 2, false, false, 2, true, false);
	}
	@Test
	public void test3730() {
		o.launch(1, false, true, 2, false, false, 2, false, true);
	}
	@Test
	public void test3731() {
		o.launch(1, false, true, 2, false, false, 2, false, false);
	}
	@Test
	public void test3732() {
		o.launch(1, false, true, 2, false, false, 3, true, true);
	}
	@Test
	public void test3733() {
		o.launch(1, false, true, 2, false, false, 3, true, false);
	}
	@Test
	public void test3734() {
		o.launch(1, false, true, 2, false, false, 3, false, true);
	}
	@Test
	public void test3735() {
		o.launch(1, false, true, 2, false, false, 3, false, false);
	}
	@Test
	public void test3736() {
		o.launch(1, false, true, 2, false, false, 4, true, true);
	}
	@Test
	public void test3737() {
		o.launch(1, false, true, 2, false, false, 4, true, false);
	}
	@Test
	public void test3738() {
		o.launch(1, false, true, 2, false, false, 4, false, true);
	}
	@Test
	public void test3739() {
		o.launch(1, false, true, 2, false, false, 4, false, false);
	}
	@Test
	public void test3740() {
		o.launch(1, false, true, 2, false, false, 5, true, true);
	}
	@Test
	public void test3741() {
		o.launch(1, false, true, 2, false, false, 5, true, false);
	}
	@Test
	public void test3742() {
		o.launch(1, false, true, 2, false, false, 5, false, true);
	}
	@Test
	public void test3743() {
		o.launch(1, false, true, 2, false, false, 5, false, false);
	}
	@Test
	public void test3744() {
		o.launch(1, false, true, 3, true, true, 0, true, true);
	}
	@Test
	public void test3745() {
		o.launch(1, false, true, 3, true, true, 0, true, false);
	}
	@Test
	public void test3746() {
		o.launch(1, false, true, 3, true, true, 0, false, true);
	}
	@Test
	public void test3747() {
		o.launch(1, false, true, 3, true, true, 0, false, false);
	}
	@Test
	public void test3748() {
		o.launch(1, false, true, 3, true, true, 1, true, true);
	}
	@Test
	public void test3749() {
		o.launch(1, false, true, 3, true, true, 1, true, false);
	}
	@Test
	public void test3750() {
		o.launch(1, false, true, 3, true, true, 1, false, true);
	}
	@Test
	public void test3751() {
		o.launch(1, false, true, 3, true, true, 1, false, false);
	}
	@Test
	public void test3752() {
		o.launch(1, false, true, 3, true, true, 2, true, true);
	}
	@Test
	public void test3753() {
		o.launch(1, false, true, 3, true, true, 2, true, false);
	}
	@Test
	public void test3754() {
		o.launch(1, false, true, 3, true, true, 2, false, true);
	}
	@Test
	public void test3755() {
		o.launch(1, false, true, 3, true, true, 2, false, false);
	}
	@Test
	public void test3756() {
		o.launch(1, false, true, 3, true, true, 3, true, true);
	}
	@Test
	public void test3757() {
		o.launch(1, false, true, 3, true, true, 3, true, false);
	}
	@Test
	public void test3758() {
		o.launch(1, false, true, 3, true, true, 3, false, true);
	}
	@Test
	public void test3759() {
		o.launch(1, false, true, 3, true, true, 3, false, false);
	}
	@Test
	public void test3760() {
		o.launch(1, false, true, 3, true, true, 4, true, true);
	}
	@Test
	public void test3761() {
		o.launch(1, false, true, 3, true, true, 4, true, false);
	}
	@Test
	public void test3762() {
		o.launch(1, false, true, 3, true, true, 4, false, true);
	}
	@Test
	public void test3763() {
		o.launch(1, false, true, 3, true, true, 4, false, false);
	}
	@Test
	public void test3764() {
		o.launch(1, false, true, 3, true, true, 5, true, true);
	}
	@Test
	public void test3765() {
		o.launch(1, false, true, 3, true, true, 5, true, false);
	}
	@Test
	public void test3766() {
		o.launch(1, false, true, 3, true, true, 5, false, true);
	}
	@Test
	public void test3767() {
		o.launch(1, false, true, 3, true, true, 5, false, false);
	}
	@Test
	public void test3768() {
		o.launch(1, false, true, 3, true, false, 0, true, true);
	}
	@Test
	public void test3769() {
		o.launch(1, false, true, 3, true, false, 0, true, false);
	}
	@Test
	public void test3770() {
		o.launch(1, false, true, 3, true, false, 0, false, true);
	}
	@Test
	public void test3771() {
		o.launch(1, false, true, 3, true, false, 0, false, false);
	}
	@Test
	public void test3772() {
		o.launch(1, false, true, 3, true, false, 1, true, true);
	}
	@Test
	public void test3773() {
		o.launch(1, false, true, 3, true, false, 1, true, false);
	}
	@Test
	public void test3774() {
		o.launch(1, false, true, 3, true, false, 1, false, true);
	}
	@Test
	public void test3775() {
		o.launch(1, false, true, 3, true, false, 1, false, false);
	}
	@Test
	public void test3776() {
		o.launch(1, false, true, 3, true, false, 2, true, true);
	}
	@Test
	public void test3777() {
		o.launch(1, false, true, 3, true, false, 2, true, false);
	}
	@Test
	public void test3778() {
		o.launch(1, false, true, 3, true, false, 2, false, true);
	}
	@Test
	public void test3779() {
		o.launch(1, false, true, 3, true, false, 2, false, false);
	}
	@Test
	public void test3780() {
		o.launch(1, false, true, 3, true, false, 3, true, true);
	}
	@Test
	public void test3781() {
		o.launch(1, false, true, 3, true, false, 3, true, false);
	}
	@Test
	public void test3782() {
		o.launch(1, false, true, 3, true, false, 3, false, true);
	}
	@Test
	public void test3783() {
		o.launch(1, false, true, 3, true, false, 3, false, false);
	}
	@Test
	public void test3784() {
		o.launch(1, false, true, 3, true, false, 4, true, true);
	}
	@Test
	public void test3785() {
		o.launch(1, false, true, 3, true, false, 4, true, false);
	}
	@Test
	public void test3786() {
		o.launch(1, false, true, 3, true, false, 4, false, true);
	}
	@Test
	public void test3787() {
		o.launch(1, false, true, 3, true, false, 4, false, false);
	}
	@Test
	public void test3788() {
		o.launch(1, false, true, 3, true, false, 5, true, true);
	}
	@Test
	public void test3789() {
		o.launch(1, false, true, 3, true, false, 5, true, false);
	}
	@Test
	public void test3790() {
		o.launch(1, false, true, 3, true, false, 5, false, true);
	}
	@Test
	public void test3791() {
		o.launch(1, false, true, 3, true, false, 5, false, false);
	}
	@Test
	public void test3792() {
		o.launch(1, false, true, 3, false, true, 0, true, true);
	}
	@Test
	public void test3793() {
		o.launch(1, false, true, 3, false, true, 0, true, false);
	}
	@Test
	public void test3794() {
		o.launch(1, false, true, 3, false, true, 0, false, true);
	}
	@Test
	public void test3795() {
		o.launch(1, false, true, 3, false, true, 0, false, false);
	}
	@Test
	public void test3796() {
		o.launch(1, false, true, 3, false, true, 1, true, true);
	}
	@Test
	public void test3797() {
		o.launch(1, false, true, 3, false, true, 1, true, false);
	}
	@Test
	public void test3798() {
		o.launch(1, false, true, 3, false, true, 1, false, true);
	}
	@Test
	public void test3799() {
		o.launch(1, false, true, 3, false, true, 1, false, false);
	}
	@Test
	public void test3800() {
		o.launch(1, false, true, 3, false, true, 2, true, true);
	}
	@Test
	public void test3801() {
		o.launch(1, false, true, 3, false, true, 2, true, false);
	}
	@Test
	public void test3802() {
		o.launch(1, false, true, 3, false, true, 2, false, true);
	}
	@Test
	public void test3803() {
		o.launch(1, false, true, 3, false, true, 2, false, false);
	}
	@Test
	public void test3804() {
		o.launch(1, false, true, 3, false, true, 3, true, true);
	}
	@Test
	public void test3805() {
		o.launch(1, false, true, 3, false, true, 3, true, false);
	}
	@Test
	public void test3806() {
		o.launch(1, false, true, 3, false, true, 3, false, true);
	}
	@Test
	public void test3807() {
		o.launch(1, false, true, 3, false, true, 3, false, false);
	}
	@Test
	public void test3808() {
		o.launch(1, false, true, 3, false, true, 4, true, true);
	}
	@Test
	public void test3809() {
		o.launch(1, false, true, 3, false, true, 4, true, false);
	}
	@Test
	public void test3810() {
		o.launch(1, false, true, 3, false, true, 4, false, true);
	}
	@Test
	public void test3811() {
		o.launch(1, false, true, 3, false, true, 4, false, false);
	}
	@Test
	public void test3812() {
		o.launch(1, false, true, 3, false, true, 5, true, true);
	}
	@Test
	public void test3813() {
		o.launch(1, false, true, 3, false, true, 5, true, false);
	}
	@Test
	public void test3814() {
		o.launch(1, false, true, 3, false, true, 5, false, true);
	}
	@Test
	public void test3815() {
		o.launch(1, false, true, 3, false, true, 5, false, false);
	}
	@Test
	public void test3816() {
		o.launch(1, false, true, 3, false, false, 0, true, true);
	}
	@Test
	public void test3817() {
		o.launch(1, false, true, 3, false, false, 0, true, false);
	}
	@Test
	public void test3818() {
		o.launch(1, false, true, 3, false, false, 0, false, true);
	}
	@Test
	public void test3819() {
		o.launch(1, false, true, 3, false, false, 0, false, false);
	}
	@Test
	public void test3820() {
		o.launch(1, false, true, 3, false, false, 1, true, true);
	}
	@Test
	public void test3821() {
		o.launch(1, false, true, 3, false, false, 1, true, false);
	}
	@Test
	public void test3822() {
		o.launch(1, false, true, 3, false, false, 1, false, true);
	}
	@Test
	public void test3823() {
		o.launch(1, false, true, 3, false, false, 1, false, false);
	}
	@Test
	public void test3824() {
		o.launch(1, false, true, 3, false, false, 2, true, true);
	}
	@Test
	public void test3825() {
		o.launch(1, false, true, 3, false, false, 2, true, false);
	}
	@Test
	public void test3826() {
		o.launch(1, false, true, 3, false, false, 2, false, true);
	}
	@Test
	public void test3827() {
		o.launch(1, false, true, 3, false, false, 2, false, false);
	}
	@Test
	public void test3828() {
		o.launch(1, false, true, 3, false, false, 3, true, true);
	}
	@Test
	public void test3829() {
		o.launch(1, false, true, 3, false, false, 3, true, false);
	}
	@Test
	public void test3830() {
		o.launch(1, false, true, 3, false, false, 3, false, true);
	}
	@Test
	public void test3831() {
		o.launch(1, false, true, 3, false, false, 3, false, false);
	}
	@Test
	public void test3832() {
		o.launch(1, false, true, 3, false, false, 4, true, true);
	}
	@Test
	public void test3833() {
		o.launch(1, false, true, 3, false, false, 4, true, false);
	}
	@Test
	public void test3834() {
		o.launch(1, false, true, 3, false, false, 4, false, true);
	}
	@Test
	public void test3835() {
		o.launch(1, false, true, 3, false, false, 4, false, false);
	}
	@Test
	public void test3836() {
		o.launch(1, false, true, 3, false, false, 5, true, true);
	}
	@Test
	public void test3837() {
		o.launch(1, false, true, 3, false, false, 5, true, false);
	}
	@Test
	public void test3838() {
		o.launch(1, false, true, 3, false, false, 5, false, true);
	}
	@Test
	public void test3839() {
		o.launch(1, false, true, 3, false, false, 5, false, false);
	}
	@Test
	public void test3840() {
		o.launch(1, false, true, 4, true, true, 0, true, true);
	}
	@Test
	public void test3841() {
		o.launch(1, false, true, 4, true, true, 0, true, false);
	}
	@Test
	public void test3842() {
		o.launch(1, false, true, 4, true, true, 0, false, true);
	}
	@Test
	public void test3843() {
		o.launch(1, false, true, 4, true, true, 0, false, false);
	}
	@Test
	public void test3844() {
		o.launch(1, false, true, 4, true, true, 1, true, true);
	}
	@Test
	public void test3845() {
		o.launch(1, false, true, 4, true, true, 1, true, false);
	}
	@Test
	public void test3846() {
		o.launch(1, false, true, 4, true, true, 1, false, true);
	}
	@Test
	public void test3847() {
		o.launch(1, false, true, 4, true, true, 1, false, false);
	}
	@Test
	public void test3848() {
		o.launch(1, false, true, 4, true, true, 2, true, true);
	}
	@Test
	public void test3849() {
		o.launch(1, false, true, 4, true, true, 2, true, false);
	}
	@Test
	public void test3850() {
		o.launch(1, false, true, 4, true, true, 2, false, true);
	}
	@Test
	public void test3851() {
		o.launch(1, false, true, 4, true, true, 2, false, false);
	}
	@Test
	public void test3852() {
		o.launch(1, false, true, 4, true, true, 3, true, true);
	}
	@Test
	public void test3853() {
		o.launch(1, false, true, 4, true, true, 3, true, false);
	}
	@Test
	public void test3854() {
		o.launch(1, false, true, 4, true, true, 3, false, true);
	}
	@Test
	public void test3855() {
		o.launch(1, false, true, 4, true, true, 3, false, false);
	}
	@Test
	public void test3856() {
		o.launch(1, false, true, 4, true, true, 4, true, true);
	}
	@Test
	public void test3857() {
		o.launch(1, false, true, 4, true, true, 4, true, false);
	}
	@Test
	public void test3858() {
		o.launch(1, false, true, 4, true, true, 4, false, true);
	}
	@Test
	public void test3859() {
		o.launch(1, false, true, 4, true, true, 4, false, false);
	}
	@Test
	public void test3860() {
		o.launch(1, false, true, 4, true, true, 10, true, true);
	}
	@Test
	public void test3861() {
		o.launch(1, false, true, 4, true, true, -1, true, false);
	}
	@Test
	public void test3862() {
		o.launch(1, false, true, 4, true, true, -1, false, true);
	}
	@Test
	public void test3863() {
		o.launch(1, false, true, 4, true, true, 5, false, false);
	}
	@Test
	public void test3864() {
		o.launch(1, false, true, 4, true, false, 0, true, true);
	}
	@Test
	public void test3865() {
		o.launch(1, false, true, 4, true, false, 0, true, false);
	}
	@Test
	public void test3866() {
		o.launch(1, false, true, 4, true, false, 0, false, true);
	}
	@Test
	public void test3867() {
		o.launch(1, false, true, 4, true, false, 0, false, false);
	}
	@Test
	public void test3868() {
		o.launch(1, false, true, 4, true, false, 1, true, true);
	}
	@Test
	public void test3869() {
		o.launch(1, false, true, 4, true, false, 1, true, false);
	}
	@Test
	public void test3870() {
		o.launch(1, false, true, 4, true, false, 1, false, true);
	}
	@Test
	public void test3871() {
		o.launch(1, false, true, 4, true, false, 1, false, false);
	}
	@Test
	public void test3872() {
		o.launch(1, false, true, 4, true, false, 2, true, true);
	}
	@Test
	public void test3873() {
		o.launch(1, false, true, 4, true, false, 2, true, false);
	}
	@Test
	public void test3874() {
		o.launch(1, false, true, 4, true, false, 2, false, true);
	}
	@Test
	public void test3875() {
		o.launch(1, false, true, 4, true, false, 2, false, false);
	}
	@Test
	public void test3876() {
		o.launch(1, false, true, 4, true, false, 3, true, true);
	}
	@Test
	public void test3877() {
		o.launch(1, false, true, 4, true, false, 3, true, false);
	}
	@Test
	public void test3878() {
		o.launch(1, false, true, 4, true, false, 3, false, true);
	}
	@Test
	public void test3879() {
		o.launch(1, false, true, 4, true, false, 3, false, false);
	}
	@Test
	public void test3880() {
		o.launch(1, false, true, 4, true, false, 4, true, true);
	}
	@Test
	public void test3881() {
		o.launch(1, false, true, 4, true, false, 4, true, false);
	}
	@Test
	public void test3882() {
		o.launch(1, false, true, 4, true, false, 4, false, true);
	}
	@Test
	public void test3883() {
		o.launch(1, false, true, 4, true, false, 4, false, false);
	}
	@Test
	public void test3884() {
		o.launch(1, false, true, 4, true, false, 100, true, true);
	}
	@Test
	public void test3885() {
		o.launch(1, false, true, 4, true, false, -1, true, false);
	}
	@Test
	public void test3886() {
		o.launch(1, false, true, 4, true, false, 5, false, true);
	}
	@Test
	public void test3887() {
		o.launch(1, false, true, 4, true, false, 5, false, false);
	}
	@Test
	public void test3888() {
		o.launch(1, false, true, 4, false, true, 0, true, true);
	}
	@Test
	public void test3889() {
		o.launch(1, false, true, 4, false, true, 0, true, false);
	}
	@Test
	public void test3890() {
		o.launch(1, false, true, 4, false, true, 0, false, true);
	}
	@Test
	public void test3891() {
		o.launch(1, false, true, 4, false, true, 0, false, false);
	}
	@Test
	public void test3892() {
		o.launch(1, false, true, 4, false, true, 1, true, true);
	}
	@Test
	public void test3893() {
		o.launch(1, false, true, 4, false, true, 1, true, false);
	}
	@Test
	public void test3894() {
		o.launch(1, false, true, 4, false, true, 1, false, true);
	}
	@Test
	public void test3895() {
		o.launch(1, false, true, 4, false, true, 1, false, false);
	}
	@Test
	public void test3896() {
		o.launch(1, false, true, 4, false, true, 2, true, true);
	}
	@Test
	public void test3897() {
		o.launch(1, false, true, 4, false, true, 2, true, false);
	}
	@Test
	public void test3898() {
		o.launch(1, false, true, 4, false, true, 2, false, true);
	}
	@Test
	public void test3899() {
		o.launch(1, false, true, 4, false, true, 2, false, false);
	}
	@Test
	public void test3900() {
		o.launch(1, false, true, 4, false, true, 3, true, true);
	}
	@Test
	public void test3901() {
		o.launch(1, false, true, 4, false, true, 3, true, false);
	}
	@Test
	public void test3902() {
		o.launch(1, false, true, 4, false, true, 3, false, true);
	}
	@Test
	public void test3903() {
		o.launch(1, false, true, 4, false, true, 3, false, false);
	}
	@Test
	public void test3904() {
		o.launch(1, false, true, 4, false, true, 4, true, true);
	}
	@Test
	public void test3905() {
		o.launch(1, false, true, 4, false, true, 4, true, false);
	}
	@Test
	public void test3906() {
		o.launch(1, false, true, 4, false, true, 4, false, true);
	}
	@Test
	public void test3907() {
		o.launch(1, false, true, 4, false, true, 4, false, false);
	}
	@Test
	public void test3908() {
		o.launch(1, false, true, 4, false, true, -1, true, true);
	}
	@Test
	public void test3909() {
		o.launch(1, false, true, 4, false, true, 5, true, false);
	}
	@Test
	public void test3910() {
		o.launch(1, false, true, 4, false, true, 5, false, true);
	}
	@Test
	public void test3911() {
		o.launch(1, false, true, 4, false, true, 5, false, false);
	}
	@Test
	public void test3912() {
		o.launch(1, false, true, 4, false, false, 0, true, true);
	}
	@Test
	public void test3913() {
		o.launch(1, false, true, 4, false, false, 0, true, false);
	}
	@Test
	public void test3914() {
		o.launch(1, false, true, 4, false, false, 0, false, true);
	}
	@Test
	public void test3915() {
		o.launch(1, false, true, 4, false, false, 0, false, false);
	}
	@Test
	public void test3916() {
		o.launch(1, false, true, 4, false, false, 1, true, true);
	}
	@Test
	public void test3917() {
		o.launch(1, false, true, 4, false, false, 1, true, false);
	}
	@Test
	public void test3918() {
		o.launch(1, false, true, 4, false, false, 1, false, true);
	}
	@Test
	public void test3919() {
		o.launch(1, false, true, 4, false, false, 1, false, false);
	}
	@Test
	public void test3920() {
		o.launch(1, false, true, 4, false, false, 2, true, true);
	}
	@Test
	public void test3921() {
		o.launch(1, false, true, 4, false, false, 2, true, false);
	}
	@Test
	public void test3922() {
		o.launch(1, false, true, 4, false, false, 2, false, true);
	}
	@Test
	public void test3923() {
		o.launch(1, false, true, 4, false, false, 2, false, false);
	}
	@Test
	public void test3924() {
		o.launch(1, false, true, 4, false, false, 3, true, true);
	}
	@Test
	public void test3925() {
		o.launch(1, false, true, 4, false, false, 3, true, false);
	}
	@Test
	public void test3926() {
		o.launch(1, false, true, 4, false, false, 3, false, true);
	}
	@Test
	public void test3927() {
		o.launch(1, false, true, 4, false, false, 3, false, false);
	}
	@Test
	public void test3928() {
		o.launch(1, false, true, 4, false, false, 4, true, true);
	}
	@Test
	public void test3929() {
		o.launch(1, false, true, 4, false, false, 4, true, false);
	}
	@Test
	public void test3930() {
		o.launch(1, false, true, 4, false, false, 4, false, true);
	}
	@Test
	public void test3931() {
		o.launch(1, false, true, 4, false, false, 4, false, false);
	}
	@Test
	public void test3932() {
		o.launch(1, false, true, 4, false, false, -1, true, true);
	}
	@Test
	public void test3933() {
		o.launch(1, false, true, 4, false, false, 10, true, false);
	}
	@Test
	public void test3934() {
		o.launch(1, false, true, 4, false, false, 5, false, true);
	}
	@Test
	public void test3935() {
		o.launch(1, false, true, 4, false, false, 5, false, false);
	}
	@Test
	public void test3936() {
		o.launch(1, false, true, -1, true, true, 0, true, true);
	}
	@Test
	public void test3937() {
		o.launch(1, false, true, -1, true, true, 0, true, false);
	}
	@Test
	public void test3938() {
		o.launch(1, false, true, -1, true, true, 0, false, true);
	}
	@Test
	public void test3939() {
		o.launch(1, false, true, -1, true, true, 0, false, false);
	}
	@Test
	public void test3940() {
		o.launch(1, false, true, -1, true, true, 1, true, true);
	}
	@Test
	public void test3941() {
		o.launch(1, false, true, -1, true, true, 1, true, false);
	}
	@Test
	public void test3942() {
		o.launch(1, false, true, 10, true, true, 1, false, true);
	}
	@Test
	public void test3943() {
		o.launch(1, false, true, 10, true, true, 1, false, false);
	}
	@Test
	public void test3944() {
		o.launch(1, false, true, 5, true, true, 2, true, true);
	}
	@Test
	public void test3945() {
		o.launch(1, false, true, 5, true, true, 2, true, false);
	}
	@Test
	public void test3946() {
		o.launch(1, false, true, 5, true, true, 2, false, true);
	}
	@Test
	public void test3947() {
		o.launch(1, false, true, 5, true, true, 2, false, false);
	}
	@Test
	public void test3948() {
		o.launch(1, false, true, 5, true, true, 3, true, true);
	}
	@Test
	public void test3949() {
		o.launch(1, false, true, 5, true, true, 3, true, false);
	}
	@Test
	public void test3950() {
		o.launch(1, false, true, 5, true, true, 3, false, true);
	}
	@Test
	public void test3951() {
		o.launch(1, false, true, 5, true, true, 3, false, false);
	}
	@Test
	public void test3952() {
		o.launch(1, false, true, 100, true, true, 4, true, true);
	}
	@Test
	public void test3953() {
		o.launch(1, false, true, 10, true, true, 4, true, false);
	}
	@Test
	public void test3954() {
		o.launch(1, false, true, 100, true, true, 4, false, true);
	}
	@Test
	public void test3955() {
		o.launch(1, false, true, -1, true, true, 4, false, false);
	}
	@Test
	public void test3956() {
		o.launch(1, false, true, -1, true, true, 100, true, true);
	}
	@Test
	public void test3957() {
		o.launch(1, false, true, 10, true, true, -1, true, false);
	}
	@Test
	public void test3958() {
		o.launch(1, false, true, 100, true, true, 10, false, true);
	}
	@Test
	public void test3959() {
		o.launch(1, false, true, 100, true, true, 10, false, false);
	}
	@Test
	public void test3960() {
		o.launch(1, false, true, 10, true, false, 0, true, true);
	}
	@Test
	public void test3961() {
		o.launch(1, false, true, 100, true, false, 0, true, false);
	}
	@Test
	public void test3962() {
		o.launch(1, false, true, 10, true, false, 0, false, true);
	}
	@Test
	public void test3963() {
		o.launch(1, false, true, 10, true, false, 0, false, false);
	}
	@Test
	public void test3964() {
		o.launch(1, false, true, 10, true, false, 1, true, true);
	}
	@Test
	public void test3965() {
		o.launch(1, false, true, 10, true, false, 1, true, false);
	}
	@Test
	public void test3966() {
		o.launch(1, false, true, 5, true, false, 1, false, true);
	}
	@Test
	public void test3967() {
		o.launch(1, false, true, 100, true, false, 1, false, false);
	}
	@Test
	public void test3968() {
		o.launch(1, false, true, 5, true, false, 2, true, true);
	}
	@Test
	public void test3969() {
		o.launch(1, false, true, 5, true, false, 2, true, false);
	}
	@Test
	public void test3970() {
		o.launch(1, false, true, 5, true, false, 2, false, true);
	}
	@Test
	public void test3971() {
		o.launch(1, false, true, 5, true, false, 2, false, false);
	}
	@Test
	public void test3972() {
		o.launch(1, false, true, 5, true, false, 3, true, true);
	}
	@Test
	public void test3973() {
		o.launch(1, false, true, 5, true, false, 3, true, false);
	}
	@Test
	public void test3974() {
		o.launch(1, false, true, 5, true, false, 3, false, true);
	}
	@Test
	public void test3975() {
		o.launch(1, false, true, 5, true, false, 3, false, false);
	}
	@Test
	public void test3976() {
		o.launch(1, false, true, 10, true, false, 4, true, true);
	}
	@Test
	public void test3977() {
		o.launch(1, false, true, 5, true, false, 4, true, false);
	}
	@Test
	public void test3978() {
		o.launch(1, false, true, 10, true, false, 4, false, true);
	}
	@Test
	public void test3979() {
		o.launch(1, false, true, 5, true, false, 4, false, false);
	}
	@Test
	public void test3980() {
		o.launch(1, false, true, 100, true, false, -1, true, true);
	}
	@Test
	public void test3981() {
		o.launch(1, false, true, 10, true, false, 100, true, false);
	}
	@Test
	public void test3982() {
		o.launch(1, false, true, 100, true, false, -1, false, true);
	}
	@Test
	public void test3983() {
		o.launch(1, false, true, 100, true, false, -1, false, false);
	}
	@Test
	public void test3984() {
		o.launch(1, false, true, 10, false, true, 0, true, true);
	}
	@Test
	public void test3985() {
		o.launch(1, false, true, -1, false, true, 0, true, false);
	}
	@Test
	public void test3986() {
		o.launch(1, false, true, 100, false, true, 0, false, true);
	}
	@Test
	public void test3987() {
		o.launch(1, false, true, 100, false, true, 0, false, false);
	}
	@Test
	public void test3988() {
		o.launch(1, false, true, 10, false, true, 1, true, true);
	}
	@Test
	public void test3989() {
		o.launch(1, false, true, 5, false, true, 1, true, false);
	}
	@Test
	public void test3990() {
		o.launch(1, false, true, 100, false, true, 1, false, true);
	}
	@Test
	public void test3991() {
		o.launch(1, false, true, 10, false, true, 1, false, false);
	}
	@Test
	public void test3992() {
		o.launch(1, false, true, 5, false, true, 2, true, true);
	}
	@Test
	public void test3993() {
		o.launch(1, false, true, 5, false, true, 2, true, false);
	}
	@Test
	public void test3994() {
		o.launch(1, false, true, 5, false, true, 2, false, true);
	}
	@Test
	public void test3995() {
		o.launch(1, false, true, 5, false, true, 2, false, false);
	}
	@Test
	public void test3996() {
		o.launch(1, false, true, 5, false, true, 3, true, true);
	}
	@Test
	public void test3997() {
		o.launch(1, false, true, 5, false, true, 3, true, false);
	}
	@Test
	public void test3998() {
		o.launch(1, false, true, 5, false, true, 3, false, true);
	}
	@Test
	public void test3999() {
		o.launch(1, false, true, 5, false, true, 3, false, false);
	}
	@Test
	public void test4000() {
		o.launch(1, false, true, 5, false, true, 4, true, true);
	}
	@Test
	public void test4001() {
		o.launch(1, false, true, 5, false, true, 4, true, false);
	}
	@Test
	public void test4002() {
		o.launch(1, false, true, 10, false, true, 4, false, true);
	}
	@Test
	public void test4003() {
		o.launch(1, false, true, 100, false, true, 4, false, false);
	}
	@Test
	public void test4004() {
		o.launch(1, false, true, 10, false, true, 100, true, true);
	}
	@Test
	public void test4005() {
		o.launch(1, false, true, 10, false, true, 100, true, false);
	}
	@Test
	public void test4006() {
		o.launch(1, false, true, 10, false, true, 100, false, true);
	}
	@Test
	public void test4007() {
		o.launch(1, false, true, 10, false, true, 10, false, false);
	}
	@Test
	public void test4008() {
		o.launch(1, false, true, 100, false, false, 0, true, true);
	}
	@Test
	public void test4009() {
		o.launch(1, false, true, 10, false, false, 0, true, false);
	}
	@Test
	public void test4010() {
		o.launch(1, false, true, 10, false, false, 0, false, true);
	}
	@Test
	public void test4011() {
		o.launch(1, false, true, 10, false, false, 0, false, false);
	}
	@Test
	public void test4012() {
		o.launch(1, false, true, 5, false, false, 1, true, true);
	}
	@Test
	public void test4013() {
		o.launch(1, false, true, 100, false, false, 1, true, false);
	}
	@Test
	public void test4014() {
		o.launch(1, false, true, 10, false, false, 1, false, true);
	}
	@Test
	public void test4015() {
		o.launch(1, false, true, 10, false, false, 1, false, false);
	}
	@Test
	public void test4016() {
		o.launch(1, false, true, 5, false, false, 2, true, true);
	}
	@Test
	public void test4017() {
		o.launch(1, false, true, 5, false, false, 2, true, false);
	}
	@Test
	public void test4018() {
		o.launch(1, false, true, 5, false, false, 2, false, true);
	}
	@Test
	public void test4019() {
		o.launch(1, false, true, 5, false, false, 2, false, false);
	}
	@Test
	public void test4020() {
		o.launch(1, false, true, 5, false, false, 3, true, true);
	}
	@Test
	public void test4021() {
		o.launch(1, false, true, 5, false, false, 3, true, false);
	}
	@Test
	public void test4022() {
		o.launch(1, false, true, 5, false, false, 3, false, true);
	}
	@Test
	public void test4023() {
		o.launch(1, false, true, 5, false, false, 3, false, false);
	}
	@Test
	public void test4024() {
		o.launch(1, false, true, 5, false, false, 4, true, true);
	}
	@Test
	public void test4025() {
		o.launch(1, false, true, -1, false, false, 4, true, false);
	}
	@Test
	public void test4026() {
		o.launch(1, false, true, 5, false, false, 4, false, true);
	}
	@Test
	public void test4027() {
		o.launch(1, false, true, -1, false, false, 4, false, false);
	}
	@Test
	public void test4028() {
		o.launch(1, false, true, -1, false, false, -1, true, true);
	}
	@Test
	public void test4029() {
		o.launch(1, false, true, -1, false, false, -1, true, false);
	}
	@Test
	public void test4030() {
		o.launch(1, false, true, -1, false, false, -1, false, true);
	}
	@Test
	public void test4031() {
		o.launch(1, false, true, -1, false, false, -1, false, false);
	}
	@Test
	public void test4032() {
		o.launch(1, false, false, 0, true, true, 0, true, true);
	}
	@Test
	public void test4033() {
		o.launch(1, false, false, 0, true, true, 0, true, false);
	}
	@Test
	public void test4034() {
		o.launch(1, false, false, 0, true, true, 0, false, true);
	}
	@Test
	public void test4035() {
		o.launch(1, false, false, 0, true, true, 0, false, false);
	}
	@Test
	public void test4036() {
		o.launch(1, false, false, 0, true, true, 1, true, true);
	}
	@Test
	public void test4037() {
		o.launch(1, false, false, 0, true, true, 1, true, false);
	}
	@Test
	public void test4038() {
		o.launch(1, false, false, 0, true, true, 1, false, true);
	}
	@Test
	public void test4039() {
		o.launch(1, false, false, 0, true, true, 1, false, false);
	}
	@Test
	public void test4040() {
		o.launch(1, false, false, 0, true, true, 2, true, true);
	}
	@Test
	public void test4041() {
		o.launch(1, false, false, 0, true, true, 2, true, false);
	}
	@Test
	public void test4042() {
		o.launch(1, false, false, 0, true, true, 2, false, true);
	}
	@Test
	public void test4043() {
		o.launch(1, false, false, 0, true, true, 2, false, false);
	}
	@Test
	public void test4044() {
		o.launch(1, false, false, 0, true, true, 3, true, true);
	}
	@Test
	public void test4045() {
		o.launch(1, false, false, 0, true, true, 3, true, false);
	}
	@Test
	public void test4046() {
		o.launch(1, false, false, 0, true, true, 3, false, true);
	}
	@Test
	public void test4047() {
		o.launch(1, false, false, 0, true, true, 3, false, false);
	}
	@Test
	public void test4048() {
		o.launch(1, false, false, 0, true, true, 4, true, true);
	}
	@Test
	public void test4049() {
		o.launch(1, false, false, 0, true, true, 4, true, false);
	}
	@Test
	public void test4050() {
		o.launch(1, false, false, 0, true, true, 4, false, true);
	}
	@Test
	public void test4051() {
		o.launch(1, false, false, 0, true, true, 4, false, false);
	}
	@Test
	public void test4052() {
		o.launch(1, false, false, 0, true, true, 5, true, true);
	}
	@Test
	public void test4053() {
		o.launch(1, false, false, 0, true, true, 10, true, false);
	}
	@Test
	public void test4054() {
		o.launch(1, false, false, 0, true, true, 100, false, true);
	}
	@Test
	public void test4055() {
		o.launch(1, false, false, 0, true, true, 100, false, false);
	}
	@Test
	public void test4056() {
		o.launch(1, false, false, 0, true, false, 0, true, true);
	}
	@Test
	public void test4057() {
		o.launch(1, false, false, 0, true, false, 0, true, false);
	}
	@Test
	public void test4058() {
		o.launch(1, false, false, 0, true, false, 0, false, true);
	}
	@Test
	public void test4059() {
		o.launch(1, false, false, 0, true, false, 0, false, false);
	}
	@Test
	public void test4060() {
		o.launch(1, false, false, 0, true, false, 1, true, true);
	}
	@Test
	public void test4061() {
		o.launch(1, false, false, 0, true, false, 1, true, false);
	}
	@Test
	public void test4062() {
		o.launch(1, false, false, 0, true, false, 1, false, true);
	}
	@Test
	public void test4063() {
		o.launch(1, false, false, 0, true, false, 1, false, false);
	}
	@Test
	public void test4064() {
		o.launch(1, false, false, 0, true, false, 2, true, true);
	}
	@Test
	public void test4065() {
		o.launch(1, false, false, 0, true, false, 2, true, false);
	}
	@Test
	public void test4066() {
		o.launch(1, false, false, 0, true, false, 2, false, true);
	}
	@Test
	public void test4067() {
		o.launch(1, false, false, 0, true, false, 2, false, false);
	}
	@Test
	public void test4068() {
		o.launch(1, false, false, 0, true, false, 3, true, true);
	}
	@Test
	public void test4069() {
		o.launch(1, false, false, 0, true, false, 3, true, false);
	}
	@Test
	public void test4070() {
		o.launch(1, false, false, 0, true, false, 3, false, true);
	}
	@Test
	public void test4071() {
		o.launch(1, false, false, 0, true, false, 3, false, false);
	}
	@Test
	public void test4072() {
		o.launch(1, false, false, 0, true, false, 4, true, true);
	}
	@Test
	public void test4073() {
		o.launch(1, false, false, 0, true, false, 4, true, false);
	}
	@Test
	public void test4074() {
		o.launch(1, false, false, 0, true, false, 4, false, true);
	}
	@Test
	public void test4075() {
		o.launch(1, false, false, 0, true, false, 4, false, false);
	}
	@Test
	public void test4076() {
		o.launch(1, false, false, 0, true, false, 10, true, true);
	}
	@Test
	public void test4077() {
		o.launch(1, false, false, 0, true, false, -1, true, false);
	}
	@Test
	public void test4078() {
		o.launch(1, false, false, 0, true, false, 10, false, true);
	}
	@Test
	public void test4079() {
		o.launch(1, false, false, 0, true, false, -1, false, false);
	}
	@Test
	public void test4080() {
		o.launch(1, false, false, 0, false, true, 0, true, true);
	}
	@Test
	public void test4081() {
		o.launch(1, false, false, 0, false, true, 0, true, false);
	}
	@Test
	public void test4082() {
		o.launch(1, false, false, 0, false, true, 0, false, true);
	}
	@Test
	public void test4083() {
		o.launch(1, false, false, 0, false, true, 0, false, false);
	}
	@Test
	public void test4084() {
		o.launch(1, false, false, 0, false, true, 1, true, true);
	}
	@Test
	public void test4085() {
		o.launch(1, false, false, 0, false, true, 1, true, false);
	}
	@Test
	public void test4086() {
		o.launch(1, false, false, 0, false, true, 1, false, true);
	}
	@Test
	public void test4087() {
		o.launch(1, false, false, 0, false, true, 1, false, false);
	}
	@Test
	public void test4088() {
		o.launch(1, false, false, 0, false, true, 2, true, true);
	}
	@Test
	public void test4089() {
		o.launch(1, false, false, 0, false, true, 2, true, false);
	}
	@Test
	public void test4090() {
		o.launch(1, false, false, 0, false, true, 2, false, true);
	}
	@Test
	public void test4091() {
		o.launch(1, false, false, 0, false, true, 2, false, false);
	}
	@Test
	public void test4092() {
		o.launch(1, false, false, 0, false, true, 3, true, true);
	}
	@Test
	public void test4093() {
		o.launch(1, false, false, 0, false, true, 3, true, false);
	}
	@Test
	public void test4094() {
		o.launch(1, false, false, 0, false, true, 3, false, true);
	}
	@Test
	public void test4095() {
		o.launch(1, false, false, 0, false, true, 3, false, false);
	}
	@Test
	public void test4096() {
		o.launch(1, false, false, 0, false, true, 4, true, true);
	}
	@Test
	public void test4097() {
		o.launch(1, false, false, 0, false, true, 4, true, false);
	}
	@Test
	public void test4098() {
		o.launch(1, false, false, 0, false, true, 4, false, true);
	}
	@Test
	public void test4099() {
		o.launch(1, false, false, 0, false, true, 4, false, false);
	}
	@Test
	public void test4100() {
		o.launch(1, false, false, 0, false, true, 100, true, true);
	}
	@Test
	public void test4101() {
		o.launch(1, false, false, 0, false, true, 10, true, false);
	}
	@Test
	public void test4102() {
		o.launch(1, false, false, 0, false, true, 10, false, true);
	}
	@Test
	public void test4103() {
		o.launch(1, false, false, 0, false, true, 10, false, false);
	}
	@Test
	public void test4104() {
		o.launch(1, false, false, 0, false, false, 0, true, true);
	}
	@Test
	public void test4105() {
		o.launch(1, false, false, 0, false, false, 0, true, false);
	}
	@Test
	public void test4106() {
		o.launch(1, false, false, 0, false, false, 0, false, true);
	}
	@Test
	public void test4107() {
		o.launch(1, false, false, 0, false, false, 0, false, false);
	}
	@Test
	public void test4108() {
		o.launch(1, false, false, 0, false, false, 1, true, true);
	}
	@Test
	public void test4109() {
		o.launch(1, false, false, 0, false, false, 1, true, false);
	}
	@Test
	public void test4110() {
		o.launch(1, false, false, 0, false, false, 1, false, true);
	}
	@Test
	public void test4111() {
		o.launch(1, false, false, 0, false, false, 1, false, false);
	}
	@Test
	public void test4112() {
		o.launch(1, false, false, 0, false, false, 2, true, true);
	}
	@Test
	public void test4113() {
		o.launch(1, false, false, 0, false, false, 2, true, false);
	}
	@Test
	public void test4114() {
		o.launch(1, false, false, 0, false, false, 2, false, true);
	}
	@Test
	public void test4115() {
		o.launch(1, false, false, 0, false, false, 2, false, false);
	}
	@Test
	public void test4116() {
		o.launch(1, false, false, 0, false, false, 3, true, true);
	}
	@Test
	public void test4117() {
		o.launch(1, false, false, 0, false, false, 3, true, false);
	}
	@Test
	public void test4118() {
		o.launch(1, false, false, 0, false, false, 3, false, true);
	}
	@Test
	public void test4119() {
		o.launch(1, false, false, 0, false, false, 3, false, false);
	}
	@Test
	public void test4120() {
		o.launch(1, false, false, 0, false, false, 4, true, true);
	}
	@Test
	public void test4121() {
		o.launch(1, false, false, 0, false, false, 4, true, false);
	}
	@Test
	public void test4122() {
		o.launch(1, false, false, 0, false, false, 4, false, true);
	}
	@Test
	public void test4123() {
		o.launch(1, false, false, 0, false, false, 4, false, false);
	}
	@Test
	public void test4124() {
		o.launch(1, false, false, 0, false, false, 10, true, true);
	}
	@Test
	public void test4125() {
		o.launch(1, false, false, 0, false, false, -1, true, false);
	}
	@Test
	public void test4126() {
		o.launch(1, false, false, 0, false, false, 100, false, true);
	}
	@Test
	public void test4127() {
		o.launch(1, false, false, 0, false, false, -1, false, false);
	}
	@Test
	public void test4128() {
		o.launch(1, false, false, 1, true, true, 0, true, true);
	}
	@Test
	public void test4129() {
		o.launch(1, false, false, 1, true, true, 0, true, false);
	}
	@Test
	public void test4130() {
		o.launch(1, false, false, 1, true, true, 0, false, true);
	}
	@Test
	public void test4131() {
		o.launch(1, false, false, 1, true, true, 0, false, false);
	}
	@Test
	public void test4132() {
		o.launch(1, false, false, 1, true, true, 1, true, true);
	}
	@Test
	public void test4133() {
		o.launch(1, false, false, 1, true, true, 1, true, false);
	}
	@Test
	public void test4134() {
		o.launch(1, false, false, 1, true, true, 1, false, true);
	}
	@Test
	public void test4135() {
		o.launch(1, false, false, 1, true, true, 1, false, false);
	}
	@Test
	public void test4136() {
		o.launch(1, false, false, 1, true, true, 2, true, true);
	}
	@Test
	public void test4137() {
		o.launch(1, false, false, 1, true, true, 2, true, false);
	}
	@Test
	public void test4138() {
		o.launch(1, false, false, 1, true, true, 2, false, true);
	}
	@Test
	public void test4139() {
		o.launch(1, false, false, 1, true, true, 2, false, false);
	}
	@Test
	public void test4140() {
		o.launch(1, false, false, 1, true, true, 3, true, true);
	}
	@Test
	public void test4141() {
		o.launch(1, false, false, 1, true, true, 3, true, false);
	}
	@Test
	public void test4142() {
		o.launch(1, false, false, 1, true, true, 3, false, true);
	}
	@Test
	public void test4143() {
		o.launch(1, false, false, 1, true, true, 3, false, false);
	}
	@Test
	public void test4144() {
		o.launch(1, false, false, 1, true, true, 4, true, true);
	}
	@Test
	public void test4145() {
		o.launch(1, false, false, 1, true, true, 4, true, false);
	}
	@Test
	public void test4146() {
		o.launch(1, false, false, 1, true, true, 4, false, true);
	}
	@Test
	public void test4147() {
		o.launch(1, false, false, 1, true, true, 4, false, false);
	}
	@Test
	public void test4148() {
		o.launch(1, false, false, 1, true, true, 10, true, true);
	}
	@Test
	public void test4149() {
		o.launch(1, false, false, 1, true, true, 10, true, false);
	}
	@Test
	public void test4150() {
		o.launch(1, false, false, 1, true, true, 10, false, true);
	}
	@Test
	public void test4151() {
		o.launch(1, false, false, 1, true, true, 10, false, false);
	}
	@Test
	public void test4152() {
		o.launch(1, false, false, 1, true, false, 0, true, true);
	}
	@Test
	public void test4153() {
		o.launch(1, false, false, 1, true, false, 0, true, false);
	}
	@Test
	public void test4154() {
		o.launch(1, false, false, 1, true, false, 0, false, true);
	}
	@Test
	public void test4155() {
		o.launch(1, false, false, 1, true, false, 0, false, false);
	}
	@Test
	public void test4156() {
		o.launch(1, false, false, 1, true, false, 1, true, true);
	}
	@Test
	public void test4157() {
		o.launch(1, false, false, 1, true, false, 1, true, false);
	}
	@Test
	public void test4158() {
		o.launch(1, false, false, 1, true, false, 1, false, true);
	}
	@Test
	public void test4159() {
		o.launch(1, false, false, 1, true, false, 1, false, false);
	}
	@Test
	public void test4160() {
		o.launch(1, false, false, 1, true, false, 2, true, true);
	}
	@Test
	public void test4161() {
		o.launch(1, false, false, 1, true, false, 2, true, false);
	}
	@Test
	public void test4162() {
		o.launch(1, false, false, 1, true, false, 2, false, true);
	}
	@Test
	public void test4163() {
		o.launch(1, false, false, 1, true, false, 2, false, false);
	}
	@Test
	public void test4164() {
		o.launch(1, false, false, 1, true, false, 3, true, true);
	}
	@Test
	public void test4165() {
		o.launch(1, false, false, 1, true, false, 3, true, false);
	}
	@Test
	public void test4166() {
		o.launch(1, false, false, 1, true, false, 3, false, true);
	}
	@Test
	public void test4167() {
		o.launch(1, false, false, 1, true, false, 3, false, false);
	}
	@Test
	public void test4168() {
		o.launch(1, false, false, 1, true, false, 4, true, true);
	}
	@Test
	public void test4169() {
		o.launch(1, false, false, 1, true, false, 4, true, false);
	}
	@Test
	public void test4170() {
		o.launch(1, false, false, 1, true, false, 4, false, true);
	}
	@Test
	public void test4171() {
		o.launch(1, false, false, 1, true, false, 4, false, false);
	}
	@Test
	public void test4172() {
		o.launch(1, false, false, 1, true, false, -1, true, true);
	}
	@Test
	public void test4173() {
		o.launch(1, false, false, 1, true, false, -1, true, false);
	}
	@Test
	public void test4174() {
		o.launch(1, false, false, 1, true, false, 100, false, true);
	}
	@Test
	public void test4175() {
		o.launch(1, false, false, 1, true, false, -1, false, false);
	}
	@Test
	public void test4176() {
		o.launch(1, false, false, 1, false, true, 0, true, true);
	}
	@Test
	public void test4177() {
		o.launch(1, false, false, 1, false, true, 0, true, false);
	}
	@Test
	public void test4178() {
		o.launch(1, false, false, 1, false, true, 0, false, true);
	}
	@Test
	public void test4179() {
		o.launch(1, false, false, 1, false, true, 0, false, false);
	}
	@Test
	public void test4180() {
		o.launch(1, false, false, 1, false, true, 1, true, true);
	}
	@Test
	public void test4181() {
		o.launch(1, false, false, 1, false, true, 1, true, false);
	}
	@Test
	public void test4182() {
		o.launch(1, false, false, 1, false, true, 1, false, true);
	}
	@Test
	public void test4183() {
		o.launch(1, false, false, 1, false, true, 1, false, false);
	}
	@Test
	public void test4184() {
		o.launch(1, false, false, 1, false, true, 2, true, true);
	}
	@Test
	public void test4185() {
		o.launch(1, false, false, 1, false, true, 2, true, false);
	}
	@Test
	public void test4186() {
		o.launch(1, false, false, 1, false, true, 2, false, true);
	}
	@Test
	public void test4187() {
		o.launch(1, false, false, 1, false, true, 2, false, false);
	}
	@Test
	public void test4188() {
		o.launch(1, false, false, 1, false, true, 3, true, true);
	}
	@Test
	public void test4189() {
		o.launch(1, false, false, 1, false, true, 3, true, false);
	}
	@Test
	public void test4190() {
		o.launch(1, false, false, 1, false, true, 3, false, true);
	}
	@Test
	public void test4191() {
		o.launch(1, false, false, 1, false, true, 3, false, false);
	}
	@Test
	public void test4192() {
		o.launch(1, false, false, 1, false, true, 4, true, true);
	}
	@Test
	public void test4193() {
		o.launch(1, false, false, 1, false, true, 4, true, false);
	}
	@Test
	public void test4194() {
		o.launch(1, false, false, 1, false, true, 4, false, true);
	}
	@Test
	public void test4195() {
		o.launch(1, false, false, 1, false, true, 4, false, false);
	}
	@Test
	public void test4196() {
		o.launch(1, false, false, 1, false, true, -1, true, true);
	}
	@Test
	public void test4197() {
		o.launch(1, false, false, 1, false, true, 10, true, false);
	}
	@Test
	public void test4198() {
		o.launch(1, false, false, 1, false, true, 5, false, true);
	}
	@Test
	public void test4199() {
		o.launch(1, false, false, 1, false, true, 10, false, false);
	}
	@Test
	public void test4200() {
		o.launch(1, false, false, 1, false, false, 0, true, true);
	}
	@Test
	public void test4201() {
		o.launch(1, false, false, 1, false, false, 0, true, false);
	}
	@Test
	public void test4202() {
		o.launch(1, false, false, 1, false, false, 0, false, true);
	}
	@Test
	public void test4203() {
		o.launch(1, false, false, 1, false, false, 0, false, false);
	}
	@Test
	public void test4204() {
		o.launch(1, false, false, 1, false, false, 1, true, true);
	}
	@Test
	public void test4205() {
		o.launch(1, false, false, 1, false, false, 1, true, false);
	}
	@Test
	public void test4206() {
		o.launch(1, false, false, 1, false, false, 1, false, true);
	}
	@Test
	public void test4207() {
		o.launch(1, false, false, 1, false, false, 1, false, false);
	}
	@Test
	public void test4208() {
		o.launch(1, false, false, 1, false, false, 2, true, true);
	}
	@Test
	public void test4209() {
		o.launch(1, false, false, 1, false, false, 2, true, false);
	}
	@Test
	public void test4210() {
		o.launch(1, false, false, 1, false, false, 2, false, true);
	}
	@Test
	public void test4211() {
		o.launch(1, false, false, 1, false, false, 2, false, false);
	}
	@Test
	public void test4212() {
		o.launch(1, false, false, 1, false, false, 3, true, true);
	}
	@Test
	public void test4213() {
		o.launch(1, false, false, 1, false, false, 3, true, false);
	}
	@Test
	public void test4214() {
		o.launch(1, false, false, 1, false, false, 3, false, true);
	}
	@Test
	public void test4215() {
		o.launch(1, false, false, 1, false, false, 3, false, false);
	}
	@Test
	public void test4216() {
		o.launch(1, false, false, 1, false, false, 4, true, true);
	}
	@Test
	public void test4217() {
		o.launch(1, false, false, 1, false, false, 4, true, false);
	}
	@Test
	public void test4218() {
		o.launch(1, false, false, 1, false, false, 4, false, true);
	}
	@Test
	public void test4219() {
		o.launch(1, false, false, 1, false, false, 4, false, false);
	}
	@Test
	public void test4220() {
		o.launch(1, false, false, 1, false, false, 10, true, true);
	}
	@Test
	public void test4221() {
		o.launch(1, false, false, 1, false, false, -1, true, false);
	}
	@Test
	public void test4222() {
		o.launch(1, false, false, 1, false, false, 10, false, true);
	}
	@Test
	public void test4223() {
		o.launch(1, false, false, 1, false, false, 10, false, false);
	}
	@Test
	public void test4224() {
		o.launch(1, false, false, 2, true, true, 0, true, true);
	}
	@Test
	public void test4225() {
		o.launch(1, false, false, 2, true, true, 0, true, false);
	}
	@Test
	public void test4226() {
		o.launch(1, false, false, 2, true, true, 0, false, true);
	}
	@Test
	public void test4227() {
		o.launch(1, false, false, 2, true, true, 0, false, false);
	}
	@Test
	public void test4228() {
		o.launch(1, false, false, 2, true, true, 1, true, true);
	}
	@Test
	public void test4229() {
		o.launch(1, false, false, 2, true, true, 1, true, false);
	}
	@Test
	public void test4230() {
		o.launch(1, false, false, 2, true, true, 1, false, true);
	}
	@Test
	public void test4231() {
		o.launch(1, false, false, 2, true, true, 1, false, false);
	}
	@Test
	public void test4232() {
		o.launch(1, false, false, 2, true, true, 2, true, true);
	}
	@Test
	public void test4233() {
		o.launch(1, false, false, 2, true, true, 2, true, false);
	}
	@Test
	public void test4234() {
		o.launch(1, false, false, 2, true, true, 2, false, true);
	}
	@Test
	public void test4235() {
		o.launch(1, false, false, 2, true, true, 2, false, false);
	}
	@Test
	public void test4236() {
		o.launch(1, false, false, 2, true, true, 3, true, true);
	}
	@Test
	public void test4237() {
		o.launch(1, false, false, 2, true, true, 3, true, false);
	}
	@Test
	public void test4238() {
		o.launch(1, false, false, 2, true, true, 3, false, true);
	}
	@Test
	public void test4239() {
		o.launch(1, false, false, 2, true, true, 3, false, false);
	}
	@Test
	public void test4240() {
		o.launch(1, false, false, 2, true, true, 4, true, true);
	}
	@Test
	public void test4241() {
		o.launch(1, false, false, 2, true, true, 4, true, false);
	}
	@Test
	public void test4242() {
		o.launch(1, false, false, 2, true, true, 4, false, true);
	}
	@Test
	public void test4243() {
		o.launch(1, false, false, 2, true, true, 4, false, false);
	}
	@Test
	public void test4244() {
		o.launch(1, false, false, 2, true, true, 5, true, true);
	}
	@Test
	public void test4245() {
		o.launch(1, false, false, 2, true, true, 5, true, false);
	}
	@Test
	public void test4246() {
		o.launch(1, false, false, 2, true, true, 5, false, true);
	}
	@Test
	public void test4247() {
		o.launch(1, false, false, 2, true, true, 5, false, false);
	}
	@Test
	public void test4248() {
		o.launch(1, false, false, 2, true, false, 0, true, true);
	}
	@Test
	public void test4249() {
		o.launch(1, false, false, 2, true, false, 0, true, false);
	}
	@Test
	public void test4250() {
		o.launch(1, false, false, 2, true, false, 0, false, true);
	}
	@Test
	public void test4251() {
		o.launch(1, false, false, 2, true, false, 0, false, false);
	}
	@Test
	public void test4252() {
		o.launch(1, false, false, 2, true, false, 1, true, true);
	}
	@Test
	public void test4253() {
		o.launch(1, false, false, 2, true, false, 1, true, false);
	}
	@Test
	public void test4254() {
		o.launch(1, false, false, 2, true, false, 1, false, true);
	}
	@Test
	public void test4255() {
		o.launch(1, false, false, 2, true, false, 1, false, false);
	}
	@Test
	public void test4256() {
		o.launch(1, false, false, 2, true, false, 2, true, true);
	}
	@Test
	public void test4257() {
		o.launch(1, false, false, 2, true, false, 2, true, false);
	}
	@Test
	public void test4258() {
		o.launch(1, false, false, 2, true, false, 2, false, true);
	}
	@Test
	public void test4259() {
		o.launch(1, false, false, 2, true, false, 2, false, false);
	}
	@Test
	public void test4260() {
		o.launch(1, false, false, 2, true, false, 3, true, true);
	}
	@Test
	public void test4261() {
		o.launch(1, false, false, 2, true, false, 3, true, false);
	}
	@Test
	public void test4262() {
		o.launch(1, false, false, 2, true, false, 3, false, true);
	}
	@Test
	public void test4263() {
		o.launch(1, false, false, 2, true, false, 3, false, false);
	}
	@Test
	public void test4264() {
		o.launch(1, false, false, 2, true, false, 4, true, true);
	}
	@Test
	public void test4265() {
		o.launch(1, false, false, 2, true, false, 4, true, false);
	}
	@Test
	public void test4266() {
		o.launch(1, false, false, 2, true, false, 4, false, true);
	}
	@Test
	public void test4267() {
		o.launch(1, false, false, 2, true, false, 4, false, false);
	}
	@Test
	public void test4268() {
		o.launch(1, false, false, 2, true, false, 5, true, true);
	}
	@Test
	public void test4269() {
		o.launch(1, false, false, 2, true, false, 5, true, false);
	}
	@Test
	public void test4270() {
		o.launch(1, false, false, 2, true, false, 5, false, true);
	}
	@Test
	public void test4271() {
		o.launch(1, false, false, 2, true, false, 5, false, false);
	}
	@Test
	public void test4272() {
		o.launch(1, false, false, 2, false, true, 0, true, true);
	}
	@Test
	public void test4273() {
		o.launch(1, false, false, 2, false, true, 0, true, false);
	}
	@Test
	public void test4274() {
		o.launch(1, false, false, 2, false, true, 0, false, true);
	}
	@Test
	public void test4275() {
		o.launch(1, false, false, 2, false, true, 0, false, false);
	}
	@Test
	public void test4276() {
		o.launch(1, false, false, 2, false, true, 1, true, true);
	}
	@Test
	public void test4277() {
		o.launch(1, false, false, 2, false, true, 1, true, false);
	}
	@Test
	public void test4278() {
		o.launch(1, false, false, 2, false, true, 1, false, true);
	}
	@Test
	public void test4279() {
		o.launch(1, false, false, 2, false, true, 1, false, false);
	}
	@Test
	public void test4280() {
		o.launch(1, false, false, 2, false, true, 2, true, true);
	}
	@Test
	public void test4281() {
		o.launch(1, false, false, 2, false, true, 2, true, false);
	}
	@Test
	public void test4282() {
		o.launch(1, false, false, 2, false, true, 2, false, true);
	}
	@Test
	public void test4283() {
		o.launch(1, false, false, 2, false, true, 2, false, false);
	}
	@Test
	public void test4284() {
		o.launch(1, false, false, 2, false, true, 3, true, true);
	}
	@Test
	public void test4285() {
		o.launch(1, false, false, 2, false, true, 3, true, false);
	}
	@Test
	public void test4286() {
		o.launch(1, false, false, 2, false, true, 3, false, true);
	}
	@Test
	public void test4287() {
		o.launch(1, false, false, 2, false, true, 3, false, false);
	}
	@Test
	public void test4288() {
		o.launch(1, false, false, 2, false, true, 4, true, true);
	}
	@Test
	public void test4289() {
		o.launch(1, false, false, 2, false, true, 4, true, false);
	}
	@Test
	public void test4290() {
		o.launch(1, false, false, 2, false, true, 4, false, true);
	}
	@Test
	public void test4291() {
		o.launch(1, false, false, 2, false, true, 4, false, false);
	}
	@Test
	public void test4292() {
		o.launch(1, false, false, 2, false, true, 5, true, true);
	}
	@Test
	public void test4293() {
		o.launch(1, false, false, 2, false, true, 5, true, false);
	}
	@Test
	public void test4294() {
		o.launch(1, false, false, 2, false, true, 5, false, true);
	}
	@Test
	public void test4295() {
		o.launch(1, false, false, 2, false, true, 5, false, false);
	}
	@Test
	public void test4296() {
		o.launch(1, false, false, 2, false, false, 0, true, true);
	}
	@Test
	public void test4297() {
		o.launch(1, false, false, 2, false, false, 0, true, false);
	}
	@Test
	public void test4298() {
		o.launch(1, false, false, 2, false, false, 0, false, true);
	}
	@Test
	public void test4299() {
		o.launch(1, false, false, 2, false, false, 0, false, false);
	}
	@Test
	public void test4300() {
		o.launch(1, false, false, 2, false, false, 1, true, true);
	}
	@Test
	public void test4301() {
		o.launch(1, false, false, 2, false, false, 1, true, false);
	}
	@Test
	public void test4302() {
		o.launch(1, false, false, 2, false, false, 1, false, true);
	}
	@Test
	public void test4303() {
		o.launch(1, false, false, 2, false, false, 1, false, false);
	}
	@Test
	public void test4304() {
		o.launch(1, false, false, 2, false, false, 2, true, true);
	}
	@Test
	public void test4305() {
		o.launch(1, false, false, 2, false, false, 2, true, false);
	}
	@Test
	public void test4306() {
		o.launch(1, false, false, 2, false, false, 2, false, true);
	}
	@Test
	public void test4307() {
		o.launch(1, false, false, 2, false, false, 2, false, false);
	}
	@Test
	public void test4308() {
		o.launch(1, false, false, 2, false, false, 3, true, true);
	}
	@Test
	public void test4309() {
		o.launch(1, false, false, 2, false, false, 3, true, false);
	}
	@Test
	public void test4310() {
		o.launch(1, false, false, 2, false, false, 3, false, true);
	}
	@Test
	public void test4311() {
		o.launch(1, false, false, 2, false, false, 3, false, false);
	}
	@Test
	public void test4312() {
		o.launch(1, false, false, 2, false, false, 4, true, true);
	}
	@Test
	public void test4313() {
		o.launch(1, false, false, 2, false, false, 4, true, false);
	}
	@Test
	public void test4314() {
		o.launch(1, false, false, 2, false, false, 4, false, true);
	}
	@Test
	public void test4315() {
		o.launch(1, false, false, 2, false, false, 4, false, false);
	}
	@Test
	public void test4316() {
		o.launch(1, false, false, 2, false, false, 5, true, true);
	}
	@Test
	public void test4317() {
		o.launch(1, false, false, 2, false, false, 5, true, false);
	}
	@Test
	public void test4318() {
		o.launch(1, false, false, 2, false, false, 5, false, true);
	}
	@Test
	public void test4319() {
		o.launch(1, false, false, 2, false, false, 5, false, false);
	}
	@Test
	public void test4320() {
		o.launch(1, false, false, 3, true, true, 0, true, true);
	}
	@Test
	public void test4321() {
		o.launch(1, false, false, 3, true, true, 0, true, false);
	}
	@Test
	public void test4322() {
		o.launch(1, false, false, 3, true, true, 0, false, true);
	}
	@Test
	public void test4323() {
		o.launch(1, false, false, 3, true, true, 0, false, false);
	}
	@Test
	public void test4324() {
		o.launch(1, false, false, 3, true, true, 1, true, true);
	}
	@Test
	public void test4325() {
		o.launch(1, false, false, 3, true, true, 1, true, false);
	}
	@Test
	public void test4326() {
		o.launch(1, false, false, 3, true, true, 1, false, true);
	}
	@Test
	public void test4327() {
		o.launch(1, false, false, 3, true, true, 1, false, false);
	}
	@Test
	public void test4328() {
		o.launch(1, false, false, 3, true, true, 2, true, true);
	}
	@Test
	public void test4329() {
		o.launch(1, false, false, 3, true, true, 2, true, false);
	}
	@Test
	public void test4330() {
		o.launch(1, false, false, 3, true, true, 2, false, true);
	}
	@Test
	public void test4331() {
		o.launch(1, false, false, 3, true, true, 2, false, false);
	}
	@Test
	public void test4332() {
		o.launch(1, false, false, 3, true, true, 3, true, true);
	}
	@Test
	public void test4333() {
		o.launch(1, false, false, 3, true, true, 3, true, false);
	}
	@Test
	public void test4334() {
		o.launch(1, false, false, 3, true, true, 3, false, true);
	}
	@Test
	public void test4335() {
		o.launch(1, false, false, 3, true, true, 3, false, false);
	}
	@Test
	public void test4336() {
		o.launch(1, false, false, 3, true, true, 4, true, true);
	}
	@Test
	public void test4337() {
		o.launch(1, false, false, 3, true, true, 4, true, false);
	}
	@Test
	public void test4338() {
		o.launch(1, false, false, 3, true, true, 4, false, true);
	}
	@Test
	public void test4339() {
		o.launch(1, false, false, 3, true, true, 4, false, false);
	}
	@Test
	public void test4340() {
		o.launch(1, false, false, 3, true, true, 5, true, true);
	}
	@Test
	public void test4341() {
		o.launch(1, false, false, 3, true, true, 5, true, false);
	}
	@Test
	public void test4342() {
		o.launch(1, false, false, 3, true, true, 5, false, true);
	}
	@Test
	public void test4343() {
		o.launch(1, false, false, 3, true, true, 5, false, false);
	}
	@Test
	public void test4344() {
		o.launch(1, false, false, 3, true, false, 0, true, true);
	}
	@Test
	public void test4345() {
		o.launch(1, false, false, 3, true, false, 0, true, false);
	}
	@Test
	public void test4346() {
		o.launch(1, false, false, 3, true, false, 0, false, true);
	}
	@Test
	public void test4347() {
		o.launch(1, false, false, 3, true, false, 0, false, false);
	}
	@Test
	public void test4348() {
		o.launch(1, false, false, 3, true, false, 1, true, true);
	}
	@Test
	public void test4349() {
		o.launch(1, false, false, 3, true, false, 1, true, false);
	}
	@Test
	public void test4350() {
		o.launch(1, false, false, 3, true, false, 1, false, true);
	}
	@Test
	public void test4351() {
		o.launch(1, false, false, 3, true, false, 1, false, false);
	}
	@Test
	public void test4352() {
		o.launch(1, false, false, 3, true, false, 2, true, true);
	}
	@Test
	public void test4353() {
		o.launch(1, false, false, 3, true, false, 2, true, false);
	}
	@Test
	public void test4354() {
		o.launch(1, false, false, 3, true, false, 2, false, true);
	}
	@Test
	public void test4355() {
		o.launch(1, false, false, 3, true, false, 2, false, false);
	}
	@Test
	public void test4356() {
		o.launch(1, false, false, 3, true, false, 3, true, true);
	}
	@Test
	public void test4357() {
		o.launch(1, false, false, 3, true, false, 3, true, false);
	}
	@Test
	public void test4358() {
		o.launch(1, false, false, 3, true, false, 3, false, true);
	}
	@Test
	public void test4359() {
		o.launch(1, false, false, 3, true, false, 3, false, false);
	}
	@Test
	public void test4360() {
		o.launch(1, false, false, 3, true, false, 4, true, true);
	}
	@Test
	public void test4361() {
		o.launch(1, false, false, 3, true, false, 4, true, false);
	}
	@Test
	public void test4362() {
		o.launch(1, false, false, 3, true, false, 4, false, true);
	}
	@Test
	public void test4363() {
		o.launch(1, false, false, 3, true, false, 4, false, false);
	}
	@Test
	public void test4364() {
		o.launch(1, false, false, 3, true, false, 5, true, true);
	}
	@Test
	public void test4365() {
		o.launch(1, false, false, 3, true, false, 5, true, false);
	}
	@Test
	public void test4366() {
		o.launch(1, false, false, 3, true, false, 5, false, true);
	}
	@Test
	public void test4367() {
		o.launch(1, false, false, 3, true, false, 5, false, false);
	}
	@Test
	public void test4368() {
		o.launch(1, false, false, 3, false, true, 0, true, true);
	}
	@Test
	public void test4369() {
		o.launch(1, false, false, 3, false, true, 0, true, false);
	}
	@Test
	public void test4370() {
		o.launch(1, false, false, 3, false, true, 0, false, true);
	}
	@Test
	public void test4371() {
		o.launch(1, false, false, 3, false, true, 0, false, false);
	}
	@Test
	public void test4372() {
		o.launch(1, false, false, 3, false, true, 1, true, true);
	}
	@Test
	public void test4373() {
		o.launch(1, false, false, 3, false, true, 1, true, false);
	}
	@Test
	public void test4374() {
		o.launch(1, false, false, 3, false, true, 1, false, true);
	}
	@Test
	public void test4375() {
		o.launch(1, false, false, 3, false, true, 1, false, false);
	}
	@Test
	public void test4376() {
		o.launch(1, false, false, 3, false, true, 2, true, true);
	}
	@Test
	public void test4377() {
		o.launch(1, false, false, 3, false, true, 2, true, false);
	}
	@Test
	public void test4378() {
		o.launch(1, false, false, 3, false, true, 2, false, true);
	}
	@Test
	public void test4379() {
		o.launch(1, false, false, 3, false, true, 2, false, false);
	}
	@Test
	public void test4380() {
		o.launch(1, false, false, 3, false, true, 3, true, true);
	}
	@Test
	public void test4381() {
		o.launch(1, false, false, 3, false, true, 3, true, false);
	}
	@Test
	public void test4382() {
		o.launch(1, false, false, 3, false, true, 3, false, true);
	}
	@Test
	public void test4383() {
		o.launch(1, false, false, 3, false, true, 3, false, false);
	}
	@Test
	public void test4384() {
		o.launch(1, false, false, 3, false, true, 4, true, true);
	}
	@Test
	public void test4385() {
		o.launch(1, false, false, 3, false, true, 4, true, false);
	}
	@Test
	public void test4386() {
		o.launch(1, false, false, 3, false, true, 4, false, true);
	}
	@Test
	public void test4387() {
		o.launch(1, false, false, 3, false, true, 4, false, false);
	}
	@Test
	public void test4388() {
		o.launch(1, false, false, 3, false, true, 5, true, true);
	}
	@Test
	public void test4389() {
		o.launch(1, false, false, 3, false, true, 5, true, false);
	}
	@Test
	public void test4390() {
		o.launch(1, false, false, 3, false, true, 5, false, true);
	}
	@Test
	public void test4391() {
		o.launch(1, false, false, 3, false, true, 5, false, false);
	}
	@Test
	public void test4392() {
		o.launch(1, false, false, 3, false, false, 0, true, true);
	}
	@Test
	public void test4393() {
		o.launch(1, false, false, 3, false, false, 0, true, false);
	}
	@Test
	public void test4394() {
		o.launch(1, false, false, 3, false, false, 0, false, true);
	}
	@Test
	public void test4395() {
		o.launch(1, false, false, 3, false, false, 0, false, false);
	}
	@Test
	public void test4396() {
		o.launch(1, false, false, 3, false, false, 1, true, true);
	}
	@Test
	public void test4397() {
		o.launch(1, false, false, 3, false, false, 1, true, false);
	}
	@Test
	public void test4398() {
		o.launch(1, false, false, 3, false, false, 1, false, true);
	}
	@Test
	public void test4399() {
		o.launch(1, false, false, 3, false, false, 1, false, false);
	}
	@Test
	public void test4400() {
		o.launch(1, false, false, 3, false, false, 2, true, true);
	}
	@Test
	public void test4401() {
		o.launch(1, false, false, 3, false, false, 2, true, false);
	}
	@Test
	public void test4402() {
		o.launch(1, false, false, 3, false, false, 2, false, true);
	}
	@Test
	public void test4403() {
		o.launch(1, false, false, 3, false, false, 2, false, false);
	}
	@Test
	public void test4404() {
		o.launch(1, false, false, 3, false, false, 3, true, true);
	}
	@Test
	public void test4405() {
		o.launch(1, false, false, 3, false, false, 3, true, false);
	}
	@Test
	public void test4406() {
		o.launch(1, false, false, 3, false, false, 3, false, true);
	}
	@Test
	public void test4407() {
		o.launch(1, false, false, 3, false, false, 3, false, false);
	}
	@Test
	public void test4408() {
		o.launch(1, false, false, 3, false, false, 4, true, true);
	}
	@Test
	public void test4409() {
		o.launch(1, false, false, 3, false, false, 4, true, false);
	}
	@Test
	public void test4410() {
		o.launch(1, false, false, 3, false, false, 4, false, true);
	}
	@Test
	public void test4411() {
		o.launch(1, false, false, 3, false, false, 4, false, false);
	}
	@Test
	public void test4412() {
		o.launch(1, false, false, 3, false, false, 5, true, true);
	}
	@Test
	public void test4413() {
		o.launch(1, false, false, 3, false, false, 5, true, false);
	}
	@Test
	public void test4414() {
		o.launch(1, false, false, 3, false, false, 5, false, true);
	}
	@Test
	public void test4415() {
		o.launch(1, false, false, 3, false, false, 5, false, false);
	}
	@Test
	public void test4416() {
		o.launch(1, false, false, 4, true, true, 0, true, true);
	}
	@Test
	public void test4417() {
		o.launch(1, false, false, 4, true, true, 0, true, false);
	}
	@Test
	public void test4418() {
		o.launch(1, false, false, 4, true, true, 0, false, true);
	}
	@Test
	public void test4419() {
		o.launch(1, false, false, 4, true, true, 0, false, false);
	}
	@Test
	public void test4420() {
		o.launch(1, false, false, 4, true, true, 1, true, true);
	}
	@Test
	public void test4421() {
		o.launch(1, false, false, 4, true, true, 1, true, false);
	}
	@Test
	public void test4422() {
		o.launch(1, false, false, 4, true, true, 1, false, true);
	}
	@Test
	public void test4423() {
		o.launch(1, false, false, 4, true, true, 1, false, false);
	}
	@Test
	public void test4424() {
		o.launch(1, false, false, 4, true, true, 2, true, true);
	}
	@Test
	public void test4425() {
		o.launch(1, false, false, 4, true, true, 2, true, false);
	}
	@Test
	public void test4426() {
		o.launch(1, false, false, 4, true, true, 2, false, true);
	}
	@Test
	public void test4427() {
		o.launch(1, false, false, 4, true, true, 2, false, false);
	}
	@Test
	public void test4428() {
		o.launch(1, false, false, 4, true, true, 3, true, true);
	}
	@Test
	public void test4429() {
		o.launch(1, false, false, 4, true, true, 3, true, false);
	}
	@Test
	public void test4430() {
		o.launch(1, false, false, 4, true, true, 3, false, true);
	}
	@Test
	public void test4431() {
		o.launch(1, false, false, 4, true, true, 3, false, false);
	}
	@Test
	public void test4432() {
		o.launch(1, false, false, 4, true, true, 4, true, true);
	}
	@Test
	public void test4433() {
		o.launch(1, false, false, 4, true, true, 4, true, false);
	}
	@Test
	public void test4434() {
		o.launch(1, false, false, 4, true, true, 4, false, true);
	}
	@Test
	public void test4435() {
		o.launch(1, false, false, 4, true, true, 4, false, false);
	}
	@Test
	public void test4436() {
		o.launch(1, false, false, 4, true, true, -1, true, true);
	}
	@Test
	public void test4437() {
		o.launch(1, false, false, 4, true, true, -1, true, false);
	}
	@Test
	public void test4438() {
		o.launch(1, false, false, 4, true, true, 10, false, true);
	}
	@Test
	public void test4439() {
		o.launch(1, false, false, 4, true, true, -1, false, false);
	}
	@Test
	public void test4440() {
		o.launch(1, false, false, 4, true, false, 0, true, true);
	}
	@Test
	public void test4441() {
		o.launch(1, false, false, 4, true, false, 0, true, false);
	}
	@Test
	public void test4442() {
		o.launch(1, false, false, 4, true, false, 0, false, true);
	}
	@Test
	public void test4443() {
		o.launch(1, false, false, 4, true, false, 0, false, false);
	}
	@Test
	public void test4444() {
		o.launch(1, false, false, 4, true, false, 1, true, true);
	}
	@Test
	public void test4445() {
		o.launch(1, false, false, 4, true, false, 1, true, false);
	}
	@Test
	public void test4446() {
		o.launch(1, false, false, 4, true, false, 1, false, true);
	}
	@Test
	public void test4447() {
		o.launch(1, false, false, 4, true, false, 1, false, false);
	}
	@Test
	public void test4448() {
		o.launch(1, false, false, 4, true, false, 2, true, true);
	}
	@Test
	public void test4449() {
		o.launch(1, false, false, 4, true, false, 2, true, false);
	}
	@Test
	public void test4450() {
		o.launch(1, false, false, 4, true, false, 2, false, true);
	}
	@Test
	public void test4451() {
		o.launch(1, false, false, 4, true, false, 2, false, false);
	}
	@Test
	public void test4452() {
		o.launch(1, false, false, 4, true, false, 3, true, true);
	}
	@Test
	public void test4453() {
		o.launch(1, false, false, 4, true, false, 3, true, false);
	}
	@Test
	public void test4454() {
		o.launch(1, false, false, 4, true, false, 3, false, true);
	}
	@Test
	public void test4455() {
		o.launch(1, false, false, 4, true, false, 3, false, false);
	}
	@Test
	public void test4456() {
		o.launch(1, false, false, 4, true, false, 4, true, true);
	}
	@Test
	public void test4457() {
		o.launch(1, false, false, 4, true, false, 4, true, false);
	}
	@Test
	public void test4458() {
		o.launch(1, false, false, 4, true, false, 4, false, true);
	}
	@Test
	public void test4459() {
		o.launch(1, false, false, 4, true, false, 4, false, false);
	}
	@Test
	public void test4460() {
		o.launch(1, false, false, 4, true, false, 5, true, true);
	}
	@Test
	public void test4461() {
		o.launch(1, false, false, 4, true, false, 5, true, false);
	}
	@Test
	public void test4462() {
		o.launch(1, false, false, 4, true, false, 5, false, true);
	}
	@Test
	public void test4463() {
		o.launch(1, false, false, 4, true, false, 5, false, false);
	}
	@Test
	public void test4464() {
		o.launch(1, false, false, 4, false, true, 0, true, true);
	}
	@Test
	public void test4465() {
		o.launch(1, false, false, 4, false, true, 0, true, false);
	}
	@Test
	public void test4466() {
		o.launch(1, false, false, 4, false, true, 0, false, true);
	}
	@Test
	public void test4467() {
		o.launch(1, false, false, 4, false, true, 0, false, false);
	}
	@Test
	public void test4468() {
		o.launch(1, false, false, 4, false, true, 1, true, true);
	}
	@Test
	public void test4469() {
		o.launch(1, false, false, 4, false, true, 1, true, false);
	}
	@Test
	public void test4470() {
		o.launch(1, false, false, 4, false, true, 1, false, true);
	}
	@Test
	public void test4471() {
		o.launch(1, false, false, 4, false, true, 1, false, false);
	}
	@Test
	public void test4472() {
		o.launch(1, false, false, 4, false, true, 2, true, true);
	}
	@Test
	public void test4473() {
		o.launch(1, false, false, 4, false, true, 2, true, false);
	}
	@Test
	public void test4474() {
		o.launch(1, false, false, 4, false, true, 2, false, true);
	}
	@Test
	public void test4475() {
		o.launch(1, false, false, 4, false, true, 2, false, false);
	}
	@Test
	public void test4476() {
		o.launch(1, false, false, 4, false, true, 3, true, true);
	}
	@Test
	public void test4477() {
		o.launch(1, false, false, 4, false, true, 3, true, false);
	}
	@Test
	public void test4478() {
		o.launch(1, false, false, 4, false, true, 3, false, true);
	}
	@Test
	public void test4479() {
		o.launch(1, false, false, 4, false, true, 3, false, false);
	}
	@Test
	public void test4480() {
		o.launch(1, false, false, 4, false, true, 4, true, true);
	}
	@Test
	public void test4481() {
		o.launch(1, false, false, 4, false, true, 4, true, false);
	}
	@Test
	public void test4482() {
		o.launch(1, false, false, 4, false, true, 4, false, true);
	}
	@Test
	public void test4483() {
		o.launch(1, false, false, 4, false, true, 4, false, false);
	}
	@Test
	public void test4484() {
		o.launch(1, false, false, 4, false, true, 5, true, true);
	}
	@Test
	public void test4485() {
		o.launch(1, false, false, 4, false, true, 5, true, false);
	}
	@Test
	public void test4486() {
		o.launch(1, false, false, 4, false, true, -1, false, true);
	}
	@Test
	public void test4487() {
		o.launch(1, false, false, 4, false, true, -1, false, false);
	}
	@Test
	public void test4488() {
		o.launch(1, false, false, 4, false, false, 0, true, true);
	}
	@Test
	public void test4489() {
		o.launch(1, false, false, 4, false, false, 0, true, false);
	}
	@Test
	public void test4490() {
		o.launch(1, false, false, 4, false, false, 0, false, true);
	}
	@Test
	public void test4491() {
		o.launch(1, false, false, 4, false, false, 0, false, false);
	}
	@Test
	public void test4492() {
		o.launch(1, false, false, 4, false, false, 1, true, true);
	}
	@Test
	public void test4493() {
		o.launch(1, false, false, 4, false, false, 1, true, false);
	}
	@Test
	public void test4494() {
		o.launch(1, false, false, 4, false, false, 1, false, true);
	}
	@Test
	public void test4495() {
		o.launch(1, false, false, 4, false, false, 1, false, false);
	}
	@Test
	public void test4496() {
		o.launch(1, false, false, 4, false, false, 2, true, true);
	}
	@Test
	public void test4497() {
		o.launch(1, false, false, 4, false, false, 2, true, false);
	}
	@Test
	public void test4498() {
		o.launch(1, false, false, 4, false, false, 2, false, true);
	}
	@Test
	public void test4499() {
		o.launch(1, false, false, 4, false, false, 2, false, false);
	}
	@Test
	public void test4500() {
		o.launch(1, false, false, 4, false, false, 3, true, true);
	}
	@Test
	public void test4501() {
		o.launch(1, false, false, 4, false, false, 3, true, false);
	}
	@Test
	public void test4502() {
		o.launch(1, false, false, 4, false, false, 3, false, true);
	}
	@Test
	public void test4503() {
		o.launch(1, false, false, 4, false, false, 3, false, false);
	}
	@Test
	public void test4504() {
		o.launch(1, false, false, 4, false, false, 4, true, true);
	}
	@Test
	public void test4505() {
		o.launch(1, false, false, 4, false, false, 4, true, false);
	}
	@Test
	public void test4506() {
		o.launch(1, false, false, 4, false, false, 4, false, true);
	}
	@Test
	public void test4507() {
		o.launch(1, false, false, 4, false, false, 4, false, false);
	}
	@Test
	public void test4508() {
		o.launch(1, false, false, 4, false, false, -1, true, true);
	}
	@Test
	public void test4509() {
		o.launch(1, false, false, 4, false, false, 5, true, false);
	}
	@Test
	public void test4510() {
		o.launch(1, false, false, 4, false, false, 5, false, true);
	}
	@Test
	public void test4511() {
		o.launch(1, false, false, 4, false, false, 100, false, false);
	}
	@Test
	public void test4512() {
		o.launch(1, false, false, 10, true, true, 0, true, true);
	}
	@Test
	public void test4513() {
		o.launch(1, false, false, 10, true, true, 0, true, false);
	}
	@Test
	public void test4514() {
		o.launch(1, false, false, -1, true, true, 0, false, true);
	}
	@Test
	public void test4515() {
		o.launch(1, false, false, -1, true, true, 0, false, false);
	}
	@Test
	public void test4516() {
		o.launch(1, false, false, 100, true, true, 1, true, true);
	}
	@Test
	public void test4517() {
		o.launch(1, false, false, 10, true, true, 1, true, false);
	}
	@Test
	public void test4518() {
		o.launch(1, false, false, 10, true, true, 1, false, true);
	}
	@Test
	public void test4519() {
		o.launch(1, false, false, 10, true, true, 1, false, false);
	}
	@Test
	public void test4520() {
		o.launch(1, false, false, 5, true, true, 2, true, true);
	}
	@Test
	public void test4521() {
		o.launch(1, false, false, 5, true, true, 2, true, false);
	}
	@Test
	public void test4522() {
		o.launch(1, false, false, 5, true, true, 2, false, true);
	}
	@Test
	public void test4523() {
		o.launch(1, false, false, 5, true, true, 2, false, false);
	}
	@Test
	public void test4524() {
		o.launch(1, false, false, 5, true, true, 3, true, true);
	}
	@Test
	public void test4525() {
		o.launch(1, false, false, 5, true, true, 3, true, false);
	}
	@Test
	public void test4526() {
		o.launch(1, false, false, 5, true, true, 3, false, true);
	}
	@Test
	public void test4527() {
		o.launch(1, false, false, 5, true, true, 3, false, false);
	}
	@Test
	public void test4528() {
		o.launch(1, false, false, 5, true, true, 4, true, true);
	}
	@Test
	public void test4529() {
		o.launch(1, false, false, 5, true, true, 4, true, false);
	}
	@Test
	public void test4530() {
		o.launch(1, false, false, 5, true, true, 4, false, true);
	}
	@Test
	public void test4531() {
		o.launch(1, false, false, 5, true, true, 4, false, false);
	}
	@Test
	public void test4532() {
		o.launch(1, false, false, 10, true, true, 10, true, true);
	}
	@Test
	public void test4533() {
		o.launch(1, false, false, -1, true, true, 100, true, false);
	}
	@Test
	public void test4534() {
		o.launch(1, false, false, 10, true, true, 10, false, true);
	}
	@Test
	public void test4535() {
		o.launch(1, false, false, -1, true, true, -1, false, false);
	}
	@Test
	public void test4536() {
		o.launch(1, false, false, 5, true, false, 0, true, true);
	}
	@Test
	public void test4537() {
		o.launch(1, false, false, 100, true, false, 0, true, false);
	}
	@Test
	public void test4538() {
		o.launch(1, false, false, 100, true, false, 0, false, true);
	}
	@Test
	public void test4539() {
		o.launch(1, false, false, 10, true, false, 0, false, false);
	}
	@Test
	public void test4540() {
		o.launch(1, false, false, 10, true, false, 1, true, true);
	}
	@Test
	public void test4541() {
		o.launch(1, false, false, -1, true, false, 1, true, false);
	}
	@Test
	public void test4542() {
		o.launch(1, false, false, -1, true, false, 1, false, true);
	}
	@Test
	public void test4543() {
		o.launch(1, false, false, 100, true, false, 1, false, false);
	}
	@Test
	public void test4544() {
		o.launch(1, false, false, 5, true, false, 2, true, true);
	}
	@Test
	public void test4545() {
		o.launch(1, false, false, 5, true, false, 2, true, false);
	}
	@Test
	public void test4546() {
		o.launch(1, false, false, 5, true, false, 2, false, true);
	}
	@Test
	public void test4547() {
		o.launch(1, false, false, 5, true, false, 2, false, false);
	}
	@Test
	public void test4548() {
		o.launch(1, false, false, 5, true, false, 3, true, true);
	}
	@Test
	public void test4549() {
		o.launch(1, false, false, 5, true, false, 3, true, false);
	}
	@Test
	public void test4550() {
		o.launch(1, false, false, 5, true, false, 3, false, true);
	}
	@Test
	public void test4551() {
		o.launch(1, false, false, 5, true, false, 3, false, false);
	}
	@Test
	public void test4552() {
		o.launch(1, false, false, 5, true, false, 4, true, true);
	}
	@Test
	public void test4553() {
		o.launch(1, false, false, 5, true, false, 4, true, false);
	}
	@Test
	public void test4554() {
		o.launch(1, false, false, 5, true, false, 4, false, true);
	}
	@Test
	public void test4555() {
		o.launch(1, false, false, 10, true, false, 4, false, false);
	}
	@Test
	public void test4556() {
		o.launch(1, false, false, -1, true, false, 100, true, true);
	}
	@Test
	public void test4557() {
		o.launch(1, false, false, -1, true, false, 10, true, false);
	}
	@Test
	public void test4558() {
		o.launch(1, false, false, -1, true, false, 10, false, true);
	}
	@Test
	public void test4559() {
		o.launch(1, false, false, 100, true, false, -1, false, false);
	}
	@Test
	public void test4560() {
		o.launch(1, false, false, -1, false, true, 0, true, true);
	}
	@Test
	public void test4561() {
		o.launch(1, false, false, -1, false, true, 0, true, false);
	}
	@Test
	public void test4562() {
		o.launch(1, false, false, 10, false, true, 0, false, true);
	}
	@Test
	public void test4563() {
		o.launch(1, false, false, -1, false, true, 0, false, false);
	}
	@Test
	public void test4564() {
		o.launch(1, false, false, 10, false, true, 1, true, true);
	}
	@Test
	public void test4565() {
		o.launch(1, false, false, 10, false, true, 1, true, false);
	}
	@Test
	public void test4566() {
		o.launch(1, false, false, -1, false, true, 1, false, true);
	}
	@Test
	public void test4567() {
		o.launch(1, false, false, -1, false, true, 1, false, false);
	}
	@Test
	public void test4568() {
		o.launch(1, false, false, 5, false, true, 2, true, true);
	}
	@Test
	public void test4569() {
		o.launch(1, false, false, 5, false, true, 2, true, false);
	}
	@Test
	public void test4570() {
		o.launch(1, false, false, 5, false, true, 2, false, true);
	}
	@Test
	public void test4571() {
		o.launch(1, false, false, 5, false, true, 2, false, false);
	}
	@Test
	public void test4572() {
		o.launch(1, false, false, 5, false, true, 3, true, true);
	}
	@Test
	public void test4573() {
		o.launch(1, false, false, 5, false, true, 3, true, false);
	}
	@Test
	public void test4574() {
		o.launch(1, false, false, 5, false, true, 3, false, true);
	}
	@Test
	public void test4575() {
		o.launch(1, false, false, 5, false, true, 3, false, false);
	}
	@Test
	public void test4576() {
		o.launch(1, false, false, 5, false, true, 4, true, true);
	}
	@Test
	public void test4577() {
		o.launch(1, false, false, 10, false, true, 4, true, false);
	}
	@Test
	public void test4578() {
		o.launch(1, false, false, 5, false, true, 4, false, true);
	}
	@Test
	public void test4579() {
		o.launch(1, false, false, -1, false, true, 4, false, false);
	}
	@Test
	public void test4580() {
		o.launch(1, false, false, 100, false, true, 10, true, true);
	}
	@Test
	public void test4581() {
		o.launch(1, false, false, 10, false, true, -1, true, false);
	}
	@Test
	public void test4582() {
		o.launch(1, false, false, 10, false, true, -1, false, true);
	}
	@Test
	public void test4583() {
		o.launch(1, false, false, 100, false, true, -1, false, false);
	}
	@Test
	public void test4584() {
		o.launch(1, false, false, 10, false, false, 0, true, true);
	}
	@Test
	public void test4585() {
		o.launch(1, false, false, 100, false, false, 0, true, false);
	}
	@Test
	public void test4586() {
		o.launch(1, false, false, 10, false, false, 0, false, true);
	}
	@Test
	public void test4587() {
		o.launch(1, false, false, 10, false, false, 0, false, false);
	}
	@Test
	public void test4588() {
		o.launch(1, false, false, 10, false, false, 1, true, true);
	}
	@Test
	public void test4589() {
		o.launch(1, false, false, 5, false, false, 1, true, false);
	}
	@Test
	public void test4590() {
		o.launch(1, false, false, 100, false, false, 1, false, true);
	}
	@Test
	public void test4591() {
		o.launch(1, false, false, 10, false, false, 1, false, false);
	}
	@Test
	public void test4592() {
		o.launch(1, false, false, 5, false, false, 2, true, true);
	}
	@Test
	public void test4593() {
		o.launch(1, false, false, 5, false, false, 2, true, false);
	}
	@Test
	public void test4594() {
		o.launch(1, false, false, 5, false, false, 2, false, true);
	}
	@Test
	public void test4595() {
		o.launch(1, false, false, 5, false, false, 2, false, false);
	}
	@Test
	public void test4596() {
		o.launch(1, false, false, 5, false, false, 3, true, true);
	}
	@Test
	public void test4597() {
		o.launch(1, false, false, 5, false, false, 3, true, false);
	}
	@Test
	public void test4598() {
		o.launch(1, false, false, 5, false, false, 3, false, true);
	}
	@Test
	public void test4599() {
		o.launch(1, false, false, 5, false, false, 3, false, false);
	}
	@Test
	public void test4600() {
		o.launch(1, false, false, 5, false, false, 4, true, true);
	}
	@Test
	public void test4601() {
		o.launch(1, false, false, -1, false, false, 4, true, false);
	}
	@Test
	public void test4602() {
		o.launch(1, false, false, 5, false, false, 4, false, true);
	}
	@Test
	public void test4603() {
		o.launch(1, false, false, 5, false, false, 4, false, false);
	}
	@Test
	public void test4604() {
		o.launch(1, false, false, 10, false, false, 100, true, true);
	}
	@Test
	public void test4605() {
		o.launch(1, false, false, 100, false, false, 100, true, false);
	}
	@Test
	public void test4606() {
		o.launch(1, false, false, 100, false, false, 100, false, true);
	}
	@Test
	public void test4607() {
		o.launch(1, false, false, 10, false, false, -1, false, false);
	}
	@Test
	public void test4608() {
		o.launch(2, true, true, 0, true, true, 0, true, true);
	}
	@Test
	public void test4609() {
		o.launch(2, true, true, 0, true, true, 0, true, false);
	}
	@Test
	public void test4610() {
		o.launch(2, true, true, 0, true, true, 0, false, true);
	}
	@Test
	public void test4611() {
		o.launch(2, true, true, 0, true, true, 0, false, false);
	}
	@Test
	public void test4612() {
		o.launch(2, true, true, 0, true, true, 1, true, true);
	}
	@Test
	public void test4613() {
		o.launch(2, true, true, 0, true, true, 1, true, false);
	}
	@Test
	public void test4614() {
		o.launch(2, true, true, 0, true, true, 1, false, true);
	}
	@Test
	public void test4615() {
		o.launch(2, true, true, 0, true, true, 1, false, false);
	}
	@Test
	public void test4616() {
		o.launch(2, true, true, 0, true, true, 2, true, true);
	}
	@Test
	public void test4617() {
		o.launch(2, true, true, 0, true, true, 2, true, false);
	}
	@Test
	public void test4618() {
		o.launch(2, true, true, 0, true, true, 2, false, true);
	}
	@Test
	public void test4619() {
		o.launch(2, true, true, 0, true, true, 2, false, false);
	}
	@Test
	public void test4620() {
		o.launch(2, true, true, 0, true, true, 3, true, true);
	}
	@Test
	public void test4621() {
		o.launch(2, true, true, 0, true, true, 3, true, false);
	}
	@Test
	public void test4622() {
		o.launch(2, true, true, 0, true, true, 3, false, true);
	}
	@Test
	public void test4623() {
		o.launch(2, true, true, 0, true, true, 3, false, false);
	}
	@Test
	public void test4624() {
		o.launch(2, true, true, 0, true, true, 4, true, true);
	}
	@Test
	public void test4625() {
		o.launch(2, true, true, 0, true, true, 4, true, false);
	}
	@Test
	public void test4626() {
		o.launch(2, true, true, 0, true, true, 4, false, true);
	}
	@Test
	public void test4627() {
		o.launch(2, true, true, 0, true, true, 4, false, false);
	}
	@Test
	public void test4628() {
		o.launch(2, true, true, 0, true, true, 5, true, true);
	}
	@Test
	public void test4629() {
		o.launch(2, true, true, 0, true, true, 5, true, false);
	}
	@Test
	public void test4630() {
		o.launch(2, true, true, 0, true, true, 5, false, true);
	}
	@Test
	public void test4631() {
		o.launch(2, true, true, 0, true, true, 5, false, false);
	}
	@Test
	public void test4632() {
		o.launch(2, true, true, 0, true, false, 0, true, true);
	}
	@Test
	public void test4633() {
		o.launch(2, true, true, 0, true, false, 0, true, false);
	}
	@Test
	public void test4634() {
		o.launch(2, true, true, 0, true, false, 0, false, true);
	}
	@Test
	public void test4635() {
		o.launch(2, true, true, 0, true, false, 0, false, false);
	}
	@Test
	public void test4636() {
		o.launch(2, true, true, 0, true, false, 1, true, true);
	}
	@Test
	public void test4637() {
		o.launch(2, true, true, 0, true, false, 1, true, false);
	}
	@Test
	public void test4638() {
		o.launch(2, true, true, 0, true, false, 1, false, true);
	}
	@Test
	public void test4639() {
		o.launch(2, true, true, 0, true, false, 1, false, false);
	}
	@Test
	public void test4640() {
		o.launch(2, true, true, 0, true, false, 2, true, true);
	}
	@Test
	public void test4641() {
		o.launch(2, true, true, 0, true, false, 2, true, false);
	}
	@Test
	public void test4642() {
		o.launch(2, true, true, 0, true, false, 2, false, true);
	}
	@Test
	public void test4643() {
		o.launch(2, true, true, 0, true, false, 2, false, false);
	}
	@Test
	public void test4644() {
		o.launch(2, true, true, 0, true, false, 3, true, true);
	}
	@Test
	public void test4645() {
		o.launch(2, true, true, 0, true, false, 3, true, false);
	}
	@Test
	public void test4646() {
		o.launch(2, true, true, 0, true, false, 3, false, true);
	}
	@Test
	public void test4647() {
		o.launch(2, true, true, 0, true, false, 3, false, false);
	}
	@Test
	public void test4648() {
		o.launch(2, true, true, 0, true, false, 4, true, true);
	}
	@Test
	public void test4649() {
		o.launch(2, true, true, 0, true, false, 4, true, false);
	}
	@Test
	public void test4650() {
		o.launch(2, true, true, 0, true, false, 4, false, true);
	}
	@Test
	public void test4651() {
		o.launch(2, true, true, 0, true, false, 4, false, false);
	}
	@Test
	public void test4652() {
		o.launch(2, true, true, 0, true, false, 5, true, true);
	}
	@Test
	public void test4653() {
		o.launch(2, true, true, 0, true, false, 5, true, false);
	}
	@Test
	public void test4654() {
		o.launch(2, true, true, 0, true, false, 5, false, true);
	}
	@Test
	public void test4655() {
		o.launch(2, true, true, 0, true, false, 5, false, false);
	}
	@Test
	public void test4656() {
		o.launch(2, true, true, 0, false, true, 0, true, true);
	}
	@Test
	public void test4657() {
		o.launch(2, true, true, 0, false, true, 0, true, false);
	}
	@Test
	public void test4658() {
		o.launch(2, true, true, 0, false, true, 0, false, true);
	}
	@Test
	public void test4659() {
		o.launch(2, true, true, 0, false, true, 0, false, false);
	}
	@Test
	public void test4660() {
		o.launch(2, true, true, 0, false, true, 1, true, true);
	}
	@Test
	public void test4661() {
		o.launch(2, true, true, 0, false, true, 1, true, false);
	}
	@Test
	public void test4662() {
		o.launch(2, true, true, 0, false, true, 1, false, true);
	}
	@Test
	public void test4663() {
		o.launch(2, true, true, 0, false, true, 1, false, false);
	}
	@Test
	public void test4664() {
		o.launch(2, true, true, 0, false, true, 2, true, true);
	}
	@Test
	public void test4665() {
		o.launch(2, true, true, 0, false, true, 2, true, false);
	}
	@Test
	public void test4666() {
		o.launch(2, true, true, 0, false, true, 2, false, true);
	}
	@Test
	public void test4667() {
		o.launch(2, true, true, 0, false, true, 2, false, false);
	}
	@Test
	public void test4668() {
		o.launch(2, true, true, 0, false, true, 3, true, true);
	}
	@Test
	public void test4669() {
		o.launch(2, true, true, 0, false, true, 3, true, false);
	}
	@Test
	public void test4670() {
		o.launch(2, true, true, 0, false, true, 3, false, true);
	}
	@Test
	public void test4671() {
		o.launch(2, true, true, 0, false, true, 3, false, false);
	}
	@Test
	public void test4672() {
		o.launch(2, true, true, 0, false, true, 4, true, true);
	}
	@Test
	public void test4673() {
		o.launch(2, true, true, 0, false, true, 4, true, false);
	}
	@Test
	public void test4674() {
		o.launch(2, true, true, 0, false, true, 4, false, true);
	}
	@Test
	public void test4675() {
		o.launch(2, true, true, 0, false, true, 4, false, false);
	}
	@Test
	public void test4676() {
		o.launch(2, true, true, 0, false, true, 5, true, true);
	}
	@Test
	public void test4677() {
		o.launch(2, true, true, 0, false, true, 5, true, false);
	}
	@Test
	public void test4678() {
		o.launch(2, true, true, 0, false, true, 5, false, true);
	}
	@Test
	public void test4679() {
		o.launch(2, true, true, 0, false, true, 5, false, false);
	}
	@Test
	public void test4680() {
		o.launch(2, true, true, 0, false, false, 0, true, true);
	}
	@Test
	public void test4681() {
		o.launch(2, true, true, 0, false, false, 0, true, false);
	}
	@Test
	public void test4682() {
		o.launch(2, true, true, 0, false, false, 0, false, true);
	}
	@Test
	public void test4683() {
		o.launch(2, true, true, 0, false, false, 0, false, false);
	}
	@Test
	public void test4684() {
		o.launch(2, true, true, 0, false, false, 1, true, true);
	}
	@Test
	public void test4685() {
		o.launch(2, true, true, 0, false, false, 1, true, false);
	}
	@Test
	public void test4686() {
		o.launch(2, true, true, 0, false, false, 1, false, true);
	}
	@Test
	public void test4687() {
		o.launch(2, true, true, 0, false, false, 1, false, false);
	}
	@Test
	public void test4688() {
		o.launch(2, true, true, 0, false, false, 2, true, true);
	}
	@Test
	public void test4689() {
		o.launch(2, true, true, 0, false, false, 2, true, false);
	}
	@Test
	public void test4690() {
		o.launch(2, true, true, 0, false, false, 2, false, true);
	}
	@Test
	public void test4691() {
		o.launch(2, true, true, 0, false, false, 2, false, false);
	}
	@Test
	public void test4692() {
		o.launch(2, true, true, 0, false, false, 3, true, true);
	}
	@Test
	public void test4693() {
		o.launch(2, true, true, 0, false, false, 3, true, false);
	}
	@Test
	public void test4694() {
		o.launch(2, true, true, 0, false, false, 3, false, true);
	}
	@Test
	public void test4695() {
		o.launch(2, true, true, 0, false, false, 3, false, false);
	}
	@Test
	public void test4696() {
		o.launch(2, true, true, 0, false, false, 4, true, true);
	}
	@Test
	public void test4697() {
		o.launch(2, true, true, 0, false, false, 4, true, false);
	}
	@Test
	public void test4698() {
		o.launch(2, true, true, 0, false, false, 4, false, true);
	}
	@Test
	public void test4699() {
		o.launch(2, true, true, 0, false, false, 4, false, false);
	}
	@Test
	public void test4700() {
		o.launch(2, true, true, 0, false, false, 5, true, true);
	}
	@Test
	public void test4701() {
		o.launch(2, true, true, 0, false, false, 5, true, false);
	}
	@Test
	public void test4702() {
		o.launch(2, true, true, 0, false, false, 5, false, true);
	}
	@Test
	public void test4703() {
		o.launch(2, true, true, 0, false, false, 5, false, false);
	}
	@Test
	public void test4704() {
		o.launch(2, true, true, 1, true, true, 0, true, true);
	}
	@Test
	public void test4705() {
		o.launch(2, true, true, 1, true, true, 0, true, false);
	}
	@Test
	public void test4706() {
		o.launch(2, true, true, 1, true, true, 0, false, true);
	}
	@Test
	public void test4707() {
		o.launch(2, true, true, 1, true, true, 0, false, false);
	}
	@Test
	public void test4708() {
		o.launch(2, true, true, 1, true, true, 1, true, true);
	}
	@Test
	public void test4709() {
		o.launch(2, true, true, 1, true, true, 1, true, false);
	}
	@Test
	public void test4710() {
		o.launch(2, true, true, 1, true, true, 1, false, true);
	}
	@Test
	public void test4711() {
		o.launch(2, true, true, 1, true, true, 1, false, false);
	}
	@Test
	public void test4712() {
		o.launch(2, true, true, 1, true, true, 2, true, true);
	}
	@Test
	public void test4713() {
		o.launch(2, true, true, 1, true, true, 2, true, false);
	}
	@Test
	public void test4714() {
		o.launch(2, true, true, 1, true, true, 2, false, true);
	}
	@Test
	public void test4715() {
		o.launch(2, true, true, 1, true, true, 2, false, false);
	}
	@Test
	public void test4716() {
		o.launch(2, true, true, 1, true, true, 3, true, true);
	}
	@Test
	public void test4717() {
		o.launch(2, true, true, 1, true, true, 3, true, false);
	}
	@Test
	public void test4718() {
		o.launch(2, true, true, 1, true, true, 3, false, true);
	}
	@Test
	public void test4719() {
		o.launch(2, true, true, 1, true, true, 3, false, false);
	}
	@Test
	public void test4720() {
		o.launch(2, true, true, 1, true, true, 4, true, true);
	}
	@Test
	public void test4721() {
		o.launch(2, true, true, 1, true, true, 4, true, false);
	}
	@Test
	public void test4722() {
		o.launch(2, true, true, 1, true, true, 4, false, true);
	}
	@Test
	public void test4723() {
		o.launch(2, true, true, 1, true, true, 4, false, false);
	}
	@Test
	public void test4724() {
		o.launch(2, true, true, 1, true, true, 5, true, true);
	}
	@Test
	public void test4725() {
		o.launch(2, true, true, 1, true, true, 5, true, false);
	}
	@Test
	public void test4726() {
		o.launch(2, true, true, 1, true, true, 5, false, true);
	}
	@Test
	public void test4727() {
		o.launch(2, true, true, 1, true, true, 5, false, false);
	}
	@Test
	public void test4728() {
		o.launch(2, true, true, 1, true, false, 0, true, true);
	}
	@Test
	public void test4729() {
		o.launch(2, true, true, 1, true, false, 0, true, false);
	}
	@Test
	public void test4730() {
		o.launch(2, true, true, 1, true, false, 0, false, true);
	}
	@Test
	public void test4731() {
		o.launch(2, true, true, 1, true, false, 0, false, false);
	}
	@Test
	public void test4732() {
		o.launch(2, true, true, 1, true, false, 1, true, true);
	}
	@Test
	public void test4733() {
		o.launch(2, true, true, 1, true, false, 1, true, false);
	}
	@Test
	public void test4734() {
		o.launch(2, true, true, 1, true, false, 1, false, true);
	}
	@Test
	public void test4735() {
		o.launch(2, true, true, 1, true, false, 1, false, false);
	}
	@Test
	public void test4736() {
		o.launch(2, true, true, 1, true, false, 2, true, true);
	}
	@Test
	public void test4737() {
		o.launch(2, true, true, 1, true, false, 2, true, false);
	}
	@Test
	public void test4738() {
		o.launch(2, true, true, 1, true, false, 2, false, true);
	}
	@Test
	public void test4739() {
		o.launch(2, true, true, 1, true, false, 2, false, false);
	}
	@Test
	public void test4740() {
		o.launch(2, true, true, 1, true, false, 3, true, true);
	}
	@Test
	public void test4741() {
		o.launch(2, true, true, 1, true, false, 3, true, false);
	}
	@Test
	public void test4742() {
		o.launch(2, true, true, 1, true, false, 3, false, true);
	}
	@Test
	public void test4743() {
		o.launch(2, true, true, 1, true, false, 3, false, false);
	}
	@Test
	public void test4744() {
		o.launch(2, true, true, 1, true, false, 4, true, true);
	}
	@Test
	public void test4745() {
		o.launch(2, true, true, 1, true, false, 4, true, false);
	}
	@Test
	public void test4746() {
		o.launch(2, true, true, 1, true, false, 4, false, true);
	}
	@Test
	public void test4747() {
		o.launch(2, true, true, 1, true, false, 4, false, false);
	}
	@Test
	public void test4748() {
		o.launch(2, true, true, 1, true, false, 5, true, true);
	}
	@Test
	public void test4749() {
		o.launch(2, true, true, 1, true, false, 5, true, false);
	}
	@Test
	public void test4750() {
		o.launch(2, true, true, 1, true, false, 5, false, true);
	}
	@Test
	public void test4751() {
		o.launch(2, true, true, 1, true, false, 5, false, false);
	}
	@Test
	public void test4752() {
		o.launch(2, true, true, 1, false, true, 0, true, true);
	}
	@Test
	public void test4753() {
		o.launch(2, true, true, 1, false, true, 0, true, false);
	}
	@Test
	public void test4754() {
		o.launch(2, true, true, 1, false, true, 0, false, true);
	}
	@Test
	public void test4755() {
		o.launch(2, true, true, 1, false, true, 0, false, false);
	}
	@Test
	public void test4756() {
		o.launch(2, true, true, 1, false, true, 1, true, true);
	}
	@Test
	public void test4757() {
		o.launch(2, true, true, 1, false, true, 1, true, false);
	}
	@Test
	public void test4758() {
		o.launch(2, true, true, 1, false, true, 1, false, true);
	}
	@Test
	public void test4759() {
		o.launch(2, true, true, 1, false, true, 1, false, false);
	}
	@Test
	public void test4760() {
		o.launch(2, true, true, 1, false, true, 2, true, true);
	}
	@Test
	public void test4761() {
		o.launch(2, true, true, 1, false, true, 2, true, false);
	}
	@Test
	public void test4762() {
		o.launch(2, true, true, 1, false, true, 2, false, true);
	}
	@Test
	public void test4763() {
		o.launch(2, true, true, 1, false, true, 2, false, false);
	}
	@Test
	public void test4764() {
		o.launch(2, true, true, 1, false, true, 3, true, true);
	}
	@Test
	public void test4765() {
		o.launch(2, true, true, 1, false, true, 3, true, false);
	}
	@Test
	public void test4766() {
		o.launch(2, true, true, 1, false, true, 3, false, true);
	}
	@Test
	public void test4767() {
		o.launch(2, true, true, 1, false, true, 3, false, false);
	}
	@Test
	public void test4768() {
		o.launch(2, true, true, 1, false, true, 4, true, true);
	}
	@Test
	public void test4769() {
		o.launch(2, true, true, 1, false, true, 4, true, false);
	}
	@Test
	public void test4770() {
		o.launch(2, true, true, 1, false, true, 4, false, true);
	}
	@Test
	public void test4771() {
		o.launch(2, true, true, 1, false, true, 4, false, false);
	}
	@Test
	public void test4772() {
		o.launch(2, true, true, 1, false, true, 5, true, true);
	}
	@Test
	public void test4773() {
		o.launch(2, true, true, 1, false, true, 5, true, false);
	}
	@Test
	public void test4774() {
		o.launch(2, true, true, 1, false, true, 5, false, true);
	}
	@Test
	public void test4775() {
		o.launch(2, true, true, 1, false, true, 5, false, false);
	}
	@Test
	public void test4776() {
		o.launch(2, true, true, 1, false, false, 0, true, true);
	}
	@Test
	public void test4777() {
		o.launch(2, true, true, 1, false, false, 0, true, false);
	}
	@Test
	public void test4778() {
		o.launch(2, true, true, 1, false, false, 0, false, true);
	}
	@Test
	public void test4779() {
		o.launch(2, true, true, 1, false, false, 0, false, false);
	}
	@Test
	public void test4780() {
		o.launch(2, true, true, 1, false, false, 1, true, true);
	}
	@Test
	public void test4781() {
		o.launch(2, true, true, 1, false, false, 1, true, false);
	}
	@Test
	public void test4782() {
		o.launch(2, true, true, 1, false, false, 1, false, true);
	}
	@Test
	public void test4783() {
		o.launch(2, true, true, 1, false, false, 1, false, false);
	}
	@Test
	public void test4784() {
		o.launch(2, true, true, 1, false, false, 2, true, true);
	}
	@Test
	public void test4785() {
		o.launch(2, true, true, 1, false, false, 2, true, false);
	}
	@Test
	public void test4786() {
		o.launch(2, true, true, 1, false, false, 2, false, true);
	}
	@Test
	public void test4787() {
		o.launch(2, true, true, 1, false, false, 2, false, false);
	}
	@Test
	public void test4788() {
		o.launch(2, true, true, 1, false, false, 3, true, true);
	}
	@Test
	public void test4789() {
		o.launch(2, true, true, 1, false, false, 3, true, false);
	}
	@Test
	public void test4790() {
		o.launch(2, true, true, 1, false, false, 3, false, true);
	}
	@Test
	public void test4791() {
		o.launch(2, true, true, 1, false, false, 3, false, false);
	}
	@Test
	public void test4792() {
		o.launch(2, true, true, 1, false, false, 4, true, true);
	}
	@Test
	public void test4793() {
		o.launch(2, true, true, 1, false, false, 4, true, false);
	}
	@Test
	public void test4794() {
		o.launch(2, true, true, 1, false, false, 4, false, true);
	}
	@Test
	public void test4795() {
		o.launch(2, true, true, 1, false, false, 4, false, false);
	}
	@Test
	public void test4796() {
		o.launch(2, true, true, 1, false, false, 5, true, true);
	}
	@Test
	public void test4797() {
		o.launch(2, true, true, 1, false, false, 5, true, false);
	}
	@Test
	public void test4798() {
		o.launch(2, true, true, 1, false, false, 5, false, true);
	}
	@Test
	public void test4799() {
		o.launch(2, true, true, 1, false, false, 5, false, false);
	}
	@Test
	public void test4800() {
		o.launch(2, true, true, 2, true, true, 0, true, true);
	}
	@Test
	public void test4801() {
		o.launch(2, true, true, 2, true, true, 0, true, false);
	}
	@Test
	public void test4802() {
		o.launch(2, true, true, 2, true, true, 0, false, true);
	}
	@Test
	public void test4803() {
		o.launch(2, true, true, 2, true, true, 0, false, false);
	}
	@Test
	public void test4804() {
		o.launch(2, true, true, 2, true, true, 1, true, true);
	}
	@Test
	public void test4805() {
		o.launch(2, true, true, 2, true, true, 1, true, false);
	}
	@Test
	public void test4806() {
		o.launch(2, true, true, 2, true, true, 1, false, true);
	}
	@Test
	public void test4807() {
		o.launch(2, true, true, 2, true, true, 1, false, false);
	}
	@Test
	public void test4808() {
		o.launch(2, true, true, 2, true, true, 2, true, true);
	}
	@Test
	public void test4809() {
		o.launch(2, true, true, 2, true, true, 2, true, false);
	}
	@Test
	public void test4810() {
		o.launch(2, true, true, 2, true, true, 2, false, true);
	}
	@Test
	public void test4811() {
		o.launch(2, true, true, 2, true, true, 2, false, false);
	}
	@Test
	public void test4812() {
		o.launch(2, true, true, 2, true, true, 3, true, true);
	}
	@Test
	public void test4813() {
		o.launch(2, true, true, 2, true, true, 3, true, false);
	}
	@Test
	public void test4814() {
		o.launch(2, true, true, 2, true, true, 3, false, true);
	}
	@Test
	public void test4815() {
		o.launch(2, true, true, 2, true, true, 3, false, false);
	}
	@Test
	public void test4816() {
		o.launch(2, true, true, 2, true, true, 4, true, true);
	}
	@Test
	public void test4817() {
		o.launch(2, true, true, 2, true, true, 4, true, false);
	}
	@Test
	public void test4818() {
		o.launch(2, true, true, 2, true, true, 4, false, true);
	}
	@Test
	public void test4819() {
		o.launch(2, true, true, 2, true, true, 4, false, false);
	}
	@Test
	public void test4820() {
		o.launch(2, true, true, 2, true, true, 5, true, true);
	}
	@Test
	public void test4821() {
		o.launch(2, true, true, 2, true, true, 5, true, false);
	}
	@Test
	public void test4822() {
		o.launch(2, true, true, 2, true, true, 5, false, true);
	}
	@Test
	public void test4823() {
		o.launch(2, true, true, 2, true, true, 5, false, false);
	}
	@Test
	public void test4824() {
		o.launch(2, true, true, 2, true, false, 0, true, true);
	}
	@Test
	public void test4825() {
		o.launch(2, true, true, 2, true, false, 0, true, false);
	}
	@Test
	public void test4826() {
		o.launch(2, true, true, 2, true, false, 0, false, true);
	}
	@Test
	public void test4827() {
		o.launch(2, true, true, 2, true, false, 0, false, false);
	}
	@Test
	public void test4828() {
		o.launch(2, true, true, 2, true, false, 1, true, true);
	}
	@Test
	public void test4829() {
		o.launch(2, true, true, 2, true, false, 1, true, false);
	}
	@Test
	public void test4830() {
		o.launch(2, true, true, 2, true, false, 1, false, true);
	}
	@Test
	public void test4831() {
		o.launch(2, true, true, 2, true, false, 1, false, false);
	}
	@Test
	public void test4832() {
		o.launch(2, true, true, 2, true, false, 2, true, true);
	}
	@Test
	public void test4833() {
		o.launch(2, true, true, 2, true, false, 2, true, false);
	}
	@Test
	public void test4834() {
		o.launch(2, true, true, 2, true, false, 2, false, true);
	}
	@Test
	public void test4835() {
		o.launch(2, true, true, 2, true, false, 2, false, false);
	}
	@Test
	public void test4836() {
		o.launch(2, true, true, 2, true, false, 3, true, true);
	}
	@Test
	public void test4837() {
		o.launch(2, true, true, 2, true, false, 3, true, false);
	}
	@Test
	public void test4838() {
		o.launch(2, true, true, 2, true, false, 3, false, true);
	}
	@Test
	public void test4839() {
		o.launch(2, true, true, 2, true, false, 3, false, false);
	}
	@Test
	public void test4840() {
		o.launch(2, true, true, 2, true, false, 4, true, true);
	}
	@Test
	public void test4841() {
		o.launch(2, true, true, 2, true, false, 4, true, false);
	}
	@Test
	public void test4842() {
		o.launch(2, true, true, 2, true, false, 4, false, true);
	}
	@Test
	public void test4843() {
		o.launch(2, true, true, 2, true, false, 4, false, false);
	}
	@Test
	public void test4844() {
		o.launch(2, true, true, 2, true, false, 5, true, true);
	}
	@Test
	public void test4845() {
		o.launch(2, true, true, 2, true, false, 5, true, false);
	}
	@Test
	public void test4846() {
		o.launch(2, true, true, 2, true, false, 5, false, true);
	}
	@Test
	public void test4847() {
		o.launch(2, true, true, 2, true, false, 5, false, false);
	}
	@Test
	public void test4848() {
		o.launch(2, true, true, 2, false, true, 0, true, true);
	}
	@Test
	public void test4849() {
		o.launch(2, true, true, 2, false, true, 0, true, false);
	}
	@Test
	public void test4850() {
		o.launch(2, true, true, 2, false, true, 0, false, true);
	}
	@Test
	public void test4851() {
		o.launch(2, true, true, 2, false, true, 0, false, false);
	}
	@Test
	public void test4852() {
		o.launch(2, true, true, 2, false, true, 1, true, true);
	}
	@Test
	public void test4853() {
		o.launch(2, true, true, 2, false, true, 1, true, false);
	}
	@Test
	public void test4854() {
		o.launch(2, true, true, 2, false, true, 1, false, true);
	}
	@Test
	public void test4855() {
		o.launch(2, true, true, 2, false, true, 1, false, false);
	}
	@Test
	public void test4856() {
		o.launch(2, true, true, 2, false, true, 2, true, true);
	}
	@Test
	public void test4857() {
		o.launch(2, true, true, 2, false, true, 2, true, false);
	}
	@Test
	public void test4858() {
		o.launch(2, true, true, 2, false, true, 2, false, true);
	}
	@Test
	public void test4859() {
		o.launch(2, true, true, 2, false, true, 2, false, false);
	}
	@Test
	public void test4860() {
		o.launch(2, true, true, 2, false, true, 3, true, true);
	}
	@Test
	public void test4861() {
		o.launch(2, true, true, 2, false, true, 3, true, false);
	}
	@Test
	public void test4862() {
		o.launch(2, true, true, 2, false, true, 3, false, true);
	}
	@Test
	public void test4863() {
		o.launch(2, true, true, 2, false, true, 3, false, false);
	}
	@Test
	public void test4864() {
		o.launch(2, true, true, 2, false, true, 4, true, true);
	}
	@Test
	public void test4865() {
		o.launch(2, true, true, 2, false, true, 4, true, false);
	}
	@Test
	public void test4866() {
		o.launch(2, true, true, 2, false, true, 4, false, true);
	}
	@Test
	public void test4867() {
		o.launch(2, true, true, 2, false, true, 4, false, false);
	}
	@Test
	public void test4868() {
		o.launch(2, true, true, 2, false, true, 5, true, true);
	}
	@Test
	public void test4869() {
		o.launch(2, true, true, 2, false, true, 5, true, false);
	}
	@Test
	public void test4870() {
		o.launch(2, true, true, 2, false, true, 5, false, true);
	}
	@Test
	public void test4871() {
		o.launch(2, true, true, 2, false, true, 5, false, false);
	}
	@Test
	public void test4872() {
		o.launch(2, true, true, 2, false, false, 0, true, true);
	}
	@Test
	public void test4873() {
		o.launch(2, true, true, 2, false, false, 0, true, false);
	}
	@Test
	public void test4874() {
		o.launch(2, true, true, 2, false, false, 0, false, true);
	}
	@Test
	public void test4875() {
		o.launch(2, true, true, 2, false, false, 0, false, false);
	}
	@Test
	public void test4876() {
		o.launch(2, true, true, 2, false, false, 1, true, true);
	}
	@Test
	public void test4877() {
		o.launch(2, true, true, 2, false, false, 1, true, false);
	}
	@Test
	public void test4878() {
		o.launch(2, true, true, 2, false, false, 1, false, true);
	}
	@Test
	public void test4879() {
		o.launch(2, true, true, 2, false, false, 1, false, false);
	}
	@Test
	public void test4880() {
		o.launch(2, true, true, 2, false, false, 2, true, true);
	}
	@Test
	public void test4881() {
		o.launch(2, true, true, 2, false, false, 2, true, false);
	}
	@Test
	public void test4882() {
		o.launch(2, true, true, 2, false, false, 2, false, true);
	}
	@Test
	public void test4883() {
		o.launch(2, true, true, 2, false, false, 2, false, false);
	}
	@Test
	public void test4884() {
		o.launch(2, true, true, 2, false, false, 3, true, true);
	}
	@Test
	public void test4885() {
		o.launch(2, true, true, 2, false, false, 3, true, false);
	}
	@Test
	public void test4886() {
		o.launch(2, true, true, 2, false, false, 3, false, true);
	}
	@Test
	public void test4887() {
		o.launch(2, true, true, 2, false, false, 3, false, false);
	}
	@Test
	public void test4888() {
		o.launch(2, true, true, 2, false, false, 4, true, true);
	}
	@Test
	public void test4889() {
		o.launch(2, true, true, 2, false, false, 4, true, false);
	}
	@Test
	public void test4890() {
		o.launch(2, true, true, 2, false, false, 4, false, true);
	}
	@Test
	public void test4891() {
		o.launch(2, true, true, 2, false, false, 4, false, false);
	}
	@Test
	public void test4892() {
		o.launch(2, true, true, 2, false, false, 5, true, true);
	}
	@Test
	public void test4893() {
		o.launch(2, true, true, 2, false, false, 5, true, false);
	}
	@Test
	public void test4894() {
		o.launch(2, true, true, 2, false, false, 5, false, true);
	}
	@Test
	public void test4895() {
		o.launch(2, true, true, 2, false, false, 5, false, false);
	}
	@Test
	public void test4896() {
		o.launch(2, true, true, 3, true, true, 0, true, true);
	}
	@Test
	public void test4897() {
		o.launch(2, true, true, 3, true, true, 0, true, false);
	}
	@Test
	public void test4898() {
		o.launch(2, true, true, 3, true, true, 0, false, true);
	}
	@Test
	public void test4899() {
		o.launch(2, true, true, 3, true, true, 0, false, false);
	}
	@Test
	public void test4900() {
		o.launch(2, true, true, 3, true, true, 1, true, true);
	}
	@Test
	public void test4901() {
		o.launch(2, true, true, 3, true, true, 1, true, false);
	}
	@Test
	public void test4902() {
		o.launch(2, true, true, 3, true, true, 1, false, true);
	}
	@Test
	public void test4903() {
		o.launch(2, true, true, 3, true, true, 1, false, false);
	}
	@Test
	public void test4904() {
		o.launch(2, true, true, 3, true, true, 2, true, true);
	}
	@Test
	public void test4905() {
		o.launch(2, true, true, 3, true, true, 2, true, false);
	}
	@Test
	public void test4906() {
		o.launch(2, true, true, 3, true, true, 2, false, true);
	}
	@Test
	public void test4907() {
		o.launch(2, true, true, 3, true, true, 2, false, false);
	}
	@Test
	public void test4908() {
		o.launch(2, true, true, 3, true, true, 3, true, true);
	}
	@Test
	public void test4909() {
		o.launch(2, true, true, 3, true, true, 3, true, false);
	}
	@Test
	public void test4910() {
		o.launch(2, true, true, 3, true, true, 3, false, true);
	}
	@Test
	public void test4911() {
		o.launch(2, true, true, 3, true, true, 3, false, false);
	}
	@Test
	public void test4912() {
		o.launch(2, true, true, 3, true, true, 4, true, true);
	}
	@Test
	public void test4913() {
		o.launch(2, true, true, 3, true, true, 4, true, false);
	}
	@Test
	public void test4914() {
		o.launch(2, true, true, 3, true, true, 4, false, true);
	}
	@Test
	public void test4915() {
		o.launch(2, true, true, 3, true, true, 4, false, false);
	}
	@Test
	public void test4916() {
		o.launch(2, true, true, 3, true, true, 5, true, true);
	}
	@Test
	public void test4917() {
		o.launch(2, true, true, 3, true, true, 5, true, false);
	}
	@Test
	public void test4918() {
		o.launch(2, true, true, 3, true, true, 5, false, true);
	}
	@Test
	public void test4919() {
		o.launch(2, true, true, 3, true, true, 5, false, false);
	}
	@Test
	public void test4920() {
		o.launch(2, true, true, 3, true, false, 0, true, true);
	}
	@Test
	public void test4921() {
		o.launch(2, true, true, 3, true, false, 0, true, false);
	}
	@Test
	public void test4922() {
		o.launch(2, true, true, 3, true, false, 0, false, true);
	}
	@Test
	public void test4923() {
		o.launch(2, true, true, 3, true, false, 0, false, false);
	}
	@Test
	public void test4924() {
		o.launch(2, true, true, 3, true, false, 1, true, true);
	}
	@Test
	public void test4925() {
		o.launch(2, true, true, 3, true, false, 1, true, false);
	}
	@Test
	public void test4926() {
		o.launch(2, true, true, 3, true, false, 1, false, true);
	}
	@Test
	public void test4927() {
		o.launch(2, true, true, 3, true, false, 1, false, false);
	}
	@Test
	public void test4928() {
		o.launch(2, true, true, 3, true, false, 2, true, true);
	}
	@Test
	public void test4929() {
		o.launch(2, true, true, 3, true, false, 2, true, false);
	}
	@Test
	public void test4930() {
		o.launch(2, true, true, 3, true, false, 2, false, true);
	}
	@Test
	public void test4931() {
		o.launch(2, true, true, 3, true, false, 2, false, false);
	}
	@Test
	public void test4932() {
		o.launch(2, true, true, 3, true, false, 3, true, true);
	}
	@Test
	public void test4933() {
		o.launch(2, true, true, 3, true, false, 3, true, false);
	}
	@Test
	public void test4934() {
		o.launch(2, true, true, 3, true, false, 3, false, true);
	}
	@Test
	public void test4935() {
		o.launch(2, true, true, 3, true, false, 3, false, false);
	}
	@Test
	public void test4936() {
		o.launch(2, true, true, 3, true, false, 4, true, true);
	}
	@Test
	public void test4937() {
		o.launch(2, true, true, 3, true, false, 4, true, false);
	}
	@Test
	public void test4938() {
		o.launch(2, true, true, 3, true, false, 4, false, true);
	}
	@Test
	public void test4939() {
		o.launch(2, true, true, 3, true, false, 4, false, false);
	}
	@Test
	public void test4940() {
		o.launch(2, true, true, 3, true, false, 5, true, true);
	}
	@Test
	public void test4941() {
		o.launch(2, true, true, 3, true, false, 5, true, false);
	}
	@Test
	public void test4942() {
		o.launch(2, true, true, 3, true, false, 5, false, true);
	}
	@Test
	public void test4943() {
		o.launch(2, true, true, 3, true, false, 5, false, false);
	}
	@Test
	public void test4944() {
		o.launch(2, true, true, 3, false, true, 0, true, true);
	}
	@Test
	public void test4945() {
		o.launch(2, true, true, 3, false, true, 0, true, false);
	}
	@Test
	public void test4946() {
		o.launch(2, true, true, 3, false, true, 0, false, true);
	}
	@Test
	public void test4947() {
		o.launch(2, true, true, 3, false, true, 0, false, false);
	}
	@Test
	public void test4948() {
		o.launch(2, true, true, 3, false, true, 1, true, true);
	}
	@Test
	public void test4949() {
		o.launch(2, true, true, 3, false, true, 1, true, false);
	}
	@Test
	public void test4950() {
		o.launch(2, true, true, 3, false, true, 1, false, true);
	}
	@Test
	public void test4951() {
		o.launch(2, true, true, 3, false, true, 1, false, false);
	}
	@Test
	public void test4952() {
		o.launch(2, true, true, 3, false, true, 2, true, true);
	}
	@Test
	public void test4953() {
		o.launch(2, true, true, 3, false, true, 2, true, false);
	}
	@Test
	public void test4954() {
		o.launch(2, true, true, 3, false, true, 2, false, true);
	}
	@Test
	public void test4955() {
		o.launch(2, true, true, 3, false, true, 2, false, false);
	}
	@Test
	public void test4956() {
		o.launch(2, true, true, 3, false, true, 3, true, true);
	}
	@Test
	public void test4957() {
		o.launch(2, true, true, 3, false, true, 3, true, false);
	}
	@Test
	public void test4958() {
		o.launch(2, true, true, 3, false, true, 3, false, true);
	}
	@Test
	public void test4959() {
		o.launch(2, true, true, 3, false, true, 3, false, false);
	}
	@Test
	public void test4960() {
		o.launch(2, true, true, 3, false, true, 4, true, true);
	}
	@Test
	public void test4961() {
		o.launch(2, true, true, 3, false, true, 4, true, false);
	}
	@Test
	public void test4962() {
		o.launch(2, true, true, 3, false, true, 4, false, true);
	}
	@Test
	public void test4963() {
		o.launch(2, true, true, 3, false, true, 4, false, false);
	}
	@Test
	public void test4964() {
		o.launch(2, true, true, 3, false, true, 5, true, true);
	}
	@Test
	public void test4965() {
		o.launch(2, true, true, 3, false, true, 5, true, false);
	}
	@Test
	public void test4966() {
		o.launch(2, true, true, 3, false, true, 5, false, true);
	}
	@Test
	public void test4967() {
		o.launch(2, true, true, 3, false, true, 5, false, false);
	}
	@Test
	public void test4968() {
		o.launch(2, true, true, 3, false, false, 0, true, true);
	}
	@Test
	public void test4969() {
		o.launch(2, true, true, 3, false, false, 0, true, false);
	}
	@Test
	public void test4970() {
		o.launch(2, true, true, 3, false, false, 0, false, true);
	}
	@Test
	public void test4971() {
		o.launch(2, true, true, 3, false, false, 0, false, false);
	}
	@Test
	public void test4972() {
		o.launch(2, true, true, 3, false, false, 1, true, true);
	}
	@Test
	public void test4973() {
		o.launch(2, true, true, 3, false, false, 1, true, false);
	}
	@Test
	public void test4974() {
		o.launch(2, true, true, 3, false, false, 1, false, true);
	}
	@Test
	public void test4975() {
		o.launch(2, true, true, 3, false, false, 1, false, false);
	}
	@Test
	public void test4976() {
		o.launch(2, true, true, 3, false, false, 2, true, true);
	}
	@Test
	public void test4977() {
		o.launch(2, true, true, 3, false, false, 2, true, false);
	}
	@Test
	public void test4978() {
		o.launch(2, true, true, 3, false, false, 2, false, true);
	}
	@Test
	public void test4979() {
		o.launch(2, true, true, 3, false, false, 2, false, false);
	}
	@Test
	public void test4980() {
		o.launch(2, true, true, 3, false, false, 3, true, true);
	}
	@Test
	public void test4981() {
		o.launch(2, true, true, 3, false, false, 3, true, false);
	}
	@Test
	public void test4982() {
		o.launch(2, true, true, 3, false, false, 3, false, true);
	}
	@Test
	public void test4983() {
		o.launch(2, true, true, 3, false, false, 3, false, false);
	}
	@Test
	public void test4984() {
		o.launch(2, true, true, 3, false, false, 4, true, true);
	}
	@Test
	public void test4985() {
		o.launch(2, true, true, 3, false, false, 4, true, false);
	}
	@Test
	public void test4986() {
		o.launch(2, true, true, 3, false, false, 4, false, true);
	}
	@Test
	public void test4987() {
		o.launch(2, true, true, 3, false, false, 4, false, false);
	}
	@Test
	public void test4988() {
		o.launch(2, true, true, 3, false, false, 5, true, true);
	}
	@Test
	public void test4989() {
		o.launch(2, true, true, 3, false, false, 5, true, false);
	}
	@Test
	public void test4990() {
		o.launch(2, true, true, 3, false, false, 5, false, true);
	}
	@Test
	public void test4991() {
		o.launch(2, true, true, 3, false, false, 5, false, false);
	}
	@Test
	public void test4992() {
		o.launch(2, true, true, 4, true, true, 0, true, true);
	}
	@Test
	public void test4993() {
		o.launch(2, true, true, 4, true, true, 0, true, false);
	}
	@Test
	public void test4994() {
		o.launch(2, true, true, 4, true, true, 0, false, true);
	}
	@Test
	public void test4995() {
		o.launch(2, true, true, 4, true, true, 0, false, false);
	}
	@Test
	public void test4996() {
		o.launch(2, true, true, 4, true, true, 1, true, true);
	}
	@Test
	public void test4997() {
		o.launch(2, true, true, 4, true, true, 1, true, false);
	}
	@Test
	public void test4998() {
		o.launch(2, true, true, 4, true, true, 1, false, true);
	}
	@Test
	public void test4999() {
		o.launch(2, true, true, 4, true, true, 1, false, false);
	}
	@Test
	public void test5000() {
		o.launch(2, true, true, 4, true, true, 2, true, true);
	}

}