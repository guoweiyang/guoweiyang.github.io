package coverage;
import org.junit.Test;
public class WBS_origTest10000 {
	etg.WBS_orig o = new etg.WBS_orig();
	@Test
	public void test10000() {
		o.launch(4, true, false, 2, true, true, 4, true, true);
	}
	@Test
	public void test10001() {
		o.launch(4, true, false, 2, true, true, 4, true, false);
	}
	@Test
	public void test10002() {
		o.launch(4, true, false, 2, true, true, 4, false, true);
	}
	@Test
	public void test10003() {
		o.launch(4, true, false, 2, true, true, 4, false, false);
	}
	@Test
	public void test10004() {
		o.launch(4, true, false, 2, true, true, 5, true, true);
	}
	@Test
	public void test10005() {
		o.launch(4, true, false, 2, true, true, 5, true, false);
	}
	@Test
	public void test10006() {
		o.launch(4, true, false, 2, true, true, 5, false, true);
	}
	@Test
	public void test10007() {
		o.launch(4, true, false, 2, true, true, 5, false, false);
	}
	@Test
	public void test10008() {
		o.launch(4, true, false, 2, true, false, 0, true, true);
	}
	@Test
	public void test10009() {
		o.launch(4, true, false, 2, true, false, 0, true, false);
	}
	@Test
	public void test10010() {
		o.launch(4, true, false, 2, true, false, 0, false, true);
	}
	@Test
	public void test10011() {
		o.launch(4, true, false, 2, true, false, 0, false, false);
	}
	@Test
	public void test10012() {
		o.launch(4, true, false, 2, true, false, 1, true, true);
	}
	@Test
	public void test10013() {
		o.launch(4, true, false, 2, true, false, 1, true, false);
	}
	@Test
	public void test10014() {
		o.launch(4, true, false, 2, true, false, 1, false, true);
	}
	@Test
	public void test10015() {
		o.launch(4, true, false, 2, true, false, 1, false, false);
	}
	@Test
	public void test10016() {
		o.launch(4, true, false, 2, true, false, 2, true, true);
	}
	@Test
	public void test10017() {
		o.launch(4, true, false, 2, true, false, 2, true, false);
	}
	@Test
	public void test10018() {
		o.launch(4, true, false, 2, true, false, 2, false, true);
	}
	@Test
	public void test10019() {
		o.launch(4, true, false, 2, true, false, 2, false, false);
	}
	@Test
	public void test10020() {
		o.launch(4, true, false, 2, true, false, 3, true, true);
	}
	@Test
	public void test10021() {
		o.launch(4, true, false, 2, true, false, 3, true, false);
	}
	@Test
	public void test10022() {
		o.launch(4, true, false, 2, true, false, 3, false, true);
	}
	@Test
	public void test10023() {
		o.launch(4, true, false, 2, true, false, 3, false, false);
	}
	@Test
	public void test10024() {
		o.launch(4, true, false, 2, true, false, 4, true, true);
	}
	@Test
	public void test10025() {
		o.launch(4, true, false, 2, true, false, 4, true, false);
	}
	@Test
	public void test10026() {
		o.launch(4, true, false, 2, true, false, 4, false, true);
	}
	@Test
	public void test10027() {
		o.launch(4, true, false, 2, true, false, 4, false, false);
	}
	@Test
	public void test10028() {
		o.launch(4, true, false, 2, true, false, 5, true, true);
	}
	@Test
	public void test10029() {
		o.launch(4, true, false, 2, true, false, 5, true, false);
	}
	@Test
	public void test10030() {
		o.launch(4, true, false, 2, true, false, 5, false, true);
	}
	@Test
	public void test10031() {
		o.launch(4, true, false, 2, true, false, 5, false, false);
	}
	@Test
	public void test10032() {
		o.launch(4, true, false, 2, false, true, 0, true, true);
	}
	@Test
	public void test10033() {
		o.launch(4, true, false, 2, false, true, 0, true, false);
	}
	@Test
	public void test10034() {
		o.launch(4, true, false, 2, false, true, 0, false, true);
	}
	@Test
	public void test10035() {
		o.launch(4, true, false, 2, false, true, 0, false, false);
	}
	@Test
	public void test10036() {
		o.launch(4, true, false, 2, false, true, 1, true, true);
	}
	@Test
	public void test10037() {
		o.launch(4, true, false, 2, false, true, 1, true, false);
	}
	@Test
	public void test10038() {
		o.launch(4, true, false, 2, false, true, 1, false, true);
	}
	@Test
	public void test10039() {
		o.launch(4, true, false, 2, false, true, 1, false, false);
	}
	@Test
	public void test10040() {
		o.launch(4, true, false, 2, false, true, 2, true, true);
	}
	@Test
	public void test10041() {
		o.launch(4, true, false, 2, false, true, 2, true, false);
	}
	@Test
	public void test10042() {
		o.launch(4, true, false, 2, false, true, 2, false, true);
	}
	@Test
	public void test10043() {
		o.launch(4, true, false, 2, false, true, 2, false, false);
	}
	@Test
	public void test10044() {
		o.launch(4, true, false, 2, false, true, 3, true, true);
	}
	@Test
	public void test10045() {
		o.launch(4, true, false, 2, false, true, 3, true, false);
	}
	@Test
	public void test10046() {
		o.launch(4, true, false, 2, false, true, 3, false, true);
	}
	@Test
	public void test10047() {
		o.launch(4, true, false, 2, false, true, 3, false, false);
	}
	@Test
	public void test10048() {
		o.launch(4, true, false, 2, false, true, 4, true, true);
	}
	@Test
	public void test10049() {
		o.launch(4, true, false, 2, false, true, 4, true, false);
	}
	@Test
	public void test10050() {
		o.launch(4, true, false, 2, false, true, 4, false, true);
	}
	@Test
	public void test10051() {
		o.launch(4, true, false, 2, false, true, 4, false, false);
	}
	@Test
	public void test10052() {
		o.launch(4, true, false, 2, false, true, 5, true, true);
	}
	@Test
	public void test10053() {
		o.launch(4, true, false, 2, false, true, 5, true, false);
	}
	@Test
	public void test10054() {
		o.launch(4, true, false, 2, false, true, 5, false, true);
	}
	@Test
	public void test10055() {
		o.launch(4, true, false, 2, false, true, 5, false, false);
	}
	@Test
	public void test10056() {
		o.launch(4, true, false, 2, false, false, 0, true, true);
	}
	@Test
	public void test10057() {
		o.launch(4, true, false, 2, false, false, 0, true, false);
	}
	@Test
	public void test10058() {
		o.launch(4, true, false, 2, false, false, 0, false, true);
	}
	@Test
	public void test10059() {
		o.launch(4, true, false, 2, false, false, 0, false, false);
	}
	@Test
	public void test10060() {
		o.launch(4, true, false, 2, false, false, 1, true, true);
	}
	@Test
	public void test10061() {
		o.launch(4, true, false, 2, false, false, 1, true, false);
	}
	@Test
	public void test10062() {
		o.launch(4, true, false, 2, false, false, 1, false, true);
	}
	@Test
	public void test10063() {
		o.launch(4, true, false, 2, false, false, 1, false, false);
	}
	@Test
	public void test10064() {
		o.launch(4, true, false, 2, false, false, 2, true, true);
	}
	@Test
	public void test10065() {
		o.launch(4, true, false, 2, false, false, 2, true, false);
	}
	@Test
	public void test10066() {
		o.launch(4, true, false, 2, false, false, 2, false, true);
	}
	@Test
	public void test10067() {
		o.launch(4, true, false, 2, false, false, 2, false, false);
	}
	@Test
	public void test10068() {
		o.launch(4, true, false, 2, false, false, 3, true, true);
	}
	@Test
	public void test10069() {
		o.launch(4, true, false, 2, false, false, 3, true, false);
	}
	@Test
	public void test10070() {
		o.launch(4, true, false, 2, false, false, 3, false, true);
	}
	@Test
	public void test10071() {
		o.launch(4, true, false, 2, false, false, 3, false, false);
	}
	@Test
	public void test10072() {
		o.launch(4, true, false, 2, false, false, 4, true, true);
	}
	@Test
	public void test10073() {
		o.launch(4, true, false, 2, false, false, 4, true, false);
	}
	@Test
	public void test10074() {
		o.launch(4, true, false, 2, false, false, 4, false, true);
	}
	@Test
	public void test10075() {
		o.launch(4, true, false, 2, false, false, 4, false, false);
	}
	@Test
	public void test10076() {
		o.launch(4, true, false, 2, false, false, 5, true, true);
	}
	@Test
	public void test10077() {
		o.launch(4, true, false, 2, false, false, 5, true, false);
	}
	@Test
	public void test10078() {
		o.launch(4, true, false, 2, false, false, 5, false, true);
	}
	@Test
	public void test10079() {
		o.launch(4, true, false, 2, false, false, 5, false, false);
	}
	@Test
	public void test10080() {
		o.launch(4, true, false, 3, true, true, 0, true, true);
	}
	@Test
	public void test10081() {
		o.launch(4, true, false, 3, true, true, 0, true, false);
	}
	@Test
	public void test10082() {
		o.launch(4, true, false, 3, true, true, 0, false, true);
	}
	@Test
	public void test10083() {
		o.launch(4, true, false, 3, true, true, 0, false, false);
	}
	@Test
	public void test10084() {
		o.launch(4, true, false, 3, true, true, 1, true, true);
	}
	@Test
	public void test10085() {
		o.launch(4, true, false, 3, true, true, 1, true, false);
	}
	@Test
	public void test10086() {
		o.launch(4, true, false, 3, true, true, 1, false, true);
	}
	@Test
	public void test10087() {
		o.launch(4, true, false, 3, true, true, 1, false, false);
	}
	@Test
	public void test10088() {
		o.launch(4, true, false, 3, true, true, 2, true, true);
	}
	@Test
	public void test10089() {
		o.launch(4, true, false, 3, true, true, 2, true, false);
	}
	@Test
	public void test10090() {
		o.launch(4, true, false, 3, true, true, 2, false, true);
	}
	@Test
	public void test10091() {
		o.launch(4, true, false, 3, true, true, 2, false, false);
	}
	@Test
	public void test10092() {
		o.launch(4, true, false, 3, true, true, 3, true, true);
	}
	@Test
	public void test10093() {
		o.launch(4, true, false, 3, true, true, 3, true, false);
	}
	@Test
	public void test10094() {
		o.launch(4, true, false, 3, true, true, 3, false, true);
	}
	@Test
	public void test10095() {
		o.launch(4, true, false, 3, true, true, 3, false, false);
	}
	@Test
	public void test10096() {
		o.launch(4, true, false, 3, true, true, 4, true, true);
	}
	@Test
	public void test10097() {
		o.launch(4, true, false, 3, true, true, 4, true, false);
	}
	@Test
	public void test10098() {
		o.launch(4, true, false, 3, true, true, 4, false, true);
	}
	@Test
	public void test10099() {
		o.launch(4, true, false, 3, true, true, 4, false, false);
	}
	@Test
	public void test10100() {
		o.launch(4, true, false, 3, true, true, 5, true, true);
	}
	@Test
	public void test10101() {
		o.launch(4, true, false, 3, true, true, 5, true, false);
	}
	@Test
	public void test10102() {
		o.launch(4, true, false, 3, true, true, 5, false, true);
	}
	@Test
	public void test10103() {
		o.launch(4, true, false, 3, true, true, 5, false, false);
	}
	@Test
	public void test10104() {
		o.launch(4, true, false, 3, true, false, 0, true, true);
	}
	@Test
	public void test10105() {
		o.launch(4, true, false, 3, true, false, 0, true, false);
	}
	@Test
	public void test10106() {
		o.launch(4, true, false, 3, true, false, 0, false, true);
	}
	@Test
	public void test10107() {
		o.launch(4, true, false, 3, true, false, 0, false, false);
	}
	@Test
	public void test10108() {
		o.launch(4, true, false, 3, true, false, 1, true, true);
	}
	@Test
	public void test10109() {
		o.launch(4, true, false, 3, true, false, 1, true, false);
	}
	@Test
	public void test10110() {
		o.launch(4, true, false, 3, true, false, 1, false, true);
	}
	@Test
	public void test10111() {
		o.launch(4, true, false, 3, true, false, 1, false, false);
	}
	@Test
	public void test10112() {
		o.launch(4, true, false, 3, true, false, 2, true, true);
	}
	@Test
	public void test10113() {
		o.launch(4, true, false, 3, true, false, 2, true, false);
	}
	@Test
	public void test10114() {
		o.launch(4, true, false, 3, true, false, 2, false, true);
	}
	@Test
	public void test10115() {
		o.launch(4, true, false, 3, true, false, 2, false, false);
	}
	@Test
	public void test10116() {
		o.launch(4, true, false, 3, true, false, 3, true, true);
	}
	@Test
	public void test10117() {
		o.launch(4, true, false, 3, true, false, 3, true, false);
	}
	@Test
	public void test10118() {
		o.launch(4, true, false, 3, true, false, 3, false, true);
	}
	@Test
	public void test10119() {
		o.launch(4, true, false, 3, true, false, 3, false, false);
	}
	@Test
	public void test10120() {
		o.launch(4, true, false, 3, true, false, 4, true, true);
	}
	@Test
	public void test10121() {
		o.launch(4, true, false, 3, true, false, 4, true, false);
	}
	@Test
	public void test10122() {
		o.launch(4, true, false, 3, true, false, 4, false, true);
	}
	@Test
	public void test10123() {
		o.launch(4, true, false, 3, true, false, 4, false, false);
	}
	@Test
	public void test10124() {
		o.launch(4, true, false, 3, true, false, 5, true, true);
	}
	@Test
	public void test10125() {
		o.launch(4, true, false, 3, true, false, 5, true, false);
	}
	@Test
	public void test10126() {
		o.launch(4, true, false, 3, true, false, 5, false, true);
	}
	@Test
	public void test10127() {
		o.launch(4, true, false, 3, true, false, 5, false, false);
	}
	@Test
	public void test10128() {
		o.launch(4, true, false, 3, false, true, 0, true, true);
	}
	@Test
	public void test10129() {
		o.launch(4, true, false, 3, false, true, 0, true, false);
	}
	@Test
	public void test10130() {
		o.launch(4, true, false, 3, false, true, 0, false, true);
	}
	@Test
	public void test10131() {
		o.launch(4, true, false, 3, false, true, 0, false, false);
	}
	@Test
	public void test10132() {
		o.launch(4, true, false, 3, false, true, 1, true, true);
	}
	@Test
	public void test10133() {
		o.launch(4, true, false, 3, false, true, 1, true, false);
	}
	@Test
	public void test10134() {
		o.launch(4, true, false, 3, false, true, 1, false, true);
	}
	@Test
	public void test10135() {
		o.launch(4, true, false, 3, false, true, 1, false, false);
	}
	@Test
	public void test10136() {
		o.launch(4, true, false, 3, false, true, 2, true, true);
	}
	@Test
	public void test10137() {
		o.launch(4, true, false, 3, false, true, 2, true, false);
	}
	@Test
	public void test10138() {
		o.launch(4, true, false, 3, false, true, 2, false, true);
	}
	@Test
	public void test10139() {
		o.launch(4, true, false, 3, false, true, 2, false, false);
	}
	@Test
	public void test10140() {
		o.launch(4, true, false, 3, false, true, 3, true, true);
	}
	@Test
	public void test10141() {
		o.launch(4, true, false, 3, false, true, 3, true, false);
	}
	@Test
	public void test10142() {
		o.launch(4, true, false, 3, false, true, 3, false, true);
	}
	@Test
	public void test10143() {
		o.launch(4, true, false, 3, false, true, 3, false, false);
	}
	@Test
	public void test10144() {
		o.launch(4, true, false, 3, false, true, 4, true, true);
	}
	@Test
	public void test10145() {
		o.launch(4, true, false, 3, false, true, 4, true, false);
	}
	@Test
	public void test10146() {
		o.launch(4, true, false, 3, false, true, 4, false, true);
	}
	@Test
	public void test10147() {
		o.launch(4, true, false, 3, false, true, 4, false, false);
	}
	@Test
	public void test10148() {
		o.launch(4, true, false, 3, false, true, 5, true, true);
	}
	@Test
	public void test10149() {
		o.launch(4, true, false, 3, false, true, 5, true, false);
	}
	@Test
	public void test10150() {
		o.launch(4, true, false, 3, false, true, 5, false, true);
	}
	@Test
	public void test10151() {
		o.launch(4, true, false, 3, false, true, 5, false, false);
	}
	@Test
	public void test10152() {
		o.launch(4, true, false, 3, false, false, 0, true, true);
	}
	@Test
	public void test10153() {
		o.launch(4, true, false, 3, false, false, 0, true, false);
	}
	@Test
	public void test10154() {
		o.launch(4, true, false, 3, false, false, 0, false, true);
	}
	@Test
	public void test10155() {
		o.launch(4, true, false, 3, false, false, 0, false, false);
	}
	@Test
	public void test10156() {
		o.launch(4, true, false, 3, false, false, 1, true, true);
	}
	@Test
	public void test10157() {
		o.launch(4, true, false, 3, false, false, 1, true, false);
	}
	@Test
	public void test10158() {
		o.launch(4, true, false, 3, false, false, 1, false, true);
	}
	@Test
	public void test10159() {
		o.launch(4, true, false, 3, false, false, 1, false, false);
	}
	@Test
	public void test10160() {
		o.launch(4, true, false, 3, false, false, 2, true, true);
	}
	@Test
	public void test10161() {
		o.launch(4, true, false, 3, false, false, 2, true, false);
	}
	@Test
	public void test10162() {
		o.launch(4, true, false, 3, false, false, 2, false, true);
	}
	@Test
	public void test10163() {
		o.launch(4, true, false, 3, false, false, 2, false, false);
	}
	@Test
	public void test10164() {
		o.launch(4, true, false, 3, false, false, 3, true, true);
	}
	@Test
	public void test10165() {
		o.launch(4, true, false, 3, false, false, 3, true, false);
	}
	@Test
	public void test10166() {
		o.launch(4, true, false, 3, false, false, 3, false, true);
	}
	@Test
	public void test10167() {
		o.launch(4, true, false, 3, false, false, 3, false, false);
	}
	@Test
	public void test10168() {
		o.launch(4, true, false, 3, false, false, 4, true, true);
	}
	@Test
	public void test10169() {
		o.launch(4, true, false, 3, false, false, 4, true, false);
	}
	@Test
	public void test10170() {
		o.launch(4, true, false, 3, false, false, 4, false, true);
	}
	@Test
	public void test10171() {
		o.launch(4, true, false, 3, false, false, 4, false, false);
	}
	@Test
	public void test10172() {
		o.launch(4, true, false, 3, false, false, 5, true, true);
	}
	@Test
	public void test10173() {
		o.launch(4, true, false, 3, false, false, 5, true, false);
	}
	@Test
	public void test10174() {
		o.launch(4, true, false, 3, false, false, 5, false, true);
	}
	@Test
	public void test10175() {
		o.launch(4, true, false, 3, false, false, 5, false, false);
	}
	@Test
	public void test10176() {
		o.launch(4, true, false, 4, true, true, 0, true, true);
	}
	@Test
	public void test10177() {
		o.launch(4, true, false, 4, true, true, 0, true, false);
	}
	@Test
	public void test10178() {
		o.launch(4, true, false, 4, true, true, 0, false, true);
	}
	@Test
	public void test10179() {
		o.launch(4, true, false, 4, true, true, 0, false, false);
	}
	@Test
	public void test10180() {
		o.launch(4, true, false, 4, true, true, 1, true, true);
	}
	@Test
	public void test10181() {
		o.launch(4, true, false, 4, true, true, 1, true, false);
	}
	@Test
	public void test10182() {
		o.launch(4, true, false, 4, true, true, 1, false, true);
	}
	@Test
	public void test10183() {
		o.launch(4, true, false, 4, true, true, 1, false, false);
	}
	@Test
	public void test10184() {
		o.launch(4, true, false, 4, true, true, 2, true, true);
	}
	@Test
	public void test10185() {
		o.launch(4, true, false, 4, true, true, 2, true, false);
	}
	@Test
	public void test10186() {
		o.launch(4, true, false, 4, true, true, 2, false, true);
	}
	@Test
	public void test10187() {
		o.launch(4, true, false, 4, true, true, 2, false, false);
	}
	@Test
	public void test10188() {
		o.launch(4, true, false, 4, true, true, 3, true, true);
	}
	@Test
	public void test10189() {
		o.launch(4, true, false, 4, true, true, 3, true, false);
	}
	@Test
	public void test10190() {
		o.launch(4, true, false, 4, true, true, 3, false, true);
	}
	@Test
	public void test10191() {
		o.launch(4, true, false, 4, true, true, 3, false, false);
	}
	@Test
	public void test10192() {
		o.launch(4, true, false, 4, true, true, 4, true, true);
	}
	@Test
	public void test10193() {
		o.launch(4, true, false, 4, true, true, 4, true, false);
	}
	@Test
	public void test10194() {
		o.launch(4, true, false, 4, true, true, 4, false, true);
	}
	@Test
	public void test10195() {
		o.launch(4, true, false, 4, true, true, 4, false, false);
	}
	@Test
	public void test10196() {
		o.launch(4, true, false, 4, true, true, 5, true, true);
	}
	@Test
	public void test10197() {
		o.launch(4, true, false, 4, true, true, 5, true, false);
	}
	@Test
	public void test10198() {
		o.launch(4, true, false, 4, true, true, 5, false, true);
	}
	@Test
	public void test10199() {
		o.launch(4, true, false, 4, true, true, 10, false, false);
	}
	@Test
	public void test10200() {
		o.launch(4, true, false, 4, true, false, 0, true, true);
	}
	@Test
	public void test10201() {
		o.launch(4, true, false, 4, true, false, 0, true, false);
	}
	@Test
	public void test10202() {
		o.launch(4, true, false, 4, true, false, 0, false, true);
	}
	@Test
	public void test10203() {
		o.launch(4, true, false, 4, true, false, 0, false, false);
	}
	@Test
	public void test10204() {
		o.launch(4, true, false, 4, true, false, 1, true, true);
	}
	@Test
	public void test10205() {
		o.launch(4, true, false, 4, true, false, 1, true, false);
	}
	@Test
	public void test10206() {
		o.launch(4, true, false, 4, true, false, 1, false, true);
	}
	@Test
	public void test10207() {
		o.launch(4, true, false, 4, true, false, 1, false, false);
	}
	@Test
	public void test10208() {
		o.launch(4, true, false, 4, true, false, 2, true, true);
	}
	@Test
	public void test10209() {
		o.launch(4, true, false, 4, true, false, 2, true, false);
	}
	@Test
	public void test10210() {
		o.launch(4, true, false, 4, true, false, 2, false, true);
	}
	@Test
	public void test10211() {
		o.launch(4, true, false, 4, true, false, 2, false, false);
	}
	@Test
	public void test10212() {
		o.launch(4, true, false, 4, true, false, 3, true, true);
	}
	@Test
	public void test10213() {
		o.launch(4, true, false, 4, true, false, 3, true, false);
	}
	@Test
	public void test10214() {
		o.launch(4, true, false, 4, true, false, 3, false, true);
	}
	@Test
	public void test10215() {
		o.launch(4, true, false, 4, true, false, 3, false, false);
	}
	@Test
	public void test10216() {
		o.launch(4, true, false, 4, true, false, 4, true, true);
	}
	@Test
	public void test10217() {
		o.launch(4, true, false, 4, true, false, 4, true, false);
	}
	@Test
	public void test10218() {
		o.launch(4, true, false, 4, true, false, 4, false, true);
	}
	@Test
	public void test10219() {
		o.launch(4, true, false, 4, true, false, 4, false, false);
	}
	@Test
	public void test10220() {
		o.launch(4, true, false, 4, true, false, 5, true, true);
	}
	@Test
	public void test10221() {
		o.launch(4, true, false, 4, true, false, 5, true, false);
	}
	@Test
	public void test10222() {
		o.launch(4, true, false, 4, true, false, 5, false, true);
	}
	@Test
	public void test10223() {
		o.launch(4, true, false, 4, true, false, 5, false, false);
	}
	@Test
	public void test10224() {
		o.launch(4, true, false, 4, false, true, 0, true, true);
	}
	@Test
	public void test10225() {
		o.launch(4, true, false, 4, false, true, 0, true, false);
	}
	@Test
	public void test10226() {
		o.launch(4, true, false, 4, false, true, 0, false, true);
	}
	@Test
	public void test10227() {
		o.launch(4, true, false, 4, false, true, 0, false, false);
	}
	@Test
	public void test10228() {
		o.launch(4, true, false, 4, false, true, 1, true, true);
	}
	@Test
	public void test10229() {
		o.launch(4, true, false, 4, false, true, 1, true, false);
	}
	@Test
	public void test10230() {
		o.launch(4, true, false, 4, false, true, 1, false, true);
	}
	@Test
	public void test10231() {
		o.launch(4, true, false, 4, false, true, 1, false, false);
	}
	@Test
	public void test10232() {
		o.launch(4, true, false, 4, false, true, 2, true, true);
	}
	@Test
	public void test10233() {
		o.launch(4, true, false, 4, false, true, 2, true, false);
	}
	@Test
	public void test10234() {
		o.launch(4, true, false, 4, false, true, 2, false, true);
	}
	@Test
	public void test10235() {
		o.launch(4, true, false, 4, false, true, 2, false, false);
	}
	@Test
	public void test10236() {
		o.launch(4, true, false, 4, false, true, 3, true, true);
	}
	@Test
	public void test10237() {
		o.launch(4, true, false, 4, false, true, 3, true, false);
	}
	@Test
	public void test10238() {
		o.launch(4, true, false, 4, false, true, 3, false, true);
	}
	@Test
	public void test10239() {
		o.launch(4, true, false, 4, false, true, 3, false, false);
	}
	@Test
	public void test10240() {
		o.launch(4, true, false, 4, false, true, 4, true, true);
	}
	@Test
	public void test10241() {
		o.launch(4, true, false, 4, false, true, 4, true, false);
	}
	@Test
	public void test10242() {
		o.launch(4, true, false, 4, false, true, 4, false, true);
	}
	@Test
	public void test10243() {
		o.launch(4, true, false, 4, false, true, 4, false, false);
	}
	@Test
	public void test10244() {
		o.launch(4, true, false, 4, false, true, 5, true, true);
	}
	@Test
	public void test10245() {
		o.launch(4, true, false, 4, false, true, 5, true, false);
	}
	@Test
	public void test10246() {
		o.launch(4, true, false, 4, false, true, 5, false, true);
	}
	@Test
	public void test10247() {
		o.launch(4, true, false, 4, false, true, 5, false, false);
	}
	@Test
	public void test10248() {
		o.launch(4, true, false, 4, false, false, 0, true, true);
	}
	@Test
	public void test10249() {
		o.launch(4, true, false, 4, false, false, 0, true, false);
	}
	@Test
	public void test10250() {
		o.launch(4, true, false, 4, false, false, 0, false, true);
	}
	@Test
	public void test10251() {
		o.launch(4, true, false, 4, false, false, 0, false, false);
	}
	@Test
	public void test10252() {
		o.launch(4, true, false, 4, false, false, 1, true, true);
	}
	@Test
	public void test10253() {
		o.launch(4, true, false, 4, false, false, 1, true, false);
	}
	@Test
	public void test10254() {
		o.launch(4, true, false, 4, false, false, 1, false, true);
	}
	@Test
	public void test10255() {
		o.launch(4, true, false, 4, false, false, 1, false, false);
	}
	@Test
	public void test10256() {
		o.launch(4, true, false, 4, false, false, 2, true, true);
	}
	@Test
	public void test10257() {
		o.launch(4, true, false, 4, false, false, 2, true, false);
	}
	@Test
	public void test10258() {
		o.launch(4, true, false, 4, false, false, 2, false, true);
	}
	@Test
	public void test10259() {
		o.launch(4, true, false, 4, false, false, 2, false, false);
	}
	@Test
	public void test10260() {
		o.launch(4, true, false, 4, false, false, 3, true, true);
	}
	@Test
	public void test10261() {
		o.launch(4, true, false, 4, false, false, 3, true, false);
	}
	@Test
	public void test10262() {
		o.launch(4, true, false, 4, false, false, 3, false, true);
	}
	@Test
	public void test10263() {
		o.launch(4, true, false, 4, false, false, 3, false, false);
	}
	@Test
	public void test10264() {
		o.launch(4, true, false, 4, false, false, 4, true, true);
	}
	@Test
	public void test10265() {
		o.launch(4, true, false, 4, false, false, 4, true, false);
	}
	@Test
	public void test10266() {
		o.launch(4, true, false, 4, false, false, 4, false, true);
	}
	@Test
	public void test10267() {
		o.launch(4, true, false, 4, false, false, 4, false, false);
	}
	@Test
	public void test10268() {
		o.launch(4, true, false, 4, false, false, 5, true, true);
	}
	@Test
	public void test10269() {
		o.launch(4, true, false, 4, false, false, 5, true, false);
	}
	@Test
	public void test10270() {
		o.launch(4, true, false, 4, false, false, 5, false, true);
	}
	@Test
	public void test10271() {
		o.launch(4, true, false, 4, false, false, 10, false, false);
	}
	@Test
	public void test10272() {
		o.launch(4, true, false, -1, true, true, 0, true, true);
	}
	@Test
	public void test10273() {
		o.launch(4, true, false, 5, true, true, 0, true, false);
	}
	@Test
	public void test10274() {
		o.launch(4, true, false, 5, true, true, 0, false, true);
	}
	@Test
	public void test10275() {
		o.launch(4, true, false, 5, true, true, 0, false, false);
	}
	@Test
	public void test10276() {
		o.launch(4, true, false, 5, true, true, 1, true, true);
	}
	@Test
	public void test10277() {
		o.launch(4, true, false, -1, true, true, 1, true, false);
	}
	@Test
	public void test10278() {
		o.launch(4, true, false, 100, true, true, 1, false, true);
	}
	@Test
	public void test10279() {
		o.launch(4, true, false, 5, true, true, 1, false, false);
	}
	@Test
	public void test10280() {
		o.launch(4, true, false, 5, true, true, 2, true, true);
	}
	@Test
	public void test10281() {
		o.launch(4, true, false, 5, true, true, 2, true, false);
	}
	@Test
	public void test10282() {
		o.launch(4, true, false, 5, true, true, 2, false, true);
	}
	@Test
	public void test10283() {
		o.launch(4, true, false, 5, true, true, 2, false, false);
	}
	@Test
	public void test10284() {
		o.launch(4, true, false, 5, true, true, 3, true, true);
	}
	@Test
	public void test10285() {
		o.launch(4, true, false, 5, true, true, 3, true, false);
	}
	@Test
	public void test10286() {
		o.launch(4, true, false, 5, true, true, 3, false, true);
	}
	@Test
	public void test10287() {
		o.launch(4, true, false, 5, true, true, 3, false, false);
	}
	@Test
	public void test10288() {
		o.launch(4, true, false, -1, true, true, 4, true, true);
	}
	@Test
	public void test10289() {
		o.launch(4, true, false, 5, true, true, 4, true, false);
	}
	@Test
	public void test10290() {
		o.launch(4, true, false, 5, true, true, 4, false, true);
	}
	@Test
	public void test10291() {
		o.launch(4, true, false, 5, true, true, 4, false, false);
	}
	@Test
	public void test10292() {
		o.launch(4, true, false, -1, true, true, -1, true, true);
	}
	@Test
	public void test10293() {
		o.launch(4, true, false, 100, true, true, 100, true, false);
	}
	@Test
	public void test10294() {
		o.launch(4, true, false, 10, true, true, 10, false, true);
	}
	@Test
	public void test10295() {
		o.launch(4, true, false, -1, true, true, -1, false, false);
	}
	@Test
	public void test10296() {
		o.launch(4, true, false, 100, true, false, 0, true, true);
	}
	@Test
	public void test10297() {
		o.launch(4, true, false, 5, true, false, 0, true, false);
	}
	@Test
	public void test10298() {
		o.launch(4, true, false, 100, true, false, 0, false, true);
	}
	@Test
	public void test10299() {
		o.launch(4, true, false, -1, true, false, 0, false, false);
	}
	@Test
	public void test10300() {
		o.launch(4, true, false, 5, true, false, 1, true, true);
	}
	@Test
	public void test10301() {
		o.launch(4, true, false, 100, true, false, 1, true, false);
	}
	@Test
	public void test10302() {
		o.launch(4, true, false, 10, true, false, 1, false, true);
	}
	@Test
	public void test10303() {
		o.launch(4, true, false, 5, true, false, 1, false, false);
	}
	@Test
	public void test10304() {
		o.launch(4, true, false, 5, true, false, 2, true, true);
	}
	@Test
	public void test10305() {
		o.launch(4, true, false, 5, true, false, 2, true, false);
	}
	@Test
	public void test10306() {
		o.launch(4, true, false, 5, true, false, 2, false, true);
	}
	@Test
	public void test10307() {
		o.launch(4, true, false, 5, true, false, 2, false, false);
	}
	@Test
	public void test10308() {
		o.launch(4, true, false, 5, true, false, 3, true, true);
	}
	@Test
	public void test10309() {
		o.launch(4, true, false, 5, true, false, 3, true, false);
	}
	@Test
	public void test10310() {
		o.launch(4, true, false, 5, true, false, 3, false, true);
	}
	@Test
	public void test10311() {
		o.launch(4, true, false, 5, true, false, 3, false, false);
	}
	@Test
	public void test10312() {
		o.launch(4, true, false, 5, true, false, 4, true, true);
	}
	@Test
	public void test10313() {
		o.launch(4, true, false, 5, true, false, 4, true, false);
	}
	@Test
	public void test10314() {
		o.launch(4, true, false, 5, true, false, 4, false, true);
	}
	@Test
	public void test10315() {
		o.launch(4, true, false, 5, true, false, 4, false, false);
	}
	@Test
	public void test10316() {
		o.launch(4, true, false, 100, true, false, -1, true, true);
	}
	@Test
	public void test10317() {
		o.launch(4, true, false, -1, true, false, 10, true, false);
	}
	@Test
	public void test10318() {
		o.launch(4, true, false, 10, true, false, 100, false, true);
	}
	@Test
	public void test10319() {
		o.launch(4, true, false, 10, true, false, -1, false, false);
	}
	@Test
	public void test10320() {
		o.launch(4, true, false, 5, false, true, 0, true, true);
	}
	@Test
	public void test10321() {
		o.launch(4, true, false, 5, false, true, 0, true, false);
	}
	@Test
	public void test10322() {
		o.launch(4, true, false, -1, false, true, 0, false, true);
	}
	@Test
	public void test10323() {
		o.launch(4, true, false, -1, false, true, 0, false, false);
	}
	@Test
	public void test10324() {
		o.launch(4, true, false, 5, false, true, 1, true, true);
	}
	@Test
	public void test10325() {
		o.launch(4, true, false, 5, false, true, 1, true, false);
	}
	@Test
	public void test10326() {
		o.launch(4, true, false, -1, false, true, 1, false, true);
	}
	@Test
	public void test10327() {
		o.launch(4, true, false, 10, false, true, 1, false, false);
	}
	@Test
	public void test10328() {
		o.launch(4, true, false, 5, false, true, 2, true, true);
	}
	@Test
	public void test10329() {
		o.launch(4, true, false, 5, false, true, 2, true, false);
	}
	@Test
	public void test10330() {
		o.launch(4, true, false, 5, false, true, 2, false, true);
	}
	@Test
	public void test10331() {
		o.launch(4, true, false, 5, false, true, 2, false, false);
	}
	@Test
	public void test10332() {
		o.launch(4, true, false, 5, false, true, 3, true, true);
	}
	@Test
	public void test10333() {
		o.launch(4, true, false, 5, false, true, 3, true, false);
	}
	@Test
	public void test10334() {
		o.launch(4, true, false, 5, false, true, 3, false, true);
	}
	@Test
	public void test10335() {
		o.launch(4, true, false, 5, false, true, 3, false, false);
	}
	@Test
	public void test10336() {
		o.launch(4, true, false, 5, false, true, 4, true, true);
	}
	@Test
	public void test10337() {
		o.launch(4, true, false, 5, false, true, 4, true, false);
	}
	@Test
	public void test10338() {
		o.launch(4, true, false, 5, false, true, 4, false, true);
	}
	@Test
	public void test10339() {
		o.launch(4, true, false, 5, false, true, 4, false, false);
	}
	@Test
	public void test10340() {
		o.launch(4, true, false, 10, false, true, 100, true, true);
	}
	@Test
	public void test10341() {
		o.launch(4, true, false, -1, false, true, -1, true, false);
	}
	@Test
	public void test10342() {
		o.launch(4, true, false, -1, false, true, -1, false, true);
	}
	@Test
	public void test10343() {
		o.launch(4, true, false, 10, false, true, 100, false, false);
	}
	@Test
	public void test10344() {
		o.launch(4, true, false, 5, false, false, 0, true, true);
	}
	@Test
	public void test10345() {
		o.launch(4, true, false, 10, false, false, 0, true, false);
	}
	@Test
	public void test10346() {
		o.launch(4, true, false, -1, false, false, 0, false, true);
	}
	@Test
	public void test10347() {
		o.launch(4, true, false, 100, false, false, 0, false, false);
	}
	@Test
	public void test10348() {
		o.launch(4, true, false, 5, false, false, 1, true, true);
	}
	@Test
	public void test10349() {
		o.launch(4, true, false, 5, false, false, 1, true, false);
	}
	@Test
	public void test10350() {
		o.launch(4, true, false, 10, false, false, 1, false, true);
	}
	@Test
	public void test10351() {
		o.launch(4, true, false, 100, false, false, 1, false, false);
	}
	@Test
	public void test10352() {
		o.launch(4, true, false, 5, false, false, 2, true, true);
	}
	@Test
	public void test10353() {
		o.launch(4, true, false, 5, false, false, 2, true, false);
	}
	@Test
	public void test10354() {
		o.launch(4, true, false, 5, false, false, 2, false, true);
	}
	@Test
	public void test10355() {
		o.launch(4, true, false, 5, false, false, 2, false, false);
	}
	@Test
	public void test10356() {
		o.launch(4, true, false, 5, false, false, 3, true, true);
	}
	@Test
	public void test10357() {
		o.launch(4, true, false, 5, false, false, 3, true, false);
	}
	@Test
	public void test10358() {
		o.launch(4, true, false, 5, false, false, 3, false, true);
	}
	@Test
	public void test10359() {
		o.launch(4, true, false, 5, false, false, 3, false, false);
	}
	@Test
	public void test10360() {
		o.launch(4, true, false, 5, false, false, 4, true, true);
	}
	@Test
	public void test10361() {
		o.launch(4, true, false, 5, false, false, 4, true, false);
	}
	@Test
	public void test10362() {
		o.launch(4, true, false, 5, false, false, 4, false, true);
	}
	@Test
	public void test10363() {
		o.launch(4, true, false, 5, false, false, 4, false, false);
	}
	@Test
	public void test10364() {
		o.launch(4, true, false, 10, false, false, 100, true, true);
	}
	@Test
	public void test10365() {
		o.launch(4, true, false, 10, false, false, 10, true, false);
	}
	@Test
	public void test10366() {
		o.launch(4, true, false, 10, false, false, 10, false, true);
	}
	@Test
	public void test10367() {
		o.launch(4, true, false, 10, false, false, 10, false, false);
	}
	@Test
	public void test10368() {
		o.launch(4, false, true, 0, true, true, 0, true, true);
	}
	@Test
	public void test10369() {
		o.launch(4, false, true, 0, true, true, 0, true, false);
	}
	@Test
	public void test10370() {
		o.launch(4, false, true, 0, true, true, 0, false, true);
	}
	@Test
	public void test10371() {
		o.launch(4, false, true, 0, true, true, 0, false, false);
	}
	@Test
	public void test10372() {
		o.launch(4, false, true, 0, true, true, 1, true, true);
	}
	@Test
	public void test10373() {
		o.launch(4, false, true, 0, true, true, 1, true, false);
	}
	@Test
	public void test10374() {
		o.launch(4, false, true, 0, true, true, 1, false, true);
	}
	@Test
	public void test10375() {
		o.launch(4, false, true, 0, true, true, 1, false, false);
	}
	@Test
	public void test10376() {
		o.launch(4, false, true, 0, true, true, 2, true, true);
	}
	@Test
	public void test10377() {
		o.launch(4, false, true, 0, true, true, 2, true, false);
	}
	@Test
	public void test10378() {
		o.launch(4, false, true, 0, true, true, 2, false, true);
	}
	@Test
	public void test10379() {
		o.launch(4, false, true, 0, true, true, 2, false, false);
	}
	@Test
	public void test10380() {
		o.launch(4, false, true, 0, true, true, 3, true, true);
	}
	@Test
	public void test10381() {
		o.launch(4, false, true, 0, true, true, 3, true, false);
	}
	@Test
	public void test10382() {
		o.launch(4, false, true, 0, true, true, 3, false, true);
	}
	@Test
	public void test10383() {
		o.launch(4, false, true, 0, true, true, 3, false, false);
	}
	@Test
	public void test10384() {
		o.launch(4, false, true, 0, true, true, 4, true, true);
	}
	@Test
	public void test10385() {
		o.launch(4, false, true, 0, true, true, 4, true, false);
	}
	@Test
	public void test10386() {
		o.launch(4, false, true, 0, true, true, 4, false, true);
	}
	@Test
	public void test10387() {
		o.launch(4, false, true, 0, true, true, 4, false, false);
	}
	@Test
	public void test10388() {
		o.launch(4, false, true, 0, true, true, -1, true, true);
	}
	@Test
	public void test10389() {
		o.launch(4, false, true, 0, true, true, 5, true, false);
	}
	@Test
	public void test10390() {
		o.launch(4, false, true, 0, true, true, 5, false, true);
	}
	@Test
	public void test10391() {
		o.launch(4, false, true, 0, true, true, 100, false, false);
	}
	@Test
	public void test10392() {
		o.launch(4, false, true, 0, true, false, 0, true, true);
	}
	@Test
	public void test10393() {
		o.launch(4, false, true, 0, true, false, 0, true, false);
	}
	@Test
	public void test10394() {
		o.launch(4, false, true, 0, true, false, 0, false, true);
	}
	@Test
	public void test10395() {
		o.launch(4, false, true, 0, true, false, 0, false, false);
	}
	@Test
	public void test10396() {
		o.launch(4, false, true, 0, true, false, 1, true, true);
	}
	@Test
	public void test10397() {
		o.launch(4, false, true, 0, true, false, 1, true, false);
	}
	@Test
	public void test10398() {
		o.launch(4, false, true, 0, true, false, 1, false, true);
	}
	@Test
	public void test10399() {
		o.launch(4, false, true, 0, true, false, 1, false, false);
	}
	@Test
	public void test10400() {
		o.launch(4, false, true, 0, true, false, 2, true, true);
	}
	@Test
	public void test10401() {
		o.launch(4, false, true, 0, true, false, 2, true, false);
	}
	@Test
	public void test10402() {
		o.launch(4, false, true, 0, true, false, 2, false, true);
	}
	@Test
	public void test10403() {
		o.launch(4, false, true, 0, true, false, 2, false, false);
	}
	@Test
	public void test10404() {
		o.launch(4, false, true, 0, true, false, 3, true, true);
	}
	@Test
	public void test10405() {
		o.launch(4, false, true, 0, true, false, 3, true, false);
	}
	@Test
	public void test10406() {
		o.launch(4, false, true, 0, true, false, 3, false, true);
	}
	@Test
	public void test10407() {
		o.launch(4, false, true, 0, true, false, 3, false, false);
	}
	@Test
	public void test10408() {
		o.launch(4, false, true, 0, true, false, 4, true, true);
	}
	@Test
	public void test10409() {
		o.launch(4, false, true, 0, true, false, 4, true, false);
	}
	@Test
	public void test10410() {
		o.launch(4, false, true, 0, true, false, 4, false, true);
	}
	@Test
	public void test10411() {
		o.launch(4, false, true, 0, true, false, 4, false, false);
	}
	@Test
	public void test10412() {
		o.launch(4, false, true, 0, true, false, 5, true, true);
	}
	@Test
	public void test10413() {
		o.launch(4, false, true, 0, true, false, 5, true, false);
	}
	@Test
	public void test10414() {
		o.launch(4, false, true, 0, true, false, 5, false, true);
	}
	@Test
	public void test10415() {
		o.launch(4, false, true, 0, true, false, -1, false, false);
	}
	@Test
	public void test10416() {
		o.launch(4, false, true, 0, false, true, 0, true, true);
	}
	@Test
	public void test10417() {
		o.launch(4, false, true, 0, false, true, 0, true, false);
	}
	@Test
	public void test10418() {
		o.launch(4, false, true, 0, false, true, 0, false, true);
	}
	@Test
	public void test10419() {
		o.launch(4, false, true, 0, false, true, 0, false, false);
	}
	@Test
	public void test10420() {
		o.launch(4, false, true, 0, false, true, 1, true, true);
	}
	@Test
	public void test10421() {
		o.launch(4, false, true, 0, false, true, 1, true, false);
	}
	@Test
	public void test10422() {
		o.launch(4, false, true, 0, false, true, 1, false, true);
	}
	@Test
	public void test10423() {
		o.launch(4, false, true, 0, false, true, 1, false, false);
	}
	@Test
	public void test10424() {
		o.launch(4, false, true, 0, false, true, 2, true, true);
	}
	@Test
	public void test10425() {
		o.launch(4, false, true, 0, false, true, 2, true, false);
	}
	@Test
	public void test10426() {
		o.launch(4, false, true, 0, false, true, 2, false, true);
	}
	@Test
	public void test10427() {
		o.launch(4, false, true, 0, false, true, 2, false, false);
	}
	@Test
	public void test10428() {
		o.launch(4, false, true, 0, false, true, 3, true, true);
	}
	@Test
	public void test10429() {
		o.launch(4, false, true, 0, false, true, 3, true, false);
	}
	@Test
	public void test10430() {
		o.launch(4, false, true, 0, false, true, 3, false, true);
	}
	@Test
	public void test10431() {
		o.launch(4, false, true, 0, false, true, 3, false, false);
	}
	@Test
	public void test10432() {
		o.launch(4, false, true, 0, false, true, 4, true, true);
	}
	@Test
	public void test10433() {
		o.launch(4, false, true, 0, false, true, 4, true, false);
	}
	@Test
	public void test10434() {
		o.launch(4, false, true, 0, false, true, 4, false, true);
	}
	@Test
	public void test10435() {
		o.launch(4, false, true, 0, false, true, 4, false, false);
	}
	@Test
	public void test10436() {
		o.launch(4, false, true, 0, false, true, 5, true, true);
	}
	@Test
	public void test10437() {
		o.launch(4, false, true, 0, false, true, 5, true, false);
	}
	@Test
	public void test10438() {
		o.launch(4, false, true, 0, false, true, 10, false, true);
	}
	@Test
	public void test10439() {
		o.launch(4, false, true, 0, false, true, 100, false, false);
	}
	@Test
	public void test10440() {
		o.launch(4, false, true, 0, false, false, 0, true, true);
	}
	@Test
	public void test10441() {
		o.launch(4, false, true, 0, false, false, 0, true, false);
	}
	@Test
	public void test10442() {
		o.launch(4, false, true, 0, false, false, 0, false, true);
	}
	@Test
	public void test10443() {
		o.launch(4, false, true, 0, false, false, 0, false, false);
	}
	@Test
	public void test10444() {
		o.launch(4, false, true, 0, false, false, 1, true, true);
	}
	@Test
	public void test10445() {
		o.launch(4, false, true, 0, false, false, 1, true, false);
	}
	@Test
	public void test10446() {
		o.launch(4, false, true, 0, false, false, 1, false, true);
	}
	@Test
	public void test10447() {
		o.launch(4, false, true, 0, false, false, 1, false, false);
	}
	@Test
	public void test10448() {
		o.launch(4, false, true, 0, false, false, 2, true, true);
	}
	@Test
	public void test10449() {
		o.launch(4, false, true, 0, false, false, 2, true, false);
	}
	@Test
	public void test10450() {
		o.launch(4, false, true, 0, false, false, 2, false, true);
	}
	@Test
	public void test10451() {
		o.launch(4, false, true, 0, false, false, 2, false, false);
	}
	@Test
	public void test10452() {
		o.launch(4, false, true, 0, false, false, 3, true, true);
	}
	@Test
	public void test10453() {
		o.launch(4, false, true, 0, false, false, 3, true, false);
	}
	@Test
	public void test10454() {
		o.launch(4, false, true, 0, false, false, 3, false, true);
	}
	@Test
	public void test10455() {
		o.launch(4, false, true, 0, false, false, 3, false, false);
	}
	@Test
	public void test10456() {
		o.launch(4, false, true, 0, false, false, 4, true, true);
	}
	@Test
	public void test10457() {
		o.launch(4, false, true, 0, false, false, 4, true, false);
	}
	@Test
	public void test10458() {
		o.launch(4, false, true, 0, false, false, 4, false, true);
	}
	@Test
	public void test10459() {
		o.launch(4, false, true, 0, false, false, 4, false, false);
	}
	@Test
	public void test10460() {
		o.launch(4, false, true, 0, false, false, -1, true, true);
	}
	@Test
	public void test10461() {
		o.launch(4, false, true, 0, false, false, 10, true, false);
	}
	@Test
	public void test10462() {
		o.launch(4, false, true, 0, false, false, 5, false, true);
	}
	@Test
	public void test10463() {
		o.launch(4, false, true, 0, false, false, 5, false, false);
	}
	@Test
	public void test10464() {
		o.launch(4, false, true, 1, true, true, 0, true, true);
	}
	@Test
	public void test10465() {
		o.launch(4, false, true, 1, true, true, 0, true, false);
	}
	@Test
	public void test10466() {
		o.launch(4, false, true, 1, true, true, 0, false, true);
	}
	@Test
	public void test10467() {
		o.launch(4, false, true, 1, true, true, 0, false, false);
	}
	@Test
	public void test10468() {
		o.launch(4, false, true, 1, true, true, 1, true, true);
	}
	@Test
	public void test10469() {
		o.launch(4, false, true, 1, true, true, 1, true, false);
	}
	@Test
	public void test10470() {
		o.launch(4, false, true, 1, true, true, 1, false, true);
	}
	@Test
	public void test10471() {
		o.launch(4, false, true, 1, true, true, 1, false, false);
	}
	@Test
	public void test10472() {
		o.launch(4, false, true, 1, true, true, 2, true, true);
	}
	@Test
	public void test10473() {
		o.launch(4, false, true, 1, true, true, 2, true, false);
	}
	@Test
	public void test10474() {
		o.launch(4, false, true, 1, true, true, 2, false, true);
	}
	@Test
	public void test10475() {
		o.launch(4, false, true, 1, true, true, 2, false, false);
	}
	@Test
	public void test10476() {
		o.launch(4, false, true, 1, true, true, 3, true, true);
	}
	@Test
	public void test10477() {
		o.launch(4, false, true, 1, true, true, 3, true, false);
	}
	@Test
	public void test10478() {
		o.launch(4, false, true, 1, true, true, 3, false, true);
	}
	@Test
	public void test10479() {
		o.launch(4, false, true, 1, true, true, 3, false, false);
	}
	@Test
	public void test10480() {
		o.launch(4, false, true, 1, true, true, 4, true, true);
	}
	@Test
	public void test10481() {
		o.launch(4, false, true, 1, true, true, 4, true, false);
	}
	@Test
	public void test10482() {
		o.launch(4, false, true, 1, true, true, 4, false, true);
	}
	@Test
	public void test10483() {
		o.launch(4, false, true, 1, true, true, 4, false, false);
	}
	@Test
	public void test10484() {
		o.launch(4, false, true, 1, true, true, -1, true, true);
	}
	@Test
	public void test10485() {
		o.launch(4, false, true, 1, true, true, 5, true, false);
	}
	@Test
	public void test10486() {
		o.launch(4, false, true, 1, true, true, 10, false, true);
	}
	@Test
	public void test10487() {
		o.launch(4, false, true, 1, true, true, -1, false, false);
	}
	@Test
	public void test10488() {
		o.launch(4, false, true, 1, true, false, 0, true, true);
	}
	@Test
	public void test10489() {
		o.launch(4, false, true, 1, true, false, 0, true, false);
	}
	@Test
	public void test10490() {
		o.launch(4, false, true, 1, true, false, 0, false, true);
	}
	@Test
	public void test10491() {
		o.launch(4, false, true, 1, true, false, 0, false, false);
	}
	@Test
	public void test10492() {
		o.launch(4, false, true, 1, true, false, 1, true, true);
	}
	@Test
	public void test10493() {
		o.launch(4, false, true, 1, true, false, 1, true, false);
	}
	@Test
	public void test10494() {
		o.launch(4, false, true, 1, true, false, 1, false, true);
	}
	@Test
	public void test10495() {
		o.launch(4, false, true, 1, true, false, 1, false, false);
	}
	@Test
	public void test10496() {
		o.launch(4, false, true, 1, true, false, 2, true, true);
	}
	@Test
	public void test10497() {
		o.launch(4, false, true, 1, true, false, 2, true, false);
	}
	@Test
	public void test10498() {
		o.launch(4, false, true, 1, true, false, 2, false, true);
	}
	@Test
	public void test10499() {
		o.launch(4, false, true, 1, true, false, 2, false, false);
	}
	@Test
	public void test10500() {
		o.launch(4, false, true, 1, true, false, 3, true, true);
	}
	@Test
	public void test10501() {
		o.launch(4, false, true, 1, true, false, 3, true, false);
	}
	@Test
	public void test10502() {
		o.launch(4, false, true, 1, true, false, 3, false, true);
	}
	@Test
	public void test10503() {
		o.launch(4, false, true, 1, true, false, 3, false, false);
	}
	@Test
	public void test10504() {
		o.launch(4, false, true, 1, true, false, 4, true, true);
	}
	@Test
	public void test10505() {
		o.launch(4, false, true, 1, true, false, 4, true, false);
	}
	@Test
	public void test10506() {
		o.launch(4, false, true, 1, true, false, 4, false, true);
	}
	@Test
	public void test10507() {
		o.launch(4, false, true, 1, true, false, 4, false, false);
	}
	@Test
	public void test10508() {
		o.launch(4, false, true, 1, true, false, 100, true, true);
	}
	@Test
	public void test10509() {
		o.launch(4, false, true, 1, true, false, 5, true, false);
	}
	@Test
	public void test10510() {
		o.launch(4, false, true, 1, true, false, 5, false, true);
	}
	@Test
	public void test10511() {
		o.launch(4, false, true, 1, true, false, 100, false, false);
	}
	@Test
	public void test10512() {
		o.launch(4, false, true, 1, false, true, 0, true, true);
	}
	@Test
	public void test10513() {
		o.launch(4, false, true, 1, false, true, 0, true, false);
	}
	@Test
	public void test10514() {
		o.launch(4, false, true, 1, false, true, 0, false, true);
	}
	@Test
	public void test10515() {
		o.launch(4, false, true, 1, false, true, 0, false, false);
	}
	@Test
	public void test10516() {
		o.launch(4, false, true, 1, false, true, 1, true, true);
	}
	@Test
	public void test10517() {
		o.launch(4, false, true, 1, false, true, 1, true, false);
	}
	@Test
	public void test10518() {
		o.launch(4, false, true, 1, false, true, 1, false, true);
	}
	@Test
	public void test10519() {
		o.launch(4, false, true, 1, false, true, 1, false, false);
	}
	@Test
	public void test10520() {
		o.launch(4, false, true, 1, false, true, 2, true, true);
	}
	@Test
	public void test10521() {
		o.launch(4, false, true, 1, false, true, 2, true, false);
	}
	@Test
	public void test10522() {
		o.launch(4, false, true, 1, false, true, 2, false, true);
	}
	@Test
	public void test10523() {
		o.launch(4, false, true, 1, false, true, 2, false, false);
	}
	@Test
	public void test10524() {
		o.launch(4, false, true, 1, false, true, 3, true, true);
	}
	@Test
	public void test10525() {
		o.launch(4, false, true, 1, false, true, 3, true, false);
	}
	@Test
	public void test10526() {
		o.launch(4, false, true, 1, false, true, 3, false, true);
	}
	@Test
	public void test10527() {
		o.launch(4, false, true, 1, false, true, 3, false, false);
	}
	@Test
	public void test10528() {
		o.launch(4, false, true, 1, false, true, 4, true, true);
	}
	@Test
	public void test10529() {
		o.launch(4, false, true, 1, false, true, 4, true, false);
	}
	@Test
	public void test10530() {
		o.launch(4, false, true, 1, false, true, 4, false, true);
	}
	@Test
	public void test10531() {
		o.launch(4, false, true, 1, false, true, 4, false, false);
	}
	@Test
	public void test10532() {
		o.launch(4, false, true, 1, false, true, 100, true, true);
	}
	@Test
	public void test10533() {
		o.launch(4, false, true, 1, false, true, -1, true, false);
	}
	@Test
	public void test10534() {
		o.launch(4, false, true, 1, false, true, -1, false, true);
	}
	@Test
	public void test10535() {
		o.launch(4, false, true, 1, false, true, 5, false, false);
	}
	@Test
	public void test10536() {
		o.launch(4, false, true, 1, false, false, 0, true, true);
	}
	@Test
	public void test10537() {
		o.launch(4, false, true, 1, false, false, 0, true, false);
	}
	@Test
	public void test10538() {
		o.launch(4, false, true, 1, false, false, 0, false, true);
	}
	@Test
	public void test10539() {
		o.launch(4, false, true, 1, false, false, 0, false, false);
	}
	@Test
	public void test10540() {
		o.launch(4, false, true, 1, false, false, 1, true, true);
	}
	@Test
	public void test10541() {
		o.launch(4, false, true, 1, false, false, 1, true, false);
	}
	@Test
	public void test10542() {
		o.launch(4, false, true, 1, false, false, 1, false, true);
	}
	@Test
	public void test10543() {
		o.launch(4, false, true, 1, false, false, 1, false, false);
	}
	@Test
	public void test10544() {
		o.launch(4, false, true, 1, false, false, 2, true, true);
	}
	@Test
	public void test10545() {
		o.launch(4, false, true, 1, false, false, 2, true, false);
	}
	@Test
	public void test10546() {
		o.launch(4, false, true, 1, false, false, 2, false, true);
	}
	@Test
	public void test10547() {
		o.launch(4, false, true, 1, false, false, 2, false, false);
	}
	@Test
	public void test10548() {
		o.launch(4, false, true, 1, false, false, 3, true, true);
	}
	@Test
	public void test10549() {
		o.launch(4, false, true, 1, false, false, 3, true, false);
	}
	@Test
	public void test10550() {
		o.launch(4, false, true, 1, false, false, 3, false, true);
	}
	@Test
	public void test10551() {
		o.launch(4, false, true, 1, false, false, 3, false, false);
	}
	@Test
	public void test10552() {
		o.launch(4, false, true, 1, false, false, 4, true, true);
	}
	@Test
	public void test10553() {
		o.launch(4, false, true, 1, false, false, 4, true, false);
	}
	@Test
	public void test10554() {
		o.launch(4, false, true, 1, false, false, 4, false, true);
	}
	@Test
	public void test10555() {
		o.launch(4, false, true, 1, false, false, 4, false, false);
	}
	@Test
	public void test10556() {
		o.launch(4, false, true, 1, false, false, 5, true, true);
	}
	@Test
	public void test10557() {
		o.launch(4, false, true, 1, false, false, -1, true, false);
	}
	@Test
	public void test10558() {
		o.launch(4, false, true, 1, false, false, -1, false, true);
	}
	@Test
	public void test10559() {
		o.launch(4, false, true, 1, false, false, -1, false, false);
	}
	@Test
	public void test10560() {
		o.launch(4, false, true, 2, true, true, 0, true, true);
	}
	@Test
	public void test10561() {
		o.launch(4, false, true, 2, true, true, 0, true, false);
	}
	@Test
	public void test10562() {
		o.launch(4, false, true, 2, true, true, 0, false, true);
	}
	@Test
	public void test10563() {
		o.launch(4, false, true, 2, true, true, 0, false, false);
	}
	@Test
	public void test10564() {
		o.launch(4, false, true, 2, true, true, 1, true, true);
	}
	@Test
	public void test10565() {
		o.launch(4, false, true, 2, true, true, 1, true, false);
	}
	@Test
	public void test10566() {
		o.launch(4, false, true, 2, true, true, 1, false, true);
	}
	@Test
	public void test10567() {
		o.launch(4, false, true, 2, true, true, 1, false, false);
	}
	@Test
	public void test10568() {
		o.launch(4, false, true, 2, true, true, 2, true, true);
	}
	@Test
	public void test10569() {
		o.launch(4, false, true, 2, true, true, 2, true, false);
	}
	@Test
	public void test10570() {
		o.launch(4, false, true, 2, true, true, 2, false, true);
	}
	@Test
	public void test10571() {
		o.launch(4, false, true, 2, true, true, 2, false, false);
	}
	@Test
	public void test10572() {
		o.launch(4, false, true, 2, true, true, 3, true, true);
	}
	@Test
	public void test10573() {
		o.launch(4, false, true, 2, true, true, 3, true, false);
	}
	@Test
	public void test10574() {
		o.launch(4, false, true, 2, true, true, 3, false, true);
	}
	@Test
	public void test10575() {
		o.launch(4, false, true, 2, true, true, 3, false, false);
	}
	@Test
	public void test10576() {
		o.launch(4, false, true, 2, true, true, 4, true, true);
	}
	@Test
	public void test10577() {
		o.launch(4, false, true, 2, true, true, 4, true, false);
	}
	@Test
	public void test10578() {
		o.launch(4, false, true, 2, true, true, 4, false, true);
	}
	@Test
	public void test10579() {
		o.launch(4, false, true, 2, true, true, 4, false, false);
	}
	@Test
	public void test10580() {
		o.launch(4, false, true, 2, true, true, 5, true, true);
	}
	@Test
	public void test10581() {
		o.launch(4, false, true, 2, true, true, 5, true, false);
	}
	@Test
	public void test10582() {
		o.launch(4, false, true, 2, true, true, 5, false, true);
	}
	@Test
	public void test10583() {
		o.launch(4, false, true, 2, true, true, 5, false, false);
	}
	@Test
	public void test10584() {
		o.launch(4, false, true, 2, true, false, 0, true, true);
	}
	@Test
	public void test10585() {
		o.launch(4, false, true, 2, true, false, 0, true, false);
	}
	@Test
	public void test10586() {
		o.launch(4, false, true, 2, true, false, 0, false, true);
	}
	@Test
	public void test10587() {
		o.launch(4, false, true, 2, true, false, 0, false, false);
	}
	@Test
	public void test10588() {
		o.launch(4, false, true, 2, true, false, 1, true, true);
	}
	@Test
	public void test10589() {
		o.launch(4, false, true, 2, true, false, 1, true, false);
	}
	@Test
	public void test10590() {
		o.launch(4, false, true, 2, true, false, 1, false, true);
	}
	@Test
	public void test10591() {
		o.launch(4, false, true, 2, true, false, 1, false, false);
	}
	@Test
	public void test10592() {
		o.launch(4, false, true, 2, true, false, 2, true, true);
	}
	@Test
	public void test10593() {
		o.launch(4, false, true, 2, true, false, 2, true, false);
	}
	@Test
	public void test10594() {
		o.launch(4, false, true, 2, true, false, 2, false, true);
	}
	@Test
	public void test10595() {
		o.launch(4, false, true, 2, true, false, 2, false, false);
	}
	@Test
	public void test10596() {
		o.launch(4, false, true, 2, true, false, 3, true, true);
	}
	@Test
	public void test10597() {
		o.launch(4, false, true, 2, true, false, 3, true, false);
	}
	@Test
	public void test10598() {
		o.launch(4, false, true, 2, true, false, 3, false, true);
	}
	@Test
	public void test10599() {
		o.launch(4, false, true, 2, true, false, 3, false, false);
	}
	@Test
	public void test10600() {
		o.launch(4, false, true, 2, true, false, 4, true, true);
	}
	@Test
	public void test10601() {
		o.launch(4, false, true, 2, true, false, 4, true, false);
	}
	@Test
	public void test10602() {
		o.launch(4, false, true, 2, true, false, 4, false, true);
	}
	@Test
	public void test10603() {
		o.launch(4, false, true, 2, true, false, 4, false, false);
	}
	@Test
	public void test10604() {
		o.launch(4, false, true, 2, true, false, 5, true, true);
	}
	@Test
	public void test10605() {
		o.launch(4, false, true, 2, true, false, 5, true, false);
	}
	@Test
	public void test10606() {
		o.launch(4, false, true, 2, true, false, 5, false, true);
	}
	@Test
	public void test10607() {
		o.launch(4, false, true, 2, true, false, 5, false, false);
	}
	@Test
	public void test10608() {
		o.launch(4, false, true, 2, false, true, 0, true, true);
	}
	@Test
	public void test10609() {
		o.launch(4, false, true, 2, false, true, 0, true, false);
	}
	@Test
	public void test10610() {
		o.launch(4, false, true, 2, false, true, 0, false, true);
	}
	@Test
	public void test10611() {
		o.launch(4, false, true, 2, false, true, 0, false, false);
	}
	@Test
	public void test10612() {
		o.launch(4, false, true, 2, false, true, 1, true, true);
	}
	@Test
	public void test10613() {
		o.launch(4, false, true, 2, false, true, 1, true, false);
	}
	@Test
	public void test10614() {
		o.launch(4, false, true, 2, false, true, 1, false, true);
	}
	@Test
	public void test10615() {
		o.launch(4, false, true, 2, false, true, 1, false, false);
	}
	@Test
	public void test10616() {
		o.launch(4, false, true, 2, false, true, 2, true, true);
	}
	@Test
	public void test10617() {
		o.launch(4, false, true, 2, false, true, 2, true, false);
	}
	@Test
	public void test10618() {
		o.launch(4, false, true, 2, false, true, 2, false, true);
	}
	@Test
	public void test10619() {
		o.launch(4, false, true, 2, false, true, 2, false, false);
	}
	@Test
	public void test10620() {
		o.launch(4, false, true, 2, false, true, 3, true, true);
	}
	@Test
	public void test10621() {
		o.launch(4, false, true, 2, false, true, 3, true, false);
	}
	@Test
	public void test10622() {
		o.launch(4, false, true, 2, false, true, 3, false, true);
	}
	@Test
	public void test10623() {
		o.launch(4, false, true, 2, false, true, 3, false, false);
	}
	@Test
	public void test10624() {
		o.launch(4, false, true, 2, false, true, 4, true, true);
	}
	@Test
	public void test10625() {
		o.launch(4, false, true, 2, false, true, 4, true, false);
	}
	@Test
	public void test10626() {
		o.launch(4, false, true, 2, false, true, 4, false, true);
	}
	@Test
	public void test10627() {
		o.launch(4, false, true, 2, false, true, 4, false, false);
	}
	@Test
	public void test10628() {
		o.launch(4, false, true, 2, false, true, 5, true, true);
	}
	@Test
	public void test10629() {
		o.launch(4, false, true, 2, false, true, 5, true, false);
	}
	@Test
	public void test10630() {
		o.launch(4, false, true, 2, false, true, 5, false, true);
	}
	@Test
	public void test10631() {
		o.launch(4, false, true, 2, false, true, 5, false, false);
	}
	@Test
	public void test10632() {
		o.launch(4, false, true, 2, false, false, 0, true, true);
	}
	@Test
	public void test10633() {
		o.launch(4, false, true, 2, false, false, 0, true, false);
	}
	@Test
	public void test10634() {
		o.launch(4, false, true, 2, false, false, 0, false, true);
	}
	@Test
	public void test10635() {
		o.launch(4, false, true, 2, false, false, 0, false, false);
	}
	@Test
	public void test10636() {
		o.launch(4, false, true, 2, false, false, 1, true, true);
	}
	@Test
	public void test10637() {
		o.launch(4, false, true, 2, false, false, 1, true, false);
	}
	@Test
	public void test10638() {
		o.launch(4, false, true, 2, false, false, 1, false, true);
	}
	@Test
	public void test10639() {
		o.launch(4, false, true, 2, false, false, 1, false, false);
	}
	@Test
	public void test10640() {
		o.launch(4, false, true, 2, false, false, 2, true, true);
	}
	@Test
	public void test10641() {
		o.launch(4, false, true, 2, false, false, 2, true, false);
	}
	@Test
	public void test10642() {
		o.launch(4, false, true, 2, false, false, 2, false, true);
	}
	@Test
	public void test10643() {
		o.launch(4, false, true, 2, false, false, 2, false, false);
	}
	@Test
	public void test10644() {
		o.launch(4, false, true, 2, false, false, 3, true, true);
	}
	@Test
	public void test10645() {
		o.launch(4, false, true, 2, false, false, 3, true, false);
	}
	@Test
	public void test10646() {
		o.launch(4, false, true, 2, false, false, 3, false, true);
	}
	@Test
	public void test10647() {
		o.launch(4, false, true, 2, false, false, 3, false, false);
	}
	@Test
	public void test10648() {
		o.launch(4, false, true, 2, false, false, 4, true, true);
	}
	@Test
	public void test10649() {
		o.launch(4, false, true, 2, false, false, 4, true, false);
	}
	@Test
	public void test10650() {
		o.launch(4, false, true, 2, false, false, 4, false, true);
	}
	@Test
	public void test10651() {
		o.launch(4, false, true, 2, false, false, 4, false, false);
	}
	@Test
	public void test10652() {
		o.launch(4, false, true, 2, false, false, 5, true, true);
	}
	@Test
	public void test10653() {
		o.launch(4, false, true, 2, false, false, 5, true, false);
	}
	@Test
	public void test10654() {
		o.launch(4, false, true, 2, false, false, 5, false, true);
	}
	@Test
	public void test10655() {
		o.launch(4, false, true, 2, false, false, 5, false, false);
	}
	@Test
	public void test10656() {
		o.launch(4, false, true, 3, true, true, 0, true, true);
	}
	@Test
	public void test10657() {
		o.launch(4, false, true, 3, true, true, 0, true, false);
	}
	@Test
	public void test10658() {
		o.launch(4, false, true, 3, true, true, 0, false, true);
	}
	@Test
	public void test10659() {
		o.launch(4, false, true, 3, true, true, 0, false, false);
	}
	@Test
	public void test10660() {
		o.launch(4, false, true, 3, true, true, 1, true, true);
	}
	@Test
	public void test10661() {
		o.launch(4, false, true, 3, true, true, 1, true, false);
	}
	@Test
	public void test10662() {
		o.launch(4, false, true, 3, true, true, 1, false, true);
	}
	@Test
	public void test10663() {
		o.launch(4, false, true, 3, true, true, 1, false, false);
	}
	@Test
	public void test10664() {
		o.launch(4, false, true, 3, true, true, 2, true, true);
	}
	@Test
	public void test10665() {
		o.launch(4, false, true, 3, true, true, 2, true, false);
	}
	@Test
	public void test10666() {
		o.launch(4, false, true, 3, true, true, 2, false, true);
	}
	@Test
	public void test10667() {
		o.launch(4, false, true, 3, true, true, 2, false, false);
	}
	@Test
	public void test10668() {
		o.launch(4, false, true, 3, true, true, 3, true, true);
	}
	@Test
	public void test10669() {
		o.launch(4, false, true, 3, true, true, 3, true, false);
	}
	@Test
	public void test10670() {
		o.launch(4, false, true, 3, true, true, 3, false, true);
	}
	@Test
	public void test10671() {
		o.launch(4, false, true, 3, true, true, 3, false, false);
	}
	@Test
	public void test10672() {
		o.launch(4, false, true, 3, true, true, 4, true, true);
	}
	@Test
	public void test10673() {
		o.launch(4, false, true, 3, true, true, 4, true, false);
	}
	@Test
	public void test10674() {
		o.launch(4, false, true, 3, true, true, 4, false, true);
	}
	@Test
	public void test10675() {
		o.launch(4, false, true, 3, true, true, 4, false, false);
	}
	@Test
	public void test10676() {
		o.launch(4, false, true, 3, true, true, 5, true, true);
	}
	@Test
	public void test10677() {
		o.launch(4, false, true, 3, true, true, 5, true, false);
	}
	@Test
	public void test10678() {
		o.launch(4, false, true, 3, true, true, 5, false, true);
	}
	@Test
	public void test10679() {
		o.launch(4, false, true, 3, true, true, 5, false, false);
	}
	@Test
	public void test10680() {
		o.launch(4, false, true, 3, true, false, 0, true, true);
	}
	@Test
	public void test10681() {
		o.launch(4, false, true, 3, true, false, 0, true, false);
	}
	@Test
	public void test10682() {
		o.launch(4, false, true, 3, true, false, 0, false, true);
	}
	@Test
	public void test10683() {
		o.launch(4, false, true, 3, true, false, 0, false, false);
	}
	@Test
	public void test10684() {
		o.launch(4, false, true, 3, true, false, 1, true, true);
	}
	@Test
	public void test10685() {
		o.launch(4, false, true, 3, true, false, 1, true, false);
	}
	@Test
	public void test10686() {
		o.launch(4, false, true, 3, true, false, 1, false, true);
	}
	@Test
	public void test10687() {
		o.launch(4, false, true, 3, true, false, 1, false, false);
	}
	@Test
	public void test10688() {
		o.launch(4, false, true, 3, true, false, 2, true, true);
	}
	@Test
	public void test10689() {
		o.launch(4, false, true, 3, true, false, 2, true, false);
	}
	@Test
	public void test10690() {
		o.launch(4, false, true, 3, true, false, 2, false, true);
	}
	@Test
	public void test10691() {
		o.launch(4, false, true, 3, true, false, 2, false, false);
	}
	@Test
	public void test10692() {
		o.launch(4, false, true, 3, true, false, 3, true, true);
	}
	@Test
	public void test10693() {
		o.launch(4, false, true, 3, true, false, 3, true, false);
	}
	@Test
	public void test10694() {
		o.launch(4, false, true, 3, true, false, 3, false, true);
	}
	@Test
	public void test10695() {
		o.launch(4, false, true, 3, true, false, 3, false, false);
	}
	@Test
	public void test10696() {
		o.launch(4, false, true, 3, true, false, 4, true, true);
	}
	@Test
	public void test10697() {
		o.launch(4, false, true, 3, true, false, 4, true, false);
	}
	@Test
	public void test10698() {
		o.launch(4, false, true, 3, true, false, 4, false, true);
	}
	@Test
	public void test10699() {
		o.launch(4, false, true, 3, true, false, 4, false, false);
	}
	@Test
	public void test10700() {
		o.launch(4, false, true, 3, true, false, 5, true, true);
	}
	@Test
	public void test10701() {
		o.launch(4, false, true, 3, true, false, 5, true, false);
	}
	@Test
	public void test10702() {
		o.launch(4, false, true, 3, true, false, 5, false, true);
	}
	@Test
	public void test10703() {
		o.launch(4, false, true, 3, true, false, 5, false, false);
	}
	@Test
	public void test10704() {
		o.launch(4, false, true, 3, false, true, 0, true, true);
	}
	@Test
	public void test10705() {
		o.launch(4, false, true, 3, false, true, 0, true, false);
	}
	@Test
	public void test10706() {
		o.launch(4, false, true, 3, false, true, 0, false, true);
	}
	@Test
	public void test10707() {
		o.launch(4, false, true, 3, false, true, 0, false, false);
	}
	@Test
	public void test10708() {
		o.launch(4, false, true, 3, false, true, 1, true, true);
	}
	@Test
	public void test10709() {
		o.launch(4, false, true, 3, false, true, 1, true, false);
	}
	@Test
	public void test10710() {
		o.launch(4, false, true, 3, false, true, 1, false, true);
	}
	@Test
	public void test10711() {
		o.launch(4, false, true, 3, false, true, 1, false, false);
	}
	@Test
	public void test10712() {
		o.launch(4, false, true, 3, false, true, 2, true, true);
	}
	@Test
	public void test10713() {
		o.launch(4, false, true, 3, false, true, 2, true, false);
	}
	@Test
	public void test10714() {
		o.launch(4, false, true, 3, false, true, 2, false, true);
	}
	@Test
	public void test10715() {
		o.launch(4, false, true, 3, false, true, 2, false, false);
	}
	@Test
	public void test10716() {
		o.launch(4, false, true, 3, false, true, 3, true, true);
	}
	@Test
	public void test10717() {
		o.launch(4, false, true, 3, false, true, 3, true, false);
	}
	@Test
	public void test10718() {
		o.launch(4, false, true, 3, false, true, 3, false, true);
	}
	@Test
	public void test10719() {
		o.launch(4, false, true, 3, false, true, 3, false, false);
	}
	@Test
	public void test10720() {
		o.launch(4, false, true, 3, false, true, 4, true, true);
	}
	@Test
	public void test10721() {
		o.launch(4, false, true, 3, false, true, 4, true, false);
	}
	@Test
	public void test10722() {
		o.launch(4, false, true, 3, false, true, 4, false, true);
	}
	@Test
	public void test10723() {
		o.launch(4, false, true, 3, false, true, 4, false, false);
	}
	@Test
	public void test10724() {
		o.launch(4, false, true, 3, false, true, 5, true, true);
	}
	@Test
	public void test10725() {
		o.launch(4, false, true, 3, false, true, 5, true, false);
	}
	@Test
	public void test10726() {
		o.launch(4, false, true, 3, false, true, 5, false, true);
	}
	@Test
	public void test10727() {
		o.launch(4, false, true, 3, false, true, 5, false, false);
	}
	@Test
	public void test10728() {
		o.launch(4, false, true, 3, false, false, 0, true, true);
	}
	@Test
	public void test10729() {
		o.launch(4, false, true, 3, false, false, 0, true, false);
	}
	@Test
	public void test10730() {
		o.launch(4, false, true, 3, false, false, 0, false, true);
	}
	@Test
	public void test10731() {
		o.launch(4, false, true, 3, false, false, 0, false, false);
	}
	@Test
	public void test10732() {
		o.launch(4, false, true, 3, false, false, 1, true, true);
	}
	@Test
	public void test10733() {
		o.launch(4, false, true, 3, false, false, 1, true, false);
	}
	@Test
	public void test10734() {
		o.launch(4, false, true, 3, false, false, 1, false, true);
	}
	@Test
	public void test10735() {
		o.launch(4, false, true, 3, false, false, 1, false, false);
	}
	@Test
	public void test10736() {
		o.launch(4, false, true, 3, false, false, 2, true, true);
	}
	@Test
	public void test10737() {
		o.launch(4, false, true, 3, false, false, 2, true, false);
	}
	@Test
	public void test10738() {
		o.launch(4, false, true, 3, false, false, 2, false, true);
	}
	@Test
	public void test10739() {
		o.launch(4, false, true, 3, false, false, 2, false, false);
	}
	@Test
	public void test10740() {
		o.launch(4, false, true, 3, false, false, 3, true, true);
	}
	@Test
	public void test10741() {
		o.launch(4, false, true, 3, false, false, 3, true, false);
	}
	@Test
	public void test10742() {
		o.launch(4, false, true, 3, false, false, 3, false, true);
	}
	@Test
	public void test10743() {
		o.launch(4, false, true, 3, false, false, 3, false, false);
	}
	@Test
	public void test10744() {
		o.launch(4, false, true, 3, false, false, 4, true, true);
	}
	@Test
	public void test10745() {
		o.launch(4, false, true, 3, false, false, 4, true, false);
	}
	@Test
	public void test10746() {
		o.launch(4, false, true, 3, false, false, 4, false, true);
	}
	@Test
	public void test10747() {
		o.launch(4, false, true, 3, false, false, 4, false, false);
	}
	@Test
	public void test10748() {
		o.launch(4, false, true, 3, false, false, 5, true, true);
	}
	@Test
	public void test10749() {
		o.launch(4, false, true, 3, false, false, 5, true, false);
	}
	@Test
	public void test10750() {
		o.launch(4, false, true, 3, false, false, 5, false, true);
	}
	@Test
	public void test10751() {
		o.launch(4, false, true, 3, false, false, 5, false, false);
	}
	@Test
	public void test10752() {
		o.launch(4, false, true, 4, true, true, 0, true, true);
	}
	@Test
	public void test10753() {
		o.launch(4, false, true, 4, true, true, 0, true, false);
	}
	@Test
	public void test10754() {
		o.launch(4, false, true, 4, true, true, 0, false, true);
	}
	@Test
	public void test10755() {
		o.launch(4, false, true, 4, true, true, 0, false, false);
	}
	@Test
	public void test10756() {
		o.launch(4, false, true, 4, true, true, 1, true, true);
	}
	@Test
	public void test10757() {
		o.launch(4, false, true, 4, true, true, 1, true, false);
	}
	@Test
	public void test10758() {
		o.launch(4, false, true, 4, true, true, 1, false, true);
	}
	@Test
	public void test10759() {
		o.launch(4, false, true, 4, true, true, 1, false, false);
	}
	@Test
	public void test10760() {
		o.launch(4, false, true, 4, true, true, 2, true, true);
	}
	@Test
	public void test10761() {
		o.launch(4, false, true, 4, true, true, 2, true, false);
	}
	@Test
	public void test10762() {
		o.launch(4, false, true, 4, true, true, 2, false, true);
	}
	@Test
	public void test10763() {
		o.launch(4, false, true, 4, true, true, 2, false, false);
	}
	@Test
	public void test10764() {
		o.launch(4, false, true, 4, true, true, 3, true, true);
	}
	@Test
	public void test10765() {
		o.launch(4, false, true, 4, true, true, 3, true, false);
	}
	@Test
	public void test10766() {
		o.launch(4, false, true, 4, true, true, 3, false, true);
	}
	@Test
	public void test10767() {
		o.launch(4, false, true, 4, true, true, 3, false, false);
	}
	@Test
	public void test10768() {
		o.launch(4, false, true, 4, true, true, 4, true, true);
	}
	@Test
	public void test10769() {
		o.launch(4, false, true, 4, true, true, 4, true, false);
	}
	@Test
	public void test10770() {
		o.launch(4, false, true, 4, true, true, 4, false, true);
	}
	@Test
	public void test10771() {
		o.launch(4, false, true, 4, true, true, 4, false, false);
	}
	@Test
	public void test10772() {
		o.launch(4, false, true, 4, true, true, 100, true, true);
	}
	@Test
	public void test10773() {
		o.launch(4, false, true, 4, true, true, 5, true, false);
	}
	@Test
	public void test10774() {
		o.launch(4, false, true, 4, true, true, 5, false, true);
	}
	@Test
	public void test10775() {
		o.launch(4, false, true, 4, true, true, 5, false, false);
	}
	@Test
	public void test10776() {
		o.launch(4, false, true, 4, true, false, 0, true, true);
	}
	@Test
	public void test10777() {
		o.launch(4, false, true, 4, true, false, 0, true, false);
	}
	@Test
	public void test10778() {
		o.launch(4, false, true, 4, true, false, 0, false, true);
	}
	@Test
	public void test10779() {
		o.launch(4, false, true, 4, true, false, 0, false, false);
	}
	@Test
	public void test10780() {
		o.launch(4, false, true, 4, true, false, 1, true, true);
	}
	@Test
	public void test10781() {
		o.launch(4, false, true, 4, true, false, 1, true, false);
	}
	@Test
	public void test10782() {
		o.launch(4, false, true, 4, true, false, 1, false, true);
	}
	@Test
	public void test10783() {
		o.launch(4, false, true, 4, true, false, 1, false, false);
	}
	@Test
	public void test10784() {
		o.launch(4, false, true, 4, true, false, 2, true, true);
	}
	@Test
	public void test10785() {
		o.launch(4, false, true, 4, true, false, 2, true, false);
	}
	@Test
	public void test10786() {
		o.launch(4, false, true, 4, true, false, 2, false, true);
	}
	@Test
	public void test10787() {
		o.launch(4, false, true, 4, true, false, 2, false, false);
	}
	@Test
	public void test10788() {
		o.launch(4, false, true, 4, true, false, 3, true, true);
	}
	@Test
	public void test10789() {
		o.launch(4, false, true, 4, true, false, 3, true, false);
	}
	@Test
	public void test10790() {
		o.launch(4, false, true, 4, true, false, 3, false, true);
	}
	@Test
	public void test10791() {
		o.launch(4, false, true, 4, true, false, 3, false, false);
	}
	@Test
	public void test10792() {
		o.launch(4, false, true, 4, true, false, 4, true, true);
	}
	@Test
	public void test10793() {
		o.launch(4, false, true, 4, true, false, 4, true, false);
	}
	@Test
	public void test10794() {
		o.launch(4, false, true, 4, true, false, 4, false, true);
	}
	@Test
	public void test10795() {
		o.launch(4, false, true, 4, true, false, 4, false, false);
	}
	@Test
	public void test10796() {
		o.launch(4, false, true, 4, true, false, 5, true, true);
	}
	@Test
	public void test10797() {
		o.launch(4, false, true, 4, true, false, 5, true, false);
	}
	@Test
	public void test10798() {
		o.launch(4, false, true, 4, true, false, 5, false, true);
	}
	@Test
	public void test10799() {
		o.launch(4, false, true, 4, true, false, 5, false, false);
	}
	@Test
	public void test10800() {
		o.launch(4, false, true, 4, false, true, 0, true, true);
	}
	@Test
	public void test10801() {
		o.launch(4, false, true, 4, false, true, 0, true, false);
	}
	@Test
	public void test10802() {
		o.launch(4, false, true, 4, false, true, 0, false, true);
	}
	@Test
	public void test10803() {
		o.launch(4, false, true, 4, false, true, 0, false, false);
	}
	@Test
	public void test10804() {
		o.launch(4, false, true, 4, false, true, 1, true, true);
	}
	@Test
	public void test10805() {
		o.launch(4, false, true, 4, false, true, 1, true, false);
	}
	@Test
	public void test10806() {
		o.launch(4, false, true, 4, false, true, 1, false, true);
	}
	@Test
	public void test10807() {
		o.launch(4, false, true, 4, false, true, 1, false, false);
	}
	@Test
	public void test10808() {
		o.launch(4, false, true, 4, false, true, 2, true, true);
	}
	@Test
	public void test10809() {
		o.launch(4, false, true, 4, false, true, 2, true, false);
	}
	@Test
	public void test10810() {
		o.launch(4, false, true, 4, false, true, 2, false, true);
	}
	@Test
	public void test10811() {
		o.launch(4, false, true, 4, false, true, 2, false, false);
	}
	@Test
	public void test10812() {
		o.launch(4, false, true, 4, false, true, 3, true, true);
	}
	@Test
	public void test10813() {
		o.launch(4, false, true, 4, false, true, 3, true, false);
	}
	@Test
	public void test10814() {
		o.launch(4, false, true, 4, false, true, 3, false, true);
	}
	@Test
	public void test10815() {
		o.launch(4, false, true, 4, false, true, 3, false, false);
	}
	@Test
	public void test10816() {
		o.launch(4, false, true, 4, false, true, 4, true, true);
	}
	@Test
	public void test10817() {
		o.launch(4, false, true, 4, false, true, 4, true, false);
	}
	@Test
	public void test10818() {
		o.launch(4, false, true, 4, false, true, 4, false, true);
	}
	@Test
	public void test10819() {
		o.launch(4, false, true, 4, false, true, 4, false, false);
	}
	@Test
	public void test10820() {
		o.launch(4, false, true, 4, false, true, 5, true, true);
	}
	@Test
	public void test10821() {
		o.launch(4, false, true, 4, false, true, 5, true, false);
	}
	@Test
	public void test10822() {
		o.launch(4, false, true, 4, false, true, 5, false, true);
	}
	@Test
	public void test10823() {
		o.launch(4, false, true, 4, false, true, 5, false, false);
	}
	@Test
	public void test10824() {
		o.launch(4, false, true, 4, false, false, 0, true, true);
	}
	@Test
	public void test10825() {
		o.launch(4, false, true, 4, false, false, 0, true, false);
	}
	@Test
	public void test10826() {
		o.launch(4, false, true, 4, false, false, 0, false, true);
	}
	@Test
	public void test10827() {
		o.launch(4, false, true, 4, false, false, 0, false, false);
	}
	@Test
	public void test10828() {
		o.launch(4, false, true, 4, false, false, 1, true, true);
	}
	@Test
	public void test10829() {
		o.launch(4, false, true, 4, false, false, 1, true, false);
	}
	@Test
	public void test10830() {
		o.launch(4, false, true, 4, false, false, 1, false, true);
	}
	@Test
	public void test10831() {
		o.launch(4, false, true, 4, false, false, 1, false, false);
	}
	@Test
	public void test10832() {
		o.launch(4, false, true, 4, false, false, 2, true, true);
	}
	@Test
	public void test10833() {
		o.launch(4, false, true, 4, false, false, 2, true, false);
	}
	@Test
	public void test10834() {
		o.launch(4, false, true, 4, false, false, 2, false, true);
	}
	@Test
	public void test10835() {
		o.launch(4, false, true, 4, false, false, 2, false, false);
	}
	@Test
	public void test10836() {
		o.launch(4, false, true, 4, false, false, 3, true, true);
	}
	@Test
	public void test10837() {
		o.launch(4, false, true, 4, false, false, 3, true, false);
	}
	@Test
	public void test10838() {
		o.launch(4, false, true, 4, false, false, 3, false, true);
	}
	@Test
	public void test10839() {
		o.launch(4, false, true, 4, false, false, 3, false, false);
	}
	@Test
	public void test10840() {
		o.launch(4, false, true, 4, false, false, 4, true, true);
	}
	@Test
	public void test10841() {
		o.launch(4, false, true, 4, false, false, 4, true, false);
	}
	@Test
	public void test10842() {
		o.launch(4, false, true, 4, false, false, 4, false, true);
	}
	@Test
	public void test10843() {
		o.launch(4, false, true, 4, false, false, 4, false, false);
	}
	@Test
	public void test10844() {
		o.launch(4, false, true, 4, false, false, 5, true, true);
	}
	@Test
	public void test10845() {
		o.launch(4, false, true, 4, false, false, 5, true, false);
	}
	@Test
	public void test10846() {
		o.launch(4, false, true, 4, false, false, -1, false, true);
	}
	@Test
	public void test10847() {
		o.launch(4, false, true, 4, false, false, 5, false, false);
	}
	@Test
	public void test10848() {
		o.launch(4, false, true, 100, true, true, 0, true, true);
	}
	@Test
	public void test10849() {
		o.launch(4, false, true, -1, true, true, 0, true, false);
	}
	@Test
	public void test10850() {
		o.launch(4, false, true, 100, true, true, 0, false, true);
	}
	@Test
	public void test10851() {
		o.launch(4, false, true, 5, true, true, 0, false, false);
	}
	@Test
	public void test10852() {
		o.launch(4, false, true, 100, true, true, 1, true, true);
	}
	@Test
	public void test10853() {
		o.launch(4, false, true, 5, true, true, 1, true, false);
	}
	@Test
	public void test10854() {
		o.launch(4, false, true, 5, true, true, 1, false, true);
	}
	@Test
	public void test10855() {
		o.launch(4, false, true, 5, true, true, 1, false, false);
	}
	@Test
	public void test10856() {
		o.launch(4, false, true, 5, true, true, 2, true, true);
	}
	@Test
	public void test10857() {
		o.launch(4, false, true, 5, true, true, 2, true, false);
	}
	@Test
	public void test10858() {
		o.launch(4, false, true, 5, true, true, 2, false, true);
	}
	@Test
	public void test10859() {
		o.launch(4, false, true, 5, true, true, 2, false, false);
	}
	@Test
	public void test10860() {
		o.launch(4, false, true, 5, true, true, 3, true, true);
	}
	@Test
	public void test10861() {
		o.launch(4, false, true, 5, true, true, 3, true, false);
	}
	@Test
	public void test10862() {
		o.launch(4, false, true, 5, true, true, 3, false, true);
	}
	@Test
	public void test10863() {
		o.launch(4, false, true, 5, true, true, 3, false, false);
	}
	@Test
	public void test10864() {
		o.launch(4, false, true, 5, true, true, 4, true, true);
	}
	@Test
	public void test10865() {
		o.launch(4, false, true, 5, true, true, 4, true, false);
	}
	@Test
	public void test10866() {
		o.launch(4, false, true, 5, true, true, 4, false, true);
	}
	@Test
	public void test10867() {
		o.launch(4, false, true, 5, true, true, 4, false, false);
	}
	@Test
	public void test10868() {
		o.launch(4, false, true, -1, true, true, 100, true, true);
	}
	@Test
	public void test10869() {
		o.launch(4, false, true, -1, true, true, 10, true, false);
	}
	@Test
	public void test10870() {
		o.launch(4, false, true, -1, true, true, 100, false, true);
	}
	@Test
	public void test10871() {
		o.launch(4, false, true, -1, true, true, 10, false, false);
	}
	@Test
	public void test10872() {
		o.launch(4, false, true, -1, true, false, 0, true, true);
	}
	@Test
	public void test10873() {
		o.launch(4, false, true, 5, true, false, 0, true, false);
	}
	@Test
	public void test10874() {
		o.launch(4, false, true, 10, true, false, 0, false, true);
	}
	@Test
	public void test10875() {
		o.launch(4, false, true, -1, true, false, 0, false, false);
	}
	@Test
	public void test10876() {
		o.launch(4, false, true, 5, true, false, 1, true, true);
	}
	@Test
	public void test10877() {
		o.launch(4, false, true, 10, true, false, 1, true, false);
	}
	@Test
	public void test10878() {
		o.launch(4, false, true, 5, true, false, 1, false, true);
	}
	@Test
	public void test10879() {
		o.launch(4, false, true, 100, true, false, 1, false, false);
	}
	@Test
	public void test10880() {
		o.launch(4, false, true, 5, true, false, 2, true, true);
	}
	@Test
	public void test10881() {
		o.launch(4, false, true, 5, true, false, 2, true, false);
	}
	@Test
	public void test10882() {
		o.launch(4, false, true, 5, true, false, 2, false, true);
	}
	@Test
	public void test10883() {
		o.launch(4, false, true, 5, true, false, 2, false, false);
	}
	@Test
	public void test10884() {
		o.launch(4, false, true, 5, true, false, 3, true, true);
	}
	@Test
	public void test10885() {
		o.launch(4, false, true, 5, true, false, 3, true, false);
	}
	@Test
	public void test10886() {
		o.launch(4, false, true, 5, true, false, 3, false, true);
	}
	@Test
	public void test10887() {
		o.launch(4, false, true, 5, true, false, 3, false, false);
	}
	@Test
	public void test10888() {
		o.launch(4, false, true, 5, true, false, 4, true, true);
	}
	@Test
	public void test10889() {
		o.launch(4, false, true, 100, true, false, 4, true, false);
	}
	@Test
	public void test10890() {
		o.launch(4, false, true, 5, true, false, 4, false, true);
	}
	@Test
	public void test10891() {
		o.launch(4, false, true, 5, true, false, 4, false, false);
	}
	@Test
	public void test10892() {
		o.launch(4, false, true, 10, true, false, -1, true, true);
	}
	@Test
	public void test10893() {
		o.launch(4, false, true, -1, true, false, -1, true, false);
	}
	@Test
	public void test10894() {
		o.launch(4, false, true, -1, true, false, -1, false, true);
	}
	@Test
	public void test10895() {
		o.launch(4, false, true, -1, true, false, 10, false, false);
	}
	@Test
	public void test10896() {
		o.launch(4, false, true, -1, false, true, 0, true, true);
	}
	@Test
	public void test10897() {
		o.launch(4, false, true, 5, false, true, 0, true, false);
	}
	@Test
	public void test10898() {
		o.launch(4, false, true, 100, false, true, 0, false, true);
	}
	@Test
	public void test10899() {
		o.launch(4, false, true, 10, false, true, 0, false, false);
	}
	@Test
	public void test10900() {
		o.launch(4, false, true, 5, false, true, 1, true, true);
	}
	@Test
	public void test10901() {
		o.launch(4, false, true, 5, false, true, 1, true, false);
	}
	@Test
	public void test10902() {
		o.launch(4, false, true, 5, false, true, 1, false, true);
	}
	@Test
	public void test10903() {
		o.launch(4, false, true, 10, false, true, 1, false, false);
	}
	@Test
	public void test10904() {
		o.launch(4, false, true, 5, false, true, 2, true, true);
	}
	@Test
	public void test10905() {
		o.launch(4, false, true, 5, false, true, 2, true, false);
	}
	@Test
	public void test10906() {
		o.launch(4, false, true, 5, false, true, 2, false, true);
	}
	@Test
	public void test10907() {
		o.launch(4, false, true, 5, false, true, 2, false, false);
	}
	@Test
	public void test10908() {
		o.launch(4, false, true, 5, false, true, 3, true, true);
	}
	@Test
	public void test10909() {
		o.launch(4, false, true, 5, false, true, 3, true, false);
	}
	@Test
	public void test10910() {
		o.launch(4, false, true, 5, false, true, 3, false, true);
	}
	@Test
	public void test10911() {
		o.launch(4, false, true, 5, false, true, 3, false, false);
	}
	@Test
	public void test10912() {
		o.launch(4, false, true, -1, false, true, 4, true, true);
	}
	@Test
	public void test10913() {
		o.launch(4, false, true, 10, false, true, 4, true, false);
	}
	@Test
	public void test10914() {
		o.launch(4, false, true, 5, false, true, 4, false, true);
	}
	@Test
	public void test10915() {
		o.launch(4, false, true, -1, false, true, 4, false, false);
	}
	@Test
	public void test10916() {
		o.launch(4, false, true, -1, false, true, -1, true, true);
	}
	@Test
	public void test10917() {
		o.launch(4, false, true, 100, false, true, 10, true, false);
	}
	@Test
	public void test10918() {
		o.launch(4, false, true, -1, false, true, -1, false, true);
	}
	@Test
	public void test10919() {
		o.launch(4, false, true, -1, false, true, -1, false, false);
	}
	@Test
	public void test10920() {
		o.launch(4, false, true, 10, false, false, 0, true, true);
	}
	@Test
	public void test10921() {
		o.launch(4, false, true, -1, false, false, 0, true, false);
	}
	@Test
	public void test10922() {
		o.launch(4, false, true, 10, false, false, 0, false, true);
	}
	@Test
	public void test10923() {
		o.launch(4, false, true, -1, false, false, 0, false, false);
	}
	@Test
	public void test10924() {
		o.launch(4, false, true, 5, false, false, 1, true, true);
	}
	@Test
	public void test10925() {
		o.launch(4, false, true, 10, false, false, 1, true, false);
	}
	@Test
	public void test10926() {
		o.launch(4, false, true, 10, false, false, 1, false, true);
	}
	@Test
	public void test10927() {
		o.launch(4, false, true, 10, false, false, 1, false, false);
	}
	@Test
	public void test10928() {
		o.launch(4, false, true, 5, false, false, 2, true, true);
	}
	@Test
	public void test10929() {
		o.launch(4, false, true, 5, false, false, 2, true, false);
	}
	@Test
	public void test10930() {
		o.launch(4, false, true, 5, false, false, 2, false, true);
	}
	@Test
	public void test10931() {
		o.launch(4, false, true, 5, false, false, 2, false, false);
	}
	@Test
	public void test10932() {
		o.launch(4, false, true, 5, false, false, 3, true, true);
	}
	@Test
	public void test10933() {
		o.launch(4, false, true, 5, false, false, 3, true, false);
	}
	@Test
	public void test10934() {
		o.launch(4, false, true, 5, false, false, 3, false, true);
	}
	@Test
	public void test10935() {
		o.launch(4, false, true, 5, false, false, 3, false, false);
	}
	@Test
	public void test10936() {
		o.launch(4, false, true, 5, false, false, 4, true, true);
	}
	@Test
	public void test10937() {
		o.launch(4, false, true, 5, false, false, 4, true, false);
	}
	@Test
	public void test10938() {
		o.launch(4, false, true, 5, false, false, 4, false, true);
	}
	@Test
	public void test10939() {
		o.launch(4, false, true, 5, false, false, 4, false, false);
	}
	@Test
	public void test10940() {
		o.launch(4, false, true, -1, false, false, 10, true, true);
	}
	@Test
	public void test10941() {
		o.launch(4, false, true, 10, false, false, -1, true, false);
	}
	@Test
	public void test10942() {
		o.launch(4, false, true, -1, false, false, 10, false, true);
	}
	@Test
	public void test10943() {
		o.launch(4, false, true, 100, false, false, 100, false, false);
	}
	@Test
	public void test10944() {
		o.launch(4, false, false, 0, true, true, 0, true, true);
	}
	@Test
	public void test10945() {
		o.launch(4, false, false, 0, true, true, 0, true, false);
	}
	@Test
	public void test10946() {
		o.launch(4, false, false, 0, true, true, 0, false, true);
	}
	@Test
	public void test10947() {
		o.launch(4, false, false, 0, true, true, 0, false, false);
	}
	@Test
	public void test10948() {
		o.launch(4, false, false, 0, true, true, 1, true, true);
	}
	@Test
	public void test10949() {
		o.launch(4, false, false, 0, true, true, 1, true, false);
	}
	@Test
	public void test10950() {
		o.launch(4, false, false, 0, true, true, 1, false, true);
	}
	@Test
	public void test10951() {
		o.launch(4, false, false, 0, true, true, 1, false, false);
	}
	@Test
	public void test10952() {
		o.launch(4, false, false, 0, true, true, 2, true, true);
	}
	@Test
	public void test10953() {
		o.launch(4, false, false, 0, true, true, 2, true, false);
	}
	@Test
	public void test10954() {
		o.launch(4, false, false, 0, true, true, 2, false, true);
	}
	@Test
	public void test10955() {
		o.launch(4, false, false, 0, true, true, 2, false, false);
	}
	@Test
	public void test10956() {
		o.launch(4, false, false, 0, true, true, 3, true, true);
	}
	@Test
	public void test10957() {
		o.launch(4, false, false, 0, true, true, 3, true, false);
	}
	@Test
	public void test10958() {
		o.launch(4, false, false, 0, true, true, 3, false, true);
	}
	@Test
	public void test10959() {
		o.launch(4, false, false, 0, true, true, 3, false, false);
	}
	@Test
	public void test10960() {
		o.launch(4, false, false, 0, true, true, 4, true, true);
	}
	@Test
	public void test10961() {
		o.launch(4, false, false, 0, true, true, 4, true, false);
	}
	@Test
	public void test10962() {
		o.launch(4, false, false, 0, true, true, 4, false, true);
	}
	@Test
	public void test10963() {
		o.launch(4, false, false, 0, true, true, 4, false, false);
	}
	@Test
	public void test10964() {
		o.launch(4, false, false, 0, true, true, -1, true, true);
	}
	@Test
	public void test10965() {
		o.launch(4, false, false, 0, true, true, 10, true, false);
	}
	@Test
	public void test10966() {
		o.launch(4, false, false, 0, true, true, 100, false, true);
	}
	@Test
	public void test10967() {
		o.launch(4, false, false, 0, true, true, -1, false, false);
	}
	@Test
	public void test10968() {
		o.launch(4, false, false, 0, true, false, 0, true, true);
	}
	@Test
	public void test10969() {
		o.launch(4, false, false, 0, true, false, 0, true, false);
	}
	@Test
	public void test10970() {
		o.launch(4, false, false, 0, true, false, 0, false, true);
	}
	@Test
	public void test10971() {
		o.launch(4, false, false, 0, true, false, 0, false, false);
	}
	@Test
	public void test10972() {
		o.launch(4, false, false, 0, true, false, 1, true, true);
	}
	@Test
	public void test10973() {
		o.launch(4, false, false, 0, true, false, 1, true, false);
	}
	@Test
	public void test10974() {
		o.launch(4, false, false, 0, true, false, 1, false, true);
	}
	@Test
	public void test10975() {
		o.launch(4, false, false, 0, true, false, 1, false, false);
	}
	@Test
	public void test10976() {
		o.launch(4, false, false, 0, true, false, 2, true, true);
	}
	@Test
	public void test10977() {
		o.launch(4, false, false, 0, true, false, 2, true, false);
	}
	@Test
	public void test10978() {
		o.launch(4, false, false, 0, true, false, 2, false, true);
	}
	@Test
	public void test10979() {
		o.launch(4, false, false, 0, true, false, 2, false, false);
	}
	@Test
	public void test10980() {
		o.launch(4, false, false, 0, true, false, 3, true, true);
	}
	@Test
	public void test10981() {
		o.launch(4, false, false, 0, true, false, 3, true, false);
	}
	@Test
	public void test10982() {
		o.launch(4, false, false, 0, true, false, 3, false, true);
	}
	@Test
	public void test10983() {
		o.launch(4, false, false, 0, true, false, 3, false, false);
	}
	@Test
	public void test10984() {
		o.launch(4, false, false, 0, true, false, 4, true, true);
	}
	@Test
	public void test10985() {
		o.launch(4, false, false, 0, true, false, 4, true, false);
	}
	@Test
	public void test10986() {
		o.launch(4, false, false, 0, true, false, 4, false, true);
	}
	@Test
	public void test10987() {
		o.launch(4, false, false, 0, true, false, 4, false, false);
	}
	@Test
	public void test10988() {
		o.launch(4, false, false, 0, true, false, 5, true, true);
	}
	@Test
	public void test10989() {
		o.launch(4, false, false, 0, true, false, 5, true, false);
	}
	@Test
	public void test10990() {
		o.launch(4, false, false, 0, true, false, -1, false, true);
	}
	@Test
	public void test10991() {
		o.launch(4, false, false, 0, true, false, -1, false, false);
	}
	@Test
	public void test10992() {
		o.launch(4, false, false, 0, false, true, 0, true, true);
	}
	@Test
	public void test10993() {
		o.launch(4, false, false, 0, false, true, 0, true, false);
	}
	@Test
	public void test10994() {
		o.launch(4, false, false, 0, false, true, 0, false, true);
	}
	@Test
	public void test10995() {
		o.launch(4, false, false, 0, false, true, 0, false, false);
	}
	@Test
	public void test10996() {
		o.launch(4, false, false, 0, false, true, 1, true, true);
	}
	@Test
	public void test10997() {
		o.launch(4, false, false, 0, false, true, 1, true, false);
	}
	@Test
	public void test10998() {
		o.launch(4, false, false, 0, false, true, 1, false, true);
	}
	@Test
	public void test10999() {
		o.launch(4, false, false, 0, false, true, 1, false, false);
	}
	@Test
	public void test11000() {
		o.launch(4, false, false, 0, false, true, 2, true, true);
	}
	@Test
	public void test11001() {
		o.launch(4, false, false, 0, false, true, 2, true, false);
	}
	@Test
	public void test11002() {
		o.launch(4, false, false, 0, false, true, 2, false, true);
	}
	@Test
	public void test11003() {
		o.launch(4, false, false, 0, false, true, 2, false, false);
	}
	@Test
	public void test11004() {
		o.launch(4, false, false, 0, false, true, 3, true, true);
	}
	@Test
	public void test11005() {
		o.launch(4, false, false, 0, false, true, 3, true, false);
	}
	@Test
	public void test11006() {
		o.launch(4, false, false, 0, false, true, 3, false, true);
	}
	@Test
	public void test11007() {
		o.launch(4, false, false, 0, false, true, 3, false, false);
	}
	@Test
	public void test11008() {
		o.launch(4, false, false, 0, false, true, 4, true, true);
	}
	@Test
	public void test11009() {
		o.launch(4, false, false, 0, false, true, 4, true, false);
	}
	@Test
	public void test11010() {
		o.launch(4, false, false, 0, false, true, 4, false, true);
	}
	@Test
	public void test11011() {
		o.launch(4, false, false, 0, false, true, 4, false, false);
	}
	@Test
	public void test11012() {
		o.launch(4, false, false, 0, false, true, -1, true, true);
	}
	@Test
	public void test11013() {
		o.launch(4, false, false, 0, false, true, 5, true, false);
	}
	@Test
	public void test11014() {
		o.launch(4, false, false, 0, false, true, 5, false, true);
	}
	@Test
	public void test11015() {
		o.launch(4, false, false, 0, false, true, 5, false, false);
	}
	@Test
	public void test11016() {
		o.launch(4, false, false, 0, false, false, 0, true, true);
	}
	@Test
	public void test11017() {
		o.launch(4, false, false, 0, false, false, 0, true, false);
	}
	@Test
	public void test11018() {
		o.launch(4, false, false, 0, false, false, 0, false, true);
	}
	@Test
	public void test11019() {
		o.launch(4, false, false, 0, false, false, 0, false, false);
	}
	@Test
	public void test11020() {
		o.launch(4, false, false, 0, false, false, 1, true, true);
	}
	@Test
	public void test11021() {
		o.launch(4, false, false, 0, false, false, 1, true, false);
	}
	@Test
	public void test11022() {
		o.launch(4, false, false, 0, false, false, 1, false, true);
	}
	@Test
	public void test11023() {
		o.launch(4, false, false, 0, false, false, 1, false, false);
	}
	@Test
	public void test11024() {
		o.launch(4, false, false, 0, false, false, 2, true, true);
	}
	@Test
	public void test11025() {
		o.launch(4, false, false, 0, false, false, 2, true, false);
	}
	@Test
	public void test11026() {
		o.launch(4, false, false, 0, false, false, 2, false, true);
	}
	@Test
	public void test11027() {
		o.launch(4, false, false, 0, false, false, 2, false, false);
	}
	@Test
	public void test11028() {
		o.launch(4, false, false, 0, false, false, 3, true, true);
	}
	@Test
	public void test11029() {
		o.launch(4, false, false, 0, false, false, 3, true, false);
	}
	@Test
	public void test11030() {
		o.launch(4, false, false, 0, false, false, 3, false, true);
	}
	@Test
	public void test11031() {
		o.launch(4, false, false, 0, false, false, 3, false, false);
	}
	@Test
	public void test11032() {
		o.launch(4, false, false, 0, false, false, 4, true, true);
	}
	@Test
	public void test11033() {
		o.launch(4, false, false, 0, false, false, 4, true, false);
	}
	@Test
	public void test11034() {
		o.launch(4, false, false, 0, false, false, 4, false, true);
	}
	@Test
	public void test11035() {
		o.launch(4, false, false, 0, false, false, 4, false, false);
	}
	@Test
	public void test11036() {
		o.launch(4, false, false, 0, false, false, 5, true, true);
	}
	@Test
	public void test11037() {
		o.launch(4, false, false, 0, false, false, 10, true, false);
	}
	@Test
	public void test11038() {
		o.launch(4, false, false, 0, false, false, 100, false, true);
	}
	@Test
	public void test11039() {
		o.launch(4, false, false, 0, false, false, 5, false, false);
	}
	@Test
	public void test11040() {
		o.launch(4, false, false, 1, true, true, 0, true, true);
	}
	@Test
	public void test11041() {
		o.launch(4, false, false, 1, true, true, 0, true, false);
	}
	@Test
	public void test11042() {
		o.launch(4, false, false, 1, true, true, 0, false, true);
	}
	@Test
	public void test11043() {
		o.launch(4, false, false, 1, true, true, 0, false, false);
	}
	@Test
	public void test11044() {
		o.launch(4, false, false, 1, true, true, 1, true, true);
	}
	@Test
	public void test11045() {
		o.launch(4, false, false, 1, true, true, 1, true, false);
	}
	@Test
	public void test11046() {
		o.launch(4, false, false, 1, true, true, 1, false, true);
	}
	@Test
	public void test11047() {
		o.launch(4, false, false, 1, true, true, 1, false, false);
	}
	@Test
	public void test11048() {
		o.launch(4, false, false, 1, true, true, 2, true, true);
	}
	@Test
	public void test11049() {
		o.launch(4, false, false, 1, true, true, 2, true, false);
	}
	@Test
	public void test11050() {
		o.launch(4, false, false, 1, true, true, 2, false, true);
	}
	@Test
	public void test11051() {
		o.launch(4, false, false, 1, true, true, 2, false, false);
	}
	@Test
	public void test11052() {
		o.launch(4, false, false, 1, true, true, 3, true, true);
	}
	@Test
	public void test11053() {
		o.launch(4, false, false, 1, true, true, 3, true, false);
	}
	@Test
	public void test11054() {
		o.launch(4, false, false, 1, true, true, 3, false, true);
	}
	@Test
	public void test11055() {
		o.launch(4, false, false, 1, true, true, 3, false, false);
	}
	@Test
	public void test11056() {
		o.launch(4, false, false, 1, true, true, 4, true, true);
	}
	@Test
	public void test11057() {
		o.launch(4, false, false, 1, true, true, 4, true, false);
	}
	@Test
	public void test11058() {
		o.launch(4, false, false, 1, true, true, 4, false, true);
	}
	@Test
	public void test11059() {
		o.launch(4, false, false, 1, true, true, 4, false, false);
	}
	@Test
	public void test11060() {
		o.launch(4, false, false, 1, true, true, 5, true, true);
	}
	@Test
	public void test11061() {
		o.launch(4, false, false, 1, true, true, 5, true, false);
	}
	@Test
	public void test11062() {
		o.launch(4, false, false, 1, true, true, 5, false, true);
	}
	@Test
	public void test11063() {
		o.launch(4, false, false, 1, true, true, -1, false, false);
	}
	@Test
	public void test11064() {
		o.launch(4, false, false, 1, true, false, 0, true, true);
	}
	@Test
	public void test11065() {
		o.launch(4, false, false, 1, true, false, 0, true, false);
	}
	@Test
	public void test11066() {
		o.launch(4, false, false, 1, true, false, 0, false, true);
	}
	@Test
	public void test11067() {
		o.launch(4, false, false, 1, true, false, 0, false, false);
	}
	@Test
	public void test11068() {
		o.launch(4, false, false, 1, true, false, 1, true, true);
	}
	@Test
	public void test11069() {
		o.launch(4, false, false, 1, true, false, 1, true, false);
	}
	@Test
	public void test11070() {
		o.launch(4, false, false, 1, true, false, 1, false, true);
	}
	@Test
	public void test11071() {
		o.launch(4, false, false, 1, true, false, 1, false, false);
	}
	@Test
	public void test11072() {
		o.launch(4, false, false, 1, true, false, 2, true, true);
	}
	@Test
	public void test11073() {
		o.launch(4, false, false, 1, true, false, 2, true, false);
	}
	@Test
	public void test11074() {
		o.launch(4, false, false, 1, true, false, 2, false, true);
	}
	@Test
	public void test11075() {
		o.launch(4, false, false, 1, true, false, 2, false, false);
	}
	@Test
	public void test11076() {
		o.launch(4, false, false, 1, true, false, 3, true, true);
	}
	@Test
	public void test11077() {
		o.launch(4, false, false, 1, true, false, 3, true, false);
	}
	@Test
	public void test11078() {
		o.launch(4, false, false, 1, true, false, 3, false, true);
	}
	@Test
	public void test11079() {
		o.launch(4, false, false, 1, true, false, 3, false, false);
	}
	@Test
	public void test11080() {
		o.launch(4, false, false, 1, true, false, 4, true, true);
	}
	@Test
	public void test11081() {
		o.launch(4, false, false, 1, true, false, 4, true, false);
	}
	@Test
	public void test11082() {
		o.launch(4, false, false, 1, true, false, 4, false, true);
	}
	@Test
	public void test11083() {
		o.launch(4, false, false, 1, true, false, 4, false, false);
	}
	@Test
	public void test11084() {
		o.launch(4, false, false, 1, true, false, 5, true, true);
	}
	@Test
	public void test11085() {
		o.launch(4, false, false, 1, true, false, 5, true, false);
	}
	@Test
	public void test11086() {
		o.launch(4, false, false, 1, true, false, 10, false, true);
	}
	@Test
	public void test11087() {
		o.launch(4, false, false, 1, true, false, -1, false, false);
	}
	@Test
	public void test11088() {
		o.launch(4, false, false, 1, false, true, 0, true, true);
	}
	@Test
	public void test11089() {
		o.launch(4, false, false, 1, false, true, 0, true, false);
	}
	@Test
	public void test11090() {
		o.launch(4, false, false, 1, false, true, 0, false, true);
	}
	@Test
	public void test11091() {
		o.launch(4, false, false, 1, false, true, 0, false, false);
	}
	@Test
	public void test11092() {
		o.launch(4, false, false, 1, false, true, 1, true, true);
	}
	@Test
	public void test11093() {
		o.launch(4, false, false, 1, false, true, 1, true, false);
	}
	@Test
	public void test11094() {
		o.launch(4, false, false, 1, false, true, 1, false, true);
	}
	@Test
	public void test11095() {
		o.launch(4, false, false, 1, false, true, 1, false, false);
	}
	@Test
	public void test11096() {
		o.launch(4, false, false, 1, false, true, 2, true, true);
	}
	@Test
	public void test11097() {
		o.launch(4, false, false, 1, false, true, 2, true, false);
	}
	@Test
	public void test11098() {
		o.launch(4, false, false, 1, false, true, 2, false, true);
	}
	@Test
	public void test11099() {
		o.launch(4, false, false, 1, false, true, 2, false, false);
	}
	@Test
	public void test11100() {
		o.launch(4, false, false, 1, false, true, 3, true, true);
	}
	@Test
	public void test11101() {
		o.launch(4, false, false, 1, false, true, 3, true, false);
	}
	@Test
	public void test11102() {
		o.launch(4, false, false, 1, false, true, 3, false, true);
	}
	@Test
	public void test11103() {
		o.launch(4, false, false, 1, false, true, 3, false, false);
	}
	@Test
	public void test11104() {
		o.launch(4, false, false, 1, false, true, 4, true, true);
	}
	@Test
	public void test11105() {
		o.launch(4, false, false, 1, false, true, 4, true, false);
	}
	@Test
	public void test11106() {
		o.launch(4, false, false, 1, false, true, 4, false, true);
	}
	@Test
	public void test11107() {
		o.launch(4, false, false, 1, false, true, 4, false, false);
	}
	@Test
	public void test11108() {
		o.launch(4, false, false, 1, false, true, 5, true, true);
	}
	@Test
	public void test11109() {
		o.launch(4, false, false, 1, false, true, 100, true, false);
	}
	@Test
	public void test11110() {
		o.launch(4, false, false, 1, false, true, 5, false, true);
	}
	@Test
	public void test11111() {
		o.launch(4, false, false, 1, false, true, 5, false, false);
	}
	@Test
	public void test11112() {
		o.launch(4, false, false, 1, false, false, 0, true, true);
	}
	@Test
	public void test11113() {
		o.launch(4, false, false, 1, false, false, 0, true, false);
	}
	@Test
	public void test11114() {
		o.launch(4, false, false, 1, false, false, 0, false, true);
	}
	@Test
	public void test11115() {
		o.launch(4, false, false, 1, false, false, 0, false, false);
	}
	@Test
	public void test11116() {
		o.launch(4, false, false, 1, false, false, 1, true, true);
	}
	@Test
	public void test11117() {
		o.launch(4, false, false, 1, false, false, 1, true, false);
	}
	@Test
	public void test11118() {
		o.launch(4, false, false, 1, false, false, 1, false, true);
	}
	@Test
	public void test11119() {
		o.launch(4, false, false, 1, false, false, 1, false, false);
	}
	@Test
	public void test11120() {
		o.launch(4, false, false, 1, false, false, 2, true, true);
	}
	@Test
	public void test11121() {
		o.launch(4, false, false, 1, false, false, 2, true, false);
	}
	@Test
	public void test11122() {
		o.launch(4, false, false, 1, false, false, 2, false, true);
	}
	@Test
	public void test11123() {
		o.launch(4, false, false, 1, false, false, 2, false, false);
	}
	@Test
	public void test11124() {
		o.launch(4, false, false, 1, false, false, 3, true, true);
	}
	@Test
	public void test11125() {
		o.launch(4, false, false, 1, false, false, 3, true, false);
	}
	@Test
	public void test11126() {
		o.launch(4, false, false, 1, false, false, 3, false, true);
	}
	@Test
	public void test11127() {
		o.launch(4, false, false, 1, false, false, 3, false, false);
	}
	@Test
	public void test11128() {
		o.launch(4, false, false, 1, false, false, 4, true, true);
	}
	@Test
	public void test11129() {
		o.launch(4, false, false, 1, false, false, 4, true, false);
	}
	@Test
	public void test11130() {
		o.launch(4, false, false, 1, false, false, 4, false, true);
	}
	@Test
	public void test11131() {
		o.launch(4, false, false, 1, false, false, 4, false, false);
	}
	@Test
	public void test11132() {
		o.launch(4, false, false, 1, false, false, 5, true, true);
	}
	@Test
	public void test11133() {
		o.launch(4, false, false, 1, false, false, -1, true, false);
	}
	@Test
	public void test11134() {
		o.launch(4, false, false, 1, false, false, 100, false, true);
	}
	@Test
	public void test11135() {
		o.launch(4, false, false, 1, false, false, -1, false, false);
	}
	@Test
	public void test11136() {
		o.launch(4, false, false, 2, true, true, 0, true, true);
	}
	@Test
	public void test11137() {
		o.launch(4, false, false, 2, true, true, 0, true, false);
	}
	@Test
	public void test11138() {
		o.launch(4, false, false, 2, true, true, 0, false, true);
	}
	@Test
	public void test11139() {
		o.launch(4, false, false, 2, true, true, 0, false, false);
	}
	@Test
	public void test11140() {
		o.launch(4, false, false, 2, true, true, 1, true, true);
	}
	@Test
	public void test11141() {
		o.launch(4, false, false, 2, true, true, 1, true, false);
	}
	@Test
	public void test11142() {
		o.launch(4, false, false, 2, true, true, 1, false, true);
	}
	@Test
	public void test11143() {
		o.launch(4, false, false, 2, true, true, 1, false, false);
	}
	@Test
	public void test11144() {
		o.launch(4, false, false, 2, true, true, 2, true, true);
	}
	@Test
	public void test11145() {
		o.launch(4, false, false, 2, true, true, 2, true, false);
	}
	@Test
	public void test11146() {
		o.launch(4, false, false, 2, true, true, 2, false, true);
	}
	@Test
	public void test11147() {
		o.launch(4, false, false, 2, true, true, 2, false, false);
	}
	@Test
	public void test11148() {
		o.launch(4, false, false, 2, true, true, 3, true, true);
	}
	@Test
	public void test11149() {
		o.launch(4, false, false, 2, true, true, 3, true, false);
	}
	@Test
	public void test11150() {
		o.launch(4, false, false, 2, true, true, 3, false, true);
	}
	@Test
	public void test11151() {
		o.launch(4, false, false, 2, true, true, 3, false, false);
	}
	@Test
	public void test11152() {
		o.launch(4, false, false, 2, true, true, 4, true, true);
	}
	@Test
	public void test11153() {
		o.launch(4, false, false, 2, true, true, 4, true, false);
	}
	@Test
	public void test11154() {
		o.launch(4, false, false, 2, true, true, 4, false, true);
	}
	@Test
	public void test11155() {
		o.launch(4, false, false, 2, true, true, 4, false, false);
	}
	@Test
	public void test11156() {
		o.launch(4, false, false, 2, true, true, 5, true, true);
	}
	@Test
	public void test11157() {
		o.launch(4, false, false, 2, true, true, 5, true, false);
	}
	@Test
	public void test11158() {
		o.launch(4, false, false, 2, true, true, 5, false, true);
	}
	@Test
	public void test11159() {
		o.launch(4, false, false, 2, true, true, 5, false, false);
	}
	@Test
	public void test11160() {
		o.launch(4, false, false, 2, true, false, 0, true, true);
	}
	@Test
	public void test11161() {
		o.launch(4, false, false, 2, true, false, 0, true, false);
	}
	@Test
	public void test11162() {
		o.launch(4, false, false, 2, true, false, 0, false, true);
	}
	@Test
	public void test11163() {
		o.launch(4, false, false, 2, true, false, 0, false, false);
	}
	@Test
	public void test11164() {
		o.launch(4, false, false, 2, true, false, 1, true, true);
	}
	@Test
	public void test11165() {
		o.launch(4, false, false, 2, true, false, 1, true, false);
	}
	@Test
	public void test11166() {
		o.launch(4, false, false, 2, true, false, 1, false, true);
	}
	@Test
	public void test11167() {
		o.launch(4, false, false, 2, true, false, 1, false, false);
	}
	@Test
	public void test11168() {
		o.launch(4, false, false, 2, true, false, 2, true, true);
	}
	@Test
	public void test11169() {
		o.launch(4, false, false, 2, true, false, 2, true, false);
	}
	@Test
	public void test11170() {
		o.launch(4, false, false, 2, true, false, 2, false, true);
	}
	@Test
	public void test11171() {
		o.launch(4, false, false, 2, true, false, 2, false, false);
	}
	@Test
	public void test11172() {
		o.launch(4, false, false, 2, true, false, 3, true, true);
	}
	@Test
	public void test11173() {
		o.launch(4, false, false, 2, true, false, 3, true, false);
	}
	@Test
	public void test11174() {
		o.launch(4, false, false, 2, true, false, 3, false, true);
	}
	@Test
	public void test11175() {
		o.launch(4, false, false, 2, true, false, 3, false, false);
	}
	@Test
	public void test11176() {
		o.launch(4, false, false, 2, true, false, 4, true, true);
	}
	@Test
	public void test11177() {
		o.launch(4, false, false, 2, true, false, 4, true, false);
	}
	@Test
	public void test11178() {
		o.launch(4, false, false, 2, true, false, 4, false, true);
	}
	@Test
	public void test11179() {
		o.launch(4, false, false, 2, true, false, 4, false, false);
	}
	@Test
	public void test11180() {
		o.launch(4, false, false, 2, true, false, 5, true, true);
	}
	@Test
	public void test11181() {
		o.launch(4, false, false, 2, true, false, 5, true, false);
	}
	@Test
	public void test11182() {
		o.launch(4, false, false, 2, true, false, 5, false, true);
	}
	@Test
	public void test11183() {
		o.launch(4, false, false, 2, true, false, 5, false, false);
	}
	@Test
	public void test11184() {
		o.launch(4, false, false, 2, false, true, 0, true, true);
	}
	@Test
	public void test11185() {
		o.launch(4, false, false, 2, false, true, 0, true, false);
	}
	@Test
	public void test11186() {
		o.launch(4, false, false, 2, false, true, 0, false, true);
	}
	@Test
	public void test11187() {
		o.launch(4, false, false, 2, false, true, 0, false, false);
	}
	@Test
	public void test11188() {
		o.launch(4, false, false, 2, false, true, 1, true, true);
	}
	@Test
	public void test11189() {
		o.launch(4, false, false, 2, false, true, 1, true, false);
	}
	@Test
	public void test11190() {
		o.launch(4, false, false, 2, false, true, 1, false, true);
	}
	@Test
	public void test11191() {
		o.launch(4, false, false, 2, false, true, 1, false, false);
	}
	@Test
	public void test11192() {
		o.launch(4, false, false, 2, false, true, 2, true, true);
	}
	@Test
	public void test11193() {
		o.launch(4, false, false, 2, false, true, 2, true, false);
	}
	@Test
	public void test11194() {
		o.launch(4, false, false, 2, false, true, 2, false, true);
	}
	@Test
	public void test11195() {
		o.launch(4, false, false, 2, false, true, 2, false, false);
	}
	@Test
	public void test11196() {
		o.launch(4, false, false, 2, false, true, 3, true, true);
	}
	@Test
	public void test11197() {
		o.launch(4, false, false, 2, false, true, 3, true, false);
	}
	@Test
	public void test11198() {
		o.launch(4, false, false, 2, false, true, 3, false, true);
	}
	@Test
	public void test11199() {
		o.launch(4, false, false, 2, false, true, 3, false, false);
	}
	@Test
	public void test11200() {
		o.launch(4, false, false, 2, false, true, 4, true, true);
	}
	@Test
	public void test11201() {
		o.launch(4, false, false, 2, false, true, 4, true, false);
	}
	@Test
	public void test11202() {
		o.launch(4, false, false, 2, false, true, 4, false, true);
	}
	@Test
	public void test11203() {
		o.launch(4, false, false, 2, false, true, 4, false, false);
	}
	@Test
	public void test11204() {
		o.launch(4, false, false, 2, false, true, 5, true, true);
	}
	@Test
	public void test11205() {
		o.launch(4, false, false, 2, false, true, 5, true, false);
	}
	@Test
	public void test11206() {
		o.launch(4, false, false, 2, false, true, 5, false, true);
	}
	@Test
	public void test11207() {
		o.launch(4, false, false, 2, false, true, 5, false, false);
	}
	@Test
	public void test11208() {
		o.launch(4, false, false, 2, false, false, 0, true, true);
	}
	@Test
	public void test11209() {
		o.launch(4, false, false, 2, false, false, 0, true, false);
	}
	@Test
	public void test11210() {
		o.launch(4, false, false, 2, false, false, 0, false, true);
	}
	@Test
	public void test11211() {
		o.launch(4, false, false, 2, false, false, 0, false, false);
	}
	@Test
	public void test11212() {
		o.launch(4, false, false, 2, false, false, 1, true, true);
	}
	@Test
	public void test11213() {
		o.launch(4, false, false, 2, false, false, 1, true, false);
	}
	@Test
	public void test11214() {
		o.launch(4, false, false, 2, false, false, 1, false, true);
	}
	@Test
	public void test11215() {
		o.launch(4, false, false, 2, false, false, 1, false, false);
	}
	@Test
	public void test11216() {
		o.launch(4, false, false, 2, false, false, 2, true, true);
	}
	@Test
	public void test11217() {
		o.launch(4, false, false, 2, false, false, 2, true, false);
	}
	@Test
	public void test11218() {
		o.launch(4, false, false, 2, false, false, 2, false, true);
	}
	@Test
	public void test11219() {
		o.launch(4, false, false, 2, false, false, 2, false, false);
	}
	@Test
	public void test11220() {
		o.launch(4, false, false, 2, false, false, 3, true, true);
	}
	@Test
	public void test11221() {
		o.launch(4, false, false, 2, false, false, 3, true, false);
	}
	@Test
	public void test11222() {
		o.launch(4, false, false, 2, false, false, 3, false, true);
	}
	@Test
	public void test11223() {
		o.launch(4, false, false, 2, false, false, 3, false, false);
	}
	@Test
	public void test11224() {
		o.launch(4, false, false, 2, false, false, 4, true, true);
	}
	@Test
	public void test11225() {
		o.launch(4, false, false, 2, false, false, 4, true, false);
	}
	@Test
	public void test11226() {
		o.launch(4, false, false, 2, false, false, 4, false, true);
	}
	@Test
	public void test11227() {
		o.launch(4, false, false, 2, false, false, 4, false, false);
	}
	@Test
	public void test11228() {
		o.launch(4, false, false, 2, false, false, 5, true, true);
	}
	@Test
	public void test11229() {
		o.launch(4, false, false, 2, false, false, 5, true, false);
	}
	@Test
	public void test11230() {
		o.launch(4, false, false, 2, false, false, 5, false, true);
	}
	@Test
	public void test11231() {
		o.launch(4, false, false, 2, false, false, 5, false, false);
	}
	@Test
	public void test11232() {
		o.launch(4, false, false, 3, true, true, 0, true, true);
	}
	@Test
	public void test11233() {
		o.launch(4, false, false, 3, true, true, 0, true, false);
	}
	@Test
	public void test11234() {
		o.launch(4, false, false, 3, true, true, 0, false, true);
	}
	@Test
	public void test11235() {
		o.launch(4, false, false, 3, true, true, 0, false, false);
	}
	@Test
	public void test11236() {
		o.launch(4, false, false, 3, true, true, 1, true, true);
	}
	@Test
	public void test11237() {
		o.launch(4, false, false, 3, true, true, 1, true, false);
	}
	@Test
	public void test11238() {
		o.launch(4, false, false, 3, true, true, 1, false, true);
	}
	@Test
	public void test11239() {
		o.launch(4, false, false, 3, true, true, 1, false, false);
	}
	@Test
	public void test11240() {
		o.launch(4, false, false, 3, true, true, 2, true, true);
	}
	@Test
	public void test11241() {
		o.launch(4, false, false, 3, true, true, 2, true, false);
	}
	@Test
	public void test11242() {
		o.launch(4, false, false, 3, true, true, 2, false, true);
	}
	@Test
	public void test11243() {
		o.launch(4, false, false, 3, true, true, 2, false, false);
	}
	@Test
	public void test11244() {
		o.launch(4, false, false, 3, true, true, 3, true, true);
	}
	@Test
	public void test11245() {
		o.launch(4, false, false, 3, true, true, 3, true, false);
	}
	@Test
	public void test11246() {
		o.launch(4, false, false, 3, true, true, 3, false, true);
	}
	@Test
	public void test11247() {
		o.launch(4, false, false, 3, true, true, 3, false, false);
	}
	@Test
	public void test11248() {
		o.launch(4, false, false, 3, true, true, 4, true, true);
	}
	@Test
	public void test11249() {
		o.launch(4, false, false, 3, true, true, 4, true, false);
	}
	@Test
	public void test11250() {
		o.launch(4, false, false, 3, true, true, 4, false, true);
	}
	@Test
	public void test11251() {
		o.launch(4, false, false, 3, true, true, 4, false, false);
	}
	@Test
	public void test11252() {
		o.launch(4, false, false, 3, true, true, 5, true, true);
	}
	@Test
	public void test11253() {
		o.launch(4, false, false, 3, true, true, 5, true, false);
	}
	@Test
	public void test11254() {
		o.launch(4, false, false, 3, true, true, 5, false, true);
	}
	@Test
	public void test11255() {
		o.launch(4, false, false, 3, true, true, 5, false, false);
	}
	@Test
	public void test11256() {
		o.launch(4, false, false, 3, true, false, 0, true, true);
	}
	@Test
	public void test11257() {
		o.launch(4, false, false, 3, true, false, 0, true, false);
	}
	@Test
	public void test11258() {
		o.launch(4, false, false, 3, true, false, 0, false, true);
	}
	@Test
	public void test11259() {
		o.launch(4, false, false, 3, true, false, 0, false, false);
	}
	@Test
	public void test11260() {
		o.launch(4, false, false, 3, true, false, 1, true, true);
	}
	@Test
	public void test11261() {
		o.launch(4, false, false, 3, true, false, 1, true, false);
	}
	@Test
	public void test11262() {
		o.launch(4, false, false, 3, true, false, 1, false, true);
	}
	@Test
	public void test11263() {
		o.launch(4, false, false, 3, true, false, 1, false, false);
	}
	@Test
	public void test11264() {
		o.launch(4, false, false, 3, true, false, 2, true, true);
	}
	@Test
	public void test11265() {
		o.launch(4, false, false, 3, true, false, 2, true, false);
	}
	@Test
	public void test11266() {
		o.launch(4, false, false, 3, true, false, 2, false, true);
	}
	@Test
	public void test11267() {
		o.launch(4, false, false, 3, true, false, 2, false, false);
	}
	@Test
	public void test11268() {
		o.launch(4, false, false, 3, true, false, 3, true, true);
	}
	@Test
	public void test11269() {
		o.launch(4, false, false, 3, true, false, 3, true, false);
	}
	@Test
	public void test11270() {
		o.launch(4, false, false, 3, true, false, 3, false, true);
	}
	@Test
	public void test11271() {
		o.launch(4, false, false, 3, true, false, 3, false, false);
	}
	@Test
	public void test11272() {
		o.launch(4, false, false, 3, true, false, 4, true, true);
	}
	@Test
	public void test11273() {
		o.launch(4, false, false, 3, true, false, 4, true, false);
	}
	@Test
	public void test11274() {
		o.launch(4, false, false, 3, true, false, 4, false, true);
	}
	@Test
	public void test11275() {
		o.launch(4, false, false, 3, true, false, 4, false, false);
	}
	@Test
	public void test11276() {
		o.launch(4, false, false, 3, true, false, 5, true, true);
	}
	@Test
	public void test11277() {
		o.launch(4, false, false, 3, true, false, 5, true, false);
	}
	@Test
	public void test11278() {
		o.launch(4, false, false, 3, true, false, 5, false, true);
	}
	@Test
	public void test11279() {
		o.launch(4, false, false, 3, true, false, 5, false, false);
	}
	@Test
	public void test11280() {
		o.launch(4, false, false, 3, false, true, 0, true, true);
	}
	@Test
	public void test11281() {
		o.launch(4, false, false, 3, false, true, 0, true, false);
	}
	@Test
	public void test11282() {
		o.launch(4, false, false, 3, false, true, 0, false, true);
	}
	@Test
	public void test11283() {
		o.launch(4, false, false, 3, false, true, 0, false, false);
	}
	@Test
	public void test11284() {
		o.launch(4, false, false, 3, false, true, 1, true, true);
	}
	@Test
	public void test11285() {
		o.launch(4, false, false, 3, false, true, 1, true, false);
	}
	@Test
	public void test11286() {
		o.launch(4, false, false, 3, false, true, 1, false, true);
	}
	@Test
	public void test11287() {
		o.launch(4, false, false, 3, false, true, 1, false, false);
	}
	@Test
	public void test11288() {
		o.launch(4, false, false, 3, false, true, 2, true, true);
	}
	@Test
	public void test11289() {
		o.launch(4, false, false, 3, false, true, 2, true, false);
	}
	@Test
	public void test11290() {
		o.launch(4, false, false, 3, false, true, 2, false, true);
	}
	@Test
	public void test11291() {
		o.launch(4, false, false, 3, false, true, 2, false, false);
	}
	@Test
	public void test11292() {
		o.launch(4, false, false, 3, false, true, 3, true, true);
	}
	@Test
	public void test11293() {
		o.launch(4, false, false, 3, false, true, 3, true, false);
	}
	@Test
	public void test11294() {
		o.launch(4, false, false, 3, false, true, 3, false, true);
	}
	@Test
	public void test11295() {
		o.launch(4, false, false, 3, false, true, 3, false, false);
	}
	@Test
	public void test11296() {
		o.launch(4, false, false, 3, false, true, 4, true, true);
	}
	@Test
	public void test11297() {
		o.launch(4, false, false, 3, false, true, 4, true, false);
	}
	@Test
	public void test11298() {
		o.launch(4, false, false, 3, false, true, 4, false, true);
	}
	@Test
	public void test11299() {
		o.launch(4, false, false, 3, false, true, 4, false, false);
	}
	@Test
	public void test11300() {
		o.launch(4, false, false, 3, false, true, 5, true, true);
	}
	@Test
	public void test11301() {
		o.launch(4, false, false, 3, false, true, 5, true, false);
	}
	@Test
	public void test11302() {
		o.launch(4, false, false, 3, false, true, 5, false, true);
	}
	@Test
	public void test11303() {
		o.launch(4, false, false, 3, false, true, 5, false, false);
	}
	@Test
	public void test11304() {
		o.launch(4, false, false, 3, false, false, 0, true, true);
	}
	@Test
	public void test11305() {
		o.launch(4, false, false, 3, false, false, 0, true, false);
	}
	@Test
	public void test11306() {
		o.launch(4, false, false, 3, false, false, 0, false, true);
	}
	@Test
	public void test11307() {
		o.launch(4, false, false, 3, false, false, 0, false, false);
	}
	@Test
	public void test11308() {
		o.launch(4, false, false, 3, false, false, 1, true, true);
	}
	@Test
	public void test11309() {
		o.launch(4, false, false, 3, false, false, 1, true, false);
	}
	@Test
	public void test11310() {
		o.launch(4, false, false, 3, false, false, 1, false, true);
	}
	@Test
	public void test11311() {
		o.launch(4, false, false, 3, false, false, 1, false, false);
	}
	@Test
	public void test11312() {
		o.launch(4, false, false, 3, false, false, 2, true, true);
	}
	@Test
	public void test11313() {
		o.launch(4, false, false, 3, false, false, 2, true, false);
	}
	@Test
	public void test11314() {
		o.launch(4, false, false, 3, false, false, 2, false, true);
	}
	@Test
	public void test11315() {
		o.launch(4, false, false, 3, false, false, 2, false, false);
	}
	@Test
	public void test11316() {
		o.launch(4, false, false, 3, false, false, 3, true, true);
	}
	@Test
	public void test11317() {
		o.launch(4, false, false, 3, false, false, 3, true, false);
	}
	@Test
	public void test11318() {
		o.launch(4, false, false, 3, false, false, 3, false, true);
	}
	@Test
	public void test11319() {
		o.launch(4, false, false, 3, false, false, 3, false, false);
	}
	@Test
	public void test11320() {
		o.launch(4, false, false, 3, false, false, 4, true, true);
	}
	@Test
	public void test11321() {
		o.launch(4, false, false, 3, false, false, 4, true, false);
	}
	@Test
	public void test11322() {
		o.launch(4, false, false, 3, false, false, 4, false, true);
	}
	@Test
	public void test11323() {
		o.launch(4, false, false, 3, false, false, 4, false, false);
	}
	@Test
	public void test11324() {
		o.launch(4, false, false, 3, false, false, 5, true, true);
	}
	@Test
	public void test11325() {
		o.launch(4, false, false, 3, false, false, 5, true, false);
	}
	@Test
	public void test11326() {
		o.launch(4, false, false, 3, false, false, 5, false, true);
	}
	@Test
	public void test11327() {
		o.launch(4, false, false, 3, false, false, 5, false, false);
	}
	@Test
	public void test11328() {
		o.launch(4, false, false, 4, true, true, 0, true, true);
	}
	@Test
	public void test11329() {
		o.launch(4, false, false, 4, true, true, 0, true, false);
	}
	@Test
	public void test11330() {
		o.launch(4, false, false, 4, true, true, 0, false, true);
	}
	@Test
	public void test11331() {
		o.launch(4, false, false, 4, true, true, 0, false, false);
	}
	@Test
	public void test11332() {
		o.launch(4, false, false, 4, true, true, 1, true, true);
	}
	@Test
	public void test11333() {
		o.launch(4, false, false, 4, true, true, 1, true, false);
	}
	@Test
	public void test11334() {
		o.launch(4, false, false, 4, true, true, 1, false, true);
	}
	@Test
	public void test11335() {
		o.launch(4, false, false, 4, true, true, 1, false, false);
	}
	@Test
	public void test11336() {
		o.launch(4, false, false, 4, true, true, 2, true, true);
	}
	@Test
	public void test11337() {
		o.launch(4, false, false, 4, true, true, 2, true, false);
	}
	@Test
	public void test11338() {
		o.launch(4, false, false, 4, true, true, 2, false, true);
	}
	@Test
	public void test11339() {
		o.launch(4, false, false, 4, true, true, 2, false, false);
	}
	@Test
	public void test11340() {
		o.launch(4, false, false, 4, true, true, 3, true, true);
	}
	@Test
	public void test11341() {
		o.launch(4, false, false, 4, true, true, 3, true, false);
	}
	@Test
	public void test11342() {
		o.launch(4, false, false, 4, true, true, 3, false, true);
	}
	@Test
	public void test11343() {
		o.launch(4, false, false, 4, true, true, 3, false, false);
	}
	@Test
	public void test11344() {
		o.launch(4, false, false, 4, true, true, 4, true, true);
	}
	@Test
	public void test11345() {
		o.launch(4, false, false, 4, true, true, 4, true, false);
	}
	@Test
	public void test11346() {
		o.launch(4, false, false, 4, true, true, 4, false, true);
	}
	@Test
	public void test11347() {
		o.launch(4, false, false, 4, true, true, 4, false, false);
	}
	@Test
	public void test11348() {
		o.launch(4, false, false, 4, true, true, 5, true, true);
	}
	@Test
	public void test11349() {
		o.launch(4, false, false, 4, true, true, 5, true, false);
	}
	@Test
	public void test11350() {
		o.launch(4, false, false, 4, true, true, 5, false, true);
	}
	@Test
	public void test11351() {
		o.launch(4, false, false, 4, true, true, 5, false, false);
	}
	@Test
	public void test11352() {
		o.launch(4, false, false, 4, true, false, 0, true, true);
	}
	@Test
	public void test11353() {
		o.launch(4, false, false, 4, true, false, 0, true, false);
	}
	@Test
	public void test11354() {
		o.launch(4, false, false, 4, true, false, 0, false, true);
	}
	@Test
	public void test11355() {
		o.launch(4, false, false, 4, true, false, 0, false, false);
	}
	@Test
	public void test11356() {
		o.launch(4, false, false, 4, true, false, 1, true, true);
	}
	@Test
	public void test11357() {
		o.launch(4, false, false, 4, true, false, 1, true, false);
	}
	@Test
	public void test11358() {
		o.launch(4, false, false, 4, true, false, 1, false, true);
	}
	@Test
	public void test11359() {
		o.launch(4, false, false, 4, true, false, 1, false, false);
	}
	@Test
	public void test11360() {
		o.launch(4, false, false, 4, true, false, 2, true, true);
	}
	@Test
	public void test11361() {
		o.launch(4, false, false, 4, true, false, 2, true, false);
	}
	@Test
	public void test11362() {
		o.launch(4, false, false, 4, true, false, 2, false, true);
	}
	@Test
	public void test11363() {
		o.launch(4, false, false, 4, true, false, 2, false, false);
	}
	@Test
	public void test11364() {
		o.launch(4, false, false, 4, true, false, 3, true, true);
	}
	@Test
	public void test11365() {
		o.launch(4, false, false, 4, true, false, 3, true, false);
	}
	@Test
	public void test11366() {
		o.launch(4, false, false, 4, true, false, 3, false, true);
	}
	@Test
	public void test11367() {
		o.launch(4, false, false, 4, true, false, 3, false, false);
	}
	@Test
	public void test11368() {
		o.launch(4, false, false, 4, true, false, 4, true, true);
	}
	@Test
	public void test11369() {
		o.launch(4, false, false, 4, true, false, 4, true, false);
	}
	@Test
	public void test11370() {
		o.launch(4, false, false, 4, true, false, 4, false, true);
	}
	@Test
	public void test11371() {
		o.launch(4, false, false, 4, true, false, 4, false, false);
	}
	@Test
	public void test11372() {
		o.launch(4, false, false, 4, true, false, 5, true, true);
	}
	@Test
	public void test11373() {
		o.launch(4, false, false, 4, true, false, 100, true, false);
	}
	@Test
	public void test11374() {
		o.launch(4, false, false, 4, true, false, 100, false, true);
	}
	@Test
	public void test11375() {
		o.launch(4, false, false, 4, true, false, 5, false, false);
	}
	@Test
	public void test11376() {
		o.launch(4, false, false, 4, false, true, 0, true, true);
	}
	@Test
	public void test11377() {
		o.launch(4, false, false, 4, false, true, 0, true, false);
	}
	@Test
	public void test11378() {
		o.launch(4, false, false, 4, false, true, 0, false, true);
	}
	@Test
	public void test11379() {
		o.launch(4, false, false, 4, false, true, 0, false, false);
	}
	@Test
	public void test11380() {
		o.launch(4, false, false, 4, false, true, 1, true, true);
	}
	@Test
	public void test11381() {
		o.launch(4, false, false, 4, false, true, 1, true, false);
	}
	@Test
	public void test11382() {
		o.launch(4, false, false, 4, false, true, 1, false, true);
	}
	@Test
	public void test11383() {
		o.launch(4, false, false, 4, false, true, 1, false, false);
	}
	@Test
	public void test11384() {
		o.launch(4, false, false, 4, false, true, 2, true, true);
	}
	@Test
	public void test11385() {
		o.launch(4, false, false, 4, false, true, 2, true, false);
	}
	@Test
	public void test11386() {
		o.launch(4, false, false, 4, false, true, 2, false, true);
	}
	@Test
	public void test11387() {
		o.launch(4, false, false, 4, false, true, 2, false, false);
	}
	@Test
	public void test11388() {
		o.launch(4, false, false, 4, false, true, 3, true, true);
	}
	@Test
	public void test11389() {
		o.launch(4, false, false, 4, false, true, 3, true, false);
	}
	@Test
	public void test11390() {
		o.launch(4, false, false, 4, false, true, 3, false, true);
	}
	@Test
	public void test11391() {
		o.launch(4, false, false, 4, false, true, 3, false, false);
	}
	@Test
	public void test11392() {
		o.launch(4, false, false, 4, false, true, 4, true, true);
	}
	@Test
	public void test11393() {
		o.launch(4, false, false, 4, false, true, 4, true, false);
	}
	@Test
	public void test11394() {
		o.launch(4, false, false, 4, false, true, 4, false, true);
	}
	@Test
	public void test11395() {
		o.launch(4, false, false, 4, false, true, 4, false, false);
	}
	@Test
	public void test11396() {
		o.launch(4, false, false, 4, false, true, 5, true, true);
	}
	@Test
	public void test11397() {
		o.launch(4, false, false, 4, false, true, -1, true, false);
	}
	@Test
	public void test11398() {
		o.launch(4, false, false, 4, false, true, 10, false, true);
	}
	@Test
	public void test11399() {
		o.launch(4, false, false, 4, false, true, 5, false, false);
	}
	@Test
	public void test11400() {
		o.launch(4, false, false, 4, false, false, 0, true, true);
	}
	@Test
	public void test11401() {
		o.launch(4, false, false, 4, false, false, 0, true, false);
	}
	@Test
	public void test11402() {
		o.launch(4, false, false, 4, false, false, 0, false, true);
	}
	@Test
	public void test11403() {
		o.launch(4, false, false, 4, false, false, 0, false, false);
	}
	@Test
	public void test11404() {
		o.launch(4, false, false, 4, false, false, 1, true, true);
	}
	@Test
	public void test11405() {
		o.launch(4, false, false, 4, false, false, 1, true, false);
	}
	@Test
	public void test11406() {
		o.launch(4, false, false, 4, false, false, 1, false, true);
	}
	@Test
	public void test11407() {
		o.launch(4, false, false, 4, false, false, 1, false, false);
	}
	@Test
	public void test11408() {
		o.launch(4, false, false, 4, false, false, 2, true, true);
	}
	@Test
	public void test11409() {
		o.launch(4, false, false, 4, false, false, 2, true, false);
	}
	@Test
	public void test11410() {
		o.launch(4, false, false, 4, false, false, 2, false, true);
	}
	@Test
	public void test11411() {
		o.launch(4, false, false, 4, false, false, 2, false, false);
	}
	@Test
	public void test11412() {
		o.launch(4, false, false, 4, false, false, 3, true, true);
	}
	@Test
	public void test11413() {
		o.launch(4, false, false, 4, false, false, 3, true, false);
	}
	@Test
	public void test11414() {
		o.launch(4, false, false, 4, false, false, 3, false, true);
	}
	@Test
	public void test11415() {
		o.launch(4, false, false, 4, false, false, 3, false, false);
	}
	@Test
	public void test11416() {
		o.launch(4, false, false, 4, false, false, 4, true, true);
	}
	@Test
	public void test11417() {
		o.launch(4, false, false, 4, false, false, 4, true, false);
	}
	@Test
	public void test11418() {
		o.launch(4, false, false, 4, false, false, 4, false, true);
	}
	@Test
	public void test11419() {
		o.launch(4, false, false, 4, false, false, 4, false, false);
	}
	@Test
	public void test11420() {
		o.launch(4, false, false, 4, false, false, 100, true, true);
	}
	@Test
	public void test11421() {
		o.launch(4, false, false, 4, false, false, 5, true, false);
	}
	@Test
	public void test11422() {
		o.launch(4, false, false, 4, false, false, 5, false, true);
	}
	@Test
	public void test11423() {
		o.launch(4, false, false, 4, false, false, -1, false, false);
	}
	@Test
	public void test11424() {
		o.launch(4, false, false, 5, true, true, 0, true, true);
	}
	@Test
	public void test11425() {
		o.launch(4, false, false, 5, true, true, 0, true, false);
	}
	@Test
	public void test11426() {
		o.launch(4, false, false, 5, true, true, 0, false, true);
	}
	@Test
	public void test11427() {
		o.launch(4, false, false, 5, true, true, 0, false, false);
	}
	@Test
	public void test11428() {
		o.launch(4, false, false, 5, true, true, 1, true, true);
	}
	@Test
	public void test11429() {
		o.launch(4, false, false, -1, true, true, 1, true, false);
	}
	@Test
	public void test11430() {
		o.launch(4, false, false, 100, true, true, 1, false, true);
	}
	@Test
	public void test11431() {
		o.launch(4, false, false, 5, true, true, 1, false, false);
	}
	@Test
	public void test11432() {
		o.launch(4, false, false, 5, true, true, 2, true, true);
	}
	@Test
	public void test11433() {
		o.launch(4, false, false, 5, true, true, 2, true, false);
	}
	@Test
	public void test11434() {
		o.launch(4, false, false, 5, true, true, 2, false, true);
	}
	@Test
	public void test11435() {
		o.launch(4, false, false, 5, true, true, 2, false, false);
	}
	@Test
	public void test11436() {
		o.launch(4, false, false, 5, true, true, 3, true, true);
	}
	@Test
	public void test11437() {
		o.launch(4, false, false, 5, true, true, 3, true, false);
	}
	@Test
	public void test11438() {
		o.launch(4, false, false, 5, true, true, 3, false, true);
	}
	@Test
	public void test11439() {
		o.launch(4, false, false, 5, true, true, 3, false, false);
	}
	@Test
	public void test11440() {
		o.launch(4, false, false, 5, true, true, 4, true, true);
	}
	@Test
	public void test11441() {
		o.launch(4, false, false, -1, true, true, 4, true, false);
	}
	@Test
	public void test11442() {
		o.launch(4, false, false, 10, true, true, 4, false, true);
	}
	@Test
	public void test11443() {
		o.launch(4, false, false, 5, true, true, 4, false, false);
	}
	@Test
	public void test11444() {
		o.launch(4, false, false, 100, true, true, 10, true, true);
	}
	@Test
	public void test11445() {
		o.launch(4, false, false, -1, true, true, -1, true, false);
	}
	@Test
	public void test11446() {
		o.launch(4, false, false, 100, true, true, 100, false, true);
	}
	@Test
	public void test11447() {
		o.launch(4, false, false, 10, true, true, 100, false, false);
	}
	@Test
	public void test11448() {
		o.launch(4, false, false, 5, true, false, 0, true, true);
	}
	@Test
	public void test11449() {
		o.launch(4, false, false, 5, true, false, 0, true, false);
	}
	@Test
	public void test11450() {
		o.launch(4, false, false, -1, true, false, 0, false, true);
	}
	@Test
	public void test11451() {
		o.launch(4, false, false, 5, true, false, 0, false, false);
	}
	@Test
	public void test11452() {
		o.launch(4, false, false, 5, true, false, 1, true, true);
	}
	@Test
	public void test11453() {
		o.launch(4, false, false, 5, true, false, 1, true, false);
	}
	@Test
	public void test11454() {
		o.launch(4, false, false, 5, true, false, 1, false, true);
	}
	@Test
	public void test11455() {
		o.launch(4, false, false, 10, true, false, 1, false, false);
	}
	@Test
	public void test11456() {
		o.launch(4, false, false, 5, true, false, 2, true, true);
	}
	@Test
	public void test11457() {
		o.launch(4, false, false, 5, true, false, 2, true, false);
	}
	@Test
	public void test11458() {
		o.launch(4, false, false, 5, true, false, 2, false, true);
	}
	@Test
	public void test11459() {
		o.launch(4, false, false, 5, true, false, 2, false, false);
	}
	@Test
	public void test11460() {
		o.launch(4, false, false, 5, true, false, 3, true, true);
	}
	@Test
	public void test11461() {
		o.launch(4, false, false, 5, true, false, 3, true, false);
	}
	@Test
	public void test11462() {
		o.launch(4, false, false, 5, true, false, 3, false, true);
	}
	@Test
	public void test11463() {
		o.launch(4, false, false, 5, true, false, 3, false, false);
	}
	@Test
	public void test11464() {
		o.launch(4, false, false, -1, true, false, 4, true, true);
	}
	@Test
	public void test11465() {
		o.launch(4, false, false, 5, true, false, 4, true, false);
	}
	@Test
	public void test11466() {
		o.launch(4, false, false, 5, true, false, 4, false, true);
	}
	@Test
	public void test11467() {
		o.launch(4, false, false, 5, true, false, 4, false, false);
	}
	@Test
	public void test11468() {
		o.launch(4, false, false, 10, true, false, -1, true, true);
	}
	@Test
	public void test11469() {
		o.launch(4, false, false, 10, true, false, -1, true, false);
	}
	@Test
	public void test11470() {
		o.launch(4, false, false, 100, true, false, -1, false, true);
	}
	@Test
	public void test11471() {
		o.launch(4, false, false, 100, true, false, 10, false, false);
	}
	@Test
	public void test11472() {
		o.launch(4, false, false, 10, false, true, 0, true, true);
	}
	@Test
	public void test11473() {
		o.launch(4, false, false, 5, false, true, 0, true, false);
	}
	@Test
	public void test11474() {
		o.launch(4, false, false, 100, false, true, 0, false, true);
	}
	@Test
	public void test11475() {
		o.launch(4, false, false, 5, false, true, 0, false, false);
	}
	@Test
	public void test11476() {
		o.launch(4, false, false, 100, false, true, 1, true, true);
	}
	@Test
	public void test11477() {
		o.launch(4, false, false, 5, false, true, 1, true, false);
	}
	@Test
	public void test11478() {
		o.launch(4, false, false, 5, false, true, 1, false, true);
	}
	@Test
	public void test11479() {
		o.launch(4, false, false, 10, false, true, 1, false, false);
	}
	@Test
	public void test11480() {
		o.launch(4, false, false, 5, false, true, 2, true, true);
	}
	@Test
	public void test11481() {
		o.launch(4, false, false, 5, false, true, 2, true, false);
	}
	@Test
	public void test11482() {
		o.launch(4, false, false, 5, false, true, 2, false, true);
	}
	@Test
	public void test11483() {
		o.launch(4, false, false, 5, false, true, 2, false, false);
	}
	@Test
	public void test11484() {
		o.launch(4, false, false, 5, false, true, 3, true, true);
	}
	@Test
	public void test11485() {
		o.launch(4, false, false, 5, false, true, 3, true, false);
	}
	@Test
	public void test11486() {
		o.launch(4, false, false, 5, false, true, 3, false, true);
	}
	@Test
	public void test11487() {
		o.launch(4, false, false, 5, false, true, 3, false, false);
	}
	@Test
	public void test11488() {
		o.launch(4, false, false, 5, false, true, 4, true, true);
	}
	@Test
	public void test11489() {
		o.launch(4, false, false, 5, false, true, 4, true, false);
	}
	@Test
	public void test11490() {
		o.launch(4, false, false, -1, false, true, 4, false, true);
	}
	@Test
	public void test11491() {
		o.launch(4, false, false, -1, false, true, 4, false, false);
	}
	@Test
	public void test11492() {
		o.launch(4, false, false, 10, false, true, 100, true, true);
	}
	@Test
	public void test11493() {
		o.launch(4, false, false, -1, false, true, -1, true, false);
	}
	@Test
	public void test11494() {
		o.launch(4, false, false, 10, false, true, 100, false, true);
	}
	@Test
	public void test11495() {
		o.launch(4, false, false, -1, false, true, 100, false, false);
	}
	@Test
	public void test11496() {
		o.launch(4, false, false, -1, false, false, 0, true, true);
	}
	@Test
	public void test11497() {
		o.launch(4, false, false, -1, false, false, 0, true, false);
	}
	@Test
	public void test11498() {
		o.launch(4, false, false, 10, false, false, 0, false, true);
	}
	@Test
	public void test11499() {
		o.launch(4, false, false, 100, false, false, 0, false, false);
	}
	@Test
	public void test11500() {
		o.launch(4, false, false, 5, false, false, 1, true, true);
	}
	@Test
	public void test11501() {
		o.launch(4, false, false, 5, false, false, 1, true, false);
	}
	@Test
	public void test11502() {
		o.launch(4, false, false, 10, false, false, 1, false, true);
	}
	@Test
	public void test11503() {
		o.launch(4, false, false, 100, false, false, 1, false, false);
	}
	@Test
	public void test11504() {
		o.launch(4, false, false, 5, false, false, 2, true, true);
	}
	@Test
	public void test11505() {
		o.launch(4, false, false, 5, false, false, 2, true, false);
	}
	@Test
	public void test11506() {
		o.launch(4, false, false, 5, false, false, 2, false, true);
	}
	@Test
	public void test11507() {
		o.launch(4, false, false, 5, false, false, 2, false, false);
	}
	@Test
	public void test11508() {
		o.launch(4, false, false, 5, false, false, 3, true, true);
	}
	@Test
	public void test11509() {
		o.launch(4, false, false, 5, false, false, 3, true, false);
	}
	@Test
	public void test11510() {
		o.launch(4, false, false, 5, false, false, 3, false, true);
	}
	@Test
	public void test11511() {
		o.launch(4, false, false, 5, false, false, 3, false, false);
	}
	@Test
	public void test11512() {
		o.launch(4, false, false, 5, false, false, 4, true, true);
	}
	@Test
	public void test11513() {
		o.launch(4, false, false, 5, false, false, 4, true, false);
	}
	@Test
	public void test11514() {
		o.launch(4, false, false, 5, false, false, 4, false, true);
	}
	@Test
	public void test11515() {
		o.launch(4, false, false, 10, false, false, 4, false, false);
	}
	@Test
	public void test11516() {
		o.launch(4, false, false, 100, false, false, -1, true, true);
	}
	@Test
	public void test11517() {
		o.launch(4, false, false, 100, false, false, -1, true, false);
	}
	@Test
	public void test11518() {
		o.launch(4, false, false, 10, false, false, 100, false, true);
	}
	@Test
	public void test11519() {
		o.launch(4, false, false, 10, false, false, 10, false, false);
	}
	@Test
	public void test11520() {
		o.launch(10, true, true, 0, true, true, 0, true, true);
	}
	@Test
	public void test11521() {
		o.launch(-1, true, true, 0, true, true, 0, true, false);
	}
	@Test
	public void test11522() {
		o.launch(-1, true, true, 0, true, true, 0, false, true);
	}
	@Test
	public void test11523() {
		o.launch(-1, true, true, 0, true, true, 0, false, false);
	}
	@Test
	public void test11524() {
		o.launch(-1, true, true, 0, true, true, 1, true, true);
	}
	@Test
	public void test11525() {
		o.launch(100, true, true, 0, true, true, 1, true, false);
	}
	@Test
	public void test11526() {
		o.launch(10, true, true, 0, true, true, 1, false, true);
	}
	@Test
	public void test11527() {
		o.launch(-1, true, true, 0, true, true, 1, false, false);
	}
	@Test
	public void test11528() {
		o.launch(5, true, true, 0, true, true, 2, true, true);
	}
	@Test
	public void test11529() {
		o.launch(5, true, true, 0, true, true, 2, true, false);
	}
	@Test
	public void test11530() {
		o.launch(5, true, true, 0, true, true, 2, false, true);
	}
	@Test
	public void test11531() {
		o.launch(5, true, true, 0, true, true, 2, false, false);
	}
	@Test
	public void test11532() {
		o.launch(5, true, true, 0, true, true, 3, true, true);
	}
	@Test
	public void test11533() {
		o.launch(5, true, true, 0, true, true, 3, true, false);
	}
	@Test
	public void test11534() {
		o.launch(5, true, true, 0, true, true, 3, false, true);
	}
	@Test
	public void test11535() {
		o.launch(5, true, true, 0, true, true, 3, false, false);
	}
	@Test
	public void test11536() {
		o.launch(100, true, true, 0, true, true, 4, true, true);
	}
	@Test
	public void test11537() {
		o.launch(-1, true, true, 0, true, true, 4, true, false);
	}
	@Test
	public void test11538() {
		o.launch(10, true, true, 0, true, true, 4, false, true);
	}
	@Test
	public void test11539() {
		o.launch(5, true, true, 0, true, true, 4, false, false);
	}
	@Test
	public void test11540() {
		o.launch(10, true, true, 0, true, true, -1, true, true);
	}
	@Test
	public void test11541() {
		o.launch(10, true, true, 0, true, true, -1, true, false);
	}
	@Test
	public void test11542() {
		o.launch(10, true, true, 0, true, true, -1, false, true);
	}
	@Test
	public void test11543() {
		o.launch(10, true, true, 0, true, true, -1, false, false);
	}
	@Test
	public void test11544() {
		o.launch(10, true, true, 0, true, false, 0, true, true);
	}
	@Test
	public void test11545() {
		o.launch(-1, true, true, 0, true, false, 0, true, false);
	}
	@Test
	public void test11546() {
		o.launch(10, true, true, 0, true, false, 0, false, true);
	}
	@Test
	public void test11547() {
		o.launch(5, true, true, 0, true, false, 0, false, false);
	}
	@Test
	public void test11548() {
		o.launch(10, true, true, 0, true, false, 1, true, true);
	}
	@Test
	public void test11549() {
		o.launch(-1, true, true, 0, true, false, 1, true, false);
	}
	@Test
	public void test11550() {
		o.launch(-1, true, true, 0, true, false, 1, false, true);
	}
	@Test
	public void test11551() {
		o.launch(10, true, true, 0, true, false, 1, false, false);
	}
	@Test
	public void test11552() {
		o.launch(5, true, true, 0, true, false, 2, true, true);
	}
	@Test
	public void test11553() {
		o.launch(5, true, true, 0, true, false, 2, true, false);
	}
	@Test
	public void test11554() {
		o.launch(5, true, true, 0, true, false, 2, false, true);
	}
	@Test
	public void test11555() {
		o.launch(5, true, true, 0, true, false, 2, false, false);
	}
	@Test
	public void test11556() {
		o.launch(5, true, true, 0, true, false, 3, true, true);
	}
	@Test
	public void test11557() {
		o.launch(5, true, true, 0, true, false, 3, true, false);
	}
	@Test
	public void test11558() {
		o.launch(5, true, true, 0, true, false, 3, false, true);
	}
	@Test
	public void test11559() {
		o.launch(5, true, true, 0, true, false, 3, false, false);
	}
	@Test
	public void test11560() {
		o.launch(5, true, true, 0, true, false, 4, true, true);
	}
	@Test
	public void test11561() {
		o.launch(5, true, true, 0, true, false, 4, true, false);
	}
	@Test
	public void test11562() {
		o.launch(-1, true, true, 0, true, false, 4, false, true);
	}
	@Test
	public void test11563() {
		o.launch(-1, true, true, 0, true, false, 4, false, false);
	}
	@Test
	public void test11564() {
		o.launch(10, true, true, 0, true, false, 10, true, true);
	}
	@Test
	public void test11565() {
		o.launch(-1, true, true, 0, true, false, 100, true, false);
	}
	@Test
	public void test11566() {
		o.launch(10, true, true, 0, true, false, 10, false, true);
	}
	@Test
	public void test11567() {
		o.launch(10, true, true, 0, true, false, 10, false, false);
	}
	@Test
	public void test11568() {
		o.launch(-1, true, true, 0, false, true, 0, true, true);
	}
	@Test
	public void test11569() {
		o.launch(-1, true, true, 0, false, true, 0, true, false);
	}
	@Test
	public void test11570() {
		o.launch(100, true, true, 0, false, true, 0, false, true);
	}
	@Test
	public void test11571() {
		o.launch(-1, true, true, 0, false, true, 0, false, false);
	}
	@Test
	public void test11572() {
		o.launch(10, true, true, 0, false, true, 1, true, true);
	}
	@Test
	public void test11573() {
		o.launch(-1, true, true, 0, false, true, 1, true, false);
	}
	@Test
	public void test11574() {
		o.launch(10, true, true, 0, false, true, 1, false, true);
	}
	@Test
	public void test11575() {
		o.launch(10, true, true, 0, false, true, 1, false, false);
	}
	@Test
	public void test11576() {
		o.launch(5, true, true, 0, false, true, 2, true, true);
	}
	@Test
	public void test11577() {
		o.launch(5, true, true, 0, false, true, 2, true, false);
	}
	@Test
	public void test11578() {
		o.launch(5, true, true, 0, false, true, 2, false, true);
	}
	@Test
	public void test11579() {
		o.launch(5, true, true, 0, false, true, 2, false, false);
	}
	@Test
	public void test11580() {
		o.launch(5, true, true, 0, false, true, 3, true, true);
	}
	@Test
	public void test11581() {
		o.launch(5, true, true, 0, false, true, 3, true, false);
	}
	@Test
	public void test11582() {
		o.launch(5, true, true, 0, false, true, 3, false, true);
	}
	@Test
	public void test11583() {
		o.launch(5, true, true, 0, false, true, 3, false, false);
	}
	@Test
	public void test11584() {
		o.launch(5, true, true, 0, false, true, 4, true, true);
	}
	@Test
	public void test11585() {
		o.launch(100, true, true, 0, false, true, 4, true, false);
	}
	@Test
	public void test11586() {
		o.launch(10, true, true, 0, false, true, 4, false, true);
	}
	@Test
	public void test11587() {
		o.launch(100, true, true, 0, false, true, 4, false, false);
	}
	@Test
	public void test11588() {
		o.launch(-1, true, true, 0, false, true, -1, true, true);
	}
	@Test
	public void test11589() {
		o.launch(10, true, true, 0, false, true, -1, true, false);
	}
	@Test
	public void test11590() {
		o.launch(-1, true, true, 0, false, true, -1, false, true);
	}
	@Test
	public void test11591() {
		o.launch(100, true, true, 0, false, true, -1, false, false);
	}
	@Test
	public void test11592() {
		o.launch(-1, true, true, 0, false, false, 0, true, true);
	}
	@Test
	public void test11593() {
		o.launch(-1, true, true, 0, false, false, 0, true, false);
	}
	@Test
	public void test11594() {
		o.launch(-1, true, true, 0, false, false, 0, false, true);
	}
	@Test
	public void test11595() {
		o.launch(-1, true, true, 0, false, false, 0, false, false);
	}
	@Test
	public void test11596() {
		o.launch(100, true, true, 0, false, false, 1, true, true);
	}
	@Test
	public void test11597() {
		o.launch(100, true, true, 0, false, false, 1, true, false);
	}
	@Test
	public void test11598() {
		o.launch(10, true, true, 0, false, false, 1, false, true);
	}
	@Test
	public void test11599() {
		o.launch(100, true, true, 0, false, false, 1, false, false);
	}
	@Test
	public void test11600() {
		o.launch(5, true, true, 0, false, false, 2, true, true);
	}
	@Test
	public void test11601() {
		o.launch(5, true, true, 0, false, false, 2, true, false);
	}
	@Test
	public void test11602() {
		o.launch(5, true, true, 0, false, false, 2, false, true);
	}
	@Test
	public void test11603() {
		o.launch(5, true, true, 0, false, false, 2, false, false);
	}
	@Test
	public void test11604() {
		o.launch(5, true, true, 0, false, false, 3, true, true);
	}
	@Test
	public void test11605() {
		o.launch(5, true, true, 0, false, false, 3, true, false);
	}
	@Test
	public void test11606() {
		o.launch(5, true, true, 0, false, false, 3, false, true);
	}
	@Test
	public void test11607() {
		o.launch(5, true, true, 0, false, false, 3, false, false);
	}
	@Test
	public void test11608() {
		o.launch(10, true, true, 0, false, false, 4, true, true);
	}
	@Test
	public void test11609() {
		o.launch(100, true, true, 0, false, false, 4, true, false);
	}
	@Test
	public void test11610() {
		o.launch(5, true, true, 0, false, false, 4, false, true);
	}
	@Test
	public void test11611() {
		o.launch(-1, true, true, 0, false, false, 4, false, false);
	}
	@Test
	public void test11612() {
		o.launch(-1, true, true, 0, false, false, 100, true, true);
	}
	@Test
	public void test11613() {
		o.launch(-1, true, true, 0, false, false, 10, true, false);
	}
	@Test
	public void test11614() {
		o.launch(100, true, true, 0, false, false, 100, false, true);
	}
	@Test
	public void test11615() {
		o.launch(10, true, true, 0, false, false, 100, false, false);
	}
	@Test
	public void test11616() {
		o.launch(5, true, true, 1, true, true, 0, true, true);
	}
	@Test
	public void test11617() {
		o.launch(-1, true, true, 1, true, true, 0, true, false);
	}
	@Test
	public void test11618() {
		o.launch(100, true, true, 1, true, true, 0, false, true);
	}
	@Test
	public void test11619() {
		o.launch(100, true, true, 1, true, true, 0, false, false);
	}
	@Test
	public void test11620() {
		o.launch(-1, true, true, 1, true, true, 1, true, true);
	}
	@Test
	public void test11621() {
		o.launch(-1, true, true, 1, true, true, 1, true, false);
	}
	@Test
	public void test11622() {
		o.launch(-1, true, true, 1, true, true, 1, false, true);
	}
	@Test
	public void test11623() {
		o.launch(-1, true, true, 1, true, true, 1, false, false);
	}
	@Test
	public void test11624() {
		o.launch(5, true, true, 1, true, true, 2, true, true);
	}
	@Test
	public void test11625() {
		o.launch(5, true, true, 1, true, true, 2, true, false);
	}
	@Test
	public void test11626() {
		o.launch(5, true, true, 1, true, true, 2, false, true);
	}
	@Test
	public void test11627() {
		o.launch(5, true, true, 1, true, true, 2, false, false);
	}
	@Test
	public void test11628() {
		o.launch(5, true, true, 1, true, true, 3, true, true);
	}
	@Test
	public void test11629() {
		o.launch(5, true, true, 1, true, true, 3, true, false);
	}
	@Test
	public void test11630() {
		o.launch(5, true, true, 1, true, true, 3, false, true);
	}
	@Test
	public void test11631() {
		o.launch(5, true, true, 1, true, true, 3, false, false);
	}
	@Test
	public void test11632() {
		o.launch(5, true, true, 1, true, true, 4, true, true);
	}
	@Test
	public void test11633() {
		o.launch(10, true, true, 1, true, true, 4, true, false);
	}
	@Test
	public void test11634() {
		o.launch(5, true, true, 1, true, true, 4, false, true);
	}
	@Test
	public void test11635() {
		o.launch(10, true, true, 1, true, true, 4, false, false);
	}
	@Test
	public void test11636() {
		o.launch(10, true, true, 1, true, true, 10, true, true);
	}
	@Test
	public void test11637() {
		o.launch(100, true, true, 1, true, true, 100, true, false);
	}
	@Test
	public void test11638() {
		o.launch(-1, true, true, 1, true, true, 100, false, true);
	}
	@Test
	public void test11639() {
		o.launch(100, true, true, 1, true, true, 100, false, false);
	}
	@Test
	public void test11640() {
		o.launch(100, true, true, 1, true, false, 0, true, true);
	}
	@Test
	public void test11641() {
		o.launch(5, true, true, 1, true, false, 0, true, false);
	}
	@Test
	public void test11642() {
		o.launch(-1, true, true, 1, true, false, 0, false, true);
	}
	@Test
	public void test11643() {
		o.launch(-1, true, true, 1, true, false, 0, false, false);
	}
	@Test
	public void test11644() {
		o.launch(-1, true, true, 1, true, false, 1, true, true);
	}
	@Test
	public void test11645() {
		o.launch(-1, true, true, 1, true, false, 1, true, false);
	}
	@Test
	public void test11646() {
		o.launch(-1, true, true, 1, true, false, 1, false, true);
	}
	@Test
	public void test11647() {
		o.launch(10, true, true, 1, true, false, 1, false, false);
	}
	@Test
	public void test11648() {
		o.launch(5, true, true, 1, true, false, 2, true, true);
	}
	@Test
	public void test11649() {
		o.launch(5, true, true, 1, true, false, 2, true, false);
	}
	@Test
	public void test11650() {
		o.launch(5, true, true, 1, true, false, 2, false, true);
	}
	@Test
	public void test11651() {
		o.launch(5, true, true, 1, true, false, 2, false, false);
	}
	@Test
	public void test11652() {
		o.launch(5, true, true, 1, true, false, 3, true, true);
	}
	@Test
	public void test11653() {
		o.launch(5, true, true, 1, true, false, 3, true, false);
	}
	@Test
	public void test11654() {
		o.launch(5, true, true, 1, true, false, 3, false, true);
	}
	@Test
	public void test11655() {
		o.launch(5, true, true, 1, true, false, 3, false, false);
	}
	@Test
	public void test11656() {
		o.launch(10, true, true, 1, true, false, 4, true, true);
	}
	@Test
	public void test11657() {
		o.launch(100, true, true, 1, true, false, 4, true, false);
	}
	@Test
	public void test11658() {
		o.launch(100, true, true, 1, true, false, 4, false, true);
	}
	@Test
	public void test11659() {
		o.launch(100, true, true, 1, true, false, 4, false, false);
	}
	@Test
	public void test11660() {
		o.launch(-1, true, true, 1, true, false, -1, true, true);
	}
	@Test
	public void test11661() {
		o.launch(10, true, true, 1, true, false, -1, true, false);
	}
	@Test
	public void test11662() {
		o.launch(10, true, true, 1, true, false, -1, false, true);
	}
	@Test
	public void test11663() {
		o.launch(-1, true, true, 1, true, false, -1, false, false);
	}
	@Test
	public void test11664() {
		o.launch(100, true, true, 1, false, true, 0, true, true);
	}
	@Test
	public void test11665() {
		o.launch(10, true, true, 1, false, true, 0, true, false);
	}
	@Test
	public void test11666() {
		o.launch(10, true, true, 1, false, true, 0, false, true);
	}
	@Test
	public void test11667() {
		o.launch(100, true, true, 1, false, true, 0, false, false);
	}
	@Test
	public void test11668() {
		o.launch(10, true, true, 1, false, true, 1, true, true);
	}
	@Test
	public void test11669() {
		o.launch(10, true, true, 1, false, true, 1, true, false);
	}
	@Test
	public void test11670() {
		o.launch(100, true, true, 1, false, true, 1, false, true);
	}
	@Test
	public void test11671() {
		o.launch(5, true, true, 1, false, true, 1, false, false);
	}
	@Test
	public void test11672() {
		o.launch(5, true, true, 1, false, true, 2, true, true);
	}
	@Test
	public void test11673() {
		o.launch(5, true, true, 1, false, true, 2, true, false);
	}
	@Test
	public void test11674() {
		o.launch(5, true, true, 1, false, true, 2, false, true);
	}
	@Test
	public void test11675() {
		o.launch(5, true, true, 1, false, true, 2, false, false);
	}
	@Test
	public void test11676() {
		o.launch(5, true, true, 1, false, true, 3, true, true);
	}
	@Test
	public void test11677() {
		o.launch(5, true, true, 1, false, true, 3, true, false);
	}
	@Test
	public void test11678() {
		o.launch(5, true, true, 1, false, true, 3, false, true);
	}
	@Test
	public void test11679() {
		o.launch(5, true, true, 1, false, true, 3, false, false);
	}
	@Test
	public void test11680() {
		o.launch(5, true, true, 1, false, true, 4, true, true);
	}
	@Test
	public void test11681() {
		o.launch(-1, true, true, 1, false, true, 4, true, false);
	}
	@Test
	public void test11682() {
		o.launch(5, true, true, 1, false, true, 4, false, true);
	}
	@Test
	public void test11683() {
		o.launch(5, true, true, 1, false, true, 4, false, false);
	}
	@Test
	public void test11684() {
		o.launch(10, true, true, 1, false, true, -1, true, true);
	}
	@Test
	public void test11685() {
		o.launch(-1, true, true, 1, false, true, 10, true, false);
	}
	@Test
	public void test11686() {
		o.launch(-1, true, true, 1, false, true, 10, false, true);
	}
	@Test
	public void test11687() {
		o.launch(10, true, true, 1, false, true, -1, false, false);
	}
	@Test
	public void test11688() {
		o.launch(-1, true, true, 1, false, false, 0, true, true);
	}
	@Test
	public void test11689() {
		o.launch(100, true, true, 1, false, false, 0, true, false);
	}
	@Test
	public void test11690() {
		o.launch(-1, true, true, 1, false, false, 0, false, true);
	}
	@Test
	public void test11691() {
		o.launch(-1, true, true, 1, false, false, 0, false, false);
	}
	@Test
	public void test11692() {
		o.launch(-1, true, true, 1, false, false, 1, true, true);
	}
	@Test
	public void test11693() {
		o.launch(10, true, true, 1, false, false, 1, true, false);
	}
	@Test
	public void test11694() {
		o.launch(-1, true, true, 1, false, false, 1, false, true);
	}
	@Test
	public void test11695() {
		o.launch(100, true, true, 1, false, false, 1, false, false);
	}
	@Test
	public void test11696() {
		o.launch(5, true, true, 1, false, false, 2, true, true);
	}
	@Test
	public void test11697() {
		o.launch(5, true, true, 1, false, false, 2, true, false);
	}
	@Test
	public void test11698() {
		o.launch(5, true, true, 1, false, false, 2, false, true);
	}
	@Test
	public void test11699() {
		o.launch(5, true, true, 1, false, false, 2, false, false);
	}
	@Test
	public void test11700() {
		o.launch(5, true, true, 1, false, false, 3, true, true);
	}
	@Test
	public void test11701() {
		o.launch(5, true, true, 1, false, false, 3, true, false);
	}
	@Test
	public void test11702() {
		o.launch(5, true, true, 1, false, false, 3, false, true);
	}
	@Test
	public void test11703() {
		o.launch(5, true, true, 1, false, false, 3, false, false);
	}
	@Test
	public void test11704() {
		o.launch(10, true, true, 1, false, false, 4, true, true);
	}
	@Test
	public void test11705() {
		o.launch(5, true, true, 1, false, false, 4, true, false);
	}
	@Test
	public void test11706() {
		o.launch(-1, true, true, 1, false, false, 4, false, true);
	}
	@Test
	public void test11707() {
		o.launch(-1, true, true, 1, false, false, 4, false, false);
	}
	@Test
	public void test11708() {
		o.launch(100, true, true, 1, false, false, -1, true, true);
	}
	@Test
	public void test11709() {
		o.launch(100, true, true, 1, false, false, -1, true, false);
	}
	@Test
	public void test11710() {
		o.launch(10, true, true, 1, false, false, 100, false, true);
	}
	@Test
	public void test11711() {
		o.launch(-1, true, true, 1, false, false, -1, false, false);
	}
	@Test
	public void test11712() {
		o.launch(5, true, true, 2, true, true, 0, true, true);
	}
	@Test
	public void test11713() {
		o.launch(5, true, true, 2, true, true, 0, true, false);
	}
	@Test
	public void test11714() {
		o.launch(5, true, true, 2, true, true, 0, false, true);
	}
	@Test
	public void test11715() {
		o.launch(5, true, true, 2, true, true, 0, false, false);
	}
	@Test
	public void test11716() {
		o.launch(5, true, true, 2, true, true, 1, true, true);
	}
	@Test
	public void test11717() {
		o.launch(5, true, true, 2, true, true, 1, true, false);
	}
	@Test
	public void test11718() {
		o.launch(5, true, true, 2, true, true, 1, false, true);
	}
	@Test
	public void test11719() {
		o.launch(5, true, true, 2, true, true, 1, false, false);
	}
	@Test
	public void test11720() {
		o.launch(5, true, true, 2, true, true, 2, true, true);
	}
	@Test
	public void test11721() {
		o.launch(5, true, true, 2, true, true, 2, true, false);
	}
	@Test
	public void test11722() {
		o.launch(5, true, true, 2, true, true, 2, false, true);
	}
	@Test
	public void test11723() {
		o.launch(5, true, true, 2, true, true, 2, false, false);
	}
	@Test
	public void test11724() {
		o.launch(5, true, true, 2, true, true, 3, true, true);
	}
	@Test
	public void test11725() {
		o.launch(5, true, true, 2, true, true, 3, true, false);
	}
	@Test
	public void test11726() {
		o.launch(5, true, true, 2, true, true, 3, false, true);
	}
	@Test
	public void test11727() {
		o.launch(5, true, true, 2, true, true, 3, false, false);
	}
	@Test
	public void test11728() {
		o.launch(5, true, true, 2, true, true, 4, true, true);
	}
	@Test
	public void test11729() {
		o.launch(5, true, true, 2, true, true, 4, true, false);
	}
	@Test
	public void test11730() {
		o.launch(5, true, true, 2, true, true, 4, false, true);
	}
	@Test
	public void test11731() {
		o.launch(5, true, true, 2, true, true, 4, false, false);
	}
	@Test
	public void test11732() {
		o.launch(5, true, true, 2, true, true, 5, true, true);
	}
	@Test
	public void test11733() {
		o.launch(5, true, true, 2, true, true, 5, true, false);
	}
	@Test
	public void test11734() {
		o.launch(5, true, true, 2, true, true, 5, false, true);
	}
	@Test
	public void test11735() {
		o.launch(5, true, true, 2, true, true, 5, false, false);
	}
	@Test
	public void test11736() {
		o.launch(5, true, true, 2, true, false, 0, true, true);
	}
	@Test
	public void test11737() {
		o.launch(5, true, true, 2, true, false, 0, true, false);
	}
	@Test
	public void test11738() {
		o.launch(5, true, true, 2, true, false, 0, false, true);
	}
	@Test
	public void test11739() {
		o.launch(5, true, true, 2, true, false, 0, false, false);
	}
	@Test
	public void test11740() {
		o.launch(5, true, true, 2, true, false, 1, true, true);
	}
	@Test
	public void test11741() {
		o.launch(5, true, true, 2, true, false, 1, true, false);
	}
	@Test
	public void test11742() {
		o.launch(5, true, true, 2, true, false, 1, false, true);
	}
	@Test
	public void test11743() {
		o.launch(5, true, true, 2, true, false, 1, false, false);
	}
	@Test
	public void test11744() {
		o.launch(5, true, true, 2, true, false, 2, true, true);
	}
	@Test
	public void test11745() {
		o.launch(5, true, true, 2, true, false, 2, true, false);
	}
	@Test
	public void test11746() {
		o.launch(5, true, true, 2, true, false, 2, false, true);
	}
	@Test
	public void test11747() {
		o.launch(5, true, true, 2, true, false, 2, false, false);
	}
	@Test
	public void test11748() {
		o.launch(5, true, true, 2, true, false, 3, true, true);
	}
	@Test
	public void test11749() {
		o.launch(5, true, true, 2, true, false, 3, true, false);
	}
	@Test
	public void test11750() {
		o.launch(5, true, true, 2, true, false, 3, false, true);
	}
	@Test
	public void test11751() {
		o.launch(5, true, true, 2, true, false, 3, false, false);
	}
	@Test
	public void test11752() {
		o.launch(5, true, true, 2, true, false, 4, true, true);
	}
	@Test
	public void test11753() {
		o.launch(5, true, true, 2, true, false, 4, true, false);
	}
	@Test
	public void test11754() {
		o.launch(5, true, true, 2, true, false, 4, false, true);
	}
	@Test
	public void test11755() {
		o.launch(5, true, true, 2, true, false, 4, false, false);
	}
	@Test
	public void test11756() {
		o.launch(5, true, true, 2, true, false, 5, true, true);
	}
	@Test
	public void test11757() {
		o.launch(5, true, true, 2, true, false, 5, true, false);
	}
	@Test
	public void test11758() {
		o.launch(5, true, true, 2, true, false, 5, false, true);
	}
	@Test
	public void test11759() {
		o.launch(5, true, true, 2, true, false, 5, false, false);
	}
	@Test
	public void test11760() {
		o.launch(5, true, true, 2, false, true, 0, true, true);
	}
	@Test
	public void test11761() {
		o.launch(5, true, true, 2, false, true, 0, true, false);
	}
	@Test
	public void test11762() {
		o.launch(5, true, true, 2, false, true, 0, false, true);
	}
	@Test
	public void test11763() {
		o.launch(5, true, true, 2, false, true, 0, false, false);
	}
	@Test
	public void test11764() {
		o.launch(5, true, true, 2, false, true, 1, true, true);
	}
	@Test
	public void test11765() {
		o.launch(5, true, true, 2, false, true, 1, true, false);
	}
	@Test
	public void test11766() {
		o.launch(5, true, true, 2, false, true, 1, false, true);
	}
	@Test
	public void test11767() {
		o.launch(5, true, true, 2, false, true, 1, false, false);
	}
	@Test
	public void test11768() {
		o.launch(5, true, true, 2, false, true, 2, true, true);
	}
	@Test
	public void test11769() {
		o.launch(5, true, true, 2, false, true, 2, true, false);
	}
	@Test
	public void test11770() {
		o.launch(5, true, true, 2, false, true, 2, false, true);
	}
	@Test
	public void test11771() {
		o.launch(5, true, true, 2, false, true, 2, false, false);
	}
	@Test
	public void test11772() {
		o.launch(5, true, true, 2, false, true, 3, true, true);
	}
	@Test
	public void test11773() {
		o.launch(5, true, true, 2, false, true, 3, true, false);
	}
	@Test
	public void test11774() {
		o.launch(5, true, true, 2, false, true, 3, false, true);
	}
	@Test
	public void test11775() {
		o.launch(5, true, true, 2, false, true, 3, false, false);
	}
	@Test
	public void test11776() {
		o.launch(5, true, true, 2, false, true, 4, true, true);
	}
	@Test
	public void test11777() {
		o.launch(5, true, true, 2, false, true, 4, true, false);
	}
	@Test
	public void test11778() {
		o.launch(5, true, true, 2, false, true, 4, false, true);
	}
	@Test
	public void test11779() {
		o.launch(5, true, true, 2, false, true, 4, false, false);
	}
	@Test
	public void test11780() {
		o.launch(5, true, true, 2, false, true, 5, true, true);
	}
	@Test
	public void test11781() {
		o.launch(5, true, true, 2, false, true, 5, true, false);
	}
	@Test
	public void test11782() {
		o.launch(5, true, true, 2, false, true, 5, false, true);
	}
	@Test
	public void test11783() {
		o.launch(5, true, true, 2, false, true, 5, false, false);
	}
	@Test
	public void test11784() {
		o.launch(5, true, true, 2, false, false, 0, true, true);
	}
	@Test
	public void test11785() {
		o.launch(5, true, true, 2, false, false, 0, true, false);
	}
	@Test
	public void test11786() {
		o.launch(5, true, true, 2, false, false, 0, false, true);
	}
	@Test
	public void test11787() {
		o.launch(5, true, true, 2, false, false, 0, false, false);
	}
	@Test
	public void test11788() {
		o.launch(5, true, true, 2, false, false, 1, true, true);
	}
	@Test
	public void test11789() {
		o.launch(5, true, true, 2, false, false, 1, true, false);
	}
	@Test
	public void test11790() {
		o.launch(5, true, true, 2, false, false, 1, false, true);
	}
	@Test
	public void test11791() {
		o.launch(5, true, true, 2, false, false, 1, false, false);
	}
	@Test
	public void test11792() {
		o.launch(5, true, true, 2, false, false, 2, true, true);
	}
	@Test
	public void test11793() {
		o.launch(5, true, true, 2, false, false, 2, true, false);
	}
	@Test
	public void test11794() {
		o.launch(5, true, true, 2, false, false, 2, false, true);
	}
	@Test
	public void test11795() {
		o.launch(5, true, true, 2, false, false, 2, false, false);
	}
	@Test
	public void test11796() {
		o.launch(5, true, true, 2, false, false, 3, true, true);
	}
	@Test
	public void test11797() {
		o.launch(5, true, true, 2, false, false, 3, true, false);
	}
	@Test
	public void test11798() {
		o.launch(5, true, true, 2, false, false, 3, false, true);
	}
	@Test
	public void test11799() {
		o.launch(5, true, true, 2, false, false, 3, false, false);
	}
	@Test
	public void test11800() {
		o.launch(5, true, true, 2, false, false, 4, true, true);
	}
	@Test
	public void test11801() {
		o.launch(5, true, true, 2, false, false, 4, true, false);
	}
	@Test
	public void test11802() {
		o.launch(5, true, true, 2, false, false, 4, false, true);
	}
	@Test
	public void test11803() {
		o.launch(5, true, true, 2, false, false, 4, false, false);
	}
	@Test
	public void test11804() {
		o.launch(5, true, true, 2, false, false, 5, true, true);
	}
	@Test
	public void test11805() {
		o.launch(5, true, true, 2, false, false, 5, true, false);
	}
	@Test
	public void test11806() {
		o.launch(5, true, true, 2, false, false, 5, false, true);
	}
	@Test
	public void test11807() {
		o.launch(5, true, true, 2, false, false, 5, false, false);
	}
	@Test
	public void test11808() {
		o.launch(5, true, true, 3, true, true, 0, true, true);
	}
	@Test
	public void test11809() {
		o.launch(5, true, true, 3, true, true, 0, true, false);
	}
	@Test
	public void test11810() {
		o.launch(5, true, true, 3, true, true, 0, false, true);
	}
	@Test
	public void test11811() {
		o.launch(5, true, true, 3, true, true, 0, false, false);
	}
	@Test
	public void test11812() {
		o.launch(5, true, true, 3, true, true, 1, true, true);
	}
	@Test
	public void test11813() {
		o.launch(5, true, true, 3, true, true, 1, true, false);
	}
	@Test
	public void test11814() {
		o.launch(5, true, true, 3, true, true, 1, false, true);
	}
	@Test
	public void test11815() {
		o.launch(5, true, true, 3, true, true, 1, false, false);
	}
	@Test
	public void test11816() {
		o.launch(5, true, true, 3, true, true, 2, true, true);
	}
	@Test
	public void test11817() {
		o.launch(5, true, true, 3, true, true, 2, true, false);
	}
	@Test
	public void test11818() {
		o.launch(5, true, true, 3, true, true, 2, false, true);
	}
	@Test
	public void test11819() {
		o.launch(5, true, true, 3, true, true, 2, false, false);
	}
	@Test
	public void test11820() {
		o.launch(5, true, true, 3, true, true, 3, true, true);
	}
	@Test
	public void test11821() {
		o.launch(5, true, true, 3, true, true, 3, true, false);
	}
	@Test
	public void test11822() {
		o.launch(5, true, true, 3, true, true, 3, false, true);
	}
	@Test
	public void test11823() {
		o.launch(5, true, true, 3, true, true, 3, false, false);
	}
	@Test
	public void test11824() {
		o.launch(5, true, true, 3, true, true, 4, true, true);
	}
	@Test
	public void test11825() {
		o.launch(5, true, true, 3, true, true, 4, true, false);
	}
	@Test
	public void test11826() {
		o.launch(5, true, true, 3, true, true, 4, false, true);
	}
	@Test
	public void test11827() {
		o.launch(5, true, true, 3, true, true, 4, false, false);
	}
	@Test
	public void test11828() {
		o.launch(5, true, true, 3, true, true, 5, true, true);
	}
	@Test
	public void test11829() {
		o.launch(5, true, true, 3, true, true, 5, true, false);
	}
	@Test
	public void test11830() {
		o.launch(5, true, true, 3, true, true, 5, false, true);
	}
	@Test
	public void test11831() {
		o.launch(5, true, true, 3, true, true, 5, false, false);
	}
	@Test
	public void test11832() {
		o.launch(5, true, true, 3, true, false, 0, true, true);
	}
	@Test
	public void test11833() {
		o.launch(5, true, true, 3, true, false, 0, true, false);
	}
	@Test
	public void test11834() {
		o.launch(5, true, true, 3, true, false, 0, false, true);
	}
	@Test
	public void test11835() {
		o.launch(5, true, true, 3, true, false, 0, false, false);
	}
	@Test
	public void test11836() {
		o.launch(5, true, true, 3, true, false, 1, true, true);
	}
	@Test
	public void test11837() {
		o.launch(5, true, true, 3, true, false, 1, true, false);
	}
	@Test
	public void test11838() {
		o.launch(5, true, true, 3, true, false, 1, false, true);
	}
	@Test
	public void test11839() {
		o.launch(5, true, true, 3, true, false, 1, false, false);
	}
	@Test
	public void test11840() {
		o.launch(5, true, true, 3, true, false, 2, true, true);
	}
	@Test
	public void test11841() {
		o.launch(5, true, true, 3, true, false, 2, true, false);
	}
	@Test
	public void test11842() {
		o.launch(5, true, true, 3, true, false, 2, false, true);
	}
	@Test
	public void test11843() {
		o.launch(5, true, true, 3, true, false, 2, false, false);
	}
	@Test
	public void test11844() {
		o.launch(5, true, true, 3, true, false, 3, true, true);
	}
	@Test
	public void test11845() {
		o.launch(5, true, true, 3, true, false, 3, true, false);
	}
	@Test
	public void test11846() {
		o.launch(5, true, true, 3, true, false, 3, false, true);
	}
	@Test
	public void test11847() {
		o.launch(5, true, true, 3, true, false, 3, false, false);
	}
	@Test
	public void test11848() {
		o.launch(5, true, true, 3, true, false, 4, true, true);
	}
	@Test
	public void test11849() {
		o.launch(5, true, true, 3, true, false, 4, true, false);
	}
	@Test
	public void test11850() {
		o.launch(5, true, true, 3, true, false, 4, false, true);
	}
	@Test
	public void test11851() {
		o.launch(5, true, true, 3, true, false, 4, false, false);
	}
	@Test
	public void test11852() {
		o.launch(5, true, true, 3, true, false, 5, true, true);
	}
	@Test
	public void test11853() {
		o.launch(5, true, true, 3, true, false, 5, true, false);
	}
	@Test
	public void test11854() {
		o.launch(5, true, true, 3, true, false, 5, false, true);
	}
	@Test
	public void test11855() {
		o.launch(5, true, true, 3, true, false, 5, false, false);
	}
	@Test
	public void test11856() {
		o.launch(5, true, true, 3, false, true, 0, true, true);
	}
	@Test
	public void test11857() {
		o.launch(5, true, true, 3, false, true, 0, true, false);
	}
	@Test
	public void test11858() {
		o.launch(5, true, true, 3, false, true, 0, false, true);
	}
	@Test
	public void test11859() {
		o.launch(5, true, true, 3, false, true, 0, false, false);
	}
	@Test
	public void test11860() {
		o.launch(5, true, true, 3, false, true, 1, true, true);
	}
	@Test
	public void test11861() {
		o.launch(5, true, true, 3, false, true, 1, true, false);
	}
	@Test
	public void test11862() {
		o.launch(5, true, true, 3, false, true, 1, false, true);
	}
	@Test
	public void test11863() {
		o.launch(5, true, true, 3, false, true, 1, false, false);
	}
	@Test
	public void test11864() {
		o.launch(5, true, true, 3, false, true, 2, true, true);
	}
	@Test
	public void test11865() {
		o.launch(5, true, true, 3, false, true, 2, true, false);
	}
	@Test
	public void test11866() {
		o.launch(5, true, true, 3, false, true, 2, false, true);
	}
	@Test
	public void test11867() {
		o.launch(5, true, true, 3, false, true, 2, false, false);
	}
	@Test
	public void test11868() {
		o.launch(5, true, true, 3, false, true, 3, true, true);
	}
	@Test
	public void test11869() {
		o.launch(5, true, true, 3, false, true, 3, true, false);
	}
	@Test
	public void test11870() {
		o.launch(5, true, true, 3, false, true, 3, false, true);
	}
	@Test
	public void test11871() {
		o.launch(5, true, true, 3, false, true, 3, false, false);
	}
	@Test
	public void test11872() {
		o.launch(5, true, true, 3, false, true, 4, true, true);
	}
	@Test
	public void test11873() {
		o.launch(5, true, true, 3, false, true, 4, true, false);
	}
	@Test
	public void test11874() {
		o.launch(5, true, true, 3, false, true, 4, false, true);
	}
	@Test
	public void test11875() {
		o.launch(5, true, true, 3, false, true, 4, false, false);
	}
	@Test
	public void test11876() {
		o.launch(5, true, true, 3, false, true, 5, true, true);
	}
	@Test
	public void test11877() {
		o.launch(5, true, true, 3, false, true, 5, true, false);
	}
	@Test
	public void test11878() {
		o.launch(5, true, true, 3, false, true, 5, false, true);
	}
	@Test
	public void test11879() {
		o.launch(5, true, true, 3, false, true, 5, false, false);
	}
	@Test
	public void test11880() {
		o.launch(5, true, true, 3, false, false, 0, true, true);
	}
	@Test
	public void test11881() {
		o.launch(5, true, true, 3, false, false, 0, true, false);
	}
	@Test
	public void test11882() {
		o.launch(5, true, true, 3, false, false, 0, false, true);
	}
	@Test
	public void test11883() {
		o.launch(5, true, true, 3, false, false, 0, false, false);
	}
	@Test
	public void test11884() {
		o.launch(5, true, true, 3, false, false, 1, true, true);
	}
	@Test
	public void test11885() {
		o.launch(5, true, true, 3, false, false, 1, true, false);
	}
	@Test
	public void test11886() {
		o.launch(5, true, true, 3, false, false, 1, false, true);
	}
	@Test
	public void test11887() {
		o.launch(5, true, true, 3, false, false, 1, false, false);
	}
	@Test
	public void test11888() {
		o.launch(5, true, true, 3, false, false, 2, true, true);
	}
	@Test
	public void test11889() {
		o.launch(5, true, true, 3, false, false, 2, true, false);
	}
	@Test
	public void test11890() {
		o.launch(5, true, true, 3, false, false, 2, false, true);
	}
	@Test
	public void test11891() {
		o.launch(5, true, true, 3, false, false, 2, false, false);
	}
	@Test
	public void test11892() {
		o.launch(5, true, true, 3, false, false, 3, true, true);
	}
	@Test
	public void test11893() {
		o.launch(5, true, true, 3, false, false, 3, true, false);
	}
	@Test
	public void test11894() {
		o.launch(5, true, true, 3, false, false, 3, false, true);
	}
	@Test
	public void test11895() {
		o.launch(5, true, true, 3, false, false, 3, false, false);
	}
	@Test
	public void test11896() {
		o.launch(5, true, true, 3, false, false, 4, true, true);
	}
	@Test
	public void test11897() {
		o.launch(5, true, true, 3, false, false, 4, true, false);
	}
	@Test
	public void test11898() {
		o.launch(5, true, true, 3, false, false, 4, false, true);
	}
	@Test
	public void test11899() {
		o.launch(5, true, true, 3, false, false, 4, false, false);
	}
	@Test
	public void test11900() {
		o.launch(5, true, true, 3, false, false, 5, true, true);
	}
	@Test
	public void test11901() {
		o.launch(5, true, true, 3, false, false, 5, true, false);
	}
	@Test
	public void test11902() {
		o.launch(5, true, true, 3, false, false, 5, false, true);
	}
	@Test
	public void test11903() {
		o.launch(5, true, true, 3, false, false, 5, false, false);
	}
	@Test
	public void test11904() {
		o.launch(5, true, true, 4, true, true, 0, true, true);
	}
	@Test
	public void test11905() {
		o.launch(5, true, true, 4, true, true, 0, true, false);
	}
	@Test
	public void test11906() {
		o.launch(5, true, true, 4, true, true, 0, false, true);
	}
	@Test
	public void test11907() {
		o.launch(-1, true, true, 4, true, true, 0, false, false);
	}
	@Test
	public void test11908() {
		o.launch(100, true, true, 4, true, true, 1, true, true);
	}
	@Test
	public void test11909() {
		o.launch(5, true, true, 4, true, true, 1, true, false);
	}
	@Test
	public void test11910() {
		o.launch(5, true, true, 4, true, true, 1, false, true);
	}
	@Test
	public void test11911() {
		o.launch(5, true, true, 4, true, true, 1, false, false);
	}
	@Test
	public void test11912() {
		o.launch(5, true, true, 4, true, true, 2, true, true);
	}
	@Test
	public void test11913() {
		o.launch(5, true, true, 4, true, true, 2, true, false);
	}
	@Test
	public void test11914() {
		o.launch(5, true, true, 4, true, true, 2, false, true);
	}
	@Test
	public void test11915() {
		o.launch(5, true, true, 4, true, true, 2, false, false);
	}
	@Test
	public void test11916() {
		o.launch(5, true, true, 4, true, true, 3, true, true);
	}
	@Test
	public void test11917() {
		o.launch(5, true, true, 4, true, true, 3, true, false);
	}
	@Test
	public void test11918() {
		o.launch(5, true, true, 4, true, true, 3, false, true);
	}
	@Test
	public void test11919() {
		o.launch(5, true, true, 4, true, true, 3, false, false);
	}
	@Test
	public void test11920() {
		o.launch(5, true, true, 4, true, true, 4, true, true);
	}
	@Test
	public void test11921() {
		o.launch(5, true, true, 4, true, true, 4, true, false);
	}
	@Test
	public void test11922() {
		o.launch(5, true, true, 4, true, true, 4, false, true);
	}
	@Test
	public void test11923() {
		o.launch(5, true, true, 4, true, true, 4, false, false);
	}
	@Test
	public void test11924() {
		o.launch(-1, true, true, 4, true, true, 10, true, true);
	}
	@Test
	public void test11925() {
		o.launch(100, true, true, 4, true, true, 100, true, false);
	}
	@Test
	public void test11926() {
		o.launch(10, true, true, 4, true, true, -1, false, true);
	}
	@Test
	public void test11927() {
		o.launch(100, true, true, 4, true, true, 100, false, false);
	}
	@Test
	public void test11928() {
		o.launch(10, true, true, 4, true, false, 0, true, true);
	}
	@Test
	public void test11929() {
		o.launch(10, true, true, 4, true, false, 0, true, false);
	}
	@Test
	public void test11930() {
		o.launch(-1, true, true, 4, true, false, 0, false, true);
	}
	@Test
	public void test11931() {
		o.launch(10, true, true, 4, true, false, 0, false, false);
	}
	@Test
	public void test11932() {
		o.launch(5, true, true, 4, true, false, 1, true, true);
	}
	@Test
	public void test11933() {
		o.launch(5, true, true, 4, true, false, 1, true, false);
	}
	@Test
	public void test11934() {
		o.launch(10, true, true, 4, true, false, 1, false, true);
	}
	@Test
	public void test11935() {
		o.launch(-1, true, true, 4, true, false, 1, false, false);
	}
	@Test
	public void test11936() {
		o.launch(5, true, true, 4, true, false, 2, true, true);
	}
	@Test
	public void test11937() {
		o.launch(5, true, true, 4, true, false, 2, true, false);
	}
	@Test
	public void test11938() {
		o.launch(5, true, true, 4, true, false, 2, false, true);
	}
	@Test
	public void test11939() {
		o.launch(5, true, true, 4, true, false, 2, false, false);
	}
	@Test
	public void test11940() {
		o.launch(5, true, true, 4, true, false, 3, true, true);
	}
	@Test
	public void test11941() {
		o.launch(5, true, true, 4, true, false, 3, true, false);
	}
	@Test
	public void test11942() {
		o.launch(5, true, true, 4, true, false, 3, false, true);
	}
	@Test
	public void test11943() {
		o.launch(5, true, true, 4, true, false, 3, false, false);
	}
	@Test
	public void test11944() {
		o.launch(10, true, true, 4, true, false, 4, true, true);
	}
	@Test
	public void test11945() {
		o.launch(5, true, true, 4, true, false, 4, true, false);
	}
	@Test
	public void test11946() {
		o.launch(10, true, true, 4, true, false, 4, false, true);
	}
	@Test
	public void test11947() {
		o.launch(100, true, true, 4, true, false, 4, false, false);
	}
	@Test
	public void test11948() {
		o.launch(100, true, true, 4, true, false, -1, true, true);
	}
	@Test
	public void test11949() {
		o.launch(10, true, true, 4, true, false, -1, true, false);
	}
	@Test
	public void test11950() {
		o.launch(10, true, true, 4, true, false, -1, false, true);
	}
	@Test
	public void test11951() {
		o.launch(100, true, true, 4, true, false, 100, false, false);
	}
	@Test
	public void test11952() {
		o.launch(5, true, true, 4, false, true, 0, true, true);
	}
	@Test
	public void test11953() {
		o.launch(5, true, true, 4, false, true, 0, true, false);
	}
	@Test
	public void test11954() {
		o.launch(100, true, true, 4, false, true, 0, false, true);
	}
	@Test
	public void test11955() {
		o.launch(100, true, true, 4, false, true, 0, false, false);
	}
	@Test
	public void test11956() {
		o.launch(5, true, true, 4, false, true, 1, true, true);
	}
	@Test
	public void test11957() {
		o.launch(5, true, true, 4, false, true, 1, true, false);
	}
	@Test
	public void test11958() {
		o.launch(5, true, true, 4, false, true, 1, false, true);
	}
	@Test
	public void test11959() {
		o.launch(10, true, true, 4, false, true, 1, false, false);
	}
	@Test
	public void test11960() {
		o.launch(5, true, true, 4, false, true, 2, true, true);
	}
	@Test
	public void test11961() {
		o.launch(5, true, true, 4, false, true, 2, true, false);
	}
	@Test
	public void test11962() {
		o.launch(5, true, true, 4, false, true, 2, false, true);
	}
	@Test
	public void test11963() {
		o.launch(5, true, true, 4, false, true, 2, false, false);
	}
	@Test
	public void test11964() {
		o.launch(5, true, true, 4, false, true, 3, true, true);
	}
	@Test
	public void test11965() {
		o.launch(5, true, true, 4, false, true, 3, true, false);
	}
	@Test
	public void test11966() {
		o.launch(5, true, true, 4, false, true, 3, false, true);
	}
	@Test
	public void test11967() {
		o.launch(5, true, true, 4, false, true, 3, false, false);
	}
	@Test
	public void test11968() {
		o.launch(5, true, true, 4, false, true, 4, true, true);
	}
	@Test
	public void test11969() {
		o.launch(5, true, true, 4, false, true, 4, true, false);
	}
	@Test
	public void test11970() {
		o.launch(5, true, true, 4, false, true, 4, false, true);
	}
	@Test
	public void test11971() {
		o.launch(5, true, true, 4, false, true, 4, false, false);
	}
	@Test
	public void test11972() {
		o.launch(100, true, true, 4, false, true, 10, true, true);
	}
	@Test
	public void test11973() {
		o.launch(10, true, true, 4, false, true, 10, true, false);
	}
	@Test
	public void test11974() {
		o.launch(-1, true, true, 4, false, true, -1, false, true);
	}
	@Test
	public void test11975() {
		o.launch(5, true, true, 4, false, true, 5, false, false);
	}
	@Test
	public void test11976() {
		o.launch(5, true, true, 4, false, false, 0, true, true);
	}
	@Test
	public void test11977() {
		o.launch(5, true, true, 4, false, false, 0, true, false);
	}
	@Test
	public void test11978() {
		o.launch(10, true, true, 4, false, false, 0, false, true);
	}
	@Test
	public void test11979() {
		o.launch(5, true, true, 4, false, false, 0, false, false);
	}
	@Test
	public void test11980() {
		o.launch(10, true, true, 4, false, false, 1, true, true);
	}
	@Test
	public void test11981() {
		o.launch(5, true, true, 4, false, false, 1, true, false);
	}
	@Test
	public void test11982() {
		o.launch(-1, true, true, 4, false, false, 1, false, true);
	}
	@Test
	public void test11983() {
		o.launch(10, true, true, 4, false, false, 1, false, false);
	}
	@Test
	public void test11984() {
		o.launch(5, true, true, 4, false, false, 2, true, true);
	}
	@Test
	public void test11985() {
		o.launch(5, true, true, 4, false, false, 2, true, false);
	}
	@Test
	public void test11986() {
		o.launch(5, true, true, 4, false, false, 2, false, true);
	}
	@Test
	public void test11987() {
		o.launch(5, true, true, 4, false, false, 2, false, false);
	}
	@Test
	public void test11988() {
		o.launch(5, true, true, 4, false, false, 3, true, true);
	}
	@Test
	public void test11989() {
		o.launch(5, true, true, 4, false, false, 3, true, false);
	}
	@Test
	public void test11990() {
		o.launch(5, true, true, 4, false, false, 3, false, true);
	}
	@Test
	public void test11991() {
		o.launch(5, true, true, 4, false, false, 3, false, false);
	}
	@Test
	public void test11992() {
		o.launch(5, true, true, 4, false, false, 4, true, true);
	}
	@Test
	public void test11993() {
		o.launch(5, true, true, 4, false, false, 4, true, false);
	}
	@Test
	public void test11994() {
		o.launch(5, true, true, 4, false, false, 4, false, true);
	}
	@Test
	public void test11995() {
		o.launch(5, true, true, 4, false, false, 4, false, false);
	}
	@Test
	public void test11996() {
		o.launch(100, true, true, 4, false, false, 10, true, true);
	}
	@Test
	public void test11997() {
		o.launch(10, true, true, 4, false, false, 100, true, false);
	}
	@Test
	public void test11998() {
		o.launch(100, true, true, 4, false, false, -1, false, true);
	}
	@Test
	public void test11999() {
		o.launch(-1, true, true, 4, false, false, 100, false, false);
	}
	@Test
	public void test12000() {
		o.launch(10, true, true, 100, true, true, 0, true, true);
	}
	@Test
	public void test12001() {
		o.launch(100, true, true, 100, true, true, 0, true, false);
	}
	@Test
	public void test12002() {
		o.launch(10, true, true, 100, true, true, 0, false, true);
	}
	@Test
	public void test12003() {
		o.launch(10, true, true, 100, true, true, 0, false, false);
	}
	@Test
	public void test12004() {
		o.launch(-1, true, true, 100, true, true, 1, true, true);
	}
	@Test
	public void test12005() {
		o.launch(-1, true, true, 100, true, true, 1, true, false);
	}
	@Test
	public void test12006() {
		o.launch(100, true, true, 10, true, true, 1, false, true);
	}
	@Test
	public void test12007() {
		o.launch(10, true, true, 100, true, true, 1, false, false);
	}
	@Test
	public void test12008() {
		o.launch(5, true, true, 5, true, true, 2, true, true);
	}
	@Test
	public void test12009() {
		o.launch(5, true, true, 5, true, true, 2, true, false);
	}
	@Test
	public void test12010() {
		o.launch(5, true, true, 5, true, true, 2, false, true);
	}
	@Test
	public void test12011() {
		o.launch(5, true, true, 5, true, true, 2, false, false);
	}
	@Test
	public void test12012() {
		o.launch(5, true, true, 5, true, true, 3, true, true);
	}
	@Test
	public void test12013() {
		o.launch(5, true, true, 5, true, true, 3, true, false);
	}
	@Test
	public void test12014() {
		o.launch(5, true, true, 5, true, true, 3, false, true);
	}
	@Test
	public void test12015() {
		o.launch(5, true, true, 5, true, true, 3, false, false);
	}
	@Test
	public void test12016() {
		o.launch(10, true, true, -1, true, true, 4, true, true);
	}
	@Test
	public void test12017() {
		o.launch(5, true, true, 5, true, true, 4, true, false);
	}
	@Test
	public void test12018() {
		o.launch(10, true, true, 10, true, true, 4, false, true);
	}
	@Test
	public void test12019() {
		o.launch(-1, true, true, 100, true, true, 4, false, false);
	}
	@Test
	public void test12020() {
		o.launch(-1, true, true, -1, true, true, 100, true, true);
	}
	@Test
	public void test12021() {
		o.launch(100, true, true, 10, true, true, 100, true, false);
	}
	@Test
	public void test12022() {
		o.launch(10, true, true, 100, true, true, -1, false, true);
	}
	@Test
	public void test12023() {
		o.launch(100, true, true, 10, true, true, 100, false, false);
	}
	@Test
	public void test12024() {
		o.launch(-1, true, true, 10, true, false, 0, true, true);
	}
	@Test
	public void test12025() {
		o.launch(100, true, true, -1, true, false, 0, true, false);
	}
	@Test
	public void test12026() {
		o.launch(-1, true, true, 10, true, false, 0, false, true);
	}
	@Test
	public void test12027() {
		o.launch(-1, true, true, 10, true, false, 0, false, false);
	}
	@Test
	public void test12028() {
		o.launch(-1, true, true, 10, true, false, 1, true, true);
	}
	@Test
	public void test12029() {
		o.launch(100, true, true, -1, true, false, 1, true, false);
	}
	@Test
	public void test12030() {
		o.launch(-1, true, true, 10, true, false, 1, false, true);
	}
	@Test
	public void test12031() {
		o.launch(100, true, true, -1, true, false, 1, false, false);
	}
	@Test
	public void test12032() {
		o.launch(5, true, true, 5, true, false, 2, true, true);
	}
	@Test
	public void test12033() {
		o.launch(5, true, true, 5, true, false, 2, true, false);
	}
	@Test
	public void test12034() {
		o.launch(5, true, true, 5, true, false, 2, false, true);
	}
	@Test
	public void test12035() {
		o.launch(5, true, true, 5, true, false, 2, false, false);
	}
	@Test
	public void test12036() {
		o.launch(5, true, true, 5, true, false, 3, true, true);
	}
	@Test
	public void test12037() {
		o.launch(5, true, true, 5, true, false, 3, true, false);
	}
	@Test
	public void test12038() {
		o.launch(5, true, true, 5, true, false, 3, false, true);
	}
	@Test
	public void test12039() {
		o.launch(5, true, true, 5, true, false, 3, false, false);
	}
	@Test
	public void test12040() {
		o.launch(10, true, true, 10, true, false, 4, true, true);
	}
	@Test
	public void test12041() {
		o.launch(-1, true, true, -1, true, false, 4, true, false);
	}
	@Test
	public void test12042() {
		o.launch(10, true, true, 100, true, false, 4, false, true);
	}
	@Test
	public void test12043() {
		o.launch(10, true, true, -1, true, false, 4, false, false);
	}
	@Test
	public void test12044() {
		o.launch(-1, true, true, 10, true, false, -1, true, true);
	}
	@Test
	public void test12045() {
		o.launch(10, true, true, -1, true, false, 10, true, false);
	}
	@Test
	public void test12046() {
		o.launch(10, true, true, -1, true, false, 10, false, true);
	}
	@Test
	public void test12047() {
		o.launch(10, true, true, -1, true, false, 10, false, false);
	}
	@Test
	public void test12048() {
		o.launch(-1, true, true, -1, false, true, 0, true, true);
	}
	@Test
	public void test12049() {
		o.launch(-1, true, true, -1, false, true, 0, true, false);
	}
	@Test
	public void test12050() {
		o.launch(-1, true, true, -1, false, true, 0, false, true);
	}
	@Test
	public void test12051() {
		o.launch(-1, true, true, -1, false, true, 0, false, false);
	}
	@Test
	public void test12052() {
		o.launch(-1, true, true, 10, false, true, 1, true, true);
	}
	@Test
	public void test12053() {
		o.launch(-1, true, true, 10, false, true, 1, true, false);
	}
	@Test
	public void test12054() {
		o.launch(100, true, true, 100, false, true, 1, false, true);
	}
	@Test
	public void test12055() {
		o.launch(100, true, true, 100, false, true, 1, false, false);
	}
	@Test
	public void test12056() {
		o.launch(5, true, true, 5, false, true, 2, true, true);
	}
	@Test
	public void test12057() {
		o.launch(5, true, true, 5, false, true, 2, true, false);
	}
	@Test
	public void test12058() {
		o.launch(5, true, true, 5, false, true, 2, false, true);
	}
	@Test
	public void test12059() {
		o.launch(5, true, true, 5, false, true, 2, false, false);
	}
	@Test
	public void test12060() {
		o.launch(5, true, true, 5, false, true, 3, true, true);
	}
	@Test
	public void test12061() {
		o.launch(5, true, true, 5, false, true, 3, true, false);
	}
	@Test
	public void test12062() {
		o.launch(5, true, true, 5, false, true, 3, false, true);
	}
	@Test
	public void test12063() {
		o.launch(5, true, true, 5, false, true, 3, false, false);
	}
	@Test
	public void test12064() {
		o.launch(-1, true, true, 10, false, true, 4, true, true);
	}
	@Test
	public void test12065() {
		o.launch(100, true, true, 100, false, true, 4, true, false);
	}
	@Test
	public void test12066() {
		o.launch(10, true, true, -1, false, true, 4, false, true);
	}
	@Test
	public void test12067() {
		o.launch(10, true, true, 10, false, true, 4, false, false);
	}
	@Test
	public void test12068() {
		o.launch(-1, true, true, -1, false, true, -1, true, true);
	}
	@Test
	public void test12069() {
		o.launch(-1, true, true, -1, false, true, -1, true, false);
	}
	@Test
	public void test12070() {
		o.launch(-1, true, true, -1, false, true, -1, false, true);
	}
	@Test
	public void test12071() {
		o.launch(-1, true, true, -1, false, true, -1, false, false);
	}
	@Test
	public void test12072() {
		o.launch(100, true, true, 100, false, false, 0, true, true);
	}
	@Test
	public void test12073() {
		o.launch(10, true, true, -1, false, false, 0, true, false);
	}
	@Test
	public void test12074() {
		o.launch(-1, true, true, -1, false, false, 0, false, true);
	}
	@Test
	public void test12075() {
		o.launch(-1, true, true, -1, false, false, 0, false, false);
	}
	@Test
	public void test12076() {
		o.launch(-1, true, true, -1, false, false, 1, true, true);
	}
	@Test
	public void test12077() {
		o.launch(-1, true, true, -1, false, false, 1, true, false);
	}
	@Test
	public void test12078() {
		o.launch(-1, true, true, -1, false, false, 1, false, true);
	}
	@Test
	public void test12079() {
		o.launch(-1, true, true, -1, false, false, 1, false, false);
	}
	@Test
	public void test12080() {
		o.launch(5, true, true, 5, false, false, 2, true, true);
	}
	@Test
	public void test12081() {
		o.launch(5, true, true, 5, false, false, 2, true, false);
	}
	@Test
	public void test12082() {
		o.launch(5, true, true, 5, false, false, 2, false, true);
	}
	@Test
	public void test12083() {
		o.launch(5, true, true, 5, false, false, 2, false, false);
	}
	@Test
	public void test12084() {
		o.launch(5, true, true, 5, false, false, 3, true, true);
	}
	@Test
	public void test12085() {
		o.launch(5, true, true, 5, false, false, 3, true, false);
	}
	@Test
	public void test12086() {
		o.launch(5, true, true, 5, false, false, 3, false, true);
	}
	@Test
	public void test12087() {
		o.launch(5, true, true, 5, false, false, 3, false, false);
	}
	@Test
	public void test12088() {
		o.launch(100, true, true, 10, false, false, 4, true, true);
	}
	@Test
	public void test12089() {
		o.launch(-1, true, true, 100, false, false, 4, true, false);
	}
	@Test
	public void test12090() {
		o.launch(10, true, true, 100, false, false, 4, false, true);
	}
	@Test
	public void test12091() {
		o.launch(10, true, true, 100, false, false, 4, false, false);
	}
	@Test
	public void test12092() {
		o.launch(100, true, true, 100, false, false, 10, true, true);
	}
	@Test
	public void test12093() {
		o.launch(-1, true, true, 100, false, false, 10, true, false);
	}
	@Test
	public void test12094() {
		o.launch(-1, true, true, 100, false, false, 10, false, true);
	}
	@Test
	public void test12095() {
		o.launch(-1, true, true, 100, false, false, 10, false, false);
	}
	@Test
	public void test12096() {
		o.launch(100, true, false, 0, true, true, 0, true, true);
	}
	@Test
	public void test12097() {
		o.launch(-1, true, false, 0, true, true, 0, true, false);
	}
	@Test
	public void test12098() {
		o.launch(100, true, false, 0, true, true, 0, false, true);
	}
	@Test
	public void test12099() {
		o.launch(100, true, false, 0, true, true, 0, false, false);
	}
	@Test
	public void test12100() {
		o.launch(100, true, false, 0, true, true, 1, true, true);
	}
	@Test
	public void test12101() {
		o.launch(100, true, false, 0, true, true, 1, true, false);
	}
	@Test
	public void test12102() {
		o.launch(-1, true, false, 0, true, true, 1, false, true);
	}
	@Test
	public void test12103() {
		o.launch(5, true, false, 0, true, true, 1, false, false);
	}
	@Test
	public void test12104() {
		o.launch(5, true, false, 0, true, true, 2, true, true);
	}
	@Test
	public void test12105() {
		o.launch(5, true, false, 0, true, true, 2, true, false);
	}
	@Test
	public void test12106() {
		o.launch(5, true, false, 0, true, true, 2, false, true);
	}
	@Test
	public void test12107() {
		o.launch(5, true, false, 0, true, true, 2, false, false);
	}
	@Test
	public void test12108() {
		o.launch(5, true, false, 0, true, true, 3, true, true);
	}
	@Test
	public void test12109() {
		o.launch(5, true, false, 0, true, true, 3, true, false);
	}
	@Test
	public void test12110() {
		o.launch(5, true, false, 0, true, true, 3, false, true);
	}
	@Test
	public void test12111() {
		o.launch(5, true, false, 0, true, true, 3, false, false);
	}
	@Test
	public void test12112() {
		o.launch(5, true, false, 0, true, true, 4, true, true);
	}
	@Test
	public void test12113() {
		o.launch(100, true, false, 0, true, true, 4, true, false);
	}
	@Test
	public void test12114() {
		o.launch(5, true, false, 0, true, true, 4, false, true);
	}
	@Test
	public void test12115() {
		o.launch(-1, true, false, 0, true, true, 4, false, false);
	}
	@Test
	public void test12116() {
		o.launch(-1, true, false, 0, true, true, 100, true, true);
	}
	@Test
	public void test12117() {
		o.launch(-1, true, false, 0, true, true, 10, true, false);
	}
	@Test
	public void test12118() {
		o.launch(-1, true, false, 0, true, true, 10, false, true);
	}
	@Test
	public void test12119() {
		o.launch(-1, true, false, 0, true, true, 10, false, false);
	}
	@Test
	public void test12120() {
		o.launch(10, true, false, 0, true, false, 0, true, true);
	}
	@Test
	public void test12121() {
		o.launch(10, true, false, 0, true, false, 0, true, false);
	}
	@Test
	public void test12122() {
		o.launch(10, true, false, 0, true, false, 0, false, true);
	}
	@Test
	public void test12123() {
		o.launch(10, true, false, 0, true, false, 0, false, false);
	}
	@Test
	public void test12124() {
		o.launch(10, true, false, 0, true, false, 1, true, true);
	}
	@Test
	public void test12125() {
		o.launch(-1, true, false, 0, true, false, 1, true, false);
	}
	@Test
	public void test12126() {
		o.launch(10, true, false, 0, true, false, 1, false, true);
	}
	@Test
	public void test12127() {
		o.launch(-1, true, false, 0, true, false, 1, false, false);
	}
	@Test
	public void test12128() {
		o.launch(5, true, false, 0, true, false, 2, true, true);
	}
	@Test
	public void test12129() {
		o.launch(5, true, false, 0, true, false, 2, true, false);
	}
	@Test
	public void test12130() {
		o.launch(5, true, false, 0, true, false, 2, false, true);
	}
	@Test
	public void test12131() {
		o.launch(5, true, false, 0, true, false, 2, false, false);
	}
	@Test
	public void test12132() {
		o.launch(5, true, false, 0, true, false, 3, true, true);
	}
	@Test
	public void test12133() {
		o.launch(5, true, false, 0, true, false, 3, true, false);
	}
	@Test
	public void test12134() {
		o.launch(5, true, false, 0, true, false, 3, false, true);
	}
	@Test
	public void test12135() {
		o.launch(5, true, false, 0, true, false, 3, false, false);
	}
	@Test
	public void test12136() {
		o.launch(-1, true, false, 0, true, false, 4, true, true);
	}
	@Test
	public void test12137() {
		o.launch(10, true, false, 0, true, false, 4, true, false);
	}
	@Test
	public void test12138() {
		o.launch(5, true, false, 0, true, false, 4, false, true);
	}
	@Test
	public void test12139() {
		o.launch(-1, true, false, 0, true, false, 4, false, false);
	}
	@Test
	public void test12140() {
		o.launch(-1, true, false, 0, true, false, 10, true, true);
	}
	@Test
	public void test12141() {
		o.launch(-1, true, false, 0, true, false, 10, true, false);
	}
	@Test
	public void test12142() {
		o.launch(-1, true, false, 0, true, false, 10, false, true);
	}
	@Test
	public void test12143() {
		o.launch(-1, true, false, 0, true, false, 10, false, false);
	}
	@Test
	public void test12144() {
		o.launch(10, true, false, 0, false, true, 0, true, true);
	}
	@Test
	public void test12145() {
		o.launch(-1, true, false, 0, false, true, 0, true, false);
	}
	@Test
	public void test12146() {
		o.launch(-1, true, false, 0, false, true, 0, false, true);
	}
	@Test
	public void test12147() {
		o.launch(100, true, false, 0, false, true, 0, false, false);
	}
	@Test
	public void test12148() {
		o.launch(-1, true, false, 0, false, true, 1, true, true);
	}
	@Test
	public void test12149() {
		o.launch(-1, true, false, 0, false, true, 1, true, false);
	}
	@Test
	public void test12150() {
		o.launch(10, true, false, 0, false, true, 1, false, true);
	}
	@Test
	public void test12151() {
		o.launch(-1, true, false, 0, false, true, 1, false, false);
	}
	@Test
	public void test12152() {
		o.launch(5, true, false, 0, false, true, 2, true, true);
	}
	@Test
	public void test12153() {
		o.launch(5, true, false, 0, false, true, 2, true, false);
	}
	@Test
	public void test12154() {
		o.launch(5, true, false, 0, false, true, 2, false, true);
	}
	@Test
	public void test12155() {
		o.launch(5, true, false, 0, false, true, 2, false, false);
	}
	@Test
	public void test12156() {
		o.launch(5, true, false, 0, false, true, 3, true, true);
	}
	@Test
	public void test12157() {
		o.launch(5, true, false, 0, false, true, 3, true, false);
	}
	@Test
	public void test12158() {
		o.launch(5, true, false, 0, false, true, 3, false, true);
	}
	@Test
	public void test12159() {
		o.launch(5, true, false, 0, false, true, 3, false, false);
	}
	@Test
	public void test12160() {
		o.launch(5, true, false, 0, false, true, 4, true, true);
	}
	@Test
	public void test12161() {
		o.launch(-1, true, false, 0, false, true, 4, true, false);
	}
	@Test
	public void test12162() {
		o.launch(100, true, false, 0, false, true, 4, false, true);
	}
	@Test
	public void test12163() {
		o.launch(-1, true, false, 0, false, true, 4, false, false);
	}
	@Test
	public void test12164() {
		o.launch(10, true, false, 0, false, true, 100, true, true);
	}
	@Test
	public void test12165() {
		o.launch(-1, true, false, 0, false, true, 100, true, false);
	}
	@Test
	public void test12166() {
		o.launch(10, true, false, 0, false, true, 100, false, true);
	}
	@Test
	public void test12167() {
		o.launch(10, true, false, 0, false, true, 100, false, false);
	}
	@Test
	public void test12168() {
		o.launch(-1, true, false, 0, false, false, 0, true, true);
	}
	@Test
	public void test12169() {
		o.launch(10, true, false, 0, false, false, 0, true, false);
	}
	@Test
	public void test12170() {
		o.launch(100, true, false, 0, false, false, 0, false, true);
	}
	@Test
	public void test12171() {
		o.launch(100, true, false, 0, false, false, 0, false, false);
	}
	@Test
	public void test12172() {
		o.launch(100, true, false, 0, false, false, 1, true, true);
	}
	@Test
	public void test12173() {
		o.launch(10, true, false, 0, false, false, 1, true, false);
	}
	@Test
	public void test12174() {
		o.launch(10, true, false, 0, false, false, 1, false, true);
	}
	@Test
	public void test12175() {
		o.launch(10, true, false, 0, false, false, 1, false, false);
	}
	@Test
	public void test12176() {
		o.launch(5, true, false, 0, false, false, 2, true, true);
	}
	@Test
	public void test12177() {
		o.launch(5, true, false, 0, false, false, 2, true, false);
	}
	@Test
	public void test12178() {
		o.launch(5, true, false, 0, false, false, 2, false, true);
	}
	@Test
	public void test12179() {
		o.launch(5, true, false, 0, false, false, 2, false, false);
	}
	@Test
	public void test12180() {
		o.launch(5, true, false, 0, false, false, 3, true, true);
	}
	@Test
	public void test12181() {
		o.launch(5, true, false, 0, false, false, 3, true, false);
	}
	@Test
	public void test12182() {
		o.launch(5, true, false, 0, false, false, 3, false, true);
	}
	@Test
	public void test12183() {
		o.launch(5, true, false, 0, false, false, 3, false, false);
	}
	@Test
	public void test12184() {
		o.launch(5, true, false, 0, false, false, 4, true, true);
	}
	@Test
	public void test12185() {
		o.launch(-1, true, false, 0, false, false, 4, true, false);
	}
	@Test
	public void test12186() {
		o.launch(5, true, false, 0, false, false, 4, false, true);
	}
	@Test
	public void test12187() {
		o.launch(5, true, false, 0, false, false, 4, false, false);
	}
	@Test
	public void test12188() {
		o.launch(-1, true, false, 0, false, false, 100, true, true);
	}
	@Test
	public void test12189() {
		o.launch(100, true, false, 0, false, false, -1, true, false);
	}
	@Test
	public void test12190() {
		o.launch(100, true, false, 0, false, false, -1, false, true);
	}
	@Test
	public void test12191() {
		o.launch(-1, true, false, 0, false, false, 10, false, false);
	}
	@Test
	public void test12192() {
		o.launch(-1, true, false, 1, true, true, 0, true, true);
	}
	@Test
	public void test12193() {
		o.launch(-1, true, false, 1, true, true, 0, true, false);
	}
	@Test
	public void test12194() {
		o.launch(10, true, false, 1, true, true, 0, false, true);
	}
	@Test
	public void test12195() {
		o.launch(10, true, false, 1, true, true, 0, false, false);
	}
	@Test
	public void test12196() {
		o.launch(-1, true, false, 1, true, true, 1, true, true);
	}
	@Test
	public void test12197() {
		o.launch(-1, true, false, 1, true, true, 1, true, false);
	}
	@Test
	public void test12198() {
		o.launch(-1, true, false, 1, true, true, 1, false, true);
	}
	@Test
	public void test12199() {
		o.launch(5, true, false, 1, true, true, 1, false, false);
	}
	@Test
	public void test12200() {
		o.launch(5, true, false, 1, true, true, 2, true, true);
	}
	@Test
	public void test12201() {
		o.launch(5, true, false, 1, true, true, 2, true, false);
	}
	@Test
	public void test12202() {
		o.launch(5, true, false, 1, true, true, 2, false, true);
	}
	@Test
	public void test12203() {
		o.launch(5, true, false, 1, true, true, 2, false, false);
	}
	@Test
	public void test12204() {
		o.launch(5, true, false, 1, true, true, 3, true, true);
	}
	@Test
	public void test12205() {
		o.launch(5, true, false, 1, true, true, 3, true, false);
	}
	@Test
	public void test12206() {
		o.launch(5, true, false, 1, true, true, 3, false, true);
	}
	@Test
	public void test12207() {
		o.launch(5, true, false, 1, true, true, 3, false, false);
	}
	@Test
	public void test12208() {
		o.launch(10, true, false, 1, true, true, 4, true, true);
	}
	@Test
	public void test12209() {
		o.launch(5, true, false, 1, true, true, 4, true, false);
	}
	@Test
	public void test12210() {
		o.launch(10, true, false, 1, true, true, 4, false, true);
	}
	@Test
	public void test12211() {
		o.launch(5, true, false, 1, true, true, 4, false, false);
	}
	@Test
	public void test12212() {
		o.launch(10, true, false, 1, true, true, 100, true, true);
	}
	@Test
	public void test12213() {
		o.launch(-1, true, false, 1, true, true, 10, true, false);
	}
	@Test
	public void test12214() {
		o.launch(-1, true, false, 1, true, true, 100, false, true);
	}
	@Test
	public void test12215() {
		o.launch(-1, true, false, 1, true, true, 10, false, false);
	}
	@Test
	public void test12216() {
		o.launch(10, true, false, 1, true, false, 0, true, true);
	}
	@Test
	public void test12217() {
		o.launch(10, true, false, 1, true, false, 0, true, false);
	}
	@Test
	public void test12218() {
		o.launch(10, true, false, 1, true, false, 0, false, true);
	}
	@Test
	public void test12219() {
		o.launch(10, true, false, 1, true, false, 0, false, false);
	}
	@Test
	public void test12220() {
		o.launch(-1, true, false, 1, true, false, 1, true, true);
	}
	@Test
	public void test12221() {
		o.launch(-1, true, false, 1, true, false, 1, true, false);
	}
	@Test
	public void test12222() {
		o.launch(100, true, false, 1, true, false, 1, false, true);
	}
	@Test
	public void test12223() {
		o.launch(100, true, false, 1, true, false, 1, false, false);
	}
	@Test
	public void test12224() {
		o.launch(5, true, false, 1, true, false, 2, true, true);
	}
	@Test
	public void test12225() {
		o.launch(5, true, false, 1, true, false, 2, true, false);
	}
	@Test
	public void test12226() {
		o.launch(5, true, false, 1, true, false, 2, false, true);
	}
	@Test
	public void test12227() {
		o.launch(5, true, false, 1, true, false, 2, false, false);
	}
	@Test
	public void test12228() {
		o.launch(5, true, false, 1, true, false, 3, true, true);
	}
	@Test
	public void test12229() {
		o.launch(5, true, false, 1, true, false, 3, true, false);
	}
	@Test
	public void test12230() {
		o.launch(5, true, false, 1, true, false, 3, false, true);
	}
	@Test
	public void test12231() {
		o.launch(5, true, false, 1, true, false, 3, false, false);
	}
	@Test
	public void test12232() {
		o.launch(5, true, false, 1, true, false, 4, true, true);
	}
	@Test
	public void test12233() {
		o.launch(10, true, false, 1, true, false, 4, true, false);
	}
	@Test
	public void test12234() {
		o.launch(100, true, false, 1, true, false, 4, false, true);
	}
	@Test
	public void test12235() {
		o.launch(-1, true, false, 1, true, false, 4, false, false);
	}
	@Test
	public void test12236() {
		o.launch(-1, true, false, 1, true, false, 100, true, true);
	}
	@Test
	public void test12237() {
		o.launch(100, true, false, 1, true, false, -1, true, false);
	}
	@Test
	public void test12238() {
		o.launch(100, true, false, 1, true, false, -1, false, true);
	}
	@Test
	public void test12239() {
		o.launch(10, true, false, 1, true, false, -1, false, false);
	}
	@Test
	public void test12240() {
		o.launch(10, true, false, 1, false, true, 0, true, true);
	}
	@Test
	public void test12241() {
		o.launch(10, true, false, 1, false, true, 0, true, false);
	}
	@Test
	public void test12242() {
		o.launch(100, true, false, 1, false, true, 0, false, true);
	}
	@Test
	public void test12243() {
		o.launch(100, true, false, 1, false, true, 0, false, false);
	}
	@Test
	public void test12244() {
		o.launch(100, true, false, 1, false, true, 1, true, true);
	}
	@Test
	public void test12245() {
		o.launch(-1, true, false, 1, false, true, 1, true, false);
	}
	@Test
	public void test12246() {
		o.launch(10, true, false, 1, false, true, 1, false, true);
	}
	@Test
	public void test12247() {
		o.launch(10, true, false, 1, false, true, 1, false, false);
	}
	@Test
	public void test12248() {
		o.launch(5, true, false, 1, false, true, 2, true, true);
	}
	@Test
	public void test12249() {
		o.launch(5, true, false, 1, false, true, 2, true, false);
	}
	@Test
	public void test12250() {
		o.launch(5, true, false, 1, false, true, 2, false, true);
	}
	@Test
	public void test12251() {
		o.launch(5, true, false, 1, false, true, 2, false, false);
	}
	@Test
	public void test12252() {
		o.launch(5, true, false, 1, false, true, 3, true, true);
	}
	@Test
	public void test12253() {
		o.launch(5, true, false, 1, false, true, 3, true, false);
	}
	@Test
	public void test12254() {
		o.launch(5, true, false, 1, false, true, 3, false, true);
	}
	@Test
	public void test12255() {
		o.launch(5, true, false, 1, false, true, 3, false, false);
	}
	@Test
	public void test12256() {
		o.launch(5, true, false, 1, false, true, 4, true, true);
	}
	@Test
	public void test12257() {
		o.launch(-1, true, false, 1, false, true, 4, true, false);
	}
	@Test
	public void test12258() {
		o.launch(5, true, false, 1, false, true, 4, false, true);
	}
	@Test
	public void test12259() {
		o.launch(5, true, false, 1, false, true, 4, false, false);
	}
	@Test
	public void test12260() {
		o.launch(-1, true, false, 1, false, true, 10, true, true);
	}
	@Test
	public void test12261() {
		o.launch(-1, true, false, 1, false, true, 10, true, false);
	}
	@Test
	public void test12262() {
		o.launch(100, true, false, 1, false, true, -1, false, true);
	}
	@Test
	public void test12263() {
		o.launch(100, true, false, 1, false, true, -1, false, false);
	}
	@Test
	public void test12264() {
		o.launch(-1, true, false, 1, false, false, 0, true, true);
	}
	@Test
	public void test12265() {
		o.launch(5, true, false, 1, false, false, 0, true, false);
	}
	@Test
	public void test12266() {
		o.launch(-1, true, false, 1, false, false, 0, false, true);
	}
	@Test
	public void test12267() {
		o.launch(-1, true, false, 1, false, false, 0, false, false);
	}
	@Test
	public void test12268() {
		o.launch(-1, true, false, 1, false, false, 1, true, true);
	}
	@Test
	public void test12269() {
		o.launch(-1, true, false, 1, false, false, 1, true, false);
	}
	@Test
	public void test12270() {
		o.launch(-1, true, false, 1, false, false, 1, false, true);
	}
	@Test
	public void test12271() {
		o.launch(10, true, false, 1, false, false, 1, false, false);
	}
	@Test
	public void test12272() {
		o.launch(5, true, false, 1, false, false, 2, true, true);
	}
	@Test
	public void test12273() {
		o.launch(5, true, false, 1, false, false, 2, true, false);
	}
	@Test
	public void test12274() {
		o.launch(5, true, false, 1, false, false, 2, false, true);
	}
	@Test
	public void test12275() {
		o.launch(5, true, false, 1, false, false, 2, false, false);
	}
	@Test
	public void test12276() {
		o.launch(5, true, false, 1, false, false, 3, true, true);
	}
	@Test
	public void test12277() {
		o.launch(5, true, false, 1, false, false, 3, true, false);
	}
	@Test
	public void test12278() {
		o.launch(5, true, false, 1, false, false, 3, false, true);
	}
	@Test
	public void test12279() {
		o.launch(5, true, false, 1, false, false, 3, false, false);
	}
	@Test
	public void test12280() {
		o.launch(5, true, false, 1, false, false, 4, true, true);
	}
	@Test
	public void test12281() {
		o.launch(5, true, false, 1, false, false, 4, true, false);
	}
	@Test
	public void test12282() {
		o.launch(5, true, false, 1, false, false, 4, false, true);
	}
	@Test
	public void test12283() {
		o.launch(100, true, false, 1, false, false, 4, false, false);
	}
	@Test
	public void test12284() {
		o.launch(10, true, false, 1, false, false, -1, true, true);
	}
	@Test
	public void test12285() {
		o.launch(-1, true, false, 1, false, false, -1, true, false);
	}
	@Test
	public void test12286() {
		o.launch(10, true, false, 1, false, false, -1, false, true);
	}
	@Test
	public void test12287() {
		o.launch(-1, true, false, 1, false, false, -1, false, false);
	}
	@Test
	public void test12288() {
		o.launch(5, true, false, 2, true, true, 0, true, true);
	}
	@Test
	public void test12289() {
		o.launch(5, true, false, 2, true, true, 0, true, false);
	}
	@Test
	public void test12290() {
		o.launch(5, true, false, 2, true, true, 0, false, true);
	}
	@Test
	public void test12291() {
		o.launch(5, true, false, 2, true, true, 0, false, false);
	}
	@Test
	public void test12292() {
		o.launch(5, true, false, 2, true, true, 1, true, true);
	}
	@Test
	public void test12293() {
		o.launch(5, true, false, 2, true, true, 1, true, false);
	}
	@Test
	public void test12294() {
		o.launch(5, true, false, 2, true, true, 1, false, true);
	}
	@Test
	public void test12295() {
		o.launch(5, true, false, 2, true, true, 1, false, false);
	}
	@Test
	public void test12296() {
		o.launch(5, true, false, 2, true, true, 2, true, true);
	}
	@Test
	public void test12297() {
		o.launch(5, true, false, 2, true, true, 2, true, false);
	}
	@Test
	public void test12298() {
		o.launch(5, true, false, 2, true, true, 2, false, true);
	}
	@Test
	public void test12299() {
		o.launch(5, true, false, 2, true, true, 2, false, false);
	}
	@Test
	public void test12300() {
		o.launch(5, true, false, 2, true, true, 3, true, true);
	}
	@Test
	public void test12301() {
		o.launch(5, true, false, 2, true, true, 3, true, false);
	}
	@Test
	public void test12302() {
		o.launch(5, true, false, 2, true, true, 3, false, true);
	}
	@Test
	public void test12303() {
		o.launch(5, true, false, 2, true, true, 3, false, false);
	}
	@Test
	public void test12304() {
		o.launch(5, true, false, 2, true, true, 4, true, true);
	}
	@Test
	public void test12305() {
		o.launch(5, true, false, 2, true, true, 4, true, false);
	}
	@Test
	public void test12306() {
		o.launch(5, true, false, 2, true, true, 4, false, true);
	}
	@Test
	public void test12307() {
		o.launch(5, true, false, 2, true, true, 4, false, false);
	}
	@Test
	public void test12308() {
		o.launch(5, true, false, 2, true, true, 5, true, true);
	}
	@Test
	public void test12309() {
		o.launch(5, true, false, 2, true, true, 5, true, false);
	}
	@Test
	public void test12310() {
		o.launch(5, true, false, 2, true, true, 5, false, true);
	}
	@Test
	public void test12311() {
		o.launch(5, true, false, 2, true, true, 5, false, false);
	}
	@Test
	public void test12312() {
		o.launch(5, true, false, 2, true, false, 0, true, true);
	}
	@Test
	public void test12313() {
		o.launch(5, true, false, 2, true, false, 0, true, false);
	}
	@Test
	public void test12314() {
		o.launch(5, true, false, 2, true, false, 0, false, true);
	}
	@Test
	public void test12315() {
		o.launch(5, true, false, 2, true, false, 0, false, false);
	}
	@Test
	public void test12316() {
		o.launch(5, true, false, 2, true, false, 1, true, true);
	}
	@Test
	public void test12317() {
		o.launch(5, true, false, 2, true, false, 1, true, false);
	}
	@Test
	public void test12318() {
		o.launch(5, true, false, 2, true, false, 1, false, true);
	}
	@Test
	public void test12319() {
		o.launch(5, true, false, 2, true, false, 1, false, false);
	}
	@Test
	public void test12320() {
		o.launch(5, true, false, 2, true, false, 2, true, true);
	}
	@Test
	public void test12321() {
		o.launch(5, true, false, 2, true, false, 2, true, false);
	}
	@Test
	public void test12322() {
		o.launch(5, true, false, 2, true, false, 2, false, true);
	}
	@Test
	public void test12323() {
		o.launch(5, true, false, 2, true, false, 2, false, false);
	}
	@Test
	public void test12324() {
		o.launch(5, true, false, 2, true, false, 3, true, true);
	}
	@Test
	public void test12325() {
		o.launch(5, true, false, 2, true, false, 3, true, false);
	}
	@Test
	public void test12326() {
		o.launch(5, true, false, 2, true, false, 3, false, true);
	}
	@Test
	public void test12327() {
		o.launch(5, true, false, 2, true, false, 3, false, false);
	}
	@Test
	public void test12328() {
		o.launch(5, true, false, 2, true, false, 4, true, true);
	}
	@Test
	public void test12329() {
		o.launch(5, true, false, 2, true, false, 4, true, false);
	}
	@Test
	public void test12330() {
		o.launch(5, true, false, 2, true, false, 4, false, true);
	}
	@Test
	public void test12331() {
		o.launch(5, true, false, 2, true, false, 4, false, false);
	}
	@Test
	public void test12332() {
		o.launch(5, true, false, 2, true, false, 5, true, true);
	}
	@Test
	public void test12333() {
		o.launch(5, true, false, 2, true, false, 5, true, false);
	}
	@Test
	public void test12334() {
		o.launch(5, true, false, 2, true, false, 5, false, true);
	}
	@Test
	public void test12335() {
		o.launch(5, true, false, 2, true, false, 5, false, false);
	}
	@Test
	public void test12336() {
		o.launch(5, true, false, 2, false, true, 0, true, true);
	}
	@Test
	public void test12337() {
		o.launch(5, true, false, 2, false, true, 0, true, false);
	}
	@Test
	public void test12338() {
		o.launch(5, true, false, 2, false, true, 0, false, true);
	}
	@Test
	public void test12339() {
		o.launch(5, true, false, 2, false, true, 0, false, false);
	}
	@Test
	public void test12340() {
		o.launch(5, true, false, 2, false, true, 1, true, true);
	}
	@Test
	public void test12341() {
		o.launch(5, true, false, 2, false, true, 1, true, false);
	}
	@Test
	public void test12342() {
		o.launch(5, true, false, 2, false, true, 1, false, true);
	}
	@Test
	public void test12343() {
		o.launch(5, true, false, 2, false, true, 1, false, false);
	}
	@Test
	public void test12344() {
		o.launch(5, true, false, 2, false, true, 2, true, true);
	}
	@Test
	public void test12345() {
		o.launch(5, true, false, 2, false, true, 2, true, false);
	}
	@Test
	public void test12346() {
		o.launch(5, true, false, 2, false, true, 2, false, true);
	}
	@Test
	public void test12347() {
		o.launch(5, true, false, 2, false, true, 2, false, false);
	}
	@Test
	public void test12348() {
		o.launch(5, true, false, 2, false, true, 3, true, true);
	}
	@Test
	public void test12349() {
		o.launch(5, true, false, 2, false, true, 3, true, false);
	}
	@Test
	public void test12350() {
		o.launch(5, true, false, 2, false, true, 3, false, true);
	}
	@Test
	public void test12351() {
		o.launch(5, true, false, 2, false, true, 3, false, false);
	}
	@Test
	public void test12352() {
		o.launch(5, true, false, 2, false, true, 4, true, true);
	}
	@Test
	public void test12353() {
		o.launch(5, true, false, 2, false, true, 4, true, false);
	}
	@Test
	public void test12354() {
		o.launch(5, true, false, 2, false, true, 4, false, true);
	}
	@Test
	public void test12355() {
		o.launch(5, true, false, 2, false, true, 4, false, false);
	}
	@Test
	public void test12356() {
		o.launch(5, true, false, 2, false, true, 5, true, true);
	}
	@Test
	public void test12357() {
		o.launch(5, true, false, 2, false, true, 5, true, false);
	}
	@Test
	public void test12358() {
		o.launch(5, true, false, 2, false, true, 5, false, true);
	}
	@Test
	public void test12359() {
		o.launch(5, true, false, 2, false, true, 5, false, false);
	}
	@Test
	public void test12360() {
		o.launch(5, true, false, 2, false, false, 0, true, true);
	}
	@Test
	public void test12361() {
		o.launch(5, true, false, 2, false, false, 0, true, false);
	}
	@Test
	public void test12362() {
		o.launch(5, true, false, 2, false, false, 0, false, true);
	}
	@Test
	public void test12363() {
		o.launch(5, true, false, 2, false, false, 0, false, false);
	}
	@Test
	public void test12364() {
		o.launch(5, true, false, 2, false, false, 1, true, true);
	}
	@Test
	public void test12365() {
		o.launch(5, true, false, 2, false, false, 1, true, false);
	}
	@Test
	public void test12366() {
		o.launch(5, true, false, 2, false, false, 1, false, true);
	}
	@Test
	public void test12367() {
		o.launch(5, true, false, 2, false, false, 1, false, false);
	}
	@Test
	public void test12368() {
		o.launch(5, true, false, 2, false, false, 2, true, true);
	}
	@Test
	public void test12369() {
		o.launch(5, true, false, 2, false, false, 2, true, false);
	}
	@Test
	public void test12370() {
		o.launch(5, true, false, 2, false, false, 2, false, true);
	}
	@Test
	public void test12371() {
		o.launch(5, true, false, 2, false, false, 2, false, false);
	}
	@Test
	public void test12372() {
		o.launch(5, true, false, 2, false, false, 3, true, true);
	}
	@Test
	public void test12373() {
		o.launch(5, true, false, 2, false, false, 3, true, false);
	}
	@Test
	public void test12374() {
		o.launch(5, true, false, 2, false, false, 3, false, true);
	}
	@Test
	public void test12375() {
		o.launch(5, true, false, 2, false, false, 3, false, false);
	}
	@Test
	public void test12376() {
		o.launch(5, true, false, 2, false, false, 4, true, true);
	}
	@Test
	public void test12377() {
		o.launch(5, true, false, 2, false, false, 4, true, false);
	}
	@Test
	public void test12378() {
		o.launch(5, true, false, 2, false, false, 4, false, true);
	}
	@Test
	public void test12379() {
		o.launch(5, true, false, 2, false, false, 4, false, false);
	}
	@Test
	public void test12380() {
		o.launch(5, true, false, 2, false, false, 5, true, true);
	}
	@Test
	public void test12381() {
		o.launch(5, true, false, 2, false, false, 5, true, false);
	}
	@Test
	public void test12382() {
		o.launch(5, true, false, 2, false, false, 5, false, true);
	}
	@Test
	public void test12383() {
		o.launch(5, true, false, 2, false, false, 5, false, false);
	}
	@Test
	public void test12384() {
		o.launch(5, true, false, 3, true, true, 0, true, true);
	}
	@Test
	public void test12385() {
		o.launch(5, true, false, 3, true, true, 0, true, false);
	}
	@Test
	public void test12386() {
		o.launch(5, true, false, 3, true, true, 0, false, true);
	}
	@Test
	public void test12387() {
		o.launch(5, true, false, 3, true, true, 0, false, false);
	}
	@Test
	public void test12388() {
		o.launch(5, true, false, 3, true, true, 1, true, true);
	}
	@Test
	public void test12389() {
		o.launch(5, true, false, 3, true, true, 1, true, false);
	}
	@Test
	public void test12390() {
		o.launch(5, true, false, 3, true, true, 1, false, true);
	}
	@Test
	public void test12391() {
		o.launch(5, true, false, 3, true, true, 1, false, false);
	}
	@Test
	public void test12392() {
		o.launch(5, true, false, 3, true, true, 2, true, true);
	}
	@Test
	public void test12393() {
		o.launch(5, true, false, 3, true, true, 2, true, false);
	}
	@Test
	public void test12394() {
		o.launch(5, true, false, 3, true, true, 2, false, true);
	}
	@Test
	public void test12395() {
		o.launch(5, true, false, 3, true, true, 2, false, false);
	}
	@Test
	public void test12396() {
		o.launch(5, true, false, 3, true, true, 3, true, true);
	}
	@Test
	public void test12397() {
		o.launch(5, true, false, 3, true, true, 3, true, false);
	}
	@Test
	public void test12398() {
		o.launch(5, true, false, 3, true, true, 3, false, true);
	}
	@Test
	public void test12399() {
		o.launch(5, true, false, 3, true, true, 3, false, false);
	}
	@Test
	public void test12400() {
		o.launch(5, true, false, 3, true, true, 4, true, true);
	}
	@Test
	public void test12401() {
		o.launch(5, true, false, 3, true, true, 4, true, false);
	}
	@Test
	public void test12402() {
		o.launch(5, true, false, 3, true, true, 4, false, true);
	}
	@Test
	public void test12403() {
		o.launch(5, true, false, 3, true, true, 4, false, false);
	}
	@Test
	public void test12404() {
		o.launch(5, true, false, 3, true, true, 5, true, true);
	}
	@Test
	public void test12405() {
		o.launch(5, true, false, 3, true, true, 5, true, false);
	}
	@Test
	public void test12406() {
		o.launch(5, true, false, 3, true, true, 5, false, true);
	}
	@Test
	public void test12407() {
		o.launch(5, true, false, 3, true, true, 5, false, false);
	}
	@Test
	public void test12408() {
		o.launch(5, true, false, 3, true, false, 0, true, true);
	}
	@Test
	public void test12409() {
		o.launch(5, true, false, 3, true, false, 0, true, false);
	}
	@Test
	public void test12410() {
		o.launch(5, true, false, 3, true, false, 0, false, true);
	}
	@Test
	public void test12411() {
		o.launch(5, true, false, 3, true, false, 0, false, false);
	}
	@Test
	public void test12412() {
		o.launch(5, true, false, 3, true, false, 1, true, true);
	}
	@Test
	public void test12413() {
		o.launch(5, true, false, 3, true, false, 1, true, false);
	}
	@Test
	public void test12414() {
		o.launch(5, true, false, 3, true, false, 1, false, true);
	}
	@Test
	public void test12415() {
		o.launch(5, true, false, 3, true, false, 1, false, false);
	}
	@Test
	public void test12416() {
		o.launch(5, true, false, 3, true, false, 2, true, true);
	}
	@Test
	public void test12417() {
		o.launch(5, true, false, 3, true, false, 2, true, false);
	}
	@Test
	public void test12418() {
		o.launch(5, true, false, 3, true, false, 2, false, true);
	}
	@Test
	public void test12419() {
		o.launch(5, true, false, 3, true, false, 2, false, false);
	}
	@Test
	public void test12420() {
		o.launch(5, true, false, 3, true, false, 3, true, true);
	}
	@Test
	public void test12421() {
		o.launch(5, true, false, 3, true, false, 3, true, false);
	}
	@Test
	public void test12422() {
		o.launch(5, true, false, 3, true, false, 3, false, true);
	}
	@Test
	public void test12423() {
		o.launch(5, true, false, 3, true, false, 3, false, false);
	}
	@Test
	public void test12424() {
		o.launch(5, true, false, 3, true, false, 4, true, true);
	}
	@Test
	public void test12425() {
		o.launch(5, true, false, 3, true, false, 4, true, false);
	}
	@Test
	public void test12426() {
		o.launch(5, true, false, 3, true, false, 4, false, true);
	}
	@Test
	public void test12427() {
		o.launch(5, true, false, 3, true, false, 4, false, false);
	}
	@Test
	public void test12428() {
		o.launch(5, true, false, 3, true, false, 5, true, true);
	}
	@Test
	public void test12429() {
		o.launch(5, true, false, 3, true, false, 5, true, false);
	}
	@Test
	public void test12430() {
		o.launch(5, true, false, 3, true, false, 5, false, true);
	}
	@Test
	public void test12431() {
		o.launch(5, true, false, 3, true, false, 5, false, false);
	}
	@Test
	public void test12432() {
		o.launch(5, true, false, 3, false, true, 0, true, true);
	}
	@Test
	public void test12433() {
		o.launch(5, true, false, 3, false, true, 0, true, false);
	}
	@Test
	public void test12434() {
		o.launch(5, true, false, 3, false, true, 0, false, true);
	}
	@Test
	public void test12435() {
		o.launch(5, true, false, 3, false, true, 0, false, false);
	}
	@Test
	public void test12436() {
		o.launch(5, true, false, 3, false, true, 1, true, true);
	}
	@Test
	public void test12437() {
		o.launch(5, true, false, 3, false, true, 1, true, false);
	}
	@Test
	public void test12438() {
		o.launch(5, true, false, 3, false, true, 1, false, true);
	}
	@Test
	public void test12439() {
		o.launch(5, true, false, 3, false, true, 1, false, false);
	}
	@Test
	public void test12440() {
		o.launch(5, true, false, 3, false, true, 2, true, true);
	}
	@Test
	public void test12441() {
		o.launch(5, true, false, 3, false, true, 2, true, false);
	}
	@Test
	public void test12442() {
		o.launch(5, true, false, 3, false, true, 2, false, true);
	}
	@Test
	public void test12443() {
		o.launch(5, true, false, 3, false, true, 2, false, false);
	}
	@Test
	public void test12444() {
		o.launch(5, true, false, 3, false, true, 3, true, true);
	}
	@Test
	public void test12445() {
		o.launch(5, true, false, 3, false, true, 3, true, false);
	}
	@Test
	public void test12446() {
		o.launch(5, true, false, 3, false, true, 3, false, true);
	}
	@Test
	public void test12447() {
		o.launch(5, true, false, 3, false, true, 3, false, false);
	}
	@Test
	public void test12448() {
		o.launch(5, true, false, 3, false, true, 4, true, true);
	}
	@Test
	public void test12449() {
		o.launch(5, true, false, 3, false, true, 4, true, false);
	}
	@Test
	public void test12450() {
		o.launch(5, true, false, 3, false, true, 4, false, true);
	}
	@Test
	public void test12451() {
		o.launch(5, true, false, 3, false, true, 4, false, false);
	}
	@Test
	public void test12452() {
		o.launch(5, true, false, 3, false, true, 5, true, true);
	}
	@Test
	public void test12453() {
		o.launch(5, true, false, 3, false, true, 5, true, false);
	}
	@Test
	public void test12454() {
		o.launch(5, true, false, 3, false, true, 5, false, true);
	}
	@Test
	public void test12455() {
		o.launch(5, true, false, 3, false, true, 5, false, false);
	}
	@Test
	public void test12456() {
		o.launch(5, true, false, 3, false, false, 0, true, true);
	}
	@Test
	public void test12457() {
		o.launch(5, true, false, 3, false, false, 0, true, false);
	}
	@Test
	public void test12458() {
		o.launch(5, true, false, 3, false, false, 0, false, true);
	}
	@Test
	public void test12459() {
		o.launch(5, true, false, 3, false, false, 0, false, false);
	}
	@Test
	public void test12460() {
		o.launch(5, true, false, 3, false, false, 1, true, true);
	}
	@Test
	public void test12461() {
		o.launch(5, true, false, 3, false, false, 1, true, false);
	}
	@Test
	public void test12462() {
		o.launch(5, true, false, 3, false, false, 1, false, true);
	}
	@Test
	public void test12463() {
		o.launch(5, true, false, 3, false, false, 1, false, false);
	}
	@Test
	public void test12464() {
		o.launch(5, true, false, 3, false, false, 2, true, true);
	}
	@Test
	public void test12465() {
		o.launch(5, true, false, 3, false, false, 2, true, false);
	}
	@Test
	public void test12466() {
		o.launch(5, true, false, 3, false, false, 2, false, true);
	}
	@Test
	public void test12467() {
		o.launch(5, true, false, 3, false, false, 2, false, false);
	}
	@Test
	public void test12468() {
		o.launch(5, true, false, 3, false, false, 3, true, true);
	}
	@Test
	public void test12469() {
		o.launch(5, true, false, 3, false, false, 3, true, false);
	}
	@Test
	public void test12470() {
		o.launch(5, true, false, 3, false, false, 3, false, true);
	}
	@Test
	public void test12471() {
		o.launch(5, true, false, 3, false, false, 3, false, false);
	}
	@Test
	public void test12472() {
		o.launch(5, true, false, 3, false, false, 4, true, true);
	}
	@Test
	public void test12473() {
		o.launch(5, true, false, 3, false, false, 4, true, false);
	}
	@Test
	public void test12474() {
		o.launch(5, true, false, 3, false, false, 4, false, true);
	}
	@Test
	public void test12475() {
		o.launch(5, true, false, 3, false, false, 4, false, false);
	}
	@Test
	public void test12476() {
		o.launch(5, true, false, 3, false, false, 5, true, true);
	}
	@Test
	public void test12477() {
		o.launch(5, true, false, 3, false, false, 5, true, false);
	}
	@Test
	public void test12478() {
		o.launch(5, true, false, 3, false, false, 5, false, true);
	}
	@Test
	public void test12479() {
		o.launch(5, true, false, 3, false, false, 5, false, false);
	}
	@Test
	public void test12480() {
		o.launch(5, true, false, 4, true, true, 0, true, true);
	}
	@Test
	public void test12481() {
		o.launch(-1, true, false, 4, true, true, 0, true, false);
	}
	@Test
	public void test12482() {
		o.launch(-1, true, false, 4, true, true, 0, false, true);
	}
	@Test
	public void test12483() {
		o.launch(100, true, false, 4, true, true, 0, false, false);
	}
	@Test
	public void test12484() {
		o.launch(-1, true, false, 4, true, true, 1, true, true);
	}
	@Test
	public void test12485() {
		o.launch(5, true, false, 4, true, true, 1, true, false);
	}
	@Test
	public void test12486() {
		o.launch(100, true, false, 4, true, true, 1, false, true);
	}
	@Test
	public void test12487() {
		o.launch(5, true, false, 4, true, true, 1, false, false);
	}
	@Test
	public void test12488() {
		o.launch(5, true, false, 4, true, true, 2, true, true);
	}
	@Test
	public void test12489() {
		o.launch(5, true, false, 4, true, true, 2, true, false);
	}
	@Test
	public void test12490() {
		o.launch(5, true, false, 4, true, true, 2, false, true);
	}
	@Test
	public void test12491() {
		o.launch(5, true, false, 4, true, true, 2, false, false);
	}
	@Test
	public void test12492() {
		o.launch(5, true, false, 4, true, true, 3, true, true);
	}
	@Test
	public void test12493() {
		o.launch(5, true, false, 4, true, true, 3, true, false);
	}
	@Test
	public void test12494() {
		o.launch(5, true, false, 4, true, true, 3, false, true);
	}
	@Test
	public void test12495() {
		o.launch(5, true, false, 4, true, true, 3, false, false);
	}
	@Test
	public void test12496() {
		o.launch(5, true, false, 4, true, true, 4, true, true);
	}
	@Test
	public void test12497() {
		o.launch(5, true, false, 4, true, true, 4, true, false);
	}
	@Test
	public void test12498() {
		o.launch(-1, true, false, 4, true, true, 4, false, true);
	}
	@Test
	public void test12499() {
		o.launch(5, true, false, 4, true, true, 4, false, false);
	}
	@Test
	public void test12500() {
		o.launch(10, true, false, 4, true, true, 10, true, true);
	}
	@Test
	public void test12501() {
		o.launch(100, true, false, 4, true, true, -1, true, false);
	}
	@Test
	public void test12502() {
		o.launch(10, true, false, 4, true, true, 10, false, true);
	}
	@Test
	public void test12503() {
		o.launch(-1, true, false, 4, true, true, -1, false, false);
	}
	@Test
	public void test12504() {
		o.launch(-1, true, false, 4, true, false, 0, true, true);
	}
	@Test
	public void test12505() {
		o.launch(5, true, false, 4, true, false, 0, true, false);
	}
	@Test
	public void test12506() {
		o.launch(-1, true, false, 4, true, false, 0, false, true);
	}
	@Test
	public void test12507() {
		o.launch(5, true, false, 4, true, false, 0, false, false);
	}
	@Test
	public void test12508() {
		o.launch(5, true, false, 4, true, false, 1, true, true);
	}
	@Test
	public void test12509() {
		o.launch(100, true, false, 4, true, false, 1, true, false);
	}
	@Test
	public void test12510() {
		o.launch(10, true, false, 4, true, false, 1, false, true);
	}
	@Test
	public void test12511() {
		o.launch(5, true, false, 4, true, false, 1, false, false);
	}
	@Test
	public void test12512() {
		o.launch(5, true, false, 4, true, false, 2, true, true);
	}
	@Test
	public void test12513() {
		o.launch(5, true, false, 4, true, false, 2, true, false);
	}
	@Test
	public void test12514() {
		o.launch(5, true, false, 4, true, false, 2, false, true);
	}
	@Test
	public void test12515() {
		o.launch(5, true, false, 4, true, false, 2, false, false);
	}
	@Test
	public void test12516() {
		o.launch(5, true, false, 4, true, false, 3, true, true);
	}
	@Test
	public void test12517() {
		o.launch(5, true, false, 4, true, false, 3, true, false);
	}
	@Test
	public void test12518() {
		o.launch(5, true, false, 4, true, false, 3, false, true);
	}
	@Test
	public void test12519() {
		o.launch(5, true, false, 4, true, false, 3, false, false);
	}
	@Test
	public void test12520() {
		o.launch(5, true, false, 4, true, false, 4, true, true);
	}
	@Test
	public void test12521() {
		o.launch(5, true, false, 4, true, false, 4, true, false);
	}
	@Test
	public void test12522() {
		o.launch(5, true, false, 4, true, false, 4, false, true);
	}
	@Test
	public void test12523() {
		o.launch(5, true, false, 4, true, false, 4, false, false);
	}
	@Test
	public void test12524() {
		o.launch(100, true, false, 4, true, false, -1, true, true);
	}
	@Test
	public void test12525() {
		o.launch(10, true, false, 4, true, false, 10, true, false);
	}
	@Test
	public void test12526() {
		o.launch(10, true, false, 4, true, false, -1, false, true);
	}
	@Test
	public void test12527() {
		o.launch(100, true, false, 4, true, false, -1, false, false);
	}
	@Test
	public void test12528() {
		o.launch(10, true, false, 4, false, true, 0, true, true);
	}
	@Test
	public void test12529() {
		o.launch(5, true, false, 4, false, true, 0, true, false);
	}
	@Test
	public void test12530() {
		o.launch(10, true, false, 4, false, true, 0, false, true);
	}
	@Test
	public void test12531() {
		o.launch(-1, true, false, 4, false, true, 0, false, false);
	}
	@Test
	public void test12532() {
		o.launch(10, true, false, 4, false, true, 1, true, true);
	}
	@Test
	public void test12533() {
		o.launch(5, true, false, 4, false, true, 1, true, false);
	}
	@Test
	public void test12534() {
		o.launch(5, true, false, 4, false, true, 1, false, true);
	}
	@Test
	public void test12535() {
		o.launch(5, true, false, 4, false, true, 1, false, false);
	}
	@Test
	public void test12536() {
		o.launch(5, true, false, 4, false, true, 2, true, true);
	}
	@Test
	public void test12537() {
		o.launch(5, true, false, 4, false, true, 2, true, false);
	}
	@Test
	public void test12538() {
		o.launch(5, true, false, 4, false, true, 2, false, true);
	}
	@Test
	public void test12539() {
		o.launch(5, true, false, 4, false, true, 2, false, false);
	}
	@Test
	public void test12540() {
		o.launch(5, true, false, 4, false, true, 3, true, true);
	}
	@Test
	public void test12541() {
		o.launch(5, true, false, 4, false, true, 3, true, false);
	}
	@Test
	public void test12542() {
		o.launch(5, true, false, 4, false, true, 3, false, true);
	}
	@Test
	public void test12543() {
		o.launch(5, true, false, 4, false, true, 3, false, false);
	}
	@Test
	public void test12544() {
		o.launch(5, true, false, 4, false, true, 4, true, true);
	}
	@Test
	public void test12545() {
		o.launch(5, true, false, 4, false, true, 4, true, false);
	}
	@Test
	public void test12546() {
		o.launch(5, true, false, 4, false, true, 4, false, true);
	}
	@Test
	public void test12547() {
		o.launch(5, true, false, 4, false, true, 4, false, false);
	}
	@Test
	public void test12548() {
		o.launch(-1, true, false, 4, false, true, -1, true, true);
	}
	@Test
	public void test12549() {
		o.launch(10, true, false, 4, false, true, -1, true, false);
	}
	@Test
	public void test12550() {
		o.launch(-1, true, false, 4, false, true, 10, false, true);
	}
	@Test
	public void test12551() {
		o.launch(10, true, false, 4, false, true, 10, false, false);
	}
	@Test
	public void test12552() {
		o.launch(-1, true, false, 4, false, false, 0, true, true);
	}
	@Test
	public void test12553() {
		o.launch(-1, true, false, 4, false, false, 0, true, false);
	}
	@Test
	public void test12554() {
		o.launch(100, true, false, 4, false, false, 0, false, true);
	}
	@Test
	public void test12555() {
		o.launch(100, true, false, 4, false, false, 0, false, false);
	}
	@Test
	public void test12556() {
		o.launch(100, true, false, 4, false, false, 1, true, true);
	}
	@Test
	public void test12557() {
		o.launch(5, true, false, 4, false, false, 1, true, false);
	}
	@Test
	public void test12558() {
		o.launch(5, true, false, 4, false, false, 1, false, true);
	}
	@Test
	public void test12559() {
		o.launch(5, true, false, 4, false, false, 1, false, false);
	}
	@Test
	public void test12560() {
		o.launch(5, true, false, 4, false, false, 2, true, true);
	}
	@Test
	public void test12561() {
		o.launch(5, true, false, 4, false, false, 2, true, false);
	}
	@Test
	public void test12562() {
		o.launch(5, true, false, 4, false, false, 2, false, true);
	}
	@Test
	public void test12563() {
		o.launch(5, true, false, 4, false, false, 2, false, false);
	}
	@Test
	public void test12564() {
		o.launch(5, true, false, 4, false, false, 3, true, true);
	}
	@Test
	public void test12565() {
		o.launch(5, true, false, 4, false, false, 3, true, false);
	}
	@Test
	public void test12566() {
		o.launch(5, true, false, 4, false, false, 3, false, true);
	}
	@Test
	public void test12567() {
		o.launch(5, true, false, 4, false, false, 3, false, false);
	}
	@Test
	public void test12568() {
		o.launch(5, true, false, 4, false, false, 4, true, true);
	}
	@Test
	public void test12569() {
		o.launch(5, true, false, 4, false, false, 4, true, false);
	}
	@Test
	public void test12570() {
		o.launch(5, true, false, 4, false, false, 4, false, true);
	}
	@Test
	public void test12571() {
		o.launch(10, true, false, 4, false, false, 4, false, false);
	}
	@Test
	public void test12572() {
		o.launch(-1, true, false, 4, false, false, 100, true, true);
	}
	@Test
	public void test12573() {
		o.launch(100, true, false, 4, false, false, 100, true, false);
	}
	@Test
	public void test12574() {
		o.launch(-1, true, false, 4, false, false, 100, false, true);
	}
	@Test
	public void test12575() {
		o.launch(100, true, false, 4, false, false, 100, false, false);
	}
	@Test
	public void test12576() {
		o.launch(-1, true, false, -1, true, true, 0, true, true);
	}
	@Test
	public void test12577() {
		o.launch(-1, true, false, -1, true, true, 0, true, false);
	}
	@Test
	public void test12578() {
		o.launch(100, true, false, 10, true, true, 0, false, true);
	}
	@Test
	public void test12579() {
		o.launch(-1, true, false, -1, true, true, 0, false, false);
	}
	@Test
	public void test12580() {
		o.launch(100, true, false, 10, true, true, 1, true, true);
	}
	@Test
	public void test12581() {
		o.launch(100, true, false, 10, true, true, 1, true, false);
	}
	@Test
	public void test12582() {
		o.launch(-1, true, false, 10, true, true, 1, false, true);
	}
	@Test
	public void test12583() {
		o.launch(100, true, false, 10, true, true, 1, false, false);
	}
	@Test
	public void test12584() {
		o.launch(5, true, false, 5, true, true, 2, true, true);
	}
	@Test
	public void test12585() {
		o.launch(5, true, false, 5, true, true, 2, true, false);
	}
	@Test
	public void test12586() {
		o.launch(5, true, false, 5, true, true, 2, false, true);
	}
	@Test
	public void test12587() {
		o.launch(5, true, false, 5, true, true, 2, false, false);
	}
	@Test
	public void test12588() {
		o.launch(5, true, false, 5, true, true, 3, true, true);
	}
	@Test
	public void test12589() {
		o.launch(5, true, false, 5, true, true, 3, true, false);
	}
	@Test
	public void test12590() {
		o.launch(5, true, false, 5, true, true, 3, false, true);
	}
	@Test
	public void test12591() {
		o.launch(5, true, false, 5, true, true, 3, false, false);
	}
	@Test
	public void test12592() {
		o.launch(-1, true, false, 100, true, true, 4, true, true);
	}
	@Test
	public void test12593() {
		o.launch(5, true, false, 5, true, true, 4, true, false);
	}
	@Test
	public void test12594() {
		o.launch(-1, true, false, -1, true, true, 4, false, true);
	}
	@Test
	public void test12595() {
		o.launch(-1, true, false, 10, true, true, 4, false, false);
	}
	@Test
	public void test12596() {
		o.launch(-1, true, false, -1, true, true, 100, true, true);
	}
	@Test
	public void test12597() {
		o.launch(-1, true, false, -1, true, true, 100, true, false);
	}
	@Test
	public void test12598() {
		o.launch(-1, true, false, -1, true, true, 100, false, true);
	}
	@Test
	public void test12599() {
		o.launch(-1, true, false, 100, true, true, 100, false, false);
	}
	@Test
	public void test12600() {
		o.launch(100, true, false, 10, true, false, 0, true, true);
	}
	@Test
	public void test12601() {
		o.launch(100, true, false, 10, true, false, 0, true, false);
	}
	@Test
	public void test12602() {
		o.launch(100, true, false, 10, true, false, 0, false, true);
	}
	@Test
	public void test12603() {
		o.launch(10, true, false, -1, true, false, 0, false, false);
	}
	@Test
	public void test12604() {
		o.launch(10, true, false, -1, true, false, 1, true, true);
	}
	@Test
	public void test12605() {
		o.launch(10, true, false, -1, true, false, 1, true, false);
	}
	@Test
	public void test12606() {
		o.launch(-1, true, false, 10, true, false, 1, false, true);
	}
	@Test
	public void test12607() {
		o.launch(-1, true, false, 10, true, false, 1, false, false);
	}
	@Test
	public void test12608() {
		o.launch(5, true, false, 5, true, false, 2, true, true);
	}
	@Test
	public void test12609() {
		o.launch(5, true, false, 5, true, false, 2, true, false);
	}
	@Test
	public void test12610() {
		o.launch(5, true, false, 5, true, false, 2, false, true);
	}
	@Test
	public void test12611() {
		o.launch(5, true, false, 5, true, false, 2, false, false);
	}
	@Test
	public void test12612() {
		o.launch(5, true, false, 5, true, false, 3, true, true);
	}
	@Test
	public void test12613() {
		o.launch(5, true, false, 5, true, false, 3, true, false);
	}
	@Test
	public void test12614() {
		o.launch(5, true, false, 5, true, false, 3, false, true);
	}
	@Test
	public void test12615() {
		o.launch(5, true, false, 5, true, false, 3, false, false);
	}
	@Test
	public void test12616() {
		o.launch(10, true, false, 100, true, false, 4, true, true);
	}
	@Test
	public void test12617() {
		o.launch(10, true, false, 10, true, false, 4, true, false);
	}
	@Test
	public void test12618() {
		o.launch(-1, true, false, 10, true, false, 4, false, true);
	}
	@Test
	public void test12619() {
		o.launch(10, true, false, 10, true, false, 4, false, false);
	}
	@Test
	public void test12620() {
		o.launch(-1, true, false, -1, true, false, 100, true, true);
	}
	@Test
	public void test12621() {
		o.launch(-1, true, false, -1, true, false, 100, true, false);
	}
	@Test
	public void test12622() {
		o.launch(100, true, false, 10, true, false, -1, false, true);
	}
	@Test
	public void test12623() {
		o.launch(-1, true, false, -1, true, false, 100, false, false);
	}
	@Test
	public void test12624() {
		o.launch(100, true, false, -1, false, true, 0, true, true);
	}
	@Test
	public void test12625() {
		o.launch(10, true, false, 100, false, true, 0, true, false);
	}
	@Test
	public void test12626() {
		o.launch(100, true, false, 100, false, true, 0, false, true);
	}
	@Test
	public void test12627() {
		o.launch(100, true, false, 100, false, true, 0, false, false);
	}
	@Test
	public void test12628() {
		o.launch(100, true, false, 100, false, true, 1, true, true);
	}
	@Test
	public void test12629() {
		o.launch(-1, true, false, -1, false, true, 1, true, false);
	}
	@Test
	public void test12630() {
		o.launch(10, true, false, 100, false, true, 1, false, true);
	}
	@Test
	public void test12631() {
		o.launch(100, true, false, -1, false, true, 1, false, false);
	}
	@Test
	public void test12632() {
		o.launch(5, true, false, 5, false, true, 2, true, true);
	}
	@Test
	public void test12633() {
		o.launch(5, true, false, 5, false, true, 2, true, false);
	}
	@Test
	public void test12634() {
		o.launch(5, true, false, 5, false, true, 2, false, true);
	}
	@Test
	public void test12635() {
		o.launch(5, true, false, 5, false, true, 2, false, false);
	}
	@Test
	public void test12636() {
		o.launch(5, true, false, 5, false, true, 3, true, true);
	}
	@Test
	public void test12637() {
		o.launch(5, true, false, 5, false, true, 3, true, false);
	}
	@Test
	public void test12638() {
		o.launch(5, true, false, 5, false, true, 3, false, true);
	}
	@Test
	public void test12639() {
		o.launch(5, true, false, 5, false, true, 3, false, false);
	}
	@Test
	public void test12640() {
		o.launch(10, true, false, -1, false, true, 4, true, true);
	}
	@Test
	public void test12641() {
		o.launch(100, true, false, 10, false, true, 4, true, false);
	}
	@Test
	public void test12642() {
		o.launch(-1, true, false, 100, false, true, 4, false, true);
	}
	@Test
	public void test12643() {
		o.launch(10, true, false, 10, false, true, 4, false, false);
	}
	@Test
	public void test12644() {
		o.launch(-1, true, false, 10, false, true, 10, true, true);
	}
	@Test
	public void test12645() {
		o.launch(-1, true, false, 10, false, true, 10, true, false);
	}
	@Test
	public void test12646() {
		o.launch(-1, true, false, 10, false, true, 10, false, true);
	}
	@Test
	public void test12647() {
		o.launch(-1, true, false, 10, false, true, 10, false, false);
	}
	@Test
	public void test12648() {
		o.launch(10, true, false, 100, false, false, 0, true, true);
	}
	@Test
	public void test12649() {
		o.launch(-1, true, false, 10, false, false, 0, true, false);
	}
	@Test
	public void test12650() {
		o.launch(10, true, false, 100, false, false, 0, false, true);
	}
	@Test
	public void test12651() {
		o.launch(10, true, false, 100, false, false, 0, false, false);
	}
	@Test
	public void test12652() {
		o.launch(-1, true, false, -1, false, false, 1, true, true);
	}
	@Test
	public void test12653() {
		o.launch(-1, true, false, 10, false, false, 1, true, false);
	}
	@Test
	public void test12654() {
		o.launch(-1, true, false, 10, false, false, 1, false, true);
	}
	@Test
	public void test12655() {
		o.launch(-1, true, false, 10, false, false, 1, false, false);
	}
	@Test
	public void test12656() {
		o.launch(5, true, false, 5, false, false, 2, true, true);
	}
	@Test
	public void test12657() {
		o.launch(5, true, false, 5, false, false, 2, true, false);
	}
	@Test
	public void test12658() {
		o.launch(5, true, false, 5, false, false, 2, false, true);
	}
	@Test
	public void test12659() {
		o.launch(5, true, false, 5, false, false, 2, false, false);
	}
	@Test
	public void test12660() {
		o.launch(5, true, false, 5, false, false, 3, true, true);
	}
	@Test
	public void test12661() {
		o.launch(5, true, false, 5, false, false, 3, true, false);
	}
	@Test
	public void test12662() {
		o.launch(5, true, false, 5, false, false, 3, false, true);
	}
	@Test
	public void test12663() {
		o.launch(5, true, false, 5, false, false, 3, false, false);
	}
	@Test
	public void test12664() {
		o.launch(10, true, false, 10, false, false, 4, true, true);
	}
	@Test
	public void test12665() {
		o.launch(-1, true, false, 100, false, false, 4, true, false);
	}
	@Test
	public void test12666() {
		o.launch(100, true, false, -1, false, false, 4, false, true);
	}
	@Test
	public void test12667() {
		o.launch(-1, true, false, 10, false, false, 4, false, false);
	}
	@Test
	public void test12668() {
		o.launch(10, true, false, 100, false, false, -1, true, true);
	}
	@Test
	public void test12669() {
		o.launch(10, true, false, 100, false, false, -1, true, false);
	}
	@Test
	public void test12670() {
		o.launch(10, true, false, 100, false, false, -1, false, true);
	}
	@Test
	public void test12671() {
		o.launch(10, true, false, 100, false, false, -1, false, false);
	}
	@Test
	public void test12672() {
		o.launch(-1, false, true, 0, true, true, 0, true, true);
	}
	@Test
	public void test12673() {
		o.launch(10, false, true, 0, true, true, 0, true, false);
	}
	@Test
	public void test12674() {
		o.launch(-1, false, true, 0, true, true, 0, false, true);
	}
	@Test
	public void test12675() {
		o.launch(10, false, true, 0, true, true, 0, false, false);
	}
	@Test
	public void test12676() {
		o.launch(10, false, true, 0, true, true, 1, true, true);
	}
	@Test
	public void test12677() {
		o.launch(-1, false, true, 0, true, true, 1, true, false);
	}
	@Test
	public void test12678() {
		o.launch(-1, false, true, 0, true, true, 1, false, true);
	}
	@Test
	public void test12679() {
		o.launch(10, false, true, 0, true, true, 1, false, false);
	}
	@Test
	public void test12680() {
		o.launch(5, false, true, 0, true, true, 2, true, true);
	}
	@Test
	public void test12681() {
		o.launch(5, false, true, 0, true, true, 2, true, false);
	}
	@Test
	public void test12682() {
		o.launch(5, false, true, 0, true, true, 2, false, true);
	}
	@Test
	public void test12683() {
		o.launch(5, false, true, 0, true, true, 2, false, false);
	}
	@Test
	public void test12684() {
		o.launch(5, false, true, 0, true, true, 3, true, true);
	}
	@Test
	public void test12685() {
		o.launch(5, false, true, 0, true, true, 3, true, false);
	}
	@Test
	public void test12686() {
		o.launch(5, false, true, 0, true, true, 3, false, true);
	}
	@Test
	public void test12687() {
		o.launch(5, false, true, 0, true, true, 3, false, false);
	}
	@Test
	public void test12688() {
		o.launch(-1, false, true, 0, true, true, 4, true, true);
	}
	@Test
	public void test12689() {
		o.launch(100, false, true, 0, true, true, 4, true, false);
	}
	@Test
	public void test12690() {
		o.launch(10, false, true, 0, true, true, 4, false, true);
	}
	@Test
	public void test12691() {
		o.launch(5, false, true, 0, true, true, 4, false, false);
	}
	@Test
	public void test12692() {
		o.launch(100, false, true, 0, true, true, -1, true, true);
	}
	@Test
	public void test12693() {
		o.launch(100, false, true, 0, true, true, -1, true, false);
	}
	@Test
	public void test12694() {
		o.launch(100, false, true, 0, true, true, -1, false, true);
	}
	@Test
	public void test12695() {
		o.launch(10, false, true, 0, true, true, 10, false, false);
	}
	@Test
	public void test12696() {
		o.launch(10, false, true, 0, true, false, 0, true, true);
	}
	@Test
	public void test12697() {
		o.launch(-1, false, true, 0, true, false, 0, true, false);
	}
	@Test
	public void test12698() {
		o.launch(-1, false, true, 0, true, false, 0, false, true);
	}
	@Test
	public void test12699() {
		o.launch(-1, false, true, 0, true, false, 0, false, false);
	}
	@Test
	public void test12700() {
		o.launch(-1, false, true, 0, true, false, 1, true, true);
	}
	@Test
	public void test12701() {
		o.launch(-1, false, true, 0, true, false, 1, true, false);
	}
	@Test
	public void test12702() {
		o.launch(-1, false, true, 0, true, false, 1, false, true);
	}
	@Test
	public void test12703() {
		o.launch(-1, false, true, 0, true, false, 1, false, false);
	}
	@Test
	public void test12704() {
		o.launch(5, false, true, 0, true, false, 2, true, true);
	}
	@Test
	public void test12705() {
		o.launch(5, false, true, 0, true, false, 2, true, false);
	}
	@Test
	public void test12706() {
		o.launch(5, false, true, 0, true, false, 2, false, true);
	}
	@Test
	public void test12707() {
		o.launch(5, false, true, 0, true, false, 2, false, false);
	}
	@Test
	public void test12708() {
		o.launch(5, false, true, 0, true, false, 3, true, true);
	}
	@Test
	public void test12709() {
		o.launch(5, false, true, 0, true, false, 3, true, false);
	}
	@Test
	public void test12710() {
		o.launch(5, false, true, 0, true, false, 3, false, true);
	}
	@Test
	public void test12711() {
		o.launch(5, false, true, 0, true, false, 3, false, false);
	}
	@Test
	public void test12712() {
		o.launch(-1, false, true, 0, true, false, 4, true, true);
	}
	@Test
	public void test12713() {
		o.launch(-1, false, true, 0, true, false, 4, true, false);
	}
	@Test
	public void test12714() {
		o.launch(-1, false, true, 0, true, false, 4, false, true);
	}
	@Test
	public void test12715() {
		o.launch(-1, false, true, 0, true, false, 4, false, false);
	}
	@Test
	public void test12716() {
		o.launch(-1, false, true, 0, true, false, -1, true, true);
	}
	@Test
	public void test12717() {
		o.launch(-1, false, true, 0, true, false, -1, true, false);
	}
	@Test
	public void test12718() {
		o.launch(-1, false, true, 0, true, false, -1, false, true);
	}
	@Test
	public void test12719() {
		o.launch(-1, false, true, 0, true, false, -1, false, false);
	}
	@Test
	public void test12720() {
		o.launch(-1, false, true, 0, false, true, 0, true, true);
	}
	@Test
	public void test12721() {
		o.launch(10, false, true, 0, false, true, 0, true, false);
	}
	@Test
	public void test12722() {
		o.launch(10, false, true, 0, false, true, 0, false, true);
	}
	@Test
	public void test12723() {
		o.launch(10, false, true, 0, false, true, 0, false, false);
	}
	@Test
	public void test12724() {
		o.launch(10, false, true, 0, false, true, 1, true, true);
	}
	@Test
	public void test12725() {
		o.launch(5, false, true, 0, false, true, 1, true, false);
	}
	@Test
	public void test12726() {
		o.launch(-1, false, true, 0, false, true, 1, false, true);
	}
	@Test
	public void test12727() {
		o.launch(-1, false, true, 0, false, true, 1, false, false);
	}
	@Test
	public void test12728() {
		o.launch(5, false, true, 0, false, true, 2, true, true);
	}
	@Test
	public void test12729() {
		o.launch(5, false, true, 0, false, true, 2, true, false);
	}
	@Test
	public void test12730() {
		o.launch(5, false, true, 0, false, true, 2, false, true);
	}
	@Test
	public void test12731() {
		o.launch(5, false, true, 0, false, true, 2, false, false);
	}
	@Test
	public void test12732() {
		o.launch(5, false, true, 0, false, true, 3, true, true);
	}
	@Test
	public void test12733() {
		o.launch(5, false, true, 0, false, true, 3, true, false);
	}
	@Test
	public void test12734() {
		o.launch(5, false, true, 0, false, true, 3, false, true);
	}
	@Test
	public void test12735() {
		o.launch(5, false, true, 0, false, true, 3, false, false);
	}
	@Test
	public void test12736() {
		o.launch(5, false, true, 0, false, true, 4, true, true);
	}
	@Test
	public void test12737() {
		o.launch(-1, false, true, 0, false, true, 4, true, false);
	}
	@Test
	public void test12738() {
		o.launch(5, false, true, 0, false, true, 4, false, true);
	}
	@Test
	public void test12739() {
		o.launch(5, false, true, 0, false, true, 4, false, false);
	}
	@Test
	public void test12740() {
		o.launch(100, false, true, 0, false, true, 100, true, true);
	}
	@Test
	public void test12741() {
		o.launch(10, false, true, 0, false, true, -1, true, false);
	}
	@Test
	public void test12742() {
		o.launch(10, false, true, 0, false, true, -1, false, true);
	}
	@Test
	public void test12743() {
		o.launch(100, false, true, 0, false, true, 100, false, false);
	}
	@Test
	public void test12744() {
		o.launch(100, false, true, 0, false, false, 0, true, true);
	}
	@Test
	public void test12745() {
		o.launch(10, false, true, 0, false, false, 0, true, false);
	}
	@Test
	public void test12746() {
		o.launch(100, false, true, 0, false, false, 0, false, true);
	}
	@Test
	public void test12747() {
		o.launch(10, false, true, 0, false, false, 0, false, false);
	}
	@Test
	public void test12748() {
		o.launch(100, false, true, 0, false, false, 1, true, true);
	}
	@Test
	public void test12749() {
		o.launch(-1, false, true, 0, false, false, 1, true, false);
	}
	@Test
	public void test12750() {
		o.launch(-1, false, true, 0, false, false, 1, false, true);
	}
	@Test
	public void test12751() {
		o.launch(-1, false, true, 0, false, false, 1, false, false);
	}
	@Test
	public void test12752() {
		o.launch(5, false, true, 0, false, false, 2, true, true);
	}
	@Test
	public void test12753() {
		o.launch(5, false, true, 0, false, false, 2, true, false);
	}
	@Test
	public void test12754() {
		o.launch(5, false, true, 0, false, false, 2, false, true);
	}
	@Test
	public void test12755() {
		o.launch(5, false, true, 0, false, false, 2, false, false);
	}
	@Test
	public void test12756() {
		o.launch(5, false, true, 0, false, false, 3, true, true);
	}
	@Test
	public void test12757() {
		o.launch(5, false, true, 0, false, false, 3, true, false);
	}
	@Test
	public void test12758() {
		o.launch(5, false, true, 0, false, false, 3, false, true);
	}
	@Test
	public void test12759() {
		o.launch(5, false, true, 0, false, false, 3, false, false);
	}
	@Test
	public void test12760() {
		o.launch(5, false, true, 0, false, false, 4, true, true);
	}
	@Test
	public void test12761() {
		o.launch(5, false, true, 0, false, false, 4, true, false);
	}
	@Test
	public void test12762() {
		o.launch(-1, false, true, 0, false, false, 4, false, true);
	}
	@Test
	public void test12763() {
		o.launch(-1, false, true, 0, false, false, 4, false, false);
	}
	@Test
	public void test12764() {
		o.launch(100, false, true, 0, false, false, 10, true, true);
	}
	@Test
	public void test12765() {
		o.launch(100, false, true, 0, false, false, 10, true, false);
	}
	@Test
	public void test12766() {
		o.launch(100, false, true, 0, false, false, 100, false, true);
	}
	@Test
	public void test12767() {
		o.launch(10, false, true, 0, false, false, 10, false, false);
	}
	@Test
	public void test12768() {
		o.launch(100, false, true, 1, true, true, 0, true, true);
	}
	@Test
	public void test12769() {
		o.launch(-1, false, true, 1, true, true, 0, true, false);
	}
	@Test
	public void test12770() {
		o.launch(-1, false, true, 1, true, true, 0, false, true);
	}
	@Test
	public void test12771() {
		o.launch(-1, false, true, 1, true, true, 0, false, false);
	}
	@Test
	public void test12772() {
		o.launch(-1, false, true, 1, true, true, 1, true, true);
	}
	@Test
	public void test12773() {
		o.launch(-1, false, true, 1, true, true, 1, true, false);
	}
	@Test
	public void test12774() {
		o.launch(-1, false, true, 1, true, true, 1, false, true);
	}
	@Test
	public void test12775() {
		o.launch(10, false, true, 1, true, true, 1, false, false);
	}
	@Test
	public void test12776() {
		o.launch(5, false, true, 1, true, true, 2, true, true);
	}
	@Test
	public void test12777() {
		o.launch(5, false, true, 1, true, true, 2, true, false);
	}
	@Test
	public void test12778() {
		o.launch(5, false, true, 1, true, true, 2, false, true);
	}
	@Test
	public void test12779() {
		o.launch(5, false, true, 1, true, true, 2, false, false);
	}
	@Test
	public void test12780() {
		o.launch(5, false, true, 1, true, true, 3, true, true);
	}
	@Test
	public void test12781() {
		o.launch(5, false, true, 1, true, true, 3, true, false);
	}
	@Test
	public void test12782() {
		o.launch(5, false, true, 1, true, true, 3, false, true);
	}
	@Test
	public void test12783() {
		o.launch(5, false, true, 1, true, true, 3, false, false);
	}
	@Test
	public void test12784() {
		o.launch(5, false, true, 1, true, true, 4, true, true);
	}
	@Test
	public void test12785() {
		o.launch(-1, false, true, 1, true, true, 4, true, false);
	}
	@Test
	public void test12786() {
		o.launch(5, false, true, 1, true, true, 4, false, true);
	}
	@Test
	public void test12787() {
		o.launch(-1, false, true, 1, true, true, 4, false, false);
	}
	@Test
	public void test12788() {
		o.launch(-1, false, true, 1, true, true, -1, true, true);
	}
	@Test
	public void test12789() {
		o.launch(-1, false, true, 1, true, true, -1, true, false);
	}
	@Test
	public void test12790() {
		o.launch(-1, false, true, 1, true, true, -1, false, true);
	}
	@Test
	public void test12791() {
		o.launch(-1, false, true, 1, true, true, -1, false, false);
	}
	@Test
	public void test12792() {
		o.launch(10, false, true, 1, true, false, 0, true, true);
	}
	@Test
	public void test12793() {
		o.launch(10, false, true, 1, true, false, 0, true, false);
	}
	@Test
	public void test12794() {
		o.launch(10, false, true, 1, true, false, 0, false, true);
	}
	@Test
	public void test12795() {
		o.launch(10, false, true, 1, true, false, 0, false, false);
	}
	@Test
	public void test12796() {
		o.launch(100, false, true, 1, true, false, 1, true, true);
	}
	@Test
	public void test12797() {
		o.launch(-1, false, true, 1, true, false, 1, true, false);
	}
	@Test
	public void test12798() {
		o.launch(5, false, true, 1, true, false, 1, false, true);
	}
	@Test
	public void test12799() {
		o.launch(100, false, true, 1, true, false, 1, false, false);
	}
	@Test
	public void test12800() {
		o.launch(5, false, true, 1, true, false, 2, true, true);
	}
	@Test
	public void test12801() {
		o.launch(5, false, true, 1, true, false, 2, true, false);
	}
	@Test
	public void test12802() {
		o.launch(5, false, true, 1, true, false, 2, false, true);
	}
	@Test
	public void test12803() {
		o.launch(5, false, true, 1, true, false, 2, false, false);
	}
	@Test
	public void test12804() {
		o.launch(5, false, true, 1, true, false, 3, true, true);
	}
	@Test
	public void test12805() {
		o.launch(5, false, true, 1, true, false, 3, true, false);
	}
	@Test
	public void test12806() {
		o.launch(5, false, true, 1, true, false, 3, false, true);
	}
	@Test
	public void test12807() {
		o.launch(5, false, true, 1, true, false, 3, false, false);
	}
	@Test
	public void test12808() {
		o.launch(10, false, true, 1, true, false, 4, true, true);
	}
	@Test
	public void test12809() {
		o.launch(10, false, true, 1, true, false, 4, true, false);
	}
	@Test
	public void test12810() {
		o.launch(5, false, true, 1, true, false, 4, false, true);
	}
	@Test
	public void test12811() {
		o.launch(-1, false, true, 1, true, false, 4, false, false);
	}
	@Test
	public void test12812() {
		o.launch(10, false, true, 1, true, false, -1, true, true);
	}
	@Test
	public void test12813() {
		o.launch(100, false, true, 1, true, false, 100, true, false);
	}
	@Test
	public void test12814() {
		o.launch(10, false, true, 1, true, false, -1, false, true);
	}
	@Test
	public void test12815() {
		o.launch(100, false, true, 1, true, false, 100, false, false);
	}
	@Test
	public void test12816() {
		o.launch(100, false, true, 1, false, true, 0, true, true);
	}
	@Test
	public void test12817() {
		o.launch(100, false, true, 1, false, true, 0, true, false);
	}
	@Test
	public void test12818() {
		o.launch(100, false, true, 1, false, true, 0, false, true);
	}
	@Test
	public void test12819() {
		o.launch(100, false, true, 1, false, true, 0, false, false);
	}
	@Test
	public void test12820() {
		o.launch(100, false, true, 1, false, true, 1, true, true);
	}
	@Test
	public void test12821() {
		o.launch(-1, false, true, 1, false, true, 1, true, false);
	}
	@Test
	public void test12822() {
		o.launch(100, false, true, 1, false, true, 1, false, true);
	}
	@Test
	public void test12823() {
		o.launch(100, false, true, 1, false, true, 1, false, false);
	}
	@Test
	public void test12824() {
		o.launch(5, false, true, 1, false, true, 2, true, true);
	}
	@Test
	public void test12825() {
		o.launch(5, false, true, 1, false, true, 2, true, false);
	}
	@Test
	public void test12826() {
		o.launch(5, false, true, 1, false, true, 2, false, true);
	}
	@Test
	public void test12827() {
		o.launch(5, false, true, 1, false, true, 2, false, false);
	}
	@Test
	public void test12828() {
		o.launch(5, false, true, 1, false, true, 3, true, true);
	}
	@Test
	public void test12829() {
		o.launch(5, false, true, 1, false, true, 3, true, false);
	}
	@Test
	public void test12830() {
		o.launch(5, false, true, 1, false, true, 3, false, true);
	}
	@Test
	public void test12831() {
		o.launch(5, false, true, 1, false, true, 3, false, false);
	}
	@Test
	public void test12832() {
		o.launch(-1, false, true, 1, false, true, 4, true, true);
	}
	@Test
	public void test12833() {
		o.launch(5, false, true, 1, false, true, 4, true, false);
	}
	@Test
	public void test12834() {
		o.launch(5, false, true, 1, false, true, 4, false, true);
	}
	@Test
	public void test12835() {
		o.launch(-1, false, true, 1, false, true, 4, false, false);
	}
	@Test
	public void test12836() {
		o.launch(10, false, true, 1, false, true, 10, true, true);
	}
	@Test
	public void test12837() {
		o.launch(100, false, true, 1, false, true, 10, true, false);
	}
	@Test
	public void test12838() {
		o.launch(10, false, true, 1, false, true, -1, false, true);
	}
	@Test
	public void test12839() {
		o.launch(10, false, true, 1, false, true, -1, false, false);
	}
	@Test
	public void test12840() {
		o.launch(-1, false, true, 1, false, false, 0, true, true);
	}
	@Test
	public void test12841() {
		o.launch(100, false, true, 1, false, false, 0, true, false);
	}
	@Test
	public void test12842() {
		o.launch(10, false, true, 1, false, false, 0, false, true);
	}
	@Test
	public void test12843() {
		o.launch(10, false, true, 1, false, false, 0, false, false);
	}
	@Test
	public void test12844() {
		o.launch(-1, false, true, 1, false, false, 1, true, true);
	}
	@Test
	public void test12845() {
		o.launch(100, false, true, 1, false, false, 1, true, false);
	}
	@Test
	public void test12846() {
		o.launch(-1, false, true, 1, false, false, 1, false, true);
	}
	@Test
	public void test12847() {
		o.launch(-1, false, true, 1, false, false, 1, false, false);
	}
	@Test
	public void test12848() {
		o.launch(5, false, true, 1, false, false, 2, true, true);
	}
	@Test
	public void test12849() {
		o.launch(5, false, true, 1, false, false, 2, true, false);
	}
	@Test
	public void test12850() {
		o.launch(5, false, true, 1, false, false, 2, false, true);
	}
	@Test
	public void test12851() {
		o.launch(5, false, true, 1, false, false, 2, false, false);
	}
	@Test
	public void test12852() {
		o.launch(5, false, true, 1, false, false, 3, true, true);
	}
	@Test
	public void test12853() {
		o.launch(5, false, true, 1, false, false, 3, true, false);
	}
	@Test
	public void test12854() {
		o.launch(5, false, true, 1, false, false, 3, false, true);
	}
	@Test
	public void test12855() {
		o.launch(5, false, true, 1, false, false, 3, false, false);
	}
	@Test
	public void test12856() {
		o.launch(5, false, true, 1, false, false, 4, true, true);
	}
	@Test
	public void test12857() {
		o.launch(10, false, true, 1, false, false, 4, true, false);
	}
	@Test
	public void test12858() {
		o.launch(10, false, true, 1, false, false, 4, false, true);
	}
	@Test
	public void test12859() {
		o.launch(-1, false, true, 1, false, false, 4, false, false);
	}
	@Test
	public void test12860() {
		o.launch(-1, false, true, 1, false, false, -1, true, true);
	}
	@Test
	public void test12861() {
		o.launch(10, false, true, 1, false, false, 10, true, false);
	}
	@Test
	public void test12862() {
		o.launch(-1, false, true, 1, false, false, -1, false, true);
	}
	@Test
	public void test12863() {
		o.launch(10, false, true, 1, false, false, 10, false, false);
	}
	@Test
	public void test12864() {
		o.launch(5, false, true, 2, true, true, 0, true, true);
	}
	@Test
	public void test12865() {
		o.launch(5, false, true, 2, true, true, 0, true, false);
	}
	@Test
	public void test12866() {
		o.launch(5, false, true, 2, true, true, 0, false, true);
	}
	@Test
	public void test12867() {
		o.launch(5, false, true, 2, true, true, 0, false, false);
	}
	@Test
	public void test12868() {
		o.launch(5, false, true, 2, true, true, 1, true, true);
	}
	@Test
	public void test12869() {
		o.launch(5, false, true, 2, true, true, 1, true, false);
	}
	@Test
	public void test12870() {
		o.launch(5, false, true, 2, true, true, 1, false, true);
	}
	@Test
	public void test12871() {
		o.launch(5, false, true, 2, true, true, 1, false, false);
	}
	@Test
	public void test12872() {
		o.launch(5, false, true, 2, true, true, 2, true, true);
	}
	@Test
	public void test12873() {
		o.launch(5, false, true, 2, true, true, 2, true, false);
	}
	@Test
	public void test12874() {
		o.launch(5, false, true, 2, true, true, 2, false, true);
	}
	@Test
	public void test12875() {
		o.launch(5, false, true, 2, true, true, 2, false, false);
	}
	@Test
	public void test12876() {
		o.launch(5, false, true, 2, true, true, 3, true, true);
	}
	@Test
	public void test12877() {
		o.launch(5, false, true, 2, true, true, 3, true, false);
	}
	@Test
	public void test12878() {
		o.launch(5, false, true, 2, true, true, 3, false, true);
	}
	@Test
	public void test12879() {
		o.launch(5, false, true, 2, true, true, 3, false, false);
	}
	@Test
	public void test12880() {
		o.launch(5, false, true, 2, true, true, 4, true, true);
	}
	@Test
	public void test12881() {
		o.launch(5, false, true, 2, true, true, 4, true, false);
	}
	@Test
	public void test12882() {
		o.launch(5, false, true, 2, true, true, 4, false, true);
	}
	@Test
	public void test12883() {
		o.launch(5, false, true, 2, true, true, 4, false, false);
	}
	@Test
	public void test12884() {
		o.launch(5, false, true, 2, true, true, 5, true, true);
	}
	@Test
	public void test12885() {
		o.launch(5, false, true, 2, true, true, 5, true, false);
	}
	@Test
	public void test12886() {
		o.launch(5, false, true, 2, true, true, 5, false, true);
	}
	@Test
	public void test12887() {
		o.launch(5, false, true, 2, true, true, 5, false, false);
	}
	@Test
	public void test12888() {
		o.launch(5, false, true, 2, true, false, 0, true, true);
	}
	@Test
	public void test12889() {
		o.launch(5, false, true, 2, true, false, 0, true, false);
	}
	@Test
	public void test12890() {
		o.launch(5, false, true, 2, true, false, 0, false, true);
	}
	@Test
	public void test12891() {
		o.launch(5, false, true, 2, true, false, 0, false, false);
	}
	@Test
	public void test12892() {
		o.launch(5, false, true, 2, true, false, 1, true, true);
	}
	@Test
	public void test12893() {
		o.launch(5, false, true, 2, true, false, 1, true, false);
	}
	@Test
	public void test12894() {
		o.launch(5, false, true, 2, true, false, 1, false, true);
	}
	@Test
	public void test12895() {
		o.launch(5, false, true, 2, true, false, 1, false, false);
	}
	@Test
	public void test12896() {
		o.launch(5, false, true, 2, true, false, 2, true, true);
	}
	@Test
	public void test12897() {
		o.launch(5, false, true, 2, true, false, 2, true, false);
	}
	@Test
	public void test12898() {
		o.launch(5, false, true, 2, true, false, 2, false, true);
	}
	@Test
	public void test12899() {
		o.launch(5, false, true, 2, true, false, 2, false, false);
	}
	@Test
	public void test12900() {
		o.launch(5, false, true, 2, true, false, 3, true, true);
	}
	@Test
	public void test12901() {
		o.launch(5, false, true, 2, true, false, 3, true, false);
	}
	@Test
	public void test12902() {
		o.launch(5, false, true, 2, true, false, 3, false, true);
	}
	@Test
	public void test12903() {
		o.launch(5, false, true, 2, true, false, 3, false, false);
	}
	@Test
	public void test12904() {
		o.launch(5, false, true, 2, true, false, 4, true, true);
	}
	@Test
	public void test12905() {
		o.launch(5, false, true, 2, true, false, 4, true, false);
	}
	@Test
	public void test12906() {
		o.launch(5, false, true, 2, true, false, 4, false, true);
	}
	@Test
	public void test12907() {
		o.launch(5, false, true, 2, true, false, 4, false, false);
	}
	@Test
	public void test12908() {
		o.launch(5, false, true, 2, true, false, 5, true, true);
	}
	@Test
	public void test12909() {
		o.launch(5, false, true, 2, true, false, 5, true, false);
	}
	@Test
	public void test12910() {
		o.launch(5, false, true, 2, true, false, 5, false, true);
	}
	@Test
	public void test12911() {
		o.launch(5, false, true, 2, true, false, 5, false, false);
	}
	@Test
	public void test12912() {
		o.launch(5, false, true, 2, false, true, 0, true, true);
	}
	@Test
	public void test12913() {
		o.launch(5, false, true, 2, false, true, 0, true, false);
	}
	@Test
	public void test12914() {
		o.launch(5, false, true, 2, false, true, 0, false, true);
	}
	@Test
	public void test12915() {
		o.launch(5, false, true, 2, false, true, 0, false, false);
	}
	@Test
	public void test12916() {
		o.launch(5, false, true, 2, false, true, 1, true, true);
	}
	@Test
	public void test12917() {
		o.launch(5, false, true, 2, false, true, 1, true, false);
	}
	@Test
	public void test12918() {
		o.launch(5, false, true, 2, false, true, 1, false, true);
	}
	@Test
	public void test12919() {
		o.launch(5, false, true, 2, false, true, 1, false, false);
	}
	@Test
	public void test12920() {
		o.launch(5, false, true, 2, false, true, 2, true, true);
	}
	@Test
	public void test12921() {
		o.launch(5, false, true, 2, false, true, 2, true, false);
	}
	@Test
	public void test12922() {
		o.launch(5, false, true, 2, false, true, 2, false, true);
	}
	@Test
	public void test12923() {
		o.launch(5, false, true, 2, false, true, 2, false, false);
	}
	@Test
	public void test12924() {
		o.launch(5, false, true, 2, false, true, 3, true, true);
	}
	@Test
	public void test12925() {
		o.launch(5, false, true, 2, false, true, 3, true, false);
	}
	@Test
	public void test12926() {
		o.launch(5, false, true, 2, false, true, 3, false, true);
	}
	@Test
	public void test12927() {
		o.launch(5, false, true, 2, false, true, 3, false, false);
	}
	@Test
	public void test12928() {
		o.launch(5, false, true, 2, false, true, 4, true, true);
	}
	@Test
	public void test12929() {
		o.launch(5, false, true, 2, false, true, 4, true, false);
	}
	@Test
	public void test12930() {
		o.launch(5, false, true, 2, false, true, 4, false, true);
	}
	@Test
	public void test12931() {
		o.launch(5, false, true, 2, false, true, 4, false, false);
	}
	@Test
	public void test12932() {
		o.launch(5, false, true, 2, false, true, 5, true, true);
	}
	@Test
	public void test12933() {
		o.launch(5, false, true, 2, false, true, 5, true, false);
	}
	@Test
	public void test12934() {
		o.launch(5, false, true, 2, false, true, 5, false, true);
	}
	@Test
	public void test12935() {
		o.launch(5, false, true, 2, false, true, 5, false, false);
	}
	@Test
	public void test12936() {
		o.launch(5, false, true, 2, false, false, 0, true, true);
	}
	@Test
	public void test12937() {
		o.launch(5, false, true, 2, false, false, 0, true, false);
	}
	@Test
	public void test12938() {
		o.launch(5, false, true, 2, false, false, 0, false, true);
	}
	@Test
	public void test12939() {
		o.launch(5, false, true, 2, false, false, 0, false, false);
	}
	@Test
	public void test12940() {
		o.launch(5, false, true, 2, false, false, 1, true, true);
	}
	@Test
	public void test12941() {
		o.launch(5, false, true, 2, false, false, 1, true, false);
	}
	@Test
	public void test12942() {
		o.launch(5, false, true, 2, false, false, 1, false, true);
	}
	@Test
	public void test12943() {
		o.launch(5, false, true, 2, false, false, 1, false, false);
	}
	@Test
	public void test12944() {
		o.launch(5, false, true, 2, false, false, 2, true, true);
	}
	@Test
	public void test12945() {
		o.launch(5, false, true, 2, false, false, 2, true, false);
	}
	@Test
	public void test12946() {
		o.launch(5, false, true, 2, false, false, 2, false, true);
	}
	@Test
	public void test12947() {
		o.launch(5, false, true, 2, false, false, 2, false, false);
	}
	@Test
	public void test12948() {
		o.launch(5, false, true, 2, false, false, 3, true, true);
	}
	@Test
	public void test12949() {
		o.launch(5, false, true, 2, false, false, 3, true, false);
	}
	@Test
	public void test12950() {
		o.launch(5, false, true, 2, false, false, 3, false, true);
	}
	@Test
	public void test12951() {
		o.launch(5, false, true, 2, false, false, 3, false, false);
	}
	@Test
	public void test12952() {
		o.launch(5, false, true, 2, false, false, 4, true, true);
	}
	@Test
	public void test12953() {
		o.launch(5, false, true, 2, false, false, 4, true, false);
	}
	@Test
	public void test12954() {
		o.launch(5, false, true, 2, false, false, 4, false, true);
	}
	@Test
	public void test12955() {
		o.launch(5, false, true, 2, false, false, 4, false, false);
	}
	@Test
	public void test12956() {
		o.launch(5, false, true, 2, false, false, 5, true, true);
	}
	@Test
	public void test12957() {
		o.launch(5, false, true, 2, false, false, 5, true, false);
	}
	@Test
	public void test12958() {
		o.launch(5, false, true, 2, false, false, 5, false, true);
	}
	@Test
	public void test12959() {
		o.launch(5, false, true, 2, false, false, 5, false, false);
	}
	@Test
	public void test12960() {
		o.launch(5, false, true, 3, true, true, 0, true, true);
	}
	@Test
	public void test12961() {
		o.launch(5, false, true, 3, true, true, 0, true, false);
	}
	@Test
	public void test12962() {
		o.launch(5, false, true, 3, true, true, 0, false, true);
	}
	@Test
	public void test12963() {
		o.launch(5, false, true, 3, true, true, 0, false, false);
	}
	@Test
	public void test12964() {
		o.launch(5, false, true, 3, true, true, 1, true, true);
	}
	@Test
	public void test12965() {
		o.launch(5, false, true, 3, true, true, 1, true, false);
	}
	@Test
	public void test12966() {
		o.launch(5, false, true, 3, true, true, 1, false, true);
	}
	@Test
	public void test12967() {
		o.launch(5, false, true, 3, true, true, 1, false, false);
	}
	@Test
	public void test12968() {
		o.launch(5, false, true, 3, true, true, 2, true, true);
	}
	@Test
	public void test12969() {
		o.launch(5, false, true, 3, true, true, 2, true, false);
	}
	@Test
	public void test12970() {
		o.launch(5, false, true, 3, true, true, 2, false, true);
	}
	@Test
	public void test12971() {
		o.launch(5, false, true, 3, true, true, 2, false, false);
	}
	@Test
	public void test12972() {
		o.launch(5, false, true, 3, true, true, 3, true, true);
	}
	@Test
	public void test12973() {
		o.launch(5, false, true, 3, true, true, 3, true, false);
	}
	@Test
	public void test12974() {
		o.launch(5, false, true, 3, true, true, 3, false, true);
	}
	@Test
	public void test12975() {
		o.launch(5, false, true, 3, true, true, 3, false, false);
	}
	@Test
	public void test12976() {
		o.launch(5, false, true, 3, true, true, 4, true, true);
	}
	@Test
	public void test12977() {
		o.launch(5, false, true, 3, true, true, 4, true, false);
	}
	@Test
	public void test12978() {
		o.launch(5, false, true, 3, true, true, 4, false, true);
	}
	@Test
	public void test12979() {
		o.launch(5, false, true, 3, true, true, 4, false, false);
	}
	@Test
	public void test12980() {
		o.launch(5, false, true, 3, true, true, 5, true, true);
	}
	@Test
	public void test12981() {
		o.launch(5, false, true, 3, true, true, 5, true, false);
	}
	@Test
	public void test12982() {
		o.launch(5, false, true, 3, true, true, 5, false, true);
	}
	@Test
	public void test12983() {
		o.launch(5, false, true, 3, true, true, 5, false, false);
	}
	@Test
	public void test12984() {
		o.launch(5, false, true, 3, true, false, 0, true, true);
	}
	@Test
	public void test12985() {
		o.launch(5, false, true, 3, true, false, 0, true, false);
	}
	@Test
	public void test12986() {
		o.launch(5, false, true, 3, true, false, 0, false, true);
	}
	@Test
	public void test12987() {
		o.launch(5, false, true, 3, true, false, 0, false, false);
	}
	@Test
	public void test12988() {
		o.launch(5, false, true, 3, true, false, 1, true, true);
	}
	@Test
	public void test12989() {
		o.launch(5, false, true, 3, true, false, 1, true, false);
	}
	@Test
	public void test12990() {
		o.launch(5, false, true, 3, true, false, 1, false, true);
	}
	@Test
	public void test12991() {
		o.launch(5, false, true, 3, true, false, 1, false, false);
	}
	@Test
	public void test12992() {
		o.launch(5, false, true, 3, true, false, 2, true, true);
	}
	@Test
	public void test12993() {
		o.launch(5, false, true, 3, true, false, 2, true, false);
	}
	@Test
	public void test12994() {
		o.launch(5, false, true, 3, true, false, 2, false, true);
	}
	@Test
	public void test12995() {
		o.launch(5, false, true, 3, true, false, 2, false, false);
	}
	@Test
	public void test12996() {
		o.launch(5, false, true, 3, true, false, 3, true, true);
	}
	@Test
	public void test12997() {
		o.launch(5, false, true, 3, true, false, 3, true, false);
	}
	@Test
	public void test12998() {
		o.launch(5, false, true, 3, true, false, 3, false, true);
	}
	@Test
	public void test12999() {
		o.launch(5, false, true, 3, true, false, 3, false, false);
	}
	@Test
	public void test13000() {
		o.launch(5, false, true, 3, true, false, 4, true, true);
	}
	@Test
	public void test13001() {
		o.launch(5, false, true, 3, true, false, 4, true, false);
	}
	@Test
	public void test13002() {
		o.launch(5, false, true, 3, true, false, 4, false, true);
	}
	@Test
	public void test13003() {
		o.launch(5, false, true, 3, true, false, 4, false, false);
	}
	@Test
	public void test13004() {
		o.launch(5, false, true, 3, true, false, 5, true, true);
	}
	@Test
	public void test13005() {
		o.launch(5, false, true, 3, true, false, 5, true, false);
	}
	@Test
	public void test13006() {
		o.launch(5, false, true, 3, true, false, 5, false, true);
	}
	@Test
	public void test13007() {
		o.launch(5, false, true, 3, true, false, 5, false, false);
	}
	@Test
	public void test13008() {
		o.launch(5, false, true, 3, false, true, 0, true, true);
	}
	@Test
	public void test13009() {
		o.launch(5, false, true, 3, false, true, 0, true, false);
	}
	@Test
	public void test13010() {
		o.launch(5, false, true, 3, false, true, 0, false, true);
	}
	@Test
	public void test13011() {
		o.launch(5, false, true, 3, false, true, 0, false, false);
	}
	@Test
	public void test13012() {
		o.launch(5, false, true, 3, false, true, 1, true, true);
	}
	@Test
	public void test13013() {
		o.launch(5, false, true, 3, false, true, 1, true, false);
	}
	@Test
	public void test13014() {
		o.launch(5, false, true, 3, false, true, 1, false, true);
	}
	@Test
	public void test13015() {
		o.launch(5, false, true, 3, false, true, 1, false, false);
	}
	@Test
	public void test13016() {
		o.launch(5, false, true, 3, false, true, 2, true, true);
	}
	@Test
	public void test13017() {
		o.launch(5, false, true, 3, false, true, 2, true, false);
	}
	@Test
	public void test13018() {
		o.launch(5, false, true, 3, false, true, 2, false, true);
	}
	@Test
	public void test13019() {
		o.launch(5, false, true, 3, false, true, 2, false, false);
	}
	@Test
	public void test13020() {
		o.launch(5, false, true, 3, false, true, 3, true, true);
	}
	@Test
	public void test13021() {
		o.launch(5, false, true, 3, false, true, 3, true, false);
	}
	@Test
	public void test13022() {
		o.launch(5, false, true, 3, false, true, 3, false, true);
	}
	@Test
	public void test13023() {
		o.launch(5, false, true, 3, false, true, 3, false, false);
	}
	@Test
	public void test13024() {
		o.launch(5, false, true, 3, false, true, 4, true, true);
	}
	@Test
	public void test13025() {
		o.launch(5, false, true, 3, false, true, 4, true, false);
	}
	@Test
	public void test13026() {
		o.launch(5, false, true, 3, false, true, 4, false, true);
	}
	@Test
	public void test13027() {
		o.launch(5, false, true, 3, false, true, 4, false, false);
	}
	@Test
	public void test13028() {
		o.launch(5, false, true, 3, false, true, 5, true, true);
	}
	@Test
	public void test13029() {
		o.launch(5, false, true, 3, false, true, 5, true, false);
	}
	@Test
	public void test13030() {
		o.launch(5, false, true, 3, false, true, 5, false, true);
	}
	@Test
	public void test13031() {
		o.launch(5, false, true, 3, false, true, 5, false, false);
	}
	@Test
	public void test13032() {
		o.launch(5, false, true, 3, false, false, 0, true, true);
	}
	@Test
	public void test13033() {
		o.launch(5, false, true, 3, false, false, 0, true, false);
	}
	@Test
	public void test13034() {
		o.launch(5, false, true, 3, false, false, 0, false, true);
	}
	@Test
	public void test13035() {
		o.launch(5, false, true, 3, false, false, 0, false, false);
	}
	@Test
	public void test13036() {
		o.launch(5, false, true, 3, false, false, 1, true, true);
	}
	@Test
	public void test13037() {
		o.launch(5, false, true, 3, false, false, 1, true, false);
	}
	@Test
	public void test13038() {
		o.launch(5, false, true, 3, false, false, 1, false, true);
	}
	@Test
	public void test13039() {
		o.launch(5, false, true, 3, false, false, 1, false, false);
	}
	@Test
	public void test13040() {
		o.launch(5, false, true, 3, false, false, 2, true, true);
	}
	@Test
	public void test13041() {
		o.launch(5, false, true, 3, false, false, 2, true, false);
	}
	@Test
	public void test13042() {
		o.launch(5, false, true, 3, false, false, 2, false, true);
	}
	@Test
	public void test13043() {
		o.launch(5, false, true, 3, false, false, 2, false, false);
	}
	@Test
	public void test13044() {
		o.launch(5, false, true, 3, false, false, 3, true, true);
	}
	@Test
	public void test13045() {
		o.launch(5, false, true, 3, false, false, 3, true, false);
	}
	@Test
	public void test13046() {
		o.launch(5, false, true, 3, false, false, 3, false, true);
	}
	@Test
	public void test13047() {
		o.launch(5, false, true, 3, false, false, 3, false, false);
	}
	@Test
	public void test13048() {
		o.launch(5, false, true, 3, false, false, 4, true, true);
	}
	@Test
	public void test13049() {
		o.launch(5, false, true, 3, false, false, 4, true, false);
	}
	@Test
	public void test13050() {
		o.launch(5, false, true, 3, false, false, 4, false, true);
	}
	@Test
	public void test13051() {
		o.launch(5, false, true, 3, false, false, 4, false, false);
	}
	@Test
	public void test13052() {
		o.launch(5, false, true, 3, false, false, 5, true, true);
	}
	@Test
	public void test13053() {
		o.launch(5, false, true, 3, false, false, 5, true, false);
	}
	@Test
	public void test13054() {
		o.launch(5, false, true, 3, false, false, 5, false, true);
	}
	@Test
	public void test13055() {
		o.launch(5, false, true, 3, false, false, 5, false, false);
	}
	@Test
	public void test13056() {
		o.launch(5, false, true, 4, true, true, 0, true, true);
	}
	@Test
	public void test13057() {
		o.launch(5, false, true, 4, true, true, 0, true, false);
	}
	@Test
	public void test13058() {
		o.launch(10, false, true, 4, true, true, 0, false, true);
	}
	@Test
	public void test13059() {
		o.launch(-1, false, true, 4, true, true, 0, false, false);
	}
	@Test
	public void test13060() {
		o.launch(100, false, true, 4, true, true, 1, true, true);
	}
	@Test
	public void test13061() {
		o.launch(5, false, true, 4, true, true, 1, true, false);
	}
	@Test
	public void test13062() {
		o.launch(100, false, true, 4, true, true, 1, false, true);
	}
	@Test
	public void test13063() {
		o.launch(100, false, true, 4, true, true, 1, false, false);
	}
	@Test
	public void test13064() {
		o.launch(5, false, true, 4, true, true, 2, true, true);
	}
	@Test
	public void test13065() {
		o.launch(5, false, true, 4, true, true, 2, true, false);
	}
	@Test
	public void test13066() {
		o.launch(5, false, true, 4, true, true, 2, false, true);
	}
	@Test
	public void test13067() {
		o.launch(5, false, true, 4, true, true, 2, false, false);
	}
	@Test
	public void test13068() {
		o.launch(5, false, true, 4, true, true, 3, true, true);
	}
	@Test
	public void test13069() {
		o.launch(5, false, true, 4, true, true, 3, true, false);
	}
	@Test
	public void test13070() {
		o.launch(5, false, true, 4, true, true, 3, false, true);
	}
	@Test
	public void test13071() {
		o.launch(5, false, true, 4, true, true, 3, false, false);
	}
	@Test
	public void test13072() {
		o.launch(5, false, true, 4, true, true, 4, true, true);
	}
	@Test
	public void test13073() {
		o.launch(5, false, true, 4, true, true, 4, true, false);
	}
	@Test
	public void test13074() {
		o.launch(-1, false, true, 4, true, true, 4, false, true);
	}
	@Test
	public void test13075() {
		o.launch(10, false, true, 4, true, true, 4, false, false);
	}
	@Test
	public void test13076() {
		o.launch(100, false, true, 4, true, true, -1, true, true);
	}
	@Test
	public void test13077() {
		o.launch(100, false, true, 4, true, true, -1, true, false);
	}
	@Test
	public void test13078() {
		o.launch(100, false, true, 4, true, true, 100, false, true);
	}
	@Test
	public void test13079() {
		o.launch(10, false, true, 4, true, true, -1, false, false);
	}
	@Test
	public void test13080() {
		o.launch(-1, false, true, 4, true, false, 0, true, true);
	}
	@Test
	public void test13081() {
		o.launch(-1, false, true, 4, true, false, 0, true, false);
	}
	@Test
	public void test13082() {
		o.launch(10, false, true, 4, true, false, 0, false, true);
	}
	@Test
	public void test13083() {
		o.launch(-1, false, true, 4, true, false, 0, false, false);
	}
	@Test
	public void test13084() {
		o.launch(5, false, true, 4, true, false, 1, true, true);
	}
	@Test
	public void test13085() {
		o.launch(-1, false, true, 4, true, false, 1, true, false);
	}
	@Test
	public void test13086() {
		o.launch(-1, false, true, 4, true, false, 1, false, true);
	}
	@Test
	public void test13087() {
		o.launch(-1, false, true, 4, true, false, 1, false, false);
	}
	@Test
	public void test13088() {
		o.launch(5, false, true, 4, true, false, 2, true, true);
	}
	@Test
	public void test13089() {
		o.launch(5, false, true, 4, true, false, 2, true, false);
	}
	@Test
	public void test13090() {
		o.launch(5, false, true, 4, true, false, 2, false, true);
	}
	@Test
	public void test13091() {
		o.launch(5, false, true, 4, true, false, 2, false, false);
	}
	@Test
	public void test13092() {
		o.launch(5, false, true, 4, true, false, 3, true, true);
	}
	@Test
	public void test13093() {
		o.launch(5, false, true, 4, true, false, 3, true, false);
	}
	@Test
	public void test13094() {
		o.launch(5, false, true, 4, true, false, 3, false, true);
	}
	@Test
	public void test13095() {
		o.launch(5, false, true, 4, true, false, 3, false, false);
	}
	@Test
	public void test13096() {
		o.launch(5, false, true, 4, true, false, 4, true, true);
	}
	@Test
	public void test13097() {
		o.launch(5, false, true, 4, true, false, 4, true, false);
	}
	@Test
	public void test13098() {
		o.launch(5, false, true, 4, true, false, 4, false, true);
	}
	@Test
	public void test13099() {
		o.launch(-1, false, true, 4, true, false, 4, false, false);
	}
	@Test
	public void test13100() {
		o.launch(10, false, true, 4, true, false, -1, true, true);
	}
	@Test
	public void test13101() {
		o.launch(10, false, true, 4, true, false, 10, true, false);
	}
	@Test
	public void test13102() {
		o.launch(10, false, true, 4, true, false, 10, false, true);
	}
	@Test
	public void test13103() {
		o.launch(-1, false, true, 4, true, false, 100, false, false);
	}
	@Test
	public void test13104() {
		o.launch(5, false, true, 4, false, true, 0, true, true);
	}
	@Test
	public void test13105() {
		o.launch(5, false, true, 4, false, true, 0, true, false);
	}
	@Test
	public void test13106() {
		o.launch(100, false, true, 4, false, true, 0, false, true);
	}
	@Test
	public void test13107() {
		o.launch(5, false, true, 4, false, true, 0, false, false);
	}
	@Test
	public void test13108() {
		o.launch(-1, false, true, 4, false, true, 1, true, true);
	}
	@Test
	public void test13109() {
		o.launch(5, false, true, 4, false, true, 1, true, false);
	}
	@Test
	public void test13110() {
		o.launch(10, false, true, 4, false, true, 1, false, true);
	}
	@Test
	public void test13111() {
		o.launch(10, false, true, 4, false, true, 1, false, false);
	}
	@Test
	public void test13112() {
		o.launch(5, false, true, 4, false, true, 2, true, true);
	}
	@Test
	public void test13113() {
		o.launch(5, false, true, 4, false, true, 2, true, false);
	}
	@Test
	public void test13114() {
		o.launch(5, false, true, 4, false, true, 2, false, true);
	}
	@Test
	public void test13115() {
		o.launch(5, false, true, 4, false, true, 2, false, false);
	}
	@Test
	public void test13116() {
		o.launch(5, false, true, 4, false, true, 3, true, true);
	}
	@Test
	public void test13117() {
		o.launch(5, false, true, 4, false, true, 3, true, false);
	}
	@Test
	public void test13118() {
		o.launch(5, false, true, 4, false, true, 3, false, true);
	}
	@Test
	public void test13119() {
		o.launch(5, false, true, 4, false, true, 3, false, false);
	}
	@Test
	public void test13120() {
		o.launch(5, false, true, 4, false, true, 4, true, true);
	}
	@Test
	public void test13121() {
		o.launch(5, false, true, 4, false, true, 4, true, false);
	}
	@Test
	public void test13122() {
		o.launch(5, false, true, 4, false, true, 4, false, true);
	}
	@Test
	public void test13123() {
		o.launch(5, false, true, 4, false, true, 4, false, false);
	}
	@Test
	public void test13124() {
		o.launch(10, false, true, 4, false, true, 10, true, true);
	}
	@Test
	public void test13125() {
		o.launch(10, false, true, 4, false, true, -1, true, false);
	}
	@Test
	public void test13126() {
		o.launch(100, false, true, 4, false, true, 100, false, true);
	}
	@Test
	public void test13127() {
		o.launch(100, false, true, 4, false, true, 10, false, false);
	}
	@Test
	public void test13128() {
		o.launch(5, false, true, 4, false, false, 0, true, true);
	}
	@Test
	public void test13129() {
		o.launch(5, false, true, 4, false, false, 0, true, false);
	}
	@Test
	public void test13130() {
		o.launch(5, false, true, 4, false, false, 0, false, true);
	}
	@Test
	public void test13131() {
		o.launch(100, false, true, 4, false, false, 0, false, false);
	}
	@Test
	public void test13132() {
		o.launch(-1, false, true, 4, false, false, 1, true, true);
	}
	@Test
	public void test13133() {
		o.launch(10, false, true, 4, false, false, 1, true, false);
	}
	@Test
	public void test13134() {
		o.launch(-1, false, true, 4, false, false, 1, false, true);
	}
	@Test
	public void test13135() {
		o.launch(10, false, true, 4, false, false, 1, false, false);
	}
	@Test
	public void test13136() {
		o.launch(5, false, true, 4, false, false, 2, true, true);
	}
	@Test
	public void test13137() {
		o.launch(5, false, true, 4, false, false, 2, true, false);
	}
	@Test
	public void test13138() {
		o.launch(5, false, true, 4, false, false, 2, false, true);
	}
	@Test
	public void test13139() {
		o.launch(5, false, true, 4, false, false, 2, false, false);
	}
	@Test
	public void test13140() {
		o.launch(5, false, true, 4, false, false, 3, true, true);
	}
	@Test
	public void test13141() {
		o.launch(5, false, true, 4, false, false, 3, true, false);
	}
	@Test
	public void test13142() {
		o.launch(5, false, true, 4, false, false, 3, false, true);
	}
	@Test
	public void test13143() {
		o.launch(5, false, true, 4, false, false, 3, false, false);
	}
	@Test
	public void test13144() {
		o.launch(10, false, true, 4, false, false, 4, true, true);
	}
	@Test
	public void test13145() {
		o.launch(5, false, true, 4, false, false, 4, true, false);
	}
	@Test
	public void test13146() {
		o.launch(5, false, true, 4, false, false, 4, false, true);
	}
	@Test
	public void test13147() {
		o.launch(-1, false, true, 4, false, false, 4, false, false);
	}
	@Test
	public void test13148() {
		o.launch(10, false, true, 4, false, false, 10, true, true);
	}
	@Test
	public void test13149() {
		o.launch(10, false, true, 4, false, false, 100, true, false);
	}
	@Test
	public void test13150() {
		o.launch(10, false, true, 4, false, false, 10, false, true);
	}
	@Test
	public void test13151() {
		o.launch(10, false, true, 4, false, false, 10, false, false);
	}
	@Test
	public void test13152() {
		o.launch(-1, false, true, -1, true, true, 0, true, true);
	}
	@Test
	public void test13153() {
		o.launch(10, false, true, 100, true, true, 0, true, false);
	}
	@Test
	public void test13154() {
		o.launch(10, false, true, 10, true, true, 0, false, true);
	}
	@Test
	public void test13155() {
		o.launch(10, false, true, 100, true, true, 0, false, false);
	}
	@Test
	public void test13156() {
		o.launch(10, false, true, 100, true, true, 1, true, true);
	}
	@Test
	public void test13157() {
		o.launch(10, false, true, 100, true, true, 1, true, false);
	}
	@Test
	public void test13158() {
		o.launch(10, false, true, 10, true, true, 1, false, true);
	}
	@Test
	public void test13159() {
		o.launch(10, false, true, 100, true, true, 1, false, false);
	}
	@Test
	public void test13160() {
		o.launch(5, false, true, 5, true, true, 2, true, true);
	}
	@Test
	public void test13161() {
		o.launch(5, false, true, 5, true, true, 2, true, false);
	}
	@Test
	public void test13162() {
		o.launch(5, false, true, 5, true, true, 2, false, true);
	}
	@Test
	public void test13163() {
		o.launch(5, false, true, 5, true, true, 2, false, false);
	}
	@Test
	public void test13164() {
		o.launch(5, false, true, 5, true, true, 3, true, true);
	}
	@Test
	public void test13165() {
		o.launch(5, false, true, 5, true, true, 3, true, false);
	}
	@Test
	public void test13166() {
		o.launch(5, false, true, 5, true, true, 3, false, true);
	}
	@Test
	public void test13167() {
		o.launch(5, false, true, 5, true, true, 3, false, false);
	}
	@Test
	public void test13168() {
		o.launch(-1, false, true, -1, true, true, 4, true, true);
	}
	@Test
	public void test13169() {
		o.launch(10, false, true, 10, true, true, 4, true, false);
	}
	@Test
	public void test13170() {
		o.launch(100, false, true, -1, true, true, 4, false, true);
	}
	@Test
	public void test13171() {
		o.launch(10, false, true, -1, true, true, 4, false, false);
	}
	@Test
	public void test13172() {
		o.launch(100, false, true, 10, true, true, 10, true, true);
	}
	@Test
	public void test13173() {
		o.launch(10, false, true, 10, true, true, 100, true, false);
	}
	@Test
	public void test13174() {
		o.launch(100, false, true, 100, true, true, 100, false, true);
	}
	@Test
	public void test13175() {
		o.launch(100, false, true, 10, true, true, 10, false, false);
	}
	@Test
	public void test13176() {
		o.launch(-1, false, true, 100, true, false, 0, true, true);
	}
	@Test
	public void test13177() {
		o.launch(100, false, true, 10, true, false, 0, true, false);
	}
	@Test
	public void test13178() {
		o.launch(100, false, true, 10, true, false, 0, false, true);
	}
	@Test
	public void test13179() {
		o.launch(100, false, true, 10, true, false, 0, false, false);
	}
	@Test
	public void test13180() {
		o.launch(10, false, true, 10, true, false, 1, true, true);
	}
	@Test
	public void test13181() {
		o.launch(-1, false, true, 100, true, false, 1, true, false);
	}
	@Test
	public void test13182() {
		o.launch(10, false, true, 10, true, false, 1, false, true);
	}
	@Test
	public void test13183() {
		o.launch(10, false, true, 10, true, false, 1, false, false);
	}
	@Test
	public void test13184() {
		o.launch(5, false, true, 5, true, false, 2, true, true);
	}
	@Test
	public void test13185() {
		o.launch(5, false, true, 5, true, false, 2, true, false);
	}
	@Test
	public void test13186() {
		o.launch(5, false, true, 5, true, false, 2, false, true);
	}
	@Test
	public void test13187() {
		o.launch(5, false, true, 5, true, false, 2, false, false);
	}
	@Test
	public void test13188() {
		o.launch(5, false, true, 5, true, false, 3, true, true);
	}
	@Test
	public void test13189() {
		o.launch(5, false, true, 5, true, false, 3, true, false);
	}
	@Test
	public void test13190() {
		o.launch(5, false, true, 5, true, false, 3, false, true);
	}
	@Test
	public void test13191() {
		o.launch(5, false, true, 5, true, false, 3, false, false);
	}
	@Test
	public void test13192() {
		o.launch(-1, false, true, 100, true, false, 4, true, true);
	}
	@Test
	public void test13193() {
		o.launch(-1, false, true, -1, true, false, 4, true, false);
	}
	@Test
	public void test13194() {
		o.launch(5, false, true, 5, true, false, 4, false, true);
	}
	@Test
	public void test13195() {
		o.launch(-1, false, true, 10, true, false, 4, false, false);
	}
	@Test
	public void test13196() {
		o.launch(-1, false, true, 100, true, false, 100, true, true);
	}
	@Test
	public void test13197() {
		o.launch(-1, false, true, 100, true, false, 100, true, false);
	}
	@Test
	public void test13198() {
		o.launch(10, false, true, -1, true, false, 10, false, true);
	}
	@Test
	public void test13199() {
		o.launch(-1, false, true, 100, true, false, 100, false, false);
	}
	@Test
	public void test13200() {
		o.launch(100, false, true, 10, false, true, 0, true, true);
	}
	@Test
	public void test13201() {
		o.launch(-1, false, true, -1, false, true, 0, true, false);
	}
	@Test
	public void test13202() {
		o.launch(100, false, true, 10, false, true, 0, false, true);
	}
	@Test
	public void test13203() {
		o.launch(100, false, true, 10, false, true, 0, false, false);
	}
	@Test
	public void test13204() {
		o.launch(-1, false, true, -1, false, true, 1, true, true);
	}
	@Test
	public void test13205() {
		o.launch(100, false, true, 10, false, true, 1, true, false);
	}
	@Test
	public void test13206() {
		o.launch(100, false, true, 100, false, true, 1, false, true);
	}
	@Test
	public void test13207() {
		o.launch(100, false, true, 10, false, true, 1, false, false);
	}
	@Test
	public void test13208() {
		o.launch(5, false, true, 5, false, true, 2, true, true);
	}
	@Test
	public void test13209() {
		o.launch(5, false, true, 5, false, true, 2, true, false);
	}
	@Test
	public void test13210() {
		o.launch(5, false, true, 5, false, true, 2, false, true);
	}
	@Test
	public void test13211() {
		o.launch(5, false, true, 5, false, true, 2, false, false);
	}
	@Test
	public void test13212() {
		o.launch(5, false, true, 5, false, true, 3, true, true);
	}
	@Test
	public void test13213() {
		o.launch(5, false, true, 5, false, true, 3, true, false);
	}
	@Test
	public void test13214() {
		o.launch(5, false, true, 5, false, true, 3, false, true);
	}
	@Test
	public void test13215() {
		o.launch(5, false, true, 5, false, true, 3, false, false);
	}
	@Test
	public void test13216() {
		o.launch(10, false, true, -1, false, true, 4, true, true);
	}
	@Test
	public void test13217() {
		o.launch(100, false, true, 10, false, true, 4, true, false);
	}
	@Test
	public void test13218() {
		o.launch(-1, false, true, -1, false, true, 4, false, true);
	}
	@Test
	public void test13219() {
		o.launch(5, false, true, 5, false, true, 4, false, false);
	}
	@Test
	public void test13220() {
		o.launch(100, false, true, 10, false, true, -1, true, true);
	}
	@Test
	public void test13221() {
		o.launch(-1, false, true, 100, false, true, 10, true, false);
	}
	@Test
	public void test13222() {
		o.launch(-1, false, true, 100, false, true, 100, false, true);
	}
	@Test
	public void test13223() {
		o.launch(-1, false, true, 100, false, true, 100, false, false);
	}
	@Test
	public void test13224() {
		o.launch(10, false, true, -1, false, false, 0, true, true);
	}
	@Test
	public void test13225() {
		o.launch(-1, false, true, 10, false, false, 0, true, false);
	}
	@Test
	public void test13226() {
		o.launch(10, false, true, -1, false, false, 0, false, true);
	}
	@Test
	public void test13227() {
		o.launch(10, false, true, -1, false, false, 0, false, false);
	}
	@Test
	public void test13228() {
		o.launch(10, false, true, 100, false, false, 1, true, true);
	}
	@Test
	public void test13229() {
		o.launch(10, false, true, 100, false, false, 1, true, false);
	}
	@Test
	public void test13230() {
		o.launch(10, false, true, -1, false, false, 1, false, true);
	}
	@Test
	public void test13231() {
		o.launch(-1, false, true, 10, false, false, 1, false, false);
	}
	@Test
	public void test13232() {
		o.launch(5, false, true, 5, false, false, 2, true, true);
	}
	@Test
	public void test13233() {
		o.launch(5, false, true, 5, false, false, 2, true, false);
	}
	@Test
	public void test13234() {
		o.launch(5, false, true, 5, false, false, 2, false, true);
	}
	@Test
	public void test13235() {
		o.launch(5, false, true, 5, false, false, 2, false, false);
	}
	@Test
	public void test13236() {
		o.launch(5, false, true, 5, false, false, 3, true, true);
	}
	@Test
	public void test13237() {
		o.launch(5, false, true, 5, false, false, 3, true, false);
	}
	@Test
	public void test13238() {
		o.launch(5, false, true, 5, false, false, 3, false, true);
	}
	@Test
	public void test13239() {
		o.launch(5, false, true, 5, false, false, 3, false, false);
	}
	@Test
	public void test13240() {
		o.launch(-1, false, true, -1, false, false, 4, true, true);
	}
	@Test
	public void test13241() {
		o.launch(10, false, true, 100, false, false, 4, true, false);
	}
	@Test
	public void test13242() {
		o.launch(10, false, true, 10, false, false, 4, false, true);
	}
	@Test
	public void test13243() {
		o.launch(-1, false, true, 10, false, false, 4, false, false);
	}
	@Test
	public void test13244() {
		o.launch(100, false, true, -1, false, false, -1, true, true);
	}
	@Test
	public void test13245() {
		o.launch(100, false, true, -1, false, false, -1, true, false);
	}
	@Test
	public void test13246() {
		o.launch(-1, false, true, -1, false, false, 10, false, true);
	}
	@Test
	public void test13247() {
		o.launch(-1, false, true, -1, false, false, 10, false, false);
	}
	@Test
	public void test13248() {
		o.launch(10, false, false, 0, true, true, 0, true, true);
	}
	@Test
	public void test13249() {
		o.launch(10, false, false, 0, true, true, 0, true, false);
	}
	@Test
	public void test13250() {
		o.launch(-1, false, false, 0, true, true, 0, false, true);
	}
	@Test
	public void test13251() {
		o.launch(10, false, false, 0, true, true, 0, false, false);
	}
	@Test
	public void test13252() {
		o.launch(100, false, false, 0, true, true, 1, true, true);
	}
	@Test
	public void test13253() {
		o.launch(-1, false, false, 0, true, true, 1, true, false);
	}
	@Test
	public void test13254() {
		o.launch(-1, false, false, 0, true, true, 1, false, true);
	}
	@Test
	public void test13255() {
		o.launch(-1, false, false, 0, true, true, 1, false, false);
	}
	@Test
	public void test13256() {
		o.launch(5, false, false, 0, true, true, 2, true, true);
	}
	@Test
	public void test13257() {
		o.launch(5, false, false, 0, true, true, 2, true, false);
	}
	@Test
	public void test13258() {
		o.launch(5, false, false, 0, true, true, 2, false, true);
	}
	@Test
	public void test13259() {
		o.launch(5, false, false, 0, true, true, 2, false, false);
	}
	@Test
	public void test13260() {
		o.launch(5, false, false, 0, true, true, 3, true, true);
	}
	@Test
	public void test13261() {
		o.launch(5, false, false, 0, true, true, 3, true, false);
	}
	@Test
	public void test13262() {
		o.launch(5, false, false, 0, true, true, 3, false, true);
	}
	@Test
	public void test13263() {
		o.launch(5, false, false, 0, true, true, 3, false, false);
	}
	@Test
	public void test13264() {
		o.launch(-1, false, false, 0, true, true, 4, true, true);
	}
	@Test
	public void test13265() {
		o.launch(100, false, false, 0, true, true, 4, true, false);
	}
	@Test
	public void test13266() {
		o.launch(10, false, false, 0, true, true, 4, false, true);
	}
	@Test
	public void test13267() {
		o.launch(5, false, false, 0, true, true, 4, false, false);
	}
	@Test
	public void test13268() {
		o.launch(-1, false, false, 0, true, true, 100, true, true);
	}
	@Test
	public void test13269() {
		o.launch(-1, false, false, 0, true, true, 100, true, false);
	}
	@Test
	public void test13270() {
		o.launch(-1, false, false, 0, true, true, 100, false, true);
	}
	@Test
	public void test13271() {
		o.launch(-1, false, false, 0, true, true, 100, false, false);
	}
	@Test
	public void test13272() {
		o.launch(-1, false, false, 0, true, false, 0, true, true);
	}
	@Test
	public void test13273() {
		o.launch(10, false, false, 0, true, false, 0, true, false);
	}
	@Test
	public void test13274() {
		o.launch(-1, false, false, 0, true, false, 0, false, true);
	}
	@Test
	public void test13275() {
		o.launch(-1, false, false, 0, true, false, 0, false, false);
	}
	@Test
	public void test13276() {
		o.launch(10, false, false, 0, true, false, 1, true, true);
	}
	@Test
	public void test13277() {
		o.launch(100, false, false, 0, true, false, 1, true, false);
	}
	@Test
	public void test13278() {
		o.launch(10, false, false, 0, true, false, 1, false, true);
	}
	@Test
	public void test13279() {
		o.launch(100, false, false, 0, true, false, 1, false, false);
	}
	@Test
	public void test13280() {
		o.launch(5, false, false, 0, true, false, 2, true, true);
	}
	@Test
	public void test13281() {
		o.launch(5, false, false, 0, true, false, 2, true, false);
	}
	@Test
	public void test13282() {
		o.launch(5, false, false, 0, true, false, 2, false, true);
	}
	@Test
	public void test13283() {
		o.launch(5, false, false, 0, true, false, 2, false, false);
	}
	@Test
	public void test13284() {
		o.launch(5, false, false, 0, true, false, 3, true, true);
	}
	@Test
	public void test13285() {
		o.launch(5, false, false, 0, true, false, 3, true, false);
	}
	@Test
	public void test13286() {
		o.launch(5, false, false, 0, true, false, 3, false, true);
	}
	@Test
	public void test13287() {
		o.launch(5, false, false, 0, true, false, 3, false, false);
	}
	@Test
	public void test13288() {
		o.launch(100, false, false, 0, true, false, 4, true, true);
	}
	@Test
	public void test13289() {
		o.launch(-1, false, false, 0, true, false, 4, true, false);
	}
	@Test
	public void test13290() {
		o.launch(5, false, false, 0, true, false, 4, false, true);
	}
	@Test
	public void test13291() {
		o.launch(10, false, false, 0, true, false, 4, false, false);
	}
	@Test
	public void test13292() {
		o.launch(-1, false, false, 0, true, false, 10, true, true);
	}
	@Test
	public void test13293() {
		o.launch(10, false, false, 0, true, false, 10, true, false);
	}
	@Test
	public void test13294() {
		o.launch(10, false, false, 0, true, false, 10, false, true);
	}
	@Test
	public void test13295() {
		o.launch(10, false, false, 0, true, false, 10, false, false);
	}
	@Test
	public void test13296() {
		o.launch(-1, false, false, 0, false, true, 0, true, true);
	}
	@Test
	public void test13297() {
		o.launch(-1, false, false, 0, false, true, 0, true, false);
	}
	@Test
	public void test13298() {
		o.launch(-1, false, false, 0, false, true, 0, false, true);
	}
	@Test
	public void test13299() {
		o.launch(-1, false, false, 0, false, true, 0, false, false);
	}
	@Test
	public void test13300() {
		o.launch(-1, false, false, 0, false, true, 1, true, true);
	}
	@Test
	public void test13301() {
		o.launch(5, false, false, 0, false, true, 1, true, false);
	}
	@Test
	public void test13302() {
		o.launch(10, false, false, 0, false, true, 1, false, true);
	}
	@Test
	public void test13303() {
		o.launch(-1, false, false, 0, false, true, 1, false, false);
	}
	@Test
	public void test13304() {
		o.launch(5, false, false, 0, false, true, 2, true, true);
	}
	@Test
	public void test13305() {
		o.launch(5, false, false, 0, false, true, 2, true, false);
	}
	@Test
	public void test13306() {
		o.launch(5, false, false, 0, false, true, 2, false, true);
	}
	@Test
	public void test13307() {
		o.launch(5, false, false, 0, false, true, 2, false, false);
	}
	@Test
	public void test13308() {
		o.launch(5, false, false, 0, false, true, 3, true, true);
	}
	@Test
	public void test13309() {
		o.launch(5, false, false, 0, false, true, 3, true, false);
	}
	@Test
	public void test13310() {
		o.launch(5, false, false, 0, false, true, 3, false, true);
	}
	@Test
	public void test13311() {
		o.launch(5, false, false, 0, false, true, 3, false, false);
	}
	@Test
	public void test13312() {
		o.launch(-1, false, false, 0, false, true, 4, true, true);
	}
	@Test
	public void test13313() {
		o.launch(-1, false, false, 0, false, true, 4, true, false);
	}
	@Test
	public void test13314() {
		o.launch(5, false, false, 0, false, true, 4, false, true);
	}
	@Test
	public void test13315() {
		o.launch(10, false, false, 0, false, true, 4, false, false);
	}
	@Test
	public void test13316() {
		o.launch(-1, false, false, 0, false, true, 100, true, true);
	}
	@Test
	public void test13317() {
		o.launch(-1, false, false, 0, false, true, 100, true, false);
	}
	@Test
	public void test13318() {
		o.launch(-1, false, false, 0, false, true, 100, false, true);
	}
	@Test
	public void test13319() {
		o.launch(-1, false, false, 0, false, true, 100, false, false);
	}
	@Test
	public void test13320() {
		o.launch(-1, false, false, 0, false, false, 0, true, true);
	}
	@Test
	public void test13321() {
		o.launch(10, false, false, 0, false, false, 0, true, false);
	}
	@Test
	public void test13322() {
		o.launch(10, false, false, 0, false, false, 0, false, true);
	}
	@Test
	public void test13323() {
		o.launch(10, false, false, 0, false, false, 0, false, false);
	}
	@Test
	public void test13324() {
		o.launch(10, false, false, 0, false, false, 1, true, true);
	}
	@Test
	public void test13325() {
		o.launch(-1, false, false, 0, false, false, 1, true, false);
	}
	@Test
	public void test13326() {
		o.launch(10, false, false, 0, false, false, 1, false, true);
	}
	@Test
	public void test13327() {
		o.launch(10, false, false, 0, false, false, 1, false, false);
	}
	@Test
	public void test13328() {
		o.launch(5, false, false, 0, false, false, 2, true, true);
	}
	@Test
	public void test13329() {
		o.launch(5, false, false, 0, false, false, 2, true, false);
	}
	@Test
	public void test13330() {
		o.launch(5, false, false, 0, false, false, 2, false, true);
	}
	@Test
	public void test13331() {
		o.launch(5, false, false, 0, false, false, 2, false, false);
	}
	@Test
	public void test13332() {
		o.launch(5, false, false, 0, false, false, 3, true, true);
	}
	@Test
	public void test13333() {
		o.launch(5, false, false, 0, false, false, 3, true, false);
	}
	@Test
	public void test13334() {
		o.launch(5, false, false, 0, false, false, 3, false, true);
	}
	@Test
	public void test13335() {
		o.launch(5, false, false, 0, false, false, 3, false, false);
	}
	@Test
	public void test13336() {
		o.launch(10, false, false, 0, false, false, 4, true, true);
	}
	@Test
	public void test13337() {
		o.launch(-1, false, false, 0, false, false, 4, true, false);
	}
	@Test
	public void test13338() {
		o.launch(-1, false, false, 0, false, false, 4, false, true);
	}
	@Test
	public void test13339() {
		o.launch(100, false, false, 0, false, false, 4, false, false);
	}
	@Test
	public void test13340() {
		o.launch(-1, false, false, 0, false, false, 10, true, true);
	}
	@Test
	public void test13341() {
		o.launch(-1, false, false, 0, false, false, 10, true, false);
	}
	@Test
	public void test13342() {
		o.launch(10, false, false, 0, false, false, -1, false, true);
	}
	@Test
	public void test13343() {
		o.launch(-1, false, false, 0, false, false, 10, false, false);
	}
	@Test
	public void test13344() {
		o.launch(10, false, false, 1, true, true, 0, true, true);
	}
	@Test
	public void test13345() {
		o.launch(-1, false, false, 1, true, true, 0, true, false);
	}
	@Test
	public void test13346() {
		o.launch(10, false, false, 1, true, true, 0, false, true);
	}
	@Test
	public void test13347() {
		o.launch(10, false, false, 1, true, true, 0, false, false);
	}
	@Test
	public void test13348() {
		o.launch(10, false, false, 1, true, true, 1, true, true);
	}
	@Test
	public void test13349() {
		o.launch(-1, false, false, 1, true, true, 1, true, false);
	}
	@Test
	public void test13350() {
		o.launch(100, false, false, 1, true, true, 1, false, true);
	}
	@Test
	public void test13351() {
		o.launch(100, false, false, 1, true, true, 1, false, false);
	}
	@Test
	public void test13352() {
		o.launch(5, false, false, 1, true, true, 2, true, true);
	}
	@Test
	public void test13353() {
		o.launch(5, false, false, 1, true, true, 2, true, false);
	}
	@Test
	public void test13354() {
		o.launch(5, false, false, 1, true, true, 2, false, true);
	}
	@Test
	public void test13355() {
		o.launch(5, false, false, 1, true, true, 2, false, false);
	}
	@Test
	public void test13356() {
		o.launch(5, false, false, 1, true, true, 3, true, true);
	}
	@Test
	public void test13357() {
		o.launch(5, false, false, 1, true, true, 3, true, false);
	}
	@Test
	public void test13358() {
		o.launch(5, false, false, 1, true, true, 3, false, true);
	}
	@Test
	public void test13359() {
		o.launch(5, false, false, 1, true, true, 3, false, false);
	}
	@Test
	public void test13360() {
		o.launch(5, false, false, 1, true, true, 4, true, true);
	}
	@Test
	public void test13361() {
		o.launch(5, false, false, 1, true, true, 4, true, false);
	}
	@Test
	public void test13362() {
		o.launch(100, false, false, 1, true, true, 4, false, true);
	}
	@Test
	public void test13363() {
		o.launch(10, false, false, 1, true, true, 4, false, false);
	}
	@Test
	public void test13364() {
		o.launch(-1, false, false, 1, true, true, 10, true, true);
	}
	@Test
	public void test13365() {
		o.launch(-1, false, false, 1, true, true, 10, true, false);
	}
	@Test
	public void test13366() {
		o.launch(10, false, false, 1, true, true, 100, false, true);
	}
	@Test
	public void test13367() {
		o.launch(10, false, false, 1, true, true, 100, false, false);
	}
	@Test
	public void test13368() {
		o.launch(-1, false, false, 1, true, false, 0, true, true);
	}
	@Test
	public void test13369() {
		o.launch(-1, false, false, 1, true, false, 0, true, false);
	}
	@Test
	public void test13370() {
		o.launch(-1, false, false, 1, true, false, 0, false, true);
	}
	@Test
	public void test13371() {
		o.launch(-1, false, false, 1, true, false, 0, false, false);
	}
	@Test
	public void test13372() {
		o.launch(-1, false, false, 1, true, false, 1, true, true);
	}
	@Test
	public void test13373() {
		o.launch(5, false, false, 1, true, false, 1, true, false);
	}
	@Test
	public void test13374() {
		o.launch(-1, false, false, 1, true, false, 1, false, true);
	}
	@Test
	public void test13375() {
		o.launch(100, false, false, 1, true, false, 1, false, false);
	}
	@Test
	public void test13376() {
		o.launch(5, false, false, 1, true, false, 2, true, true);
	}
	@Test
	public void test13377() {
		o.launch(5, false, false, 1, true, false, 2, true, false);
	}
	@Test
	public void test13378() {
		o.launch(5, false, false, 1, true, false, 2, false, true);
	}
	@Test
	public void test13379() {
		o.launch(5, false, false, 1, true, false, 2, false, false);
	}
	@Test
	public void test13380() {
		o.launch(5, false, false, 1, true, false, 3, true, true);
	}
	@Test
	public void test13381() {
		o.launch(5, false, false, 1, true, false, 3, true, false);
	}
	@Test
	public void test13382() {
		o.launch(5, false, false, 1, true, false, 3, false, true);
	}
	@Test
	public void test13383() {
		o.launch(5, false, false, 1, true, false, 3, false, false);
	}
	@Test
	public void test13384() {
		o.launch(5, false, false, 1, true, false, 4, true, true);
	}
	@Test
	public void test13385() {
		o.launch(-1, false, false, 1, true, false, 4, true, false);
	}
	@Test
	public void test13386() {
		o.launch(-1, false, false, 1, true, false, 4, false, true);
	}
	@Test
	public void test13387() {
		o.launch(-1, false, false, 1, true, false, 4, false, false);
	}
	@Test
	public void test13388() {
		o.launch(10, false, false, 1, true, false, 10, true, true);
	}
	@Test
	public void test13389() {
		o.launch(10, false, false, 1, true, false, 10, true, false);
	}
	@Test
	public void test13390() {
		o.launch(10, false, false, 1, true, false, 10, false, true);
	}
	@Test
	public void test13391() {
		o.launch(-1, false, false, 1, true, false, -1, false, false);
	}
	@Test
	public void test13392() {
		o.launch(-1, false, false, 1, false, true, 0, true, true);
	}
	@Test
	public void test13393() {
		o.launch(-1, false, false, 1, false, true, 0, true, false);
	}
	@Test
	public void test13394() {
		o.launch(-1, false, false, 1, false, true, 0, false, true);
	}
	@Test
	public void test13395() {
		o.launch(-1, false, false, 1, false, true, 0, false, false);
	}
	@Test
	public void test13396() {
		o.launch(-1, false, false, 1, false, true, 1, true, true);
	}
	@Test
	public void test13397() {
		o.launch(10, false, false, 1, false, true, 1, true, false);
	}
	@Test
	public void test13398() {
		o.launch(10, false, false, 1, false, true, 1, false, true);
	}
	@Test
	public void test13399() {
		o.launch(10, false, false, 1, false, true, 1, false, false);
	}
	@Test
	public void test13400() {
		o.launch(5, false, false, 1, false, true, 2, true, true);
	}
	@Test
	public void test13401() {
		o.launch(5, false, false, 1, false, true, 2, true, false);
	}
	@Test
	public void test13402() {
		o.launch(5, false, false, 1, false, true, 2, false, true);
	}
	@Test
	public void test13403() {
		o.launch(5, false, false, 1, false, true, 2, false, false);
	}
	@Test
	public void test13404() {
		o.launch(5, false, false, 1, false, true, 3, true, true);
	}
	@Test
	public void test13405() {
		o.launch(5, false, false, 1, false, true, 3, true, false);
	}
	@Test
	public void test13406() {
		o.launch(5, false, false, 1, false, true, 3, false, true);
	}
	@Test
	public void test13407() {
		o.launch(5, false, false, 1, false, true, 3, false, false);
	}
	@Test
	public void test13408() {
		o.launch(5, false, false, 1, false, true, 4, true, true);
	}
	@Test
	public void test13409() {
		o.launch(-1, false, false, 1, false, true, 4, true, false);
	}
	@Test
	public void test13410() {
		o.launch(5, false, false, 1, false, true, 4, false, true);
	}
	@Test
	public void test13411() {
		o.launch(-1, false, false, 1, false, true, 4, false, false);
	}
	@Test
	public void test13412() {
		o.launch(-1, false, false, 1, false, true, 10, true, true);
	}
	@Test
	public void test13413() {
		o.launch(-1, false, false, 1, false, true, 10, true, false);
	}
	@Test
	public void test13414() {
		o.launch(-1, false, false, 1, false, true, 10, false, true);
	}
	@Test
	public void test13415() {
		o.launch(-1, false, false, 1, false, true, 10, false, false);
	}
	@Test
	public void test13416() {
		o.launch(5, false, false, 1, false, false, 0, true, true);
	}
	@Test
	public void test13417() {
		o.launch(-1, false, false, 1, false, false, 0, true, false);
	}
	@Test
	public void test13418() {
		o.launch(10, false, false, 1, false, false, 0, false, true);
	}
	@Test
	public void test13419() {
		o.launch(-1, false, false, 1, false, false, 0, false, false);
	}
	@Test
	public void test13420() {
		o.launch(-1, false, false, 1, false, false, 1, true, true);
	}
	@Test
	public void test13421() {
		o.launch(5, false, false, 1, false, false, 1, true, false);
	}
	@Test
	public void test13422() {
		o.launch(5, false, false, 1, false, false, 1, false, true);
	}
	@Test
	public void test13423() {
		o.launch(-1, false, false, 1, false, false, 1, false, false);
	}
	@Test
	public void test13424() {
		o.launch(5, false, false, 1, false, false, 2, true, true);
	}
	@Test
	public void test13425() {
		o.launch(5, false, false, 1, false, false, 2, true, false);
	}
	@Test
	public void test13426() {
		o.launch(5, false, false, 1, false, false, 2, false, true);
	}
	@Test
	public void test13427() {
		o.launch(5, false, false, 1, false, false, 2, false, false);
	}
	@Test
	public void test13428() {
		o.launch(5, false, false, 1, false, false, 3, true, true);
	}
	@Test
	public void test13429() {
		o.launch(5, false, false, 1, false, false, 3, true, false);
	}
	@Test
	public void test13430() {
		o.launch(5, false, false, 1, false, false, 3, false, true);
	}
	@Test
	public void test13431() {
		o.launch(5, false, false, 1, false, false, 3, false, false);
	}
	@Test
	public void test13432() {
		o.launch(-1, false, false, 1, false, false, 4, true, true);
	}
	@Test
	public void test13433() {
		o.launch(5, false, false, 1, false, false, 4, true, false);
	}
	@Test
	public void test13434() {
		o.launch(5, false, false, 1, false, false, 4, false, true);
	}
	@Test
	public void test13435() {
		o.launch(10, false, false, 1, false, false, 4, false, false);
	}
	@Test
	public void test13436() {
		o.launch(-1, false, false, 1, false, false, -1, true, true);
	}
	@Test
	public void test13437() {
		o.launch(10, false, false, 1, false, false, 10, true, false);
	}
	@Test
	public void test13438() {
		o.launch(10, false, false, 1, false, false, 10, false, true);
	}
	@Test
	public void test13439() {
		o.launch(10, false, false, 1, false, false, 10, false, false);
	}
	@Test
	public void test13440() {
		o.launch(5, false, false, 2, true, true, 0, true, true);
	}
	@Test
	public void test13441() {
		o.launch(5, false, false, 2, true, true, 0, true, false);
	}
	@Test
	public void test13442() {
		o.launch(5, false, false, 2, true, true, 0, false, true);
	}
	@Test
	public void test13443() {
		o.launch(5, false, false, 2, true, true, 0, false, false);
	}
	@Test
	public void test13444() {
		o.launch(5, false, false, 2, true, true, 1, true, true);
	}
	@Test
	public void test13445() {
		o.launch(5, false, false, 2, true, true, 1, true, false);
	}
	@Test
	public void test13446() {
		o.launch(5, false, false, 2, true, true, 1, false, true);
	}
	@Test
	public void test13447() {
		o.launch(5, false, false, 2, true, true, 1, false, false);
	}
	@Test
	public void test13448() {
		o.launch(5, false, false, 2, true, true, 2, true, true);
	}
	@Test
	public void test13449() {
		o.launch(5, false, false, 2, true, true, 2, true, false);
	}
	@Test
	public void test13450() {
		o.launch(5, false, false, 2, true, true, 2, false, true);
	}
	@Test
	public void test13451() {
		o.launch(5, false, false, 2, true, true, 2, false, false);
	}
	@Test
	public void test13452() {
		o.launch(5, false, false, 2, true, true, 3, true, true);
	}
	@Test
	public void test13453() {
		o.launch(5, false, false, 2, true, true, 3, true, false);
	}
	@Test
	public void test13454() {
		o.launch(5, false, false, 2, true, true, 3, false, true);
	}
	@Test
	public void test13455() {
		o.launch(5, false, false, 2, true, true, 3, false, false);
	}
	@Test
	public void test13456() {
		o.launch(5, false, false, 2, true, true, 4, true, true);
	}
	@Test
	public void test13457() {
		o.launch(5, false, false, 2, true, true, 4, true, false);
	}
	@Test
	public void test13458() {
		o.launch(5, false, false, 2, true, true, 4, false, true);
	}
	@Test
	public void test13459() {
		o.launch(5, false, false, 2, true, true, 4, false, false);
	}
	@Test
	public void test13460() {
		o.launch(5, false, false, 2, true, true, 5, true, true);
	}
	@Test
	public void test13461() {
		o.launch(5, false, false, 2, true, true, 5, true, false);
	}
	@Test
	public void test13462() {
		o.launch(5, false, false, 2, true, true, 5, false, true);
	}
	@Test
	public void test13463() {
		o.launch(5, false, false, 2, true, true, 5, false, false);
	}
	@Test
	public void test13464() {
		o.launch(5, false, false, 2, true, false, 0, true, true);
	}
	@Test
	public void test13465() {
		o.launch(5, false, false, 2, true, false, 0, true, false);
	}
	@Test
	public void test13466() {
		o.launch(5, false, false, 2, true, false, 0, false, true);
	}
	@Test
	public void test13467() {
		o.launch(5, false, false, 2, true, false, 0, false, false);
	}
	@Test
	public void test13468() {
		o.launch(5, false, false, 2, true, false, 1, true, true);
	}
	@Test
	public void test13469() {
		o.launch(5, false, false, 2, true, false, 1, true, false);
	}
	@Test
	public void test13470() {
		o.launch(5, false, false, 2, true, false, 1, false, true);
	}
	@Test
	public void test13471() {
		o.launch(5, false, false, 2, true, false, 1, false, false);
	}
	@Test
	public void test13472() {
		o.launch(5, false, false, 2, true, false, 2, true, true);
	}
	@Test
	public void test13473() {
		o.launch(5, false, false, 2, true, false, 2, true, false);
	}
	@Test
	public void test13474() {
		o.launch(5, false, false, 2, true, false, 2, false, true);
	}
	@Test
	public void test13475() {
		o.launch(5, false, false, 2, true, false, 2, false, false);
	}
	@Test
	public void test13476() {
		o.launch(5, false, false, 2, true, false, 3, true, true);
	}
	@Test
	public void test13477() {
		o.launch(5, false, false, 2, true, false, 3, true, false);
	}
	@Test
	public void test13478() {
		o.launch(5, false, false, 2, true, false, 3, false, true);
	}
	@Test
	public void test13479() {
		o.launch(5, false, false, 2, true, false, 3, false, false);
	}
	@Test
	public void test13480() {
		o.launch(5, false, false, 2, true, false, 4, true, true);
	}
	@Test
	public void test13481() {
		o.launch(5, false, false, 2, true, false, 4, true, false);
	}
	@Test
	public void test13482() {
		o.launch(5, false, false, 2, true, false, 4, false, true);
	}
	@Test
	public void test13483() {
		o.launch(5, false, false, 2, true, false, 4, false, false);
	}
	@Test
	public void test13484() {
		o.launch(5, false, false, 2, true, false, 5, true, true);
	}
	@Test
	public void test13485() {
		o.launch(5, false, false, 2, true, false, 5, true, false);
	}
	@Test
	public void test13486() {
		o.launch(5, false, false, 2, true, false, 5, false, true);
	}
	@Test
	public void test13487() {
		o.launch(5, false, false, 2, true, false, 5, false, false);
	}
	@Test
	public void test13488() {
		o.launch(5, false, false, 2, false, true, 0, true, true);
	}
	@Test
	public void test13489() {
		o.launch(5, false, false, 2, false, true, 0, true, false);
	}
	@Test
	public void test13490() {
		o.launch(5, false, false, 2, false, true, 0, false, true);
	}
	@Test
	public void test13491() {
		o.launch(5, false, false, 2, false, true, 0, false, false);
	}
	@Test
	public void test13492() {
		o.launch(5, false, false, 2, false, true, 1, true, true);
	}
	@Test
	public void test13493() {
		o.launch(5, false, false, 2, false, true, 1, true, false);
	}
	@Test
	public void test13494() {
		o.launch(5, false, false, 2, false, true, 1, false, true);
	}
	@Test
	public void test13495() {
		o.launch(5, false, false, 2, false, true, 1, false, false);
	}
	@Test
	public void test13496() {
		o.launch(5, false, false, 2, false, true, 2, true, true);
	}
	@Test
	public void test13497() {
		o.launch(5, false, false, 2, false, true, 2, true, false);
	}
	@Test
	public void test13498() {
		o.launch(5, false, false, 2, false, true, 2, false, true);
	}
	@Test
	public void test13499() {
		o.launch(5, false, false, 2, false, true, 2, false, false);
	}
	@Test
	public void test13500() {
		o.launch(5, false, false, 2, false, true, 3, true, true);
	}
	@Test
	public void test13501() {
		o.launch(5, false, false, 2, false, true, 3, true, false);
	}
	@Test
	public void test13502() {
		o.launch(5, false, false, 2, false, true, 3, false, true);
	}
	@Test
	public void test13503() {
		o.launch(5, false, false, 2, false, true, 3, false, false);
	}
	@Test
	public void test13504() {
		o.launch(5, false, false, 2, false, true, 4, true, true);
	}
	@Test
	public void test13505() {
		o.launch(5, false, false, 2, false, true, 4, true, false);
	}
	@Test
	public void test13506() {
		o.launch(5, false, false, 2, false, true, 4, false, true);
	}
	@Test
	public void test13507() {
		o.launch(5, false, false, 2, false, true, 4, false, false);
	}
	@Test
	public void test13508() {
		o.launch(5, false, false, 2, false, true, 5, true, true);
	}
	@Test
	public void test13509() {
		o.launch(5, false, false, 2, false, true, 5, true, false);
	}
	@Test
	public void test13510() {
		o.launch(5, false, false, 2, false, true, 5, false, true);
	}
	@Test
	public void test13511() {
		o.launch(5, false, false, 2, false, true, 5, false, false);
	}
	@Test
	public void test13512() {
		o.launch(5, false, false, 2, false, false, 0, true, true);
	}
	@Test
	public void test13513() {
		o.launch(5, false, false, 2, false, false, 0, true, false);
	}
	@Test
	public void test13514() {
		o.launch(5, false, false, 2, false, false, 0, false, true);
	}
	@Test
	public void test13515() {
		o.launch(5, false, false, 2, false, false, 0, false, false);
	}
	@Test
	public void test13516() {
		o.launch(5, false, false, 2, false, false, 1, true, true);
	}
	@Test
	public void test13517() {
		o.launch(5, false, false, 2, false, false, 1, true, false);
	}
	@Test
	public void test13518() {
		o.launch(5, false, false, 2, false, false, 1, false, true);
	}
	@Test
	public void test13519() {
		o.launch(5, false, false, 2, false, false, 1, false, false);
	}
	@Test
	public void test13520() {
		o.launch(5, false, false, 2, false, false, 2, true, true);
	}
	@Test
	public void test13521() {
		o.launch(5, false, false, 2, false, false, 2, true, false);
	}
	@Test
	public void test13522() {
		o.launch(5, false, false, 2, false, false, 2, false, true);
	}
	@Test
	public void test13523() {
		o.launch(5, false, false, 2, false, false, 2, false, false);
	}
	@Test
	public void test13524() {
		o.launch(5, false, false, 2, false, false, 3, true, true);
	}
	@Test
	public void test13525() {
		o.launch(5, false, false, 2, false, false, 3, true, false);
	}
	@Test
	public void test13526() {
		o.launch(5, false, false, 2, false, false, 3, false, true);
	}
	@Test
	public void test13527() {
		o.launch(5, false, false, 2, false, false, 3, false, false);
	}
	@Test
	public void test13528() {
		o.launch(5, false, false, 2, false, false, 4, true, true);
	}
	@Test
	public void test13529() {
		o.launch(5, false, false, 2, false, false, 4, true, false);
	}
	@Test
	public void test13530() {
		o.launch(5, false, false, 2, false, false, 4, false, true);
	}
	@Test
	public void test13531() {
		o.launch(5, false, false, 2, false, false, 4, false, false);
	}
	@Test
	public void test13532() {
		o.launch(5, false, false, 2, false, false, 5, true, true);
	}
	@Test
	public void test13533() {
		o.launch(5, false, false, 2, false, false, 5, true, false);
	}
	@Test
	public void test13534() {
		o.launch(5, false, false, 2, false, false, 5, false, true);
	}
	@Test
	public void test13535() {
		o.launch(5, false, false, 2, false, false, 5, false, false);
	}
	@Test
	public void test13536() {
		o.launch(5, false, false, 3, true, true, 0, true, true);
	}
	@Test
	public void test13537() {
		o.launch(5, false, false, 3, true, true, 0, true, false);
	}
	@Test
	public void test13538() {
		o.launch(5, false, false, 3, true, true, 0, false, true);
	}
	@Test
	public void test13539() {
		o.launch(5, false, false, 3, true, true, 0, false, false);
	}
	@Test
	public void test13540() {
		o.launch(5, false, false, 3, true, true, 1, true, true);
	}
	@Test
	public void test13541() {
		o.launch(5, false, false, 3, true, true, 1, true, false);
	}
	@Test
	public void test13542() {
		o.launch(5, false, false, 3, true, true, 1, false, true);
	}
	@Test
	public void test13543() {
		o.launch(5, false, false, 3, true, true, 1, false, false);
	}
	@Test
	public void test13544() {
		o.launch(5, false, false, 3, true, true, 2, true, true);
	}
	@Test
	public void test13545() {
		o.launch(5, false, false, 3, true, true, 2, true, false);
	}
	@Test
	public void test13546() {
		o.launch(5, false, false, 3, true, true, 2, false, true);
	}
	@Test
	public void test13547() {
		o.launch(5, false, false, 3, true, true, 2, false, false);
	}
	@Test
	public void test13548() {
		o.launch(5, false, false, 3, true, true, 3, true, true);
	}
	@Test
	public void test13549() {
		o.launch(5, false, false, 3, true, true, 3, true, false);
	}
	@Test
	public void test13550() {
		o.launch(5, false, false, 3, true, true, 3, false, true);
	}
	@Test
	public void test13551() {
		o.launch(5, false, false, 3, true, true, 3, false, false);
	}
	@Test
	public void test13552() {
		o.launch(5, false, false, 3, true, true, 4, true, true);
	}
	@Test
	public void test13553() {
		o.launch(5, false, false, 3, true, true, 4, true, false);
	}
	@Test
	public void test13554() {
		o.launch(5, false, false, 3, true, true, 4, false, true);
	}
	@Test
	public void test13555() {
		o.launch(5, false, false, 3, true, true, 4, false, false);
	}
	@Test
	public void test13556() {
		o.launch(5, false, false, 3, true, true, 5, true, true);
	}
	@Test
	public void test13557() {
		o.launch(5, false, false, 3, true, true, 5, true, false);
	}
	@Test
	public void test13558() {
		o.launch(5, false, false, 3, true, true, 5, false, true);
	}
	@Test
	public void test13559() {
		o.launch(5, false, false, 3, true, true, 5, false, false);
	}
	@Test
	public void test13560() {
		o.launch(5, false, false, 3, true, false, 0, true, true);
	}
	@Test
	public void test13561() {
		o.launch(5, false, false, 3, true, false, 0, true, false);
	}
	@Test
	public void test13562() {
		o.launch(5, false, false, 3, true, false, 0, false, true);
	}
	@Test
	public void test13563() {
		o.launch(5, false, false, 3, true, false, 0, false, false);
	}
	@Test
	public void test13564() {
		o.launch(5, false, false, 3, true, false, 1, true, true);
	}
	@Test
	public void test13565() {
		o.launch(5, false, false, 3, true, false, 1, true, false);
	}
	@Test
	public void test13566() {
		o.launch(5, false, false, 3, true, false, 1, false, true);
	}
	@Test
	public void test13567() {
		o.launch(5, false, false, 3, true, false, 1, false, false);
	}
	@Test
	public void test13568() {
		o.launch(5, false, false, 3, true, false, 2, true, true);
	}
	@Test
	public void test13569() {
		o.launch(5, false, false, 3, true, false, 2, true, false);
	}
	@Test
	public void test13570() {
		o.launch(5, false, false, 3, true, false, 2, false, true);
	}
	@Test
	public void test13571() {
		o.launch(5, false, false, 3, true, false, 2, false, false);
	}
	@Test
	public void test13572() {
		o.launch(5, false, false, 3, true, false, 3, true, true);
	}
	@Test
	public void test13573() {
		o.launch(5, false, false, 3, true, false, 3, true, false);
	}
	@Test
	public void test13574() {
		o.launch(5, false, false, 3, true, false, 3, false, true);
	}
	@Test
	public void test13575() {
		o.launch(5, false, false, 3, true, false, 3, false, false);
	}
	@Test
	public void test13576() {
		o.launch(5, false, false, 3, true, false, 4, true, true);
	}
	@Test
	public void test13577() {
		o.launch(5, false, false, 3, true, false, 4, true, false);
	}
	@Test
	public void test13578() {
		o.launch(5, false, false, 3, true, false, 4, false, true);
	}
	@Test
	public void test13579() {
		o.launch(5, false, false, 3, true, false, 4, false, false);
	}
	@Test
	public void test13580() {
		o.launch(5, false, false, 3, true, false, 5, true, true);
	}
	@Test
	public void test13581() {
		o.launch(5, false, false, 3, true, false, 5, true, false);
	}
	@Test
	public void test13582() {
		o.launch(5, false, false, 3, true, false, 5, false, true);
	}
	@Test
	public void test13583() {
		o.launch(5, false, false, 3, true, false, 5, false, false);
	}
	@Test
	public void test13584() {
		o.launch(5, false, false, 3, false, true, 0, true, true);
	}
	@Test
	public void test13585() {
		o.launch(5, false, false, 3, false, true, 0, true, false);
	}
	@Test
	public void test13586() {
		o.launch(5, false, false, 3, false, true, 0, false, true);
	}
	@Test
	public void test13587() {
		o.launch(5, false, false, 3, false, true, 0, false, false);
	}
	@Test
	public void test13588() {
		o.launch(5, false, false, 3, false, true, 1, true, true);
	}
	@Test
	public void test13589() {
		o.launch(5, false, false, 3, false, true, 1, true, false);
	}
	@Test
	public void test13590() {
		o.launch(5, false, false, 3, false, true, 1, false, true);
	}
	@Test
	public void test13591() {
		o.launch(5, false, false, 3, false, true, 1, false, false);
	}
	@Test
	public void test13592() {
		o.launch(5, false, false, 3, false, true, 2, true, true);
	}
	@Test
	public void test13593() {
		o.launch(5, false, false, 3, false, true, 2, true, false);
	}
	@Test
	public void test13594() {
		o.launch(5, false, false, 3, false, true, 2, false, true);
	}
	@Test
	public void test13595() {
		o.launch(5, false, false, 3, false, true, 2, false, false);
	}
	@Test
	public void test13596() {
		o.launch(5, false, false, 3, false, true, 3, true, true);
	}
	@Test
	public void test13597() {
		o.launch(5, false, false, 3, false, true, 3, true, false);
	}
	@Test
	public void test13598() {
		o.launch(5, false, false, 3, false, true, 3, false, true);
	}
	@Test
	public void test13599() {
		o.launch(5, false, false, 3, false, true, 3, false, false);
	}
	@Test
	public void test13600() {
		o.launch(5, false, false, 3, false, true, 4, true, true);
	}
	@Test
	public void test13601() {
		o.launch(5, false, false, 3, false, true, 4, true, false);
	}
	@Test
	public void test13602() {
		o.launch(5, false, false, 3, false, true, 4, false, true);
	}
	@Test
	public void test13603() {
		o.launch(5, false, false, 3, false, true, 4, false, false);
	}
	@Test
	public void test13604() {
		o.launch(5, false, false, 3, false, true, 5, true, true);
	}
	@Test
	public void test13605() {
		o.launch(5, false, false, 3, false, true, 5, true, false);
	}
	@Test
	public void test13606() {
		o.launch(5, false, false, 3, false, true, 5, false, true);
	}
	@Test
	public void test13607() {
		o.launch(5, false, false, 3, false, true, 5, false, false);
	}
	@Test
	public void test13608() {
		o.launch(5, false, false, 3, false, false, 0, true, true);
	}
	@Test
	public void test13609() {
		o.launch(5, false, false, 3, false, false, 0, true, false);
	}
	@Test
	public void test13610() {
		o.launch(5, false, false, 3, false, false, 0, false, true);
	}
	@Test
	public void test13611() {
		o.launch(5, false, false, 3, false, false, 0, false, false);
	}
	@Test
	public void test13612() {
		o.launch(5, false, false, 3, false, false, 1, true, true);
	}
	@Test
	public void test13613() {
		o.launch(5, false, false, 3, false, false, 1, true, false);
	}
	@Test
	public void test13614() {
		o.launch(5, false, false, 3, false, false, 1, false, true);
	}
	@Test
	public void test13615() {
		o.launch(5, false, false, 3, false, false, 1, false, false);
	}
	@Test
	public void test13616() {
		o.launch(5, false, false, 3, false, false, 2, true, true);
	}
	@Test
	public void test13617() {
		o.launch(5, false, false, 3, false, false, 2, true, false);
	}
	@Test
	public void test13618() {
		o.launch(5, false, false, 3, false, false, 2, false, true);
	}
	@Test
	public void test13619() {
		o.launch(5, false, false, 3, false, false, 2, false, false);
	}
	@Test
	public void test13620() {
		o.launch(5, false, false, 3, false, false, 3, true, true);
	}
	@Test
	public void test13621() {
		o.launch(5, false, false, 3, false, false, 3, true, false);
	}
	@Test
	public void test13622() {
		o.launch(5, false, false, 3, false, false, 3, false, true);
	}
	@Test
	public void test13623() {
		o.launch(5, false, false, 3, false, false, 3, false, false);
	}
	@Test
	public void test13624() {
		o.launch(5, false, false, 3, false, false, 4, true, true);
	}
	@Test
	public void test13625() {
		o.launch(5, false, false, 3, false, false, 4, true, false);
	}
	@Test
	public void test13626() {
		o.launch(5, false, false, 3, false, false, 4, false, true);
	}
	@Test
	public void test13627() {
		o.launch(5, false, false, 3, false, false, 4, false, false);
	}
	@Test
	public void test13628() {
		o.launch(5, false, false, 3, false, false, 5, true, true);
	}
	@Test
	public void test13629() {
		o.launch(5, false, false, 3, false, false, 5, true, false);
	}
	@Test
	public void test13630() {
		o.launch(5, false, false, 3, false, false, 5, false, true);
	}
	@Test
	public void test13631() {
		o.launch(5, false, false, 3, false, false, 5, false, false);
	}
	@Test
	public void test13632() {
		o.launch(5, false, false, 4, true, true, 0, true, true);
	}
	@Test
	public void test13633() {
		o.launch(-1, false, false, 4, true, true, 0, true, false);
	}
	@Test
	public void test13634() {
		o.launch(5, false, false, 4, true, true, 0, false, true);
	}
	@Test
	public void test13635() {
		o.launch(100, false, false, 4, true, true, 0, false, false);
	}
	@Test
	public void test13636() {
		o.launch(5, false, false, 4, true, true, 1, true, true);
	}
	@Test
	public void test13637() {
		o.launch(5, false, false, 4, true, true, 1, true, false);
	}
	@Test
	public void test13638() {
		o.launch(5, false, false, 4, true, true, 1, false, true);
	}
	@Test
	public void test13639() {
		o.launch(5, false, false, 4, true, true, 1, false, false);
	}
	@Test
	public void test13640() {
		o.launch(5, false, false, 4, true, true, 2, true, true);
	}
	@Test
	public void test13641() {
		o.launch(5, false, false, 4, true, true, 2, true, false);
	}
	@Test
	public void test13642() {
		o.launch(5, false, false, 4, true, true, 2, false, true);
	}
	@Test
	public void test13643() {
		o.launch(5, false, false, 4, true, true, 2, false, false);
	}
	@Test
	public void test13644() {
		o.launch(5, false, false, 4, true, true, 3, true, true);
	}
	@Test
	public void test13645() {
		o.launch(5, false, false, 4, true, true, 3, true, false);
	}
	@Test
	public void test13646() {
		o.launch(5, false, false, 4, true, true, 3, false, true);
	}
	@Test
	public void test13647() {
		o.launch(5, false, false, 4, true, true, 3, false, false);
	}
	@Test
	public void test13648() {
		o.launch(5, false, false, 4, true, true, 4, true, true);
	}
	@Test
	public void test13649() {
		o.launch(5, false, false, 4, true, true, 4, true, false);
	}
	@Test
	public void test13650() {
		o.launch(100, false, false, 4, true, true, 4, false, true);
	}
	@Test
	public void test13651() {
		o.launch(5, false, false, 4, true, true, 4, false, false);
	}
	@Test
	public void test13652() {
		o.launch(10, false, false, 4, true, true, -1, true, true);
	}
	@Test
	public void test13653() {
		o.launch(-1, false, false, 4, true, true, 100, true, false);
	}
	@Test
	public void test13654() {
		o.launch(100, false, false, 4, true, true, -1, false, true);
	}
	@Test
	public void test13655() {
		o.launch(100, false, false, 4, true, true, 10, false, false);
	}
	@Test
	public void test13656() {
		o.launch(-1, false, false, 4, true, false, 0, true, true);
	}
	@Test
	public void test13657() {
		o.launch(5, false, false, 4, true, false, 0, true, false);
	}
	@Test
	public void test13658() {
		o.launch(5, false, false, 4, true, false, 0, false, true);
	}
	@Test
	public void test13659() {
		o.launch(10, false, false, 4, true, false, 0, false, false);
	}
	@Test
	public void test13660() {
		o.launch(10, false, false, 4, true, false, 1, true, true);
	}
	@Test
	public void test13661() {
		o.launch(5, false, false, 4, true, false, 1, true, false);
	}
	@Test
	public void test13662() {
		o.launch(100, false, false, 4, true, false, 1, false, true);
	}
	@Test
	public void test13663() {
		o.launch(-1, false, false, 4, true, false, 1, false, false);
	}
	@Test
	public void test13664() {
		o.launch(5, false, false, 4, true, false, 2, true, true);
	}
	@Test
	public void test13665() {
		o.launch(5, false, false, 4, true, false, 2, true, false);
	}
	@Test
	public void test13666() {
		o.launch(5, false, false, 4, true, false, 2, false, true);
	}
	@Test
	public void test13667() {
		o.launch(5, false, false, 4, true, false, 2, false, false);
	}
	@Test
	public void test13668() {
		o.launch(5, false, false, 4, true, false, 3, true, true);
	}
	@Test
	public void test13669() {
		o.launch(5, false, false, 4, true, false, 3, true, false);
	}
	@Test
	public void test13670() {
		o.launch(5, false, false, 4, true, false, 3, false, true);
	}
	@Test
	public void test13671() {
		o.launch(5, false, false, 4, true, false, 3, false, false);
	}
	@Test
	public void test13672() {
		o.launch(5, false, false, 4, true, false, 4, true, true);
	}
	@Test
	public void test13673() {
		o.launch(100, false, false, 4, true, false, 4, true, false);
	}
	@Test
	public void test13674() {
		o.launch(5, false, false, 4, true, false, 4, false, true);
	}
	@Test
	public void test13675() {
		o.launch(100, false, false, 4, true, false, 4, false, false);
	}
	@Test
	public void test13676() {
		o.launch(5, false, false, 4, true, false, 5, true, true);
	}
	@Test
	public void test13677() {
		o.launch(100, false, false, 4, true, false, 100, true, false);
	}
	@Test
	public void test13678() {
		o.launch(100, false, false, 4, true, false, 10, false, true);
	}
	@Test
	public void test13679() {
		o.launch(10, false, false, 4, true, false, -1, false, false);
	}
	@Test
	public void test13680() {
		o.launch(-1, false, false, 4, false, true, 0, true, true);
	}
	@Test
	public void test13681() {
		o.launch(-1, false, false, 4, false, true, 0, true, false);
	}
	@Test
	public void test13682() {
		o.launch(5, false, false, 4, false, true, 0, false, true);
	}
	@Test
	public void test13683() {
		o.launch(10, false, false, 4, false, true, 0, false, false);
	}
	@Test
	public void test13684() {
		o.launch(5, false, false, 4, false, true, 1, true, true);
	}
	@Test
	public void test13685() {
		o.launch(5, false, false, 4, false, true, 1, true, false);
	}
	@Test
	public void test13686() {
		o.launch(-1, false, false, 4, false, true, 1, false, true);
	}
	@Test
	public void test13687() {
		o.launch(-1, false, false, 4, false, true, 1, false, false);
	}
	@Test
	public void test13688() {
		o.launch(5, false, false, 4, false, true, 2, true, true);
	}
	@Test
	public void test13689() {
		o.launch(5, false, false, 4, false, true, 2, true, false);
	}
	@Test
	public void test13690() {
		o.launch(5, false, false, 4, false, true, 2, false, true);
	}
	@Test
	public void test13691() {
		o.launch(5, false, false, 4, false, true, 2, false, false);
	}
	@Test
	public void test13692() {
		o.launch(5, false, false, 4, false, true, 3, true, true);
	}
	@Test
	public void test13693() {
		o.launch(5, false, false, 4, false, true, 3, true, false);
	}
	@Test
	public void test13694() {
		o.launch(5, false, false, 4, false, true, 3, false, true);
	}
	@Test
	public void test13695() {
		o.launch(5, false, false, 4, false, true, 3, false, false);
	}
	@Test
	public void test13696() {
		o.launch(5, false, false, 4, false, true, 4, true, true);
	}
	@Test
	public void test13697() {
		o.launch(5, false, false, 4, false, true, 4, true, false);
	}
	@Test
	public void test13698() {
		o.launch(5, false, false, 4, false, true, 4, false, true);
	}
	@Test
	public void test13699() {
		o.launch(5, false, false, 4, false, true, 4, false, false);
	}
	@Test
	public void test13700() {
		o.launch(10, false, false, 4, false, true, 10, true, true);
	}
	@Test
	public void test13701() {
		o.launch(-1, false, false, 4, false, true, -1, true, false);
	}
	@Test
	public void test13702() {
		o.launch(100, false, false, 4, false, true, 10, false, true);
	}
	@Test
	public void test13703() {
		o.launch(5, false, false, 4, false, true, 5, false, false);
	}
	@Test
	public void test13704() {
		o.launch(5, false, false, 4, false, false, 0, true, true);
	}
	@Test
	public void test13705() {
		o.launch(10, false, false, 4, false, false, 0, true, false);
	}
	@Test
	public void test13706() {
		o.launch(-1, false, false, 4, false, false, 0, false, true);
	}
	@Test
	public void test13707() {
		o.launch(-1, false, false, 4, false, false, 0, false, false);
	}
	@Test
	public void test13708() {
		o.launch(-1, false, false, 4, false, false, 1, true, true);
	}
	@Test
	public void test13709() {
		o.launch(5, false, false, 4, false, false, 1, true, false);
	}
	@Test
	public void test13710() {
		o.launch(10, false, false, 4, false, false, 1, false, true);
	}
	@Test
	public void test13711() {
		o.launch(5, false, false, 4, false, false, 1, false, false);
	}
	@Test
	public void test13712() {
		o.launch(5, false, false, 4, false, false, 2, true, true);
	}
	@Test
	public void test13713() {
		o.launch(5, false, false, 4, false, false, 2, true, false);
	}
	@Test
	public void test13714() {
		o.launch(5, false, false, 4, false, false, 2, false, true);
	}
	@Test
	public void test13715() {
		o.launch(5, false, false, 4, false, false, 2, false, false);
	}
	@Test
	public void test13716() {
		o.launch(5, false, false, 4, false, false, 3, true, true);
	}
	@Test
	public void test13717() {
		o.launch(5, false, false, 4, false, false, 3, true, false);
	}
	@Test
	public void test13718() {
		o.launch(5, false, false, 4, false, false, 3, false, true);
	}
	@Test
	public void test13719() {
		o.launch(5, false, false, 4, false, false, 3, false, false);
	}
	@Test
	public void test13720() {
		o.launch(5, false, false, 4, false, false, 4, true, true);
	}
	@Test
	public void test13721() {
		o.launch(5, false, false, 4, false, false, 4, true, false);
	}
	@Test
	public void test13722() {
		o.launch(5, false, false, 4, false, false, 4, false, true);
	}
	@Test
	public void test13723() {
		o.launch(5, false, false, 4, false, false, 4, false, false);
	}
	@Test
	public void test13724() {
		o.launch(-1, false, false, 4, false, false, -1, true, true);
	}
	@Test
	public void test13725() {
		o.launch(-1, false, false, 4, false, false, -1, true, false);
	}
	@Test
	public void test13726() {
		o.launch(10, false, false, 4, false, false, 100, false, true);
	}
	@Test
	public void test13727() {
		o.launch(10, false, false, 4, false, false, -1, false, false);
	}
	@Test
	public void test13728() {
		o.launch(100, false, false, -1, true, true, 0, true, true);
	}
	@Test
	public void test13729() {
		o.launch(100, false, false, -1, true, true, 0, true, false);
	}
	@Test
	public void test13730() {
		o.launch(10, false, false, 10, true, true, 0, false, true);
	}
	@Test
	public void test13731() {
		o.launch(100, false, false, 100, true, true, 0, false, false);
	}
	@Test
	public void test13732() {
		o.launch(-1, false, false, -1, true, true, 1, true, true);
	}
	@Test
	public void test13733() {
		o.launch(100, false, false, 100, true, true, 1, true, false);
	}
	@Test
	public void test13734() {
		o.launch(10, false, false, 100, true, true, 1, false, true);
	}
	@Test
	public void test13735() {
		o.launch(10, false, false, 10, true, true, 1, false, false);
	}
	@Test
	public void test13736() {
		o.launch(5, false, false, 5, true, true, 2, true, true);
	}
	@Test
	public void test13737() {
		o.launch(5, false, false, 5, true, true, 2, true, false);
	}
	@Test
	public void test13738() {
		o.launch(5, false, false, 5, true, true, 2, false, true);
	}
	@Test
	public void test13739() {
		o.launch(5, false, false, 5, true, true, 2, false, false);
	}
	@Test
	public void test13740() {
		o.launch(5, false, false, 5, true, true, 3, true, true);
	}
	@Test
	public void test13741() {
		o.launch(5, false, false, 5, true, true, 3, true, false);
	}
	@Test
	public void test13742() {
		o.launch(5, false, false, 5, true, true, 3, false, true);
	}
	@Test
	public void test13743() {
		o.launch(5, false, false, 5, true, true, 3, false, false);
	}
	@Test
	public void test13744() {
		o.launch(100, false, false, 100, true, true, 4, true, true);
	}
	@Test
	public void test13745() {
		o.launch(-1, false, false, -1, true, true, 4, true, false);
	}
	@Test
	public void test13746() {
		o.launch(-1, false, false, -1, true, true, 4, false, true);
	}
	@Test
	public void test13747() {
		o.launch(10, false, false, 10, true, true, 4, false, false);
	}
	@Test
	public void test13748() {
		o.launch(-1, false, false, 100, true, true, 100, true, true);
	}
	@Test
	public void test13749() {
		o.launch(-1, false, false, 10, true, true, 100, true, false);
	}
	@Test
	public void test13750() {
		o.launch(-1, false, false, -1, true, true, 100, false, true);
	}
	@Test
	public void test13751() {
		o.launch(-1, false, false, -1, true, true, 100, false, false);
	}
	@Test
	public void test13752() {
		o.launch(10, false, false, 10, true, false, 0, true, true);
	}
	@Test
	public void test13753() {
		o.launch(10, false, false, 10, true, false, 0, true, false);
	}
	@Test
	public void test13754() {
		o.launch(10, false, false, 10, true, false, 0, false, true);
	}
	@Test
	public void test13755() {
		o.launch(10, false, false, 10, true, false, 0, false, false);
	}
	@Test
	public void test13756() {
		o.launch(-1, false, false, -1, true, false, 1, true, true);
	}
	@Test
	public void test13757() {
		o.launch(-1, false, false, 100, true, false, 1, true, false);
	}
	@Test
	public void test13758() {
		o.launch(-1, false, false, 100, true, false, 1, false, true);
	}
	@Test
	public void test13759() {
		o.launch(-1, false, false, 100, true, false, 1, false, false);
	}
	@Test
	public void test13760() {
		o.launch(5, false, false, 5, true, false, 2, true, true);
	}
	@Test
	public void test13761() {
		o.launch(5, false, false, 5, true, false, 2, true, false);
	}
	@Test
	public void test13762() {
		o.launch(5, false, false, 5, true, false, 2, false, true);
	}
	@Test
	public void test13763() {
		o.launch(5, false, false, 5, true, false, 2, false, false);
	}
	@Test
	public void test13764() {
		o.launch(5, false, false, 5, true, false, 3, true, true);
	}
	@Test
	public void test13765() {
		o.launch(5, false, false, 5, true, false, 3, true, false);
	}
	@Test
	public void test13766() {
		o.launch(5, false, false, 5, true, false, 3, false, true);
	}
	@Test
	public void test13767() {
		o.launch(5, false, false, 5, true, false, 3, false, false);
	}
	@Test
	public void test13768() {
		o.launch(100, false, false, 10, true, false, 4, true, true);
	}
	@Test
	public void test13769() {
		o.launch(100, false, false, 10, true, false, 4, true, false);
	}
	@Test
	public void test13770() {
		o.launch(5, false, false, 5, true, false, 4, false, true);
	}
	@Test
	public void test13771() {
		o.launch(10, false, false, 100, true, false, 4, false, false);
	}
	@Test
	public void test13772() {
		o.launch(10, false, false, 10, true, false, -1, true, true);
	}
	@Test
	public void test13773() {
		o.launch(10, false, false, 10, true, false, -1, true, false);
	}
	@Test
	public void test13774() {
		o.launch(10, false, false, 10, true, false, -1, false, true);
	}
	@Test
	public void test13775() {
		o.launch(10, false, false, 10, true, false, -1, false, false);
	}
	@Test
	public void test13776() {
		o.launch(-1, false, false, 10, false, true, 0, true, true);
	}
	@Test
	public void test13777() {
		o.launch(-1, false, false, 10, false, true, 0, true, false);
	}
	@Test
	public void test13778() {
		o.launch(-1, false, false, 10, false, true, 0, false, true);
	}
	@Test
	public void test13779() {
		o.launch(-1, false, false, 10, false, true, 0, false, false);
	}
	@Test
	public void test13780() {
		o.launch(-1, false, false, 10, false, true, 1, true, true);
	}
	@Test
	public void test13781() {
		o.launch(-1, false, false, 10, false, true, 1, true, false);
	}
	@Test
	public void test13782() {
		o.launch(-1, false, false, -1, false, true, 1, false, true);
	}
	@Test
	public void test13783() {
		o.launch(-1, false, false, -1, false, true, 1, false, false);
	}
	@Test
	public void test13784() {
		o.launch(5, false, false, 5, false, true, 2, true, true);
	}
	@Test
	public void test13785() {
		o.launch(5, false, false, 5, false, true, 2, true, false);
	}
	@Test
	public void test13786() {
		o.launch(5, false, false, 5, false, true, 2, false, true);
	}
	@Test
	public void test13787() {
		o.launch(5, false, false, 5, false, true, 2, false, false);
	}
	@Test
	public void test13788() {
		o.launch(5, false, false, 5, false, true, 3, true, true);
	}
	@Test
	public void test13789() {
		o.launch(5, false, false, 5, false, true, 3, true, false);
	}
	@Test
	public void test13790() {
		o.launch(5, false, false, 5, false, true, 3, false, true);
	}
	@Test
	public void test13791() {
		o.launch(5, false, false, 5, false, true, 3, false, false);
	}
	@Test
	public void test13792() {
		o.launch(10, false, false, 100, false, true, 4, true, true);
	}
	@Test
	public void test13793() {
		o.launch(100, false, false, 10, false, true, 4, true, false);
	}
	@Test
	public void test13794() {
		o.launch(10, false, false, 10, false, true, 4, false, true);
	}
	@Test
	public void test13795() {
		o.launch(100, false, false, 10, false, true, 4, false, false);
	}
	@Test
	public void test13796() {
		o.launch(10, false, false, -1, false, true, 10, true, true);
	}
	@Test
	public void test13797() {
		o.launch(10, false, false, -1, false, true, 10, true, false);
	}
	@Test
	public void test13798() {
		o.launch(10, false, false, 100, false, true, 100, false, true);
	}
	@Test
	public void test13799() {
		o.launch(-1, false, false, 10, false, true, -1, false, false);
	}
	@Test
	public void test13800() {
		o.launch(10, false, false, -1, false, false, 0, true, true);
	}
	@Test
	public void test13801() {
		o.launch(10, false, false, -1, false, false, 0, true, false);
	}
	@Test
	public void test13802() {
		o.launch(-1, false, false, 10, false, false, 0, false, true);
	}
	@Test
	public void test13803() {
		o.launch(-1, false, false, 10, false, false, 0, false, false);
	}
	@Test
	public void test13804() {
		o.launch(-1, false, false, 10, false, false, 1, true, true);
	}
	@Test
	public void test13805() {
		o.launch(-1, false, false, 10, false, false, 1, true, false);
	}
	@Test
	public void test13806() {
		o.launch(-1, false, false, 10, false, false, 1, false, true);
	}
	@Test
	public void test13807() {
		o.launch(100, false, false, -1, false, false, 1, false, false);
	}
	@Test
	public void test13808() {
		o.launch(5, false, false, 5, false, false, 2, true, true);
	}
	@Test
	public void test13809() {
		o.launch(5, false, false, 5, false, false, 2, true, false);
	}
	@Test
	public void test13810() {
		o.launch(5, false, false, 5, false, false, 2, false, true);
	}
	@Test
	public void test13811() {
		o.launch(5, false, false, 5, false, false, 2, false, false);
	}
	@Test
	public void test13812() {
		o.launch(5, false, false, 5, false, false, 3, true, true);
	}
	@Test
	public void test13813() {
		o.launch(5, false, false, 5, false, false, 3, true, false);
	}
	@Test
	public void test13814() {
		o.launch(5, false, false, 5, false, false, 3, false, true);
	}
	@Test
	public void test13815() {
		o.launch(5, false, false, 5, false, false, 3, false, false);
	}
	@Test
	public void test13816() {
		o.launch(10, false, false, -1, false, false, 4, true, true);
	}
	@Test
	public void test13817() {
		o.launch(10, false, false, -1, false, false, 4, true, false);
	}
	@Test
	public void test13818() {
		o.launch(-1, false, false, -1, false, false, 4, false, true);
	}
	@Test
	public void test13819() {
		o.launch(-1, false, false, -1, false, false, 4, false, false);
	}
	@Test
	public void test13820() {
		o.launch(10, false, false, 100, false, false, -1, true, true);
	}
	@Test
	public void test13821() {
		o.launch(10, false, false, 100, false, false, -1, true, false);
	}
	@Test
	public void test13822() {
		o.launch(-1, false, false, 10, false, false, -1, false, true);
	}
	@Test
	public void test13823() {
		o.launch(-1, false, false, 10, false, false, -1, false, false);
	}

}